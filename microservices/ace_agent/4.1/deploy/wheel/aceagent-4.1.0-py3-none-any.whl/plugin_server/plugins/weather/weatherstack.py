"""
 copyright(c) 2023 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

import sys
import logging
import os
from fastapi import APIRouter
from typing import Optional

from plugin_server.main import FulfillmentRequest, FulfillmentResponse
from parameters import param

sys.path.append(os.path.dirname(__file__))
from weatherservice import WeatherService
from utils import process_request, create_response, get_feeling, is_xxxing

SUCCESS_CODE = "200"
ERROR_CODE = "406"

router = APIRouter()
logger = logging.getLogger("plugin")

api_key = param.get("weather").get("api-key", None) or os.getenv("WEATHERSTACK_API_KEY", "")
mock = param.get("weather").get("mock", False) or os.getenv("MOCK", "")

# Initialize weather stack
logger.info("Intialized weatherStack class..")

f_units = {"name": "fahrenheit", "shortcut": "F", "param": "f", "speed": "miles per hour"}
c_units = {"name": "celsius", "shortcut": "C", "param": "m", "speed": "kilometres per hour"}

_ws = WeatherService(api_key, mock=mock)
default_units = f_units


@router.post("/get_weather")
def get_weather(request_data: FulfillmentRequest) -> FulfillmentResponse:
    """Get weather information for location provided in fulfillment request
    param: request_data: DM fulfillment request"""

    # TODO: Use FulfillmentRequest object in process_request instead of dict
    # WAR to have request_data as dict, while regestring request_data is dict
    # whereas it's FulfillmentRequest when processing request.
    if not isinstance(request_data, dict):
        request_data = {k: v for k, v in request_data.__dict__.items()}
    resp = process_request(request_data)
    status = ERROR_CODE
    details = {}
    # Gather day and time information from user query and use it to call corrosponding API
    date, diff, query_date = _ws.time_to_days(request_data["Slots"])
    if diff > 0:
        status, response = weather_forecast(request_data, date, query_date)
        details = response["details"]
    elif diff < 0:
        status, response = weather_historical(request_data, date, query_date)
        details = response["details"]
    else:
        status, response = weather(request_data)
        details = response["details"]
    return create_response(request_data, resp, details, status)


@router.get("/get_weather_condition")
def get_weather_condition(location: str) -> Optional[str]:
    """Return weather condition for given location"""

    response = _ws.query_weather(location, default_units)
    if response["success"]:
        return response["condition"]
    return None


@router.get("/get_temperature")
def get_temperature(location: str) -> Optional[int]:
    """Return temperature for given location"""

    response = _ws.query_weather(location, default_units)
    if response["success"]:
        return response["temperature_int"]


@router.get("/is_sunny")
def is_sunny(location: str) -> Optional[bool]:
    """Check if weather is sunny at given location"""

    response = _ws.query_weather(location, default_units)

    if response["success"]:
        return is_xxxing("sunny", response["condition"])


@router.get("/is_cloudy")
def is_cloudy(location: str) -> Optional[bool]:
    """check if weather is cloudy at given location"""
    response = _ws.query_weather(location, default_units)

    if response["success"]:
        return is_xxxing("cloudy", response["condition"])


@router.get("/get_rain_precip")
def get_rain_precip(location: str) -> Optional[str]:
    """return rain precip for given location"""
    response = _ws.query_weather(location, default_units)
    if response["success"]:
        return str(round(response["precip"], 2))


@router.get("/is_raining")
def is_raining(location: str) -> Optional[bool]:
    """check if it is raining at given location"""
    response = _ws.query_weather(location, default_units)
    if response["success"]:
        if is_xxxing("rain", response["condition"]):
            return True if response["precip"] != 0 else False
        return False


@router.get("/is_snowing")
def is_snowing(location: str) -> Optional[bool]:
    """check if it is snowing at given location"""
    response = _ws.query_weather(location, default_units)

    if response["success"]:
        return is_xxxing("snow", response["condition"])


@router.get("/get_humidity")
def get_humidity(location: str) -> Optional[str]:
    """return humidity for given location"""
    response = _ws.query_weather(location, default_units)
    if response["success"]:
        return str(response["humidity"])


@router.get("/get_windspeed")
def get_windspeed(location: str) -> Optional[str]:
    """return wind speed for given location"""
    response = _ws.query_weather(location, default_units)
    if response["success"]:
        return str(response["wind"])


def weather(request_data):
    """get weather information for today's date"""
    response = _ws.query_weather(request_data["Slots"]["location"], default_units)

    if response["success"]:
        request_data["FulfillmentSlots"]["weather_condition"] = response["condition"]
        request_data["FulfillmentSlots"]["location_name"] = response["location"]
        request_data["FulfillmentSlots"]["temperature"] = response["temperature_int"]
        request_data["FulfillmentSlots"]["humidity"] = response["humidity"]
        request_data["FulfillmentSlots"]["wind_speed"] = response["wind"]
        request_data["FulfillmentSlots"]["is_snowing"] = is_xxxing("snow", response["condition"])
        request_data["FulfillmentSlots"]["is_cloudy"] = is_xxxing("cloudy", response["condition"])
        request_data["FulfillmentSlots"]["is_sunny"] = is_xxxing("sunny", response["condition"])
        request_data["FulfillmentSlots"]["temperature_feel"] = get_feeling(response["temperature_int"], default_units)

        request_data["FulfillmentSlots"].update(get_precip(response))

        return SUCCESS_CODE, response
    else:
        return ERROR_CODE, response


def weather_forecast(request_data, date, query_date):
    """get weather forecast information for given date"""
    response = _ws.query_weather_forecast(request_data["Slots"]["location"], date, default_units)

    if response["success"]:
        request_data["FulfillmentSlots"]["forecast_time"] = query_date

        request_data["FulfillmentSlots"]["is_snowing"] = xxxing(response, "snow")
        request_data["FulfillmentSlots"]["is_cloudy"] = xxxing(response, "cloudy")
        request_data["FulfillmentSlots"]["is_sunny"] = xxxing(response, "sunny")
        request_data["FulfillmentSlots"]["temperature_feel"] = feel_forecast(response)
        request_data["FulfillmentSlots"].update(precip_forecast(response))
        request_data["FulfillmentSlots"]["temperature_minimum"] = response["min_temperature_int"]
        request_data["FulfillmentSlots"]["temperature_maximum"] = response["max_temperature_int"]
        request_data["FulfillmentSlots"]["location_name"] = response["location"]
        request_data["FulfillmentSlots"]["weather_condition"] = response["condition"]
        request_data["FulfillmentSlots"]["wind_speed"] = response["wind"]
        request_data["FulfillmentSlots"]["humidity"] = response["humidity"]
        return SUCCESS_CODE, response
    else:
        return ERROR_CODE, response


def weather_historical(request_data, date, query_date):
    """get weather information historical date"""
    response = _ws.query_weather_historical(request_data["Slots"]["location"], date, default_units)

    if response["success"]:
        request_data["FulfillmentSlots"]["forecast_time"] = query_date
        request_data["FulfillmentSlots"]["is_snowing"] = xxxing(response, "snow")
        request_data["FulfillmentSlots"]["is_cloudy"] = xxxing(response, "cloudy")
        request_data["FulfillmentSlots"]["is_sunny"] = xxxing(response, "sunny")
        request_data["FulfillmentSlots"]["temperature_feel"] = feel_forecast(
            response,
        )
        request_data["FulfillmentSlots"].update(precip_forecast(response))
        request_data["FulfillmentSlots"]["temperature_minimum"] = response["min_temperature_int"]
        request_data["FulfillmentSlots"]["temperature_maximum"] = response["max_temperature_int"]
        request_data["FulfillmentSlots"]["location_name"] = response["location"]
        request_data["FulfillmentSlots"]["weather_condition"] = response["condition"]
        request_data["FulfillmentSlots"]["wind_speed"] = response["wind"]
        request_data["FulfillmentSlots"]["humidity"] = response["humidity"]
        request_data["FulfillmentSlots"]["historical_data"] = True
        return SUCCESS_CODE, response
    else:
        return ERROR_CODE, response


def xxxing(response, xxx):
    """Check given weather condition is in  forecast and historical data"""

    if response["success"]:
        return is_xxxing(xxx, response[f"condition"])
    return None


def get_precip(response):
    """get rain precip in inch"""
    resp = {"is_raining": False}
    if response["success"]:
        if is_xxxing("rain", response["condition"]):
            resp["rain_inch"] = round(response["precip"], 2) if response["precip"] != 0 else None
            resp["is_raining"] = True if resp["rain_inch"] is not None else False
    return resp


def precip_forecast(response):
    """get rain precip for historical and forecast in inch"""
    resp = {}
    if response["success"]:
        resp["is_raining"] = False

        if is_xxxing("rain", response[f"condition"]):
            resp["rain_inch"] = round(response["precip"], 2) if response["precip"] != 0 else None
            resp["is_raining"] = True if resp["rain_inch"] is not None else False
    return resp


def feel_forecast(response):
    """check temperature feel like hot, cold"""
    if response["success"]:
        predicted_temp = (response["max_temperature_int"] + response["min_temperature_int"]) / 2
        return get_feeling(predicted_temp, default_units)
    else:
        return None
