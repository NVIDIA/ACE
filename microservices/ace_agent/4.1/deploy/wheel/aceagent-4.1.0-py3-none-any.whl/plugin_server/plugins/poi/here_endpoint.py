"""
 copyright(c) 2023 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""
import logging
from typing import Optional, List
from fastapi import APIRouter
import os
import sys

from plugin_server.main import FulfillmentRequest, FulfillmentResponse
from parameters import param

sys.path.append(os.path.dirname(__file__))
from here import HereMAP

router = APIRouter()
logger = logging.getLogger("plugin")

api_key = param.get("map", {}).get("api-key", None) or os.getenv("HERE_API_KEY", "")
hmap = HereMAP({"api-key": api_key})


@router.post("/processQuery", response_model=FulfillmentResponse)
def process_query(request_data: FulfillmentRequest) -> FulfillmentResponse:
    """Call process query of here fulfillment and return a dict with complete location details"""

    if not isinstance(request_data, dict):
        request_data = {k: v for k, v in request_data.__dict__.items()}
    response = hmap.process_query(request_data)
    return response


@router.get("/get_distance")
def get_distance(source: str, destination: str, distance_unit: str = "miles") -> Optional[float]:
    """
    Get Distance between source and destination
    """
    try:
        logger.info(f"Getting distance between {source} and {destination}")
        response = hmap.get_route(hmap.get_coordinates(source), hmap.get_coordinates(destination), None).json()
        if len(response.get("response", []).get("route", [])) == 0:
            logger.error("No valid route found.")
            return None
        return hmap.convert_dist(response["response"]["route"][0]["summary"]["distance"], distance_unit)
    except Exception as e:
        logger.error(f"Error {e} while finding distance between {source} and {destination}")
    return None


@router.get("/get_travel_time")
def get_travel_time(source: str, destination: str, navigationmethod: str = "car") -> Optional[str]:
    """
    Get travel time between source and destination
    """

    try:
        logger.info(f"Getting travel time between {source} and {destination}")
        response = hmap.get_route(
            hmap.get_coordinates(source), hmap.get_coordinates(destination), {"navigationmethod": navigationmethod}
        ).json()
        if len(response.get("response", []).get("route", [])) == 0:
            logger.error("No valid route found.")
            return None
        return hmap.convert_time(response["response"]["route"][0]["summary"]["distance"])
    except Exception as e:
        logger.error(f"Error {e} while finding travel time between {source} and {destination}")
    return None


@router.get("/get_eta")
def get_eta(source: str, destination: str, navigationmethod: str = "car") -> Optional[str]:
    """
    Get Distance between source and destination
    """

    try:
        logger.info(f"Getting travel time between {source} and {destination}")
        response = hmap.get_route(
            hmap.get_coordinates(source), hmap.get_coordinates(destination), {"navigationmethod": navigationmethod}
        ).json()
        if len(response.get("response", []).get("route", [])) == 0:
            logger.error("No valid route found.")
            return None
        route_summary = response["response"]["route"][0]["summary"]
        link_details = response["response"]["route"][0]["leg"][0]["link"]
        timezone_1 = link_details[0]["timezone"]
        timezone_2 = link_details[-1]["timezone"]
        return hmap.calc_ETA(route_summary["travelTime"], timezone_1, timezone_2)
    except Exception as e:
        logger.error(f"Error {e} while finding travel time between {source} and {destination}")
    return None


@router.get("/toll_on_route")
def toll_on_route(source: str, destination: str, navigationmethod: str = "car") -> Optional[List[str]]:
    """
    Get Distance between source and destination
    """
    toll_booth = []
    try:
        logger.info(f"Getting speed limit on route from {source} to {destination}")
        response = hmap.get_route(
            hmap.get_coordinates(source), hmap.get_coordinates(destination), {"navigationmethod": navigationmethod}
        ).json()
        if len(response.get("response", []).get("route", [])) == 0:
            logger.error("No valid route found.")
            return None
        route_summary = response["response"]["route"][0]["summary"]
        link_details = response["response"]["route"][0]["leg"][0]["link"]
        i = 0
        for link in link_details:
            if "flags" in link and "tollroad" in link["flags"]:
                if link["roadName"] != "":
                    toll_booth.append(link["roadName"])
                    i = i + 1
                if i == hmap.NO_OF_RESULTS:
                    break
        return toll_booth
    except Exception as e:
        logger.error(f"Error {e} while finding travel time between {source} and {destination}")
    return None


@router.get("/get_speed_limit")
def get_speed_limit(
    source: str, destination: str, navigationmethod: str = "car", speed_unit="meters per second"
) -> Optional[float]:
    """
    Get Distance between source and destination
    """

    try:
        logger.info(f"Getting speed limit on route from {source} to {destination}")
        response = hmap.get_route(
            hmap.get_coordinates(source), hmap.get_coordinates(destination), {"navigationmethod": navigationmethod}
        ).json()
        if len(response.get("response", []).get("route", [])) == 0:
            logger.error("No valid route found.")
            return None
        route_summary = response["response"]["route"][0]["summary"]
        link_details = response["response"]["route"][0]["leg"][0]["link"]
        i = 0
        for link in link_details:
            if "speedLimit" in link:
                # units assumed to be meters per second. Need to verify with proper documentation.
                return hmap.convert_speed(link["speedLimit"], speed_unit)
    except Exception as e:
        logger.error(f"Error {e} while finding travel time between {source} and {destination}")
    return None


@router.get("/get_country")
def get_country(location: str) -> Optional[str]:
    """
    Get country name for given location
    """

    logger.info(f"Received location: {location}")
    try:
        source = hmap.get_coordinates(location)
        resp = hmap.get_details(source, {"location": location})
        return resp.json().get("items")[0].get("address").get("countryName")
    except Exception as e:
        logger.error(f"Error {e} while fetching information for location {location}")
    return None


@router.get("/get_state")
def get_state(location: str) -> Optional[str]:
    """
    Get state name for given location
    """

    logger.info(f"Received location: {location}")
    try:
        source = hmap.get_coordinates(location)
        resp = hmap.get_details(source, {"location": location})
        return resp.json().get("items")[0].get("address").get("state")
    except Exception as e:
        logger.error(f"Error {e} while fetching information for location {location}")
    return None


@router.get("/get_address")
def get_address(location: str) -> Optional[str]:
    """
    Get address for given location
    """

    logger.info(f"Received location: {location}")
    try:
        source = hmap.get_coordinates(location)
        resp = hmap.get_details(source, {"location": location})
        return resp.json().get("items")[0].get("address").get("label")
    except Exception as e:
        logger.error(f"Error {e} while fetching information for location {location}")
    return None
