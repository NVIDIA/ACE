# Copyright(c) 2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import logging
from datetime import datetime
from fastapi import APIRouter

router = APIRouter()

logger = logging.getLogger("plugin")

logger.info("Starting date module")


@router.get("/get_date")
def get_date():
    """
    Get current date from datetime module
    """
    logger.info("Retriving current date from get_date method")
    return datetime.today().strftime("%-d %B, %Y")


@router.get("/get_time")
def get_time():
    """
    Get current time from datetime module
    """
    logger.info("Retriving current time from get_time method")
    return datetime.today().strftime("%I:%M %p")
