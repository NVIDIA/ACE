"""
 copyright(c) 2022-23 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

"""WeatherService interact with weatherstack api and get weather information"""
import os
import sys
import json
import requests
import datetime
import logging

from urllib.parse import urljoin
from unittest.mock import patch

logger = logging.getLogger("plugin")


class WeatherService:
    """Module interact with weatherstack api and get relevant weather information"""

    HOURS_RANGE = 8

    def __init__(self, api_key="", mock=False):
        self._api_key = api_key
        if mock:
            sys.path.append(os.path.dirname(__file__))
            from mock_weather_api import get_free_port, start_mock_server

            port = get_free_port()
            start_mock_server(port)
            self.mock_users_url = f"http://localhost:{port}/"
        else:
            self.mock_users_url = "http://api.weatherstack.com/"
        self.session = requests.Session()
        self.timeout = 20
        self.warmup_module()
        logger.info("Intialized weatherService class..")

    def warmup_module(self):
        f_units = {"name": "fahrenheit", "shortcut": "F", "param": "f", "speed": "miles per hour"}
        date = datetime.datetime.now() + datetime.timedelta(days=1)
        self.query_weather_forecast("santa clara,us", date, f_units)
        self.query_weather("santa clara, us", f_units)
        print("WeatherService module warmup done..")

    def time_to_days(self, slots):
        """Extract date information from system slot and return date information"""

        date_type = 0  # 0: current date, 1: future date, -1: historical date
        # Use system.date_time if present else give current date
        current_date = datetime.datetime.now()
        if "system.date_time" in slots:
            vals = [
                slots["system.date_time"][0].get("system." + key)[0]
                for key in ["year", "month", "date", "hour", "minute", "second"]
            ]
            system_date = datetime.datetime(*vals)
            if system_date > current_date:
                date_type = 1
            elif system_date < current_date:
                date_type = -1
            else:
                date_type = 0
            return system_date.strftime("%Y-%m-%d"), date_type, slots["system.date_time"][0].get("original_text")[0]

        return current_date, 0, None

    # Weather forecast for a current day and time
    def query_weather(self, location, units=""):
        """get today's weather information from weatherstack api"""

        full_location = location

        params = {"access_key": self._api_key, "query": full_location, "units": units["param"]}

        self.USER_URL = "http://api.weatherstack.com/current"
        logger.info("WeatherStack current API Request:: {}".format(json.dumps(params, indent=4)))
        try:
            response = {}
            response["details"] = {"code": None, "info": "Current weather conditions found successfully."}
            url = urljoin(self.mock_users_url, "current")
            with patch.dict(self.__dict__, {"USER_URL": url}):
                api_result = self.session.request("GET", self.USER_URL, params=params, timeout=self.timeout)
            api_response = api_result.json()

            if "success" in api_response and api_response["success"] == False:
                response["success"] = False
                logger.error(f"Weatherstack API {self.USER_URL} returned error: {api_response['error']}")
                response["details"] = api_response["error"]
                return response

            if full_location[0].isdigit() and api_response["location"]["name"] != full_location:
                response["success"] = False
                response["details"]["info"] = "Invalid city name found in query."
                response["details"]["code"] = 615
                return response

            response["success"] = True
            response["unit"] = units["param"]
            response["country"] = api_response["location"]["country"]
            response["city"] = api_response["location"]["name"]
            response["region"] = api_response["location"]["region"]
            response["condition"] = api_response["current"]["weather_descriptions"][0].lower()
            response["icon"] = api_response["current"]["weather_icons"][0]
            response["temperature_int"] = api_response["current"]["temperature"]
            response["humidity"] = api_response["current"]["humidity"]
            response["wind"] = api_response["current"]["wind_speed"]
            response["precip"] = api_response["current"]["precip"]

            # return full address including country or state
            if "," in location:
                if "United States of America" not in response["country"]:
                    response["location"] = response["city"] + ", " + response["country"]
                else:
                    response["location"] = response["city"] + ", " + api_response["location"]["region"]
            else:
                response["location"] = response["city"]
            response["date"] = api_response["location"]["localtime"].split()[0]
            response["time"] = api_response["location"]["localtime"].split()[1]
            logger.info("WeatherStack current API Response:: {}".format(json.dumps(response, indent=4)))
            return response
        except Exception as e:
            logger.error(e)
            response["success"] = False
            response["details"]["info"] = str(e)
            return response

    def query_weather_forecast(self, location, date, units):
        """Extract weather forecast information from weatherstack api"""
        full_location = location

        params = {
            "access_key": self._api_key,
            "query": full_location,
            "units": units["param"],
            #'forecast_days': day  # By default gives 7 days ahead forecast
            "hourly": 1,
        }
        logger.info("WeatherStack forecast API Request:: {}".format(json.dumps(params, indent=4)))
        try:
            response = {}
            response["historical"] = False
            response["details"] = {"code": None, "info": "Weather forecast information found successfully."}
            self.USER_URL = "http://api.weatherstack.com/forecast"
            url = urljoin(self.mock_users_url, "forecast")
            with patch.dict(self.__dict__, {"USER_URL": url}):
                api_result = self.session.request("GET", self.USER_URL, params=params, timeout=self.timeout)
            api_response = api_result.json()

            if "success" in api_response and api_response["success"] == False:
                response["success"] = False
                logger.error(f"Weatherstack API {self.USER_URL} returned error: {api_response['error']}")
                response["details"] = api_response["error"]
                return response

            if full_location[0].isdigit() and api_response["location"]["name"] != full_location:
                response["success"] = False
                response["details"]["info"] = "Invalid city name found in query."
                response["details"]["code"] = 615
                return response

            logger.info(f"Extracting weather info for date: {date}..")

            response["success"] = True
            response["unit"] = units["param"]
            response["country"] = api_response["location"]["country"]
            response["city"] = api_response["location"]["name"]
            response["region"] = api_response["location"]["region"]

            current_hour = int(api_response["location"]["localtime"].split()[-1].split(":")[0])

            if date not in api_response["forecast"]:
                response["details"]["info"] = f"WeatherStack did not return any forecast information for {date}."
                response["success"] = False
                return response

            # full day forecast
            response["min_temperature_int"] = api_response["forecast"][date]["mintemp"]
            response["max_temperature_int"] = api_response["forecast"][date]["maxtemp"]

            # fill hourly forecast
            humidity = 0
            precip = 0
            windspeed = 0
            for i in range(self.HOURS_RANGE):
                response[f"condition_{i}"] = api_response["forecast"][date]["hourly"][i]["weather_descriptions"][0]
                response[f"icon_{i}"] = api_response["forecast"][date]["hourly"][i]["weather_icons"][0]
                humidity += api_response["forecast"][date]["hourly"][i]["humidity"]
                precip += api_response["forecast"][date]["hourly"][i]["precip"]
                windspeed += api_response["forecast"][date]["hourly"][i]["wind_speed"]

            # take daily average
            response["condition"] = response[f"condition_{2}"].lower()
            response["icon"] = response[f"icon_{2}"]
            response["humidity"] = int(humidity / self.HOURS_RANGE)
            response["precip"] = precip / self.HOURS_RANGE
            response["wind"] = int(windspeed / self.HOURS_RANGE)

            # return full address including country or state
            if "," in location:
                if "United States of America" not in response["country"]:
                    response["location"] = response["city"] + ", " + response["country"]
                else:
                    response["location"] = response["city"] + ", " + api_response["location"]["region"]
            else:
                response["location"] = response["city"]
            response["date"] = date
            logger.info("WeatherStack forecast API Response:: {}".format(json.dumps(response, indent=4)))
            return response
        except Exception as e:
            logger.error(e)
            response["success"] = False
            response["details"]["info"] = str(e)
            return response

    def query_weather_historical(self, location, date, units):
        """Extract weather historical information from weatherstack api"""
        full_location = location

        logger.info(f"Extracting weather info for historical date: {date}.")

        params = {
            "access_key": self._api_key,
            "query": full_location,
            "units": units["param"],
            "hourly": 1,
            "historical_date": date,
        }
        try:
            response = {}
            response["details"] = {"code": None, "info": "Historical information found successfully."}
            self.USER_URL = "https://api.weatherstack.com/historical"
            url = urljoin(self.mock_users_url, "historical")
            with patch.dict(self.__dict__, {"USER_URL": url}):
                api_result = self.session.request("GET", self.USER_URL, params=params, timeout=self.timeout)
            api_response = api_result.json()

            if "success" in api_response and api_response["success"] == False:
                response["success"] = False
                logger.error(f"Weatherstack API {self.USER_URL} returned error: {api_response['error']}")
                response["details"] = api_response["error"]
                return response

            if full_location[0].isdigit() and api_response["location"]["name"] != full_location:
                response["success"] = False
                response["details"]["info"] = "Unsupported time or invalid city name found in query."
                response["details"]["code"] = 615
                return response

            response["success"] = True
            response["unit"] = units["param"]
            response["country"] = api_response["location"]["country"]
            response["city"] = api_response["location"]["name"]
            response["region"] = api_response["location"]["region"]

            if date not in api_response["historical"]:
                response["details"]["info"] = f"WeatherStack did not return any historical information for {date}."
                response["success"] = False
                return response

            # full day historical data
            response["min_temperature_int"] = api_response["historical"][date]["mintemp"]
            response["max_temperature_int"] = api_response["historical"][date]["maxtemp"]

            # fill hourly historical data
            humidity = 0
            precip = 0
            windspeed = 0
            for i in range(self.HOURS_RANGE):
                response[f"condition_{i}"] = api_response["historical"][date]["hourly"][i]["weather_descriptions"][0]
                response[f"icon_{i}"] = api_response["historical"][date]["hourly"][i]["weather_icons"][0]
                humidity += api_response["historical"][date]["hourly"][i]["humidity"]
                precip += api_response["historical"][date]["hourly"][i]["precip"]
                windspeed += api_response["historical"][date]["hourly"][i]["wind_speed"]

            # take daily average
            response["condition"] = response[f"condition_{2}"].lower()
            response["icon"] = response[f"icon_{2}"].lower()
            response["humidity"] = int(humidity / self.HOURS_RANGE)
            response["precip"] = precip / self.HOURS_RANGE
            response["wind"] = int(windspeed / self.HOURS_RANGE)

            # return full address including country or state
            if "," in location:
                if "United States of America" not in response["country"]:
                    response["location"] = response["city"] + ", " + response["country"]
                else:
                    response["location"] = response["city"] + ", " + api_response["location"]["region"]
            else:
                response["location"] = response["city"]
            response["date"] = date
            logger.info("WeatherStack historical API Response:: {}".format(json.dumps(response, indent=4)))
            return response

        except Exception as e:
            logger.error(e)
            response["success"] = False
            response["details"]["info"] = str(e)
            return response
