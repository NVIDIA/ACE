"""
 copyright(c) 2023 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import requests
from datetime import datetime, timedelta
import logging

logger = logging.getLogger("plugin")


class HereMAP:

    SUCCESS_CODE = "200"
    ERROR_CODE = "406"
    NO_OF_RESULTS = 1

    GEO_COORDINATES_URL = "https://geocoder.ls.hereapi.com/6.2/geocode.json"
    MAP_ROUTE_URL = "https://route.ls.hereapi.com/routing/7.2/calculateroute.json"
    DISCOVER_API = "https://discover.search.hereapi.com/v1/discover"
    MAP_IMAGE_URL = "https://image.maps.ls.hereapi.com/mia/1.6/mapview"
    MAP_ROUTE_IMAGE_URL = "https://image.maps.ls.hereapi.com/mia/1.6/routing"

    def __init__(self, headers=None):
        self._api_key = headers.get("api-key", "")
        self._session = requests.Session()
        self.timeout = 20
        self.warmup_module()
        logger.info("Intialized hereMap class..")

    def warmup_module(self):
        source = self.get_coordinates("santa clara, usa")
        destination = self.get_coordinates("new york, usa")
        self.get_route(source, destination)

        print("hereMap module warmup done..")

    def is_ready(self):
        return True

    def process_query(self, request):
        resp = {
            "Response": {"Text": None, "Action": None, "Json": None, "Ready": False, "NeedUserResponse": False},
            "Status": self.ERROR_CODE,
            "CustomData": {},
            "Slots": {},
            "InvalidSlots": [],
            "FulfillmentSlots": {},
            "StatusDetails": "",
        }

        logger.info("\n\nMap domain input JSON :: {}".format(request))
        try:
            if self._api_key == "":
                resp["Response"]["Text"] = (
                    f"Failed to get map information from here.com "
                    f"as the API key has not been populated in the bot-config."
                )
                resp["Response"]["Ready"] = True
                resp["StatusDetails"] = "HERE returned error due to missing API key"
                resp["Status"] = self.SUCCESS_CODE
                return resp

            if request["Domain"] != "poi":
                logger.error("Expected domain is Maps. Domain is set to {}.".format(request["Domain"]))
                resp["StatusDetails"] = f"Invalid domain: {request['Domain']} set."
                return resp

            if "location" not in request["Slots"]:
                logger.error("Mandatory slot location missing.")
                resp["StatusDetails"] = "Mandatory slot location missing."
                return resp

            # Use the first value of all slots tagged in user query
            for slot in request["Slots"]:
                request["Slots"][slot] = request["Slots"][slot][0]

            if request["Intent"] == "navigation.stopnavigation":
                logger.info("intent {} does not require fulfillment".format(request["Intent"]))
                resp["StatusDetails"] = "Navigation is not supported yet"
                resp["Status"] = self.SUCCESS_CODE
                return resp

            place_name = request["Slots"]["location"].title()
            result, image, status_code = self.query_api(request["Slots"], request["Intent"])

            if request["Intent"] in [
                "navigation.showdirection",
                "navigation.navigationavoidhighways",
                "navigation.showdirectionavoidhighways",
                "navigation.showmap",
            ]:
                # resp["StatusDetails"] = resp["StatusDetails"] + "Displaying Map is not supported yet."
                resp["StatusDetails"] = resp["StatusDetails"]

            resp["FulfillmentSlots"] = result
            resp["FulfillmentSlots"]["place_name"] = place_name

            # Overwrite location slot's value in Chat Engine short term memory
            # Example: where is golden gate bridge? -> san francisco

            if (
                resp["FulfillmentSlots"].get("city", "") != None
                and resp["FulfillmentSlots"].get("city", "").lower() != place_name.lower()
                and request["Intent"] == "navigation.showmap"
            ):
                resp["Slots"]["location"] = resp["FulfillmentSlots"]["city"]

            resp["Status"] = status_code
            return resp

        except Exception as e:
            logger.error(f"Exception: {e} in process query of HERE module.")
            resp["Status"] = self.ERROR_CODE
            return resp

    def convert_dist(self, distance, unit):
        if unit in ["kilometers", "km", "kilometer"]:
            return round(int(distance / 100) / 10.0, 1)
        elif unit == "meters":
            return distance
        else:
            return round(int(distance / 100) / (10.0 * 1.61), 1)

    def convert_speed(self, speed, unit):
        if unit == "meters per second":
            return int(speed * 100 / 100.0)
        elif unit == "kilometers per hour":
            return int(speed * 3.6 * 100 / 100.0)
        else:
            return int(speed * 2.24 * 100 / 100.0)

    def convert_time(self, traveltime):
        hours = int(traveltime / 60 / 60)
        mins = int((traveltime - hours * 60 * 60) / 60)
        conv_time = str(mins) + " minutes"
        if hours > 0:
            conv_time = str(hours) + " hours and " + conv_time
        return conv_time

    def calc_ETA(self, traveltime, timezone_1, timezone_2):
        sign_1 = timezone_1[0]
        sign_2 = timezone_2[0]
        hours_1 = float(timezone_1[1:3]) + float(timezone_1[3:]) / 60.0
        hours_2 = float(timezone_2[1:3]) + float(timezone_2[3:]) / 60.0
        if sign_1 == "-":
            hours_1 = -hours_1
        if sign_2 == "-":
            hours_2 = -hours_2
        hour_diff = hours_2 - hours_1
        hour_delta = traveltime / 60.0 / 60.0 + hour_diff
        format = "%I:%M %p"
        curr_time = datetime.utcnow() + timedelta(hours=hours_1)
        ETA = str((curr_time + timedelta(hours=hour_delta)).strftime(format))
        return ETA

    def get_coordinates(self, address):
        PARAMS = {"apiKey": "%s" % self._api_key, "searchtext": address}
        response = self._session.request("GET", self.GEO_COORDINATES_URL, params=PARAMS, timeout=self.timeout)
        if not response.ok:
            return None
        output = response.json()
        if len(output["Response"]["View"]) == 0:
            return None
        lat = output["Response"]["View"][0]["Result"][0]["Location"]["NavigationPosition"][0]["Latitude"]
        lon = output["Response"]["View"][0]["Result"][0]["Location"]["NavigationPosition"][0]["Longitude"]
        coordinates = str(lat) + "," + str(lon)
        return coordinates

    def get_route(self, source, dest, params=None):
        if source == None:
            logger.error("Invalid Source Address")
            return None
        if dest == None:
            logger.error("Invalid Destination Address")
            return None
        PARAMS_ROUTE = {
            "apiKey": "%s" % self._api_key,
            "waypoint0": source,
            "waypoint1": dest,
            "mode": "fastest;",
            "routeattributes": "none,lg,sm",
            "linkattributes": "none,sl,fl,ro,ma,tz",
            "instructionformat": "text",
            "legattributes": "li",
        }
        if params != None and params["navigationmethod"] == "truck":
            PARAMS_ROUTE["mode"] = PARAMS_ROUTE["mode"] + "truck"
        elif params != None and params["navigationmethod"] == "walk":
            PARAMS_ROUTE["mode"] = PARAMS_ROUTE["mode"] + "pedestrian"
        else:
            PARAMS_ROUTE["mode"] = PARAMS_ROUTE["mode"] + "car"
        response = self._session.request("GET", self.MAP_ROUTE_URL, params=PARAMS_ROUTE, timeout=self.timeout)
        return response

    def parseOutput(self, params, output=None):
        response = {
            "loc_distance": None,
            "travelTime": None,
            "distance_unit": None,
            "toll_booth_present": None,
            "toll_booth_area_0": None,
            "speed_limit_0": None,
            "speed_limit_area_0": None,
            "ETA": None,
            "coordinates": None,
            "state": None,
            "city": None,
            "country": None,
            "place_type": "place",
            "place_name": None,
            "status_details": "Successfully found the map details from HERE route API.",
        }

        if output is None:
            logger.error("API returned empty json")
            response["status_details"] = "Here API did not return any response."
            return response, self.ERROR_CODE

        if "items" in output and len(output["items"]) != 0:  # Result returned from here discover API
            place_details = output["items"][0]

            address = place_details.get("address")
            response["street"] = address.get("street", None)
            response["city"] = address.get("city", None)
            response["state"] = address.get("state", None)
            response["country"] = address.get("countryName", None)
            response["loc_distance"] = self.convert_dist(place_details.get("distance"), params["distanceunit"])

            place_type = "place"
            if len(place_details.get("categories", [])) != 0:
                place_type = place_details["categories"][0]["name"]
            else:
                if "resultType" in place_details:
                    if place_details["resultType"] == "administrativeArea":
                        place_type = place_details.get("administrativeAreaType", "area")
                    elif place_details["resultType"] == "locality":
                        place_type = place_details.get("localityAreaType", "city")
                    elif place_details["resultType"] not in ["addressBlock", "houseNumber", "postalCodePoint"]:
                        place_type = place_details["resultType"]

            response["place_type"] = place_type[0].lower() + place_type[1:]
            response["status_details"] = "Valid location result found from HERE discover API."
            return response, self.SUCCESS_CODE

        if "response" not in output or "route" not in output["response"] or len(output["response"]["route"]) == 0:
            logger.error("No valid route found.")
            response["status_details"] = "No valid route found from HERE route API."
            return response, self.ERROR_CODE

        route_summary = output["response"]["route"][0]["summary"]
        response["loc_distance"] = self.convert_dist(route_summary["distance"], params["distanceunit"])
        response["travelTime"] = self.convert_time(route_summary["travelTime"])
        link_details = output["response"]["route"][0]["leg"][0]["link"]
        timezone_1 = link_details[0]["timezone"]
        timezone_2 = link_details[-1]["timezone"]
        response["ETA"] = self.calc_ETA(route_summary["travelTime"], timezone_1, timezone_2)
        i = 0
        for link in link_details:
            if "flags" in link and "tollroad" in link["flags"]:
                response["toll_booth_present"] = "Yes, toll booth is present"
                if link["roadName"] != "":
                    response["toll_booth_area_" + str(i)] = link["roadName"]
                    i = i + 1
                if i == self.NO_OF_RESULTS:
                    break
        if response["toll_booth_present"] == None:
            response["toll_booth_present"] = "No toll booth is on the way"
        i = 0
        for link in link_details:
            if "speedLimit" in link:
                # units assumed to be meters per second. Need to verify with proper documentation.
                response["speed_limit_" + str(i)] = self.convert_speed(link["speedLimit"], params["speedUnit"])
                response["speed_limit_area_" + str(i)] = link["roadName"]
                i = i + 1
                if i == self.NO_OF_RESULTS:
                    break
        return response, self.SUCCESS_CODE

    def get_details(self, source, params):
        if source == None:
            logger.error("Invalid Source Address")
            return None

        PARAMS = {"apiKey": "%s" % self._api_key, "limit": "1", "at": source, "q": params["location"]}
        response = self._session.request("GET", self.DISCOVER_API, params=PARAMS, timeout=self.timeout)

        return response if response.ok else None

    def request(self, params, intent):
        if "location" in params:
            location = params["location"]

        if "sourceplace" in params:
            location = params["sourceplace"]

        if intent == "navigation.showmap":
            source = self.get_coordinates(params["location"])
            response = self.get_details(source, params)
            logger.debug(f"Response from HERE discover API: {json.dumps(response.json(), indent=4)}")

        else:
            source = self.get_coordinates(params["sourceplace"])
            dest = self.get_coordinates(params["location"])
            response = self.get_route(source, dest, params)

        if response == None:
            return None, None
        return response.json(), None

    def query_api(self, params, intent):
        logger.debug("params {}".format(params))
        output, image = self.request(params, intent)
        response, status_code = self.parseOutput(params, output)
        return response, image, status_code
