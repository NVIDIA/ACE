# copyright(c) 2024 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

from dataclasses import dataclass
from typing import Any, Optional, Dict

from plugin_server.stores.constants import STORE_LOCAL_FILE, LOCAL_STORE_PATH


@dataclass
class UserData:
    """
    Stores the user fulfillment data.
    """

    user_id: str
    session_id: str
    memory: Dict[Any, Any]


@dataclass
class StorageConfig:
    """Stores and formulates the dm userdata storage information in a bot"""

    name: str = STORE_LOCAL_FILE
    path: Optional[str] = LOCAL_STORE_PATH
