# Copyright(c) 2024 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import os
import sys
from multiprocessing import shared_memory
from plugin_server.logging_manager import LoggingManager
from plugin_server.schemas.validator import SchemaValidator
from plugin_server.stores.constants import LOCAL_STORE_PATH


def on_starting(server):
    """gunicorn hook: Executes when master starts"""
    LoggingManager(log_dir=os.getenv("PLUGIN_LOG_ROOT", "/workspace/log"))
    config_path = os.getenv("CONFIG_PATH", default=None)
    if config_path is None:
        raise Exception("Plugin Server config file not provided")

    try:
        # Validate config file schema
        SchemaValidator.validate_file(config_path, SchemaValidator.PLUGIN_SERVER_CONFIG_SCHEMA)
    except Exception as e:
        sys.exit(1)

    # Shared List to store [DataClean, DataStorePath]
    # True: Clean store data
    try:
        store_info = shared_memory.ShareableList([True, LOCAL_STORE_PATH], name="fm")
    except FileExistsError as e:
        # Re-use shared memory if it already exist
        store_info = shared_memory.ShareableList(name="fm")
        store_info[0] = True
    store_info.shm.close()


def on_exit(server):
    """gunicorn hook: Executes when gunicorn exits"""

    try:
        store_info = shared_memory.ShareableList(name="fm")
        dirpath = store_info[1]
        store_info.shm.close()
        store_info.shm.unlink()  # Remove shared storage
        __clean_store(dirpath)
    except Exception as e:
        print(f"Exception from on_exit handler of gunicorn: {e}")


def post_worker_init(worker):
    """gunicorn hook: Executes after worker starts successfully"""

    try:
        store_info = shared_memory.ShareableList(name="fm")
        if store_info[0] == True:
            store_info[0] = False
            __clean_store(store_info[1])
        store_info.shm.close()
    except Exception as e:
        print(f"Exception from post_worker_init handler of gunicorn: {e}")


def __clean_store(dirpath):
    """Clear userdata from store path"""

    # If directory does not exist skip
    # when store type redis/mongo is used
    # directory is not created
    if not os.path.isdir(dirpath):
        return

    for filename in os.listdir(dirpath):
        if filename.endswith(".pkl"):
            path = os.path.join(dirpath, filename)
            if os.path.exists(path):
                try:
                    os.remove(path)
                except:
                    print(f"Error while deleting {path}")
