# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

"""
Parse Custom Arguments provided using YAML file.
"""

import os
import yaml
import argparse
from pathlib import Path


class ConfigParser:
    @staticmethod
    def get_requirements(config_yaml):
        """
        Get requirements list for all fulfillment provided in config
        """
        with open(config_yaml) as f:
            custom_data = yaml.safe_load(f).get("plugins", [])

        requirements = []
        for fulfillment in custom_data:
            path = fulfillment.get("path", None)
            if path is None:
                # Default fulfillment will not have any path skip them
                continue
            req = os.path.join(
                os.path.dirname(os.path.abspath(config_yaml)), os.path.dirname(path), "requirements.txt"
            )
            if Path(req).is_file():
                with open(req, "r") as f:
                    requirements.extend(f.readlines())
        return requirements

    @staticmethod
    def get_server_config(config_yaml):
        """
        Get gunicorn config parameters
        """
        with open(config_yaml) as f:
            custom_data = yaml.safe_load(f).get("config", {})

        return f" --workers {custom_data.get('workers', 1)} -t {custom_data.get('timeout', 30)}"


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description="Script to utilize plugin_config.yaml",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        allow_abbrev=False,
    )

    parser.add_argument(
        "--mode", required=True, help="Mode for the script", choices=["get_requirements", "get_server_config"]
    )
    parser.add_argument("--config_yaml", help="path of docker args config yaml", default="./plugin_config.yaml")
    args = parser.parse_args()

    return args


if __name__ == "__main__":

    args = parse_args()

    if args.mode == "get_requirements":
        print(" ".join(ConfigParser.get_requirements(config_yaml=args.config_yaml)))
    elif args.mode == "get_server_config":
        print(ConfigParser.get_server_config(config_yaml=args.config_yaml))
    else:
        raise ValueError(f"Mode {args.mode} not supported")
