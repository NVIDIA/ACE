# Copyright(c) 2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

""" Typer app exposing arguments to run the plugin server package """

import os
import pip
import typer
from rich import print
from subprocess import run
from typing import Optional, List

from plugin_server.parse_config import ConfigParser
from plugin_server import gunicorn_config

plugin_server = typer.Typer(
    no_args_is_help=True, help="Deploy or stop the RESTful Plugin server endpoints.", add_completion=False
)

# Default value of arguments accepted
PORT = 9002
CONFIG_PATH = "plugins/plugin_config.yaml"
GUNICORN_CONFIG = gunicorn_config.__file__
LOG_PATH = "./log"


@plugin_server.command(
    help="Bring up the REST API's for Plugin server. Interact with any custom plugin using these API's."
)
def deploy(
    config: Optional[str] = typer.Option(
        ...,
        "-c",
        "--config",
        exists=True,
        help="Relative path to the present working directory containing the plugin config yaml file.",
    ),
    port: Optional[int] = typer.Option(PORT, "-p", "--port", help="Port where the plugin server will start."),
    log_level: Optional[str] = typer.Option(
        default="info", help="Control the verbosity level of the plugin server logs."
    ),
    reload: Optional[bool] = typer.Option(
        False, "-r", "--reload", help="Choose whether to auto reload the server on some code changes.", hidden=True
    ),
    log_path: Optional[str] = typer.Option(
        default=LOG_PATH, help="Directory path where the plugin server logs will be stored."
    ),
):
    print(f"Starting the Plugin server with config {config}.")
    os.environ["PLUGIN_LOG_LEVEL"] = log_level
    os.environ["PLUGIN_LOG_ROOT"] = log_path
    os.environ["CONFIG_PATH"] = config

    try:
        install_from_requirements_list(ConfigParser.get_requirements(config_yaml=config))
        fm_args = ConfigParser.get_server_config(config_yaml=config)
        if reload:
            fm_args = fm_args + f" --reload"

        server_cmd = f"gunicorn 'plugin_server.main:create_app' --worker-class uvicorn.workers.UvicornWorker --bind 0.0.0.0:{port} {fm_args} --config {GUNICORN_CONFIG}"

        print(f"Starting gunicorn server with command: {server_cmd}")
        run(server_cmd, shell=True, check=True)
    except Exception as e:
        typer.echo(f"{e}")


@plugin_server.command(help="Stop any locally running Plugin Server.")
def stop():
    print(f"Stopping any running Plugin server.")
    server_cmd = f"pkill -f 'plugin_server.main:create_app'"

    print(f"Stopping gunicorn plugin server with command: {server_cmd}")
    run(server_cmd, shell=True)
    print(f"All Plugin servers stopped successfully.")


def install_from_requirements_list(requirements: List[str]):
    if not len(requirements):
        return
    print(f"Installing custom requirements: {requirements}")
    pip.main(["install"] + requirements)
