# Copyright(c) 2021-2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
chat engine core utilities
"""


import logging
import os
from abc import ABC, abstractmethod
from typing import Dict, List, Optional
from datetime import datetime, timedelta

import redis.asyncio as redis


class EventProvider(ABC):
    """Abstract interface for all event providers. Defines interface to receive and send events."""

    @abstractmethod
    async def receive_events(self, timeout: Optional[timedelta] = timedelta(seconds=0.5)) -> List[str]:
        """Receive incoming events. Returns when it received one or more events"""
        raise NotImplementedError

    @abstractmethod
    async def get_latest_event(self, channel_id: str) -> Optional[str]:
        """Return the most recent event in the channel."""
        raise NotImplementedError

    @abstractmethod
    async def send_event(self, channel_id: str, event_data: str) -> None:
        """Publishes the event"""
        raise NotImplementedError

    @abstractmethod
    async def trim_channel(self, channel_id: str, max_count: int) -> None:
        """Trim the number of events in the channel to <= max_count"""
        raise NotImplementedError

    @abstractmethod
    async def update_channel_state(self, channel_id: str) -> None:
        """
        Update the channel state to the most recent message. Future `receive_events` will only return events
        That appeared after that event.
        """
        raise NotImplementedError


class RedisEventProvider(EventProvider):
    """Event Provider for Redis. Provides interface to receive and send events"""

    def __init__(self, redis_host: str, redis_port: int, channels: List[str], discard_existing_events: bool = True):
        super().__init__()
        self.redis: redis.Redis = redis.Redis(host=redis_host, port=redis_port)
        self._channel_state: Dict[str, str] = dict(
            map(lambda c: (c, "$" if discard_existing_events else "0"), channels)
        )

    async def receive_events(self, timeout: Optional[timedelta] = timedelta(seconds=0.5)) -> List[str]:
        """Receive incoming events. Returns when it received one or more events"""
        timeout_ms: Optional[int] = None if timeout is None else int(timeout.total_seconds() * 1000)

        result = await self.redis.xread(streams=self._channel_state, block=timeout_ms)
        event_list: List[str] = []

        for channel in result:
            channel_id = str(channel[0].decode())
            for event_id, value in channel[1]:
                for key in value.keys():
                    event_data = value[key].decode()
                    event_list.append(event_data)

                self._channel_state[channel_id] = event_id.decode()

        return event_list

    async def update_channel_state(self, channel_id: str) -> None:
        """
        Update the channel state to the most recent message. Future `receive_events` will only return events
        That appeared after that event.
        """
        result = await self.redis.xrevrange(channel_id, count=1)

        if result:
            event_id, _ = result[0]
            self._channel_state[channel_id] = event_id.decode()

    async def get_latest_event(self, channel_id: str) -> Optional[str]:
        """Return the most recent events in the channel."""
        result = await self.redis.xrevrange(channel_id, count=1)

        if not result:
            return None

        _, value = result[0]
        for key in value.keys():
            event_data = value[key].decode()
        return event_data

    async def send_event(self, channel_id: str, event_data: str) -> None:
        """Publishes the event"""
        await self.redis.xadd(channel_id, {"event": event_data.encode()})

    async def trim_channel(self, channel_id: str, max_count: int) -> None:
        """Trim the number of events in the channel to <= max_count"""
        await self.redis.xtrim(channel_id, maxlen=max_count)


def event_provider_factory(
    provider_name: str,
    host: str,
    port: int,
    channels=List[str],
    discard_existing_events: bool = True,
) -> EventProvider:
    """
    Create a new event provider based on the `provider_name`. Currently only Redis is supported.
    But this factory can be easily expanded to other providers.
    """
    providers = ["redis"]
    if provider_name == "redis":
        return RedisEventProvider(host, port, channels, discard_existing_events)
    else:
        raise Exception(f"Event provider {provider_name} does not exist. Available providers { ','.join(providers)}")


def read_isoformat(timestamp: str) -> datetime:
    """
    ISO 8601 has multiple legal ways to indicate UTC timezone. 'Z' or '+00:00'. However the Python
    datetime.fromisoformat only accepts the latter.
    This function provides a more flexible wrapper to accept all valid IOS 8601 formats
    """
    normalized = timestamp.replace("Z", "+00:00")
    return datetime.fromisoformat(normalized)
