"""
 copyright(c) 2021 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""
"""  These constants are used in datetime_parser.py. """

DAYS_OF_WEEK = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]

MONTHS = [
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december",
]

PARTS_OF_DAY = {
    "morning": "9:00 am",
    "noon": "12:00 pm",
    "afternoon": "3:00 pm",
    "evening": "6:00 pm",
    "night": "9:00 pm",
    "midnight": "12:00 am",
}

HOLIDAY_OF_YEAR = {
    "christmas": "25 December",
    "new year": "1 January",
    "independence day": "4 July",
}

DATE_WORDS = ["year", "month", "week", "day", "weekend"]

TIME_WORDS = ["second", "minute", "hour"]

# The day of the week used to calculate last/next weekend.
# Currently points to Sunday. Date ranges from 0 (Monday) to 6 (Sunday)
WEEKEND_DAY_NUMBER = 6
