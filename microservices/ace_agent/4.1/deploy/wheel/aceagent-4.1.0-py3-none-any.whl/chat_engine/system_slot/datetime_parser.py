"""
 copyright(c) 2021 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

import re
import copy
import logging
import datetime
import number_parser
from dateparser import DateDataParser
from dateutil.relativedelta import relativedelta
from chat_engine.system_slot.constants import (
    DAYS_OF_WEEK,
    MONTHS,
    PARTS_OF_DAY,
    HOLIDAY_OF_YEAR,
    TIME_WORDS,
    DATE_WORDS,
    WEEKEND_DAY_NUMBER,
)

logger = logging.getLogger("__main__." + __name__)


class DateFormatter:
    """Natural Language Date time parser"""

    def __init__(self):
        self._ignore_punctuations = "!.?~$&*'"
        self._ignore_words = [
            "on",
            "around",
            "by",
            "early",
            "late",
            "before",
            "after",
            "oclock",
            "clock",
            "no",
            "later",
            "than",
            "upcoming",
            "coming",
        ]
        # TODO add arguments for configuring parser
        self._parser_settings = {
            "PREFER_DATES_FROM": "current_period",  # past, future
            "PREFER_DAY_OF_MONTH": "current",  # first, last
            "RETURN_TIME_AS_PERIOD": True,
            "SKIP_TOKENS": self._ignore_words,
        }

        # relative date calculation
        self._offset_dict = {
            "this": 0,
            "next": 1,
            "previous": -1,
            "past": -1,
            "last": -1,
            "after": 1,
            "before": -1,
            "ago": -1,
        }

        self._parser = DateDataParser(settings=self._parser_settings, languages=["en"])

    def parse(self, date_text, parse_time=True, parse_date=True):
        """
        Use parse_time and parse_date for known options for better parsing
        For example, arrive date and arrive time are 2 seperate texts, don't join them
        """

        # clean date text
        clean_text = self.__clean_text(date_text)

        # Quickfixes to get certain queries working
        # TODO: Restructure this module to better support queries. More thought needed.
        clean_text = clean_text.replace(" back", " ago")
        clean_text = clean_text.replace("week before", "last week")
        clean_text = clean_text.replace("week after", "next week")
        clean_text = clean_text.replace("weekend before", "last weekend")
        clean_text = clean_text.replace("weekend after", "next weekend")

        delta_dict = {}
        result_json = {
            "parsed_text": clean_text,
            "current_datetime": datetime.datetime.now(),  # stored for reference purposes
        }

        # get relative delta for next, past year, last week etc.
        clean_text = self.__get_offset_next(clean_text, delta_dict)

        # ten minutes from now
        clean_text = self.__get_offset_from(clean_text, delta_dict)

        # replace holidays
        holiday_words_found = []
        for holiday in HOLIDAY_OF_YEAR:
            if holiday in clean_text:
                result_json["current_datetime"] = datetime.datetime.strptime(HOLIDAY_OF_YEAR[holiday], "%d %B")
                result_json["current_datetime"] = result_json["current_datetime"].replace(
                    year=datetime.datetime.now().year
                )

        for holiday in holiday_words_found:
            clean_text = clean_text.replace(holiday, "")
        clean_text = " ".join(clean_text.split())

        if parse_time:
            self.__extract_time(clean_text, delta_dict, result_json)

        # replace part_of_day with empty string, needed for proper parsing of date
        clean_text = " ".join(tok for tok in clean_text.split() if tok not in PARTS_OF_DAY)

        if parse_date:
            self.__extract_date(clean_text, delta_dict, result_json)

        # parse and convert to datetime format
        datedata = self._parser.get_date_tuple(clean_text)
        parsed_datetime = datedata.date_obj
        result_json["parsed_datetime"] = self.__consolidate_datetime(
            parsed_datetime, result_json["parsed_date"], result_json["parsed_time"], result_json["current_datetime"]
        )

        return result_json

    def parse_ner(self, query, time_vals):
        """
        Parse TIME entities to fill composite slot.
        """

        query = query.lower()
        if len(time_vals) > 0 and isinstance(time_vals[0], dict):
            return time_vals
        format_vals = []
        word_cache = ""
        for tok in time_vals:
            tok = tok.lower()
            token = []
            for word in tok.split():
                if word not in format_vals:
                    token.append(word)
            token = " ".join(token)
            if token in format_vals:
                continue
            if word_cache:
                if all(word in query.split() for word in (word_cache + token).split()):
                    if (word_cache + token) not in format_vals:
                        format_vals.append(word_cache + token)
                    word_cache = ""
                else:
                    word_cache += token
            elif all(word in query.split() for word in token.split()):
                format_vals = format_vals + token.split()
            else:
                word_cache = token
        if word_cache:
            format_vals.append(word_cache)
        parsed_datetime = self.parse(" ".join(format_vals))

        return self.__create_datetime_slot(" ".join(format_vals), parsed_datetime["parsed_datetime"])

    def __create_datetime_slot(self, text, date_time):
        obj = {}
        for key in ["original_text", "date", "month", "year", "day", "hour", "minute", "second", "AM_PM"]:
            if key == "original_text":
                obj[key] = [text]
                continue
            elif key == "date":
                val = date_time.day
            elif key == "day":
                val = date_time.strftime("%A")
            elif key == "hour":
                val = date_time.hour % 12
            elif key == "AM_PM":
                val = "PM" if date_time.hour >= 12 else "AM"
            else:
                val = getattr(date_time, key)
            obj["system." + key] = [val]
        return [obj]

    def __extract_time(self, clean_text, delta_dict, result_json):
        # multiple period of day or time relative not handled
        result_json["period_of_day"] = self.__get_element_from_list(clean_text, PARTS_OF_DAY)
        result_json["time_relative"] = self.__get_element_from_list(
            clean_text, ["before", "after", "by", "at", "around"]
        )
        result_json["period_mod"] = self.__get_element_from_list(clean_text, ["latest", "earliest"])

        # Get specific hour if present like 4 o clock
        hour_of_day = re.findall("(?i)(\d{1,2})([.:]{,1})(\d{,2})([ ]{,2})(o clock|'o clock)", clean_text)

        # get relative delta
        timedelta_dict = dict((k, v) for (k, v) in delta_dict.items() if k[:-1] in TIME_WORDS)

        # try to get time without using period_of_day
        if hour_of_day:
            hour_of_day[0] = [tok for tok in list(hour_of_day[0]) if tok]
            am_pm = "am" if "am" in clean_text else "pm"
            clean_text = clean_text.replace("".join(hour_of_day[0]), hour_of_day[0][0] + am_pm)
        timedata = self._parser.get_date_tuple(clean_text)

        # TODO Handle start and end time seprately if both are present
        if timedata.date_obj is None or (timedata.date_obj.time() == datetime.time() and timedata.period != "time"):
            # can't find exact time
            result_json["time"] = None
            if len(timedelta_dict) == 0 and result_json["period_of_day"] is None:
                result_json["parsed_time"] = None
            else:
                period_time_text, time_type = PARTS_OF_DAY[result_json["period_of_day"]].split()
                hours, minutes = map(int, period_time_text.split(":"))
                if time_type == "pm":
                    hours += 12
                parsed_time = datetime.time(
                    hour=hours + timedelta_dict.get("hours", 0),
                    minute=minutes + timedelta_dict.get("minutes", 0),
                    second=timedelta_dict.get("seconds", 0),
                )
                result_json["parsed_time"] = parsed_time.strftime("%H:%M")

        else:
            # found time string, lets calculate final time by adding relative component
            result_json["time"] = (timedata.date_obj + relativedelta(**timedelta_dict)).time().strftime("%H:%M")
            result_json["parsed_time"] = (timedata.date_obj + relativedelta(**timedelta_dict)).time().strftime("%H:%M")

    def __extract_date(self, clean_text, delta_dict, result_json):
        result_json["date_relative"] = self.__get_element_from_list(
            clean_text, ["day after", "the following day", "next", "this"]
        )
        # not able to differnate between day after for today_relative or date_relative
        # date_relative and today_relative are not useful after current parsing
        result_json["today_relative"] = self.__get_element_from_list(
            clean_text, ["today", "tomorrow", "day after", "yesterday", "day before"]
        )

        parsed_date = self._parser.get_date_tuple(clean_text).date_obj
        datedelta_dict = dict((k, v) for (k, v) in delta_dict.items() if k[:-1] in DATE_WORDS)
        if "weeks" in delta_dict:
            datedelta_dict["days"] = datedelta_dict.get("days", 0) + delta_dict["weeks"] * 7
            datedelta_dict.pop("weeks")

        if (result_json["date_relative"] and "day after" in result_json["date_relative"]) or (
            result_json["date_relative"] and "day after" in result_json["today_relative"]
        ):
            datedelta_dict["days"] = datedelta_dict.get("days", 0) + 1

        if result_json["today_relative"] and "yesterday" in result_json["today_relative"]:
            datedelta_dict["days"] = -1

        if result_json["today_relative"] and "day before" in result_json["today_relative"]:
            datedelta_dict["days"] = datedelta_dict.get("days", 0) - 1

        if "weekends" in datedelta_dict:
            datedelta_dict["days"] = (
                delta_dict["weekends"] * 7 + WEEKEND_DAY_NUMBER - result_json["current_datetime"].weekday()
            )
            datedelta_dict.pop("weekends")

        if "day_of_week" in delta_dict:
            date_offset = DAYS_OF_WEEK.index(delta_dict["day_of_week"]) - result_json["current_datetime"].weekday()
            if date_offset < 0:
                date_offset += 7
            datedelta_dict["days"] = datedelta_dict.get("days", 0) + date_offset

        # lets set default value to None
        result_json["month_name"] = None
        result_json["year"] = None
        result_json["day_name"] = None
        result_json["day_number"] = None
        if parsed_date is None and len(datedelta_dict) == 0:
            result_json["parsed_date"] = None
        elif parsed_date is None:
            # we have extracted relative delta, set parsed_date to today relative
            result_json["parsed_date"] = (result_json["current_datetime"] + relativedelta(**datedelta_dict)).date()
        else:
            delta_date = relativedelta(**datedelta_dict)
            result_json["parsed_date"] = (parsed_date + delta_date).date()

            day_month_parsed = parsed_date
            if day_month_parsed is not None:
                result_json["year"] = result_json["parsed_date"].year

            if day_month_parsed and delta_date.years == 0:
                result_json["month_name"] = MONTHS[result_json["parsed_date"].month - 1]

            if day_month_parsed and delta_date.years == 0 and delta_date.months == 0 and delta_date.weeks == 0:
                result_json["day_number"] = result_json["parsed_date"].day

            if day_month_parsed or self.__get_element_from_list(clean_text, DAYS_OF_WEEK):
                result_json["day_name"] = DAYS_OF_WEEK[(parsed_date + delta_date).weekday()]

    def __get_element_from_list(self, clean_text, element_list):
        for element in element_list:
            if re.search(r"\b{0}\b".format(element), clean_text):
                return element
        return None

    def __clean_text(self, date_text) -> str:
        clean_text = date_text.lower()
        # remove punctuations
        clean_text = "".join(c for c in clean_text if c not in self._ignore_punctuations)
        # replace numbers
        clean_text = number_parser.parse(clean_text)
        # replace plural of days_of_week, year, month etc.
        clean_tokens = list(
            word[:-1] if word[-1] == "s" and word[:-1] in DAYS_OF_WEEK + TIME_WORDS + DATE_WORDS else word
            for word in clean_text.split()
        )
        # convert 530 pm to 5:30 pm
        for index, token in enumerate(clean_tokens):
            if token in ["am", "pm"] and index > 0:
                prev_token = clean_tokens[index - 1]
                if len(prev_token) > 2 and len(prev_token) <= 4 and all(c.isnumeric() for c in prev_token):
                    clean_tokens[index - 1] = prev_token[:-2] + ":" + prev_token[-2:]

        return " ".join(clean_tokens)

    def __get_offset_next(self, text, delta_dict) -> str:
        # find delta for next week, last wednesday, this month, past week
        old_tokens = text.split()
        index = offset = 0
        multiplier = 1
        new_tokens = []
        ignored_tokens = []
        while index < len(old_tokens):
            token = old_tokens[index]
            ignore_token = False
            if token in self._offset_dict:
                if new_tokens and new_tokens[-1] in DATE_WORDS:
                    delta_dict[new_tokens[-1] + "s"] = self._offset_dict[token] * multiplier
                    offset = 0
                    multiplier = 1
                    new_tokens = new_tokens[:-1]
                    index += 1
                    continue
                offset += self._offset_dict[token]
                ignore_token = True
            elif token in ["of", "to"] and offset != 0:
                ignore_token = True
            elif token.isnumeric():

                # HACK: Prevent number like 4 in '4 o clock' from being used as a multiplier
                if index + 1 >= len(old_tokens) or old_tokens[index + 1] not in ["o", "o'", "o'clock"]:
                    multiplier = multiplier * int(token)
                    ignore_token = True
            elif offset != 0:
                if token in DAYS_OF_WEEK:
                    delta_dict["weeks"] = offset * multiplier
                    offset = 0
                    multiplier = 1
                elif token in MONTHS:
                    delta_dict["months"] = offset * multiplier
                    offset = 0
                    multiplier = 1
                elif token in HOLIDAY_OF_YEAR:
                    delta_dict["years"] = offset * multiplier
                    offset = 0
                    multiplier = 1
                elif token in TIME_WORDS or token in DATE_WORDS:
                    delta_dict[token + "s"] = offset * multiplier
                    offset = 0
                    multiplier = 1
                    ignore_token = True
                elif token.endswith("s") and (token[:-1] in TIME_WORDS or token[:-1] in DATE_WORDS):
                    delta_dict[token] = offset * multiplier
                    offset = 0
                    multiplier = 1
                    ignore_token = True
            elif token in DAYS_OF_WEEK:
                delta_dict["day_of_week"] = token
                ignore_token = True
            if not ignore_token:
                new_tokens.append(token)
            index += 1
        return " ".join(new_tokens)

    def __get_offset_from(self, text, delta_dict) -> str:
        # handle from and after
        toklist = []
        time_words = TIME_WORDS + DATE_WORDS
        for token in text.split():
            if (
                token in ["from", "after"]
                and len(toklist) > 0
                and (toklist[-1] in time_words or toklist[-1][:-1] in time_words)
            ):
                prev_token = toklist.pop()
                prev_token = prev_token if prev_token in time_words else prev_token[:-1]
                if len(toklist) > 0 and all(c.isnumeric() for c in toklist[-1]):
                    delta_dict[prev_token + "s"] = int(toklist[-1])
                    toklist.pop()
            else:
                toklist.append(token)
        return " ".join(toklist)

    def __get_datetime_member(self, dt, date, time, curr, key):
        """
        For each given member of the date/time/datetime object, pick the value based on priority.
        """

        if date and hasattr(date, key):
            return getattr(date, key)
        if time and hasattr(time, key):
            return getattr(time, key)
        if dt and hasattr(dt, key):
            return getattr(dt, key)
        return getattr(curr, key)

    def __consolidate_datetime(self, dt, date, time, curr):
        """
        Set members in parsed_datetime in the following priority:
        1. parsed_date/parsed_time
        2. parsed_datetime
        3. curr_datetime
        """

        if time:
            time = datetime.time(*[int(t) for t in time.split(":")])
        values = []
        for key in ["year", "month", "day", "hour", "minute", "second"]:
            values.append(self.__get_datetime_member(dt, date, time, curr, key))
        return datetime.datetime(*values)


if __name__ == "__main__":
    print(DateFormatter().parse("24 april evening"))
    print(DateFormatter().parse("10 minutes from now", parse_date=False))
    print(DateFormatter().parse("sunday", parse_time=False))
