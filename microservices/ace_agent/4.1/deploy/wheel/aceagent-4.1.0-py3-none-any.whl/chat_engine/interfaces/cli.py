# Copyright (c) 2020-2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

"""
    Sample application written over dm python api's.
    Uses a CLI interface to accept input from user and display them.
    Initializated by cli mode by typer app.
"""

import os
import sys

sys.path.append(os.path.abspath(os.getcwd()))  # WAR to import dm modules

from questionary import select
from termcolor import colored
import logging
from uuid import uuid4
import texttable
import json
import gc
import ast
import datetime
import random
import asyncio

from chat_engine import Bot, Core, CreateBots
from chat_engine.logger.logging_manager import LoggingManager
from typing import Dict, Tuple, Optional, Union, List, Any
from nemoguardrails.utils import new_event_dict, new_uuid
from chat_engine.constants import INFO_COLOR, WARNING_COLOR, ERROR_COLOR
from time import sleep

logging_manager = LoggingManager(log_dir=os.environ.get("BOT_LOG_PATH", "/workspace/log"))
logger = logging.getLogger("chat_engine")

button_dict = dict()
DEFAULT_AGENT_FALLBACK_RESPONSE = "There is some internal error. Please check the logs."
RESTART = "restart"


def tabulate(data):
    table = texttable.Texttable()
    table.add_rows(data)
    return table.draw()


def print_debug_info(debug_json: dict) -> None:
    """Utility function to print debug info"""

    debug_str = "DEBUG INFO\n\n"

    # Add NLP info
    debug_str += "1. NLU\n"
    domain = debug_json.get("Domain", "None")
    intent = debug_json.get("Intent", "None")
    action = debug_json["Response"].get("Action", "None")
    data = [["Key", "Value"]]
    data.append(["Domain", domain])
    data.append(["Intent", intent])
    data.append(["Action", action])

    entities = debug_json.get("Entities", {})
    if len(entities) == 0:
        data.append(["Entities", "None"])
    else:
        debug_str += tabulate(data) + "\n"
        debug_str += "Entities\n"
        data = [["Entity", "Value"]]
        for entity in entities:
            data.append([entity["EntityName"], entity["Token"]])
        debug_str += tabulate(data) + "\n"
        data.clear()

    # Add Fulfillment info
    fulfillment_slots = debug_json["Fulfillment"]
    if len(fulfillment_slots) == 0:
        if len(data) == 0:
            data = [["Key", "Value"]]
        data.append(["Fulfillment Slots", "None"])
    else:
        if len(data) != 0:
            debug_str += tabulate(data) + "\n"
            data.clear()
        debug_str += "Fulfillment Slots\n"
        data = [["ModuleName", "Slots"]]
        for f_slot in fulfillment_slots:
            data.append([f_slot["Module"], f_slot["Slots"]])
        debug_str += tabulate(data) + "\n"
        data.clear()
    if len(data) != 0:
        debug_str += tabulate(data) + "\n"
        data.clear()
    # Add Dialog State info
    dialog_state = debug_json.get("DialogState", None)
    if dialog_state is not None:
        debug_str += "\n2. Dialog State\n"
        session_slots = debug_json["DialogState"]["SessionSlot"]
        if len(session_slots) == 0:
            data = [["Key", "Value"]]
            data.append(["Session Slots", "None"])
        else:
            debug_str += "Session Slots\n"
            data = [["Slot", "Values"]]
            for s_slot in session_slots:
                data.append([s_slot["Name"], s_slot["Values"]])
            debug_str += tabulate(data) + "\n"
            data.clear()

        global_slots = debug_json["DialogState"]["GlobalSlot"]
        if len(global_slots) == 0:
            if len(data) == 0:
                data = [["Key", "Values"]]
            data.append(["Global Slots", "None"])
        else:
            if len(data) != 0:
                debug_str += tabulate(data) + "\n"
                data.clear()
            debug_str += "Global Slots\n"
            data = [["Slot", "Values"]]
            for g_slot in global_slots:
                data.append([g_slot["Name"], g_slot["Values"]])
            debug_str += tabulate(data) + "\n"
            data.clear()
        if len(data) != 0:
            debug_str += tabulate(data) + "\n"
            data.clear()

        # Display response json
        if debug_json is not None:
            debug_str += "\n3. Details\n"
            data = [["Field", "Details"]]
            for key, val in debug_json.items():
                data.append([key, json.dumps(val, indent=4)])
            debug_str += tabulate(data) + "\n"
            data.clear()

    print(colored("[BOT] " + debug_str.replace("\n", "\n\t "), INFO_COLOR))


def create_bots(config_paths: List[str]) -> Dict[Tuple[str, str], Bot]:
    """
    Helper method to create and initialize a bot.
    Creates a mapping between botname + bot version to an instance of Bot and returns the mapping
    """

    bot_map = {}  # Stores mapping between bot name + bot version to the respective bot instance
    try:

        # Discover and initializes the available bots from a path
        bots: List[Bot] = CreateBots.from_path(config_paths)

        # For each of the returned bots, store it in a map so that we can pick up the required bot at runtime based on name/version
        for bot in bots:
            bot_map[(bot.name, bot.version)] = bot

    except Exception as e:
        logger.critical(f"Failed to initialize bots due to error {e}. Exiting chat engine server.")
        # print_exc()

    return bot_map


def get_bot(bots: Dict[Tuple[str, str], Bot], name: str, version: Optional[str] = "") -> Union[Bot, None]:
    """
    Returns a Bot based on bot name and bot version provided
    """

    if (name, version) in bots:
        return bots.get((name, version))
    return None


async def stream_response(bot: Bot, request: Dict[str, str], use_event_api: bool = False):
    """
    Stream the response from the corresponding Core method.
    """

    if use_event_api:
        streaming_handler = await Core.stream_event_response_async(bot, request)
    else:
        streaming_handler = await Core.stream_response_async(bot, request)

    print(colored("[BOT] ", INFO_COLOR), end="", flush=True)
    async for chunk in streaming_handler:
        if not chunk:
            break
        parsed = json.loads(chunk)
        if parsed["Response"]["IsFinal"]:
            break

        print(colored(parsed["Response"]["Text"], INFO_COLOR), end="", flush=True)

    print("")


async def main(config_paths: List[str], debug: str):
    """
    Entrypoint for cli sample app
    1. Creats and initializes the bots
    2. Sends and receives response from Core
    3. Parses chat engine response to display them in CLI interface properly
    """

    # Initialize and create the bots
    bot_map = create_bots(config_paths=config_paths)
    if not bot_map:
        logger.critical("Failed to initialize the bots in cli mode..")
        # print_exc()
        exit()

    user_id = str(uuid4())
    session_id = str(uuid4())

    # Here we are waiting for all bots to be ready before ensuring users can interact with them
    ready_bots = []
    print(
        colored(
            f"Initializing the discovered bots..Please wait or check the logs for any critical errors.",
            WARNING_COLOR,
        )
    )

    # Wait for all bots to be up with a max duration of 2 minutes
    endTime = datetime.datetime.now() + datetime.timedelta(minutes=2)
    while len(ready_bots) != len(bot_map):

        if datetime.datetime.now() >= endTime:
            colored(
                print("Waited too long, the bots did not came up. Please check the logs for critical errors."),
                ERROR_COLOR,
            )
            exit()

        ready_bots = [bot for bot in bot_map.values() if bot.is_ready]

        notice = random.choice(["Waiting..", "Still Waiting..", "Checking if bots are ready now.."])
        notice += f"Available bots so far are {[bot.name for bot in ready_bots]}"
        print(
            colored(
                f"{notice}",
                WARNING_COLOR,
            )
        )
        sleep(2)

    print(colored(f"Bots initialized in cli mode successfully! Type queries below to interact.", INFO_COLOR))

    # Select the first bot and version in the list of deployed bots as default bot to interact with
    bot_name = list(bot_map.keys())[0][0]
    bot_version = list(bot_map.keys())[0][1]

    while True:
        try:
            # Prompt user to select the bot if multiple bots has been instantiated
            if len(bot_map) > 1:
                loop = asyncio.get_running_loop()

                answer = await loop.run_in_executor(
                    None,
                    select(
                        "Which bot do you want to interact with?",
                        choices=[json.dumps({"Bot": name, "Version": version}) for (name, version) in bot_map]
                        + ["Exit"],
                        default=json.dumps({"Bot": bot_name, "Version": bot_version}),
                    ).ask,
                )

                if not answer or answer == "Exit":
                    break

                selected_option = ast.literal_eval(answer[answer.find("{") : answer.find("}") + 1])
                bot_name = selected_option.get("Bot")
                bot_version = selected_option.get("Version")

            # Prompt the user to provide an input
            query = input(colored("[YOU] ", INFO_COLOR))
            if query.strip().lower() in button_dict:
                query = button_dict[query.strip().lower()]
            button_dict.clear()

            # Formulate the request Json to Core based on user input
            request = {
                "UserId": user_id,
                "QueryId": str(uuid4()),
                "BotName": bot_name,
                "BotVersion": bot_version,
            }

            use_event_api = False  # Used to decide whether to call event based API of Core.

            # Handling special predefined queries
            if query.startswith("__") and query.endswith("__"):
                if query.strip("__").lower() == RESTART:
                    del bot_map
                    gc.collect()
                    bot_map = create_bots(config_paths=config_paths)
                    if not bot_map:
                        colored(print("Failed to restart the Bot in cli mode.."), ERROR_COLOR)
                        exit()
                    print(
                        colored(
                            f"Bot re-started in cli mode successfully. Type queries below to interact.", INFO_COLOR
                        )
                    )
                    continue

            elif query.startswith("{") and query.endswith("}"):
                try:
                    request.update(json.loads(query))
                    # If an Event is provided inside the json we will call the event api of core
                    if "EventType" in request:
                        use_event_api = True
                except Exception as e:
                    colored(
                        print(
                            "Invalid request json format for DM. Please check documentation for required fields.",
                            ERROR_COLOR,
                        )
                    )
                    continue

            else:
                request["Query"] = query

            # If query starts with \ as given below:
            # \UtteranceUserActionFinished(final_transcript="hello")
            # \GestureUserActionFinished(gesture="wave hand")
            # then, process the query as an event.

            try:
                if query.startswith("\\"):
                    eventType = query.split("(")[0][1:]
                    allEventParams = query.split("(")[1][:-1].split(",")
                    params = {}
                    for eventParam in allEventParams:
                        parts = eventParam.strip().split("=")
                        params[parts[0].strip()] = parts[1].strip()
                    params["source_uid"] = "ace_agent_chat_engine"
                    if "is_success" not in params:
                        params["is_success"] = True
                    if "action_uid" not in params:
                        params["action_uid"] = new_uuid()
                    input_event = new_event_dict(eventType, **params)
                    input_event["tags"] = {"is_using_event_interface": False}
                    request = {
                        "UserId": user_id,
                        "EventId": input_event["uid"],
                        "Event": "umim_event",
                        "Metadata": input_event,
                        "BotName": bot_name,
                        "BotVersion": bot_version,
                        "Context": {},
                    }
            except Exception as e:
                logger.error(f"Failed to create request json for the event due to error {e}")
                print(colored(f"[BOT] {DEFAULT_AGENT_FALLBACK_RESPONSE}", ERROR_COLOR))
                continue

            # Pass the request to Core
            try:
                # Fetch bot instance for the provided bot name and bot version
                bot = get_bot(bot_map, request["BotName"], request.get("BotVersion"))
                if bot is None:
                    print(colored(f"Failed to get the instance for bot with name: {request['BotName']}", ERROR_COLOR))
                    continue

                # Call Core with the proper request and bot
                if bot.is_ready and not use_event_api:
                    if bot.streaming:
                        await stream_response(bot, request, False)
                        continue
                    else:
                        response = await Core.get_response_async(bot, request)
                elif bot.is_ready and use_event_api:
                    if bot.streaming:
                        await stream_response(bot, request, True)
                        continue
                    else:
                        response = await Core.get_event_response_async(bot, request)
                else:
                    print(colored(f"Bot with name {bot.name} is not yet initialized. Please wait..", WARNING_COLOR))

            except Exception as e:
                logger.error(f"Failed to get DM response from core due to error {e}")
                print(colored(f"[BOT] {DEFAULT_AGENT_FALLBACK_RESPONSE}", ERROR_COLOR))
                # print_exc()

            else:
                try:
                    # Add debug prints along with the bot provided output if debug mode is enabled
                    if debug == "True" and response != None:
                        print_debug_info(response)
                    if response["Response"].get("Text", None) is None:
                        logger.warning("No response returned from dm core.")
                        print(colored("[BOT] " + DEFAULT_AGENT_FALLBACK_RESPONSE, INFO_COLOR))
                    else:
                        print(colored("[BOT] " + response["Response"].get("CleanedText", None), INFO_COLOR))

                except Exception as e:
                    print(colored("Error while parsing response object from core in debug mode.", ERROR_COLOR))
                    # print_exc()

        except (KeyboardInterrupt, SyntaxError):
            print(colored("KeyBoardInterrupt detected. Exiting CLI mode...", WARNING_COLOR))
            break
