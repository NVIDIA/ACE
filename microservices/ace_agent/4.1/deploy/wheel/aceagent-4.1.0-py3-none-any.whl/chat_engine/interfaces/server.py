# Copyright(c) 2022-2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
    NOTE: if ssl context is enabled api calls are to be made at https instead of http

    Sample application written over chat engine core.
    Exposes http endpoints which is called by a client app.
    Initializated by server mode in bot launcher script.

    Exposed endpoints can be understood and tested by the swagger URL exposed.
"""

import logging
import os
import signal
import json
import asyncio
import prometheus_client
from typing import Any, Optional, Union, Dict, List
from rich import print
from typing_extensions import Annotated
from fastapi import FastAPI, Response, status, Body, Query
from functools import wraps
from termcolor import colored
from fastapi.middleware.cors import CORSMiddleware
from traceback import print_exc
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.exceptions import RequestValidationError
from html import escape

from chat_engine import Core, CreateBots, Bot
from chat_engine.package_info import __version__
from chat_engine.logger.logging_manager import LoggingManager
from chat_engine.interfaces.server_schemas import (
    RequestBody,
    ResponseBody,
    UserContext,
    ChatRequest,
    ChatResponse,
    EventRequest,
    EventResponse,
    HealthResponse,
    ExceptionResponse,
    IsReadyResponseStatus,
    IsReadyResponseList,
)
from chat_engine.constants import INFO_COLOR
from chat_engine.bot_factory.constants import DEFAULT_BOT_VERSION, MAX_STR_LEN

tags_metadata = [
    {
        "name": "Health APIs",
        "description": "APIs for checking and monitoring Server Health Status.",
    },
    {"name": "Core APIs", "description": "APIs for sending user requests with a valid query or event."},
    {"name": "User Context APIs", "description": "APIs for configuring the user parameters at runtime."},
    {"name": "Bot APIs", "description": "APIs for controlling bot behaviour at runtime."},
]

app = FastAPI(
    title="Chat Engine Server API",
    description="NVIDIA ACE Agent Chat Engine Server API",
    version=__version__,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_tags=tags_metadata,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logging_manager = LoggingManager(log_dir=os.environ.get("BOT_LOG_PATH", "/workspace/log"))
logger = logging.getLogger("chat_engine")

# Stores the list of bots discovered
app.bots = {}


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request, exc: RequestValidationError):
    """
    Sanitize the inputs for all validation errors
    """
    errors = exc.errors()
    for error in errors:
        if "input" in error:
            error["input"] = escape(error["input"])

    return JSONResponse(status_code=400, content={"detail": errors})


def __sanitize_payload(req: Dict[str, Any]):
    """
    Sanitize the top level strings of the request payload.
    TODO: Replace this with a more robust sanitization package like 'bleach'
    """

    for key, value in req.items():
        if isinstance(value, str):
            req[key] = escape(value)


def _get_bot_instance(bot_name: Optional[str] = None, bot_version: Optional[str] = None) -> Union[Bot, None]:
    """Returns a bot instance based on bot name and bot version"""

    return app.bots.get((bot_name, bot_version), None)


def __get_bot_version_and_name(bot_name: str) -> str:
    """
    If the bot name is of the format {bot_name}_v{bot_version}, return the bot name and version.
    Else, return the default bot version and bot name
    """

    if bot_name:
        if len(bot_name.split("_v")) > 1:
            parts = bot_name.rsplit("_v", 1)
            return parts[0], parts[1]
        else:
            return bot_name, DEFAULT_BOT_VERSION

    return None, DEFAULT_BOT_VERSION


def __preprocess_request(request: Dict[str, Any]):
    """
    Pre-process the chat/event request to the format expected by Chat controller core methods.
    TODO: Make changes within Chat Engine to enable this
    """

    __sanitize_payload(request)
    top_level_keys = ["StreamId", "QueryId", "SessionId", "SourceLanguage", "TargetLanguage", "Eventid"]
    metadata = request.get("Metadata", {})
    for key, value in metadata.items():
        if key in top_level_keys:
            request[key] = value

    request["BotName"], request["BotVersion"] = __get_bot_version_and_name(request["BotName"])


def __postprocess_response(response: Dict[str, Any]):
    """
    Post-process the chat response to the response format.
    TODO: Make changes within Chat Engine to enable this
    """

    response["Metadata"] = {}
    for key in ["ApiVersion", "UserId", "SessionId", "QueryId", "StreamId", "EventId"]:
        if response.get(key):
            response["Metadata"][key] = response[key]


def validate_request(func):
    """Decorator to validate the incoming request to REST API's.
    Check and disambiguate the bot name field. Bot name field is mandatory when multiple bots are deployed with chat engine.
    After disambiguating the bot, check if the bot is ready to accept to accept requests.
    """

    @wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            bot_name = kwargs.get("request").BotName
            bot_name, bot_version = __get_bot_version_and_name(bot_name)
            # user_id = kwargs.get("request").UserId

            # If bot name is not specified and a single bot is deployed, then use that bot's name
            if bot_name is None and len(app.bots) == 1:
                kwargs.get("request").BotName = list(app.bots.keys())[0][0]
                bot_name = list(app.bots.keys())[0][0]
                logger.info(f"Auto detected bot name: {kwargs.get('request').BotName}")

            # If more than one bot is deployed and bot name is not specified,
            # Check if a active bot is available for the provided user_id - this logic is disabled now
            elif bot_name is None and len(app.bots) > 1:

                # TODO: Find a way to maintain store manager outside a bot, here we are assuming all storage configs is same for all bots
                # if user_id is not None:
                #     active_bot_name, active_bot_version = Core.get_active_bot_for_user(
                #         user_id=user_id, store=list(app.bots.items())[0][1].store_manager
                #     )

                # In case a active bot is set using /setActiveBot for the incoming userid API use it
                # if active_bot_name is not None:
                #     kwargs.get("request").BotName = active_bot_name
                #     kwargs.get("request").BotVersion = active_bot_version
                #     print(f"Auto detected bot name from active bot set for user: {kwargs.get('request').BotName}")
                # else:
                logger.critical(
                    f"Multiple bots are deployed. Please provide a valid bot name using 'BotName: \"your_bot_name\"' field in request."
                )

            # If specified bot name and version combination is not available
            elif (bot_name, bot_version) not in app.bots:
                logger.critical(
                    f"The provided BotName: {bot_name}_v{bot_version} is not available. Please register a new bot by providing its configs."
                )
                return

            # Check if the disambiguated bot is ready or not to receive requests``
            if not _get_bot_instance(bot_name=bot_name, bot_version=bot_version).is_ready:
                logger.critical(
                    f"The requested bot {bot_name} is not ready yet. Please wait or check the initialization logs.."
                )
                return

        except Exception as e:
            raise e

        response = await func(*args, **kwargs)
        return response

    return wrapper


"""
------------------------
REST API DEFINITIONS
-------------------------
"""


@app.post(
    "/processQuery",
    include_in_schema=False,
    tags=["Core APIs"],
    status_code=status.HTTP_200_OK,
    response_description="Response JSON for the corresponding request JSON comprising of useful debugging and logging information for end applications.",
)
@validate_request
async def process_query(
    request: Annotated[
        RequestBody,
        Body(
            description="Chat Engine Request JSON. All the fields populated as part of this JSON is also available as part of request JSON."
        ),
    ],
    response: Response,
) -> Union[ResponseBody, ExceptionResponse]:
    """
    This endpoint can be used to provide response to user request for a specific bot, using defined NLU models and plugin modules. The response formation methodology is picked from the bot configurations and rules defined.
    """

    req = request.dict(exclude_none=True)
    print(f"Received request JSON at /processQuery endpoint: {json.dumps(req, indent=4)}")

    try:
        __preprocess_request(req)
        resp = await Core.get_response_async(
            bot=_get_bot_instance(req.get("BotName", ""), req.get("BotVersion", DEFAULT_BOT_VERSION)), req=req
        )
        resp = ResponseBody.parse_obj(resp)
        return resp
    except Exception as e:
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return ExceptionResponse(StatusMessage=str(e))


@app.post(
    "/chat",
    tags=["Core APIs"],
    status_code=status.HTTP_200_OK,
    response_description="Response JSON for the corresponding chat request JSON.",
    response_model=None,
)
@validate_request
async def chat(
    request: Annotated[
        ChatRequest,
        Body(
            description="Chat Engine Request JSON. All the fields populated as part of this JSON is also available as part of request JSON."
        ),
    ],
    response: Response,
) -> Union[ChatResponse, Dict[str, Any], StreamingResponse]:
    """
    This endpoint can be used to provide response to query driven user request for a specific bot, using defined NLU models and plugin modules. The response formation methodology is picked from the bot configurations and rules defined.
    """

    req = request.dict(exclude_none=True)
    print(f"Received request JSON at /chat endpoint: {json.dumps(req, indent=4)}")

    try:
        __preprocess_request(req)
        bot_details = _get_bot_instance(req.get("BotName", ""), req.get("BotVersion", DEFAULT_BOT_VERSION))

        if bot_details.streaming:
            streaming_handler = await Core.stream_response_async(bot=bot_details, req=req)
            return StreamingResponse(streaming_handler, media_type="text/event-stream")

        else:
            resp = await Core.get_response_async(
                bot=_get_bot_instance(req.get("BotName", ""), req.get("BotVersion", DEFAULT_BOT_VERSION)), req=req
            )
            __postprocess_response(resp)
            resp = ChatResponse.parse_obj(resp)
            return resp
    except Exception as e:
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return ExceptionResponse(StatusMessage=str(e))


@app.post("/event", tags=["Core APIs"], status_code=status.HTTP_200_OK, include_in_schema=True)
@validate_request
async def event(
    request: Annotated[
        EventRequest,
        Body(
            description="Chat Engine Request JSON. All the fields populated as part of this JSON is also available as part of request JSON."
        ),
    ],
    response: Response,
) -> Union[EventResponse, ExceptionResponse]:
    """
    This endpoint can be used to provide response to a event driven user request for a specific bot, using defined NLU models and plugin modules. The response formation methodology is picked from the bot configurations and rules defined.
    """

    req = request.dict(exclude_none=True)
    print(f"Received request JSON at /event endpoint: {json.dumps(req, indent=4)}")

    try:
        __preprocess_request(req)
        bot_details = _get_bot_instance(req.get("BotName", ""), req.get("BotVersion", DEFAULT_BOT_VERSION))

        if bot_details.streaming:
            streaming_handler = await Core.stream_event_response_async(bot=bot_details, req=req)
            return StreamingResponse(streaming_handler, media_type="text/event-stream")

        else:
            resp = await Core.get_event_response_async(bot=bot_details, req=req)
            __postprocess_response(resp)
            resp = EventResponse.parse_obj(resp)
            return resp
    except Exception as e:
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return ExceptionResponse(StatusMessage=str(e))


@app.get("/isReady", tags=["Health APIs"], status_code=status.HTTP_200_OK)
async def is_ready(
    response: Response, BotName: str = Query(None, max_length=MAX_STR_LEN)
) -> Union[IsReadyResponseList, IsReadyResponseStatus]:
    """Check status of the bots and returns the details of available bots"""

    bot_readiness_status = []
    all_bots_is_ready = True

    try:

        if BotName is None:
            for bot in app.bots.values():
                if not bot.is_ready:
                    all_bots_is_ready = False
                bot_readiness_status.append({"BotName": f"{bot.name}_v{bot.version}", "Ready": bot.is_ready})

            if all_bots_is_ready and len(bot_readiness_status):
                response.status_code = status.HTTP_200_OK
                return bot_readiness_status
            else:
                response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
                return bot_readiness_status
        else:
            bot_name, bot_version = __get_bot_version_and_name(BotName)
            bot: Bot = _get_bot_instance(bot_name, bot_version)
            if bot is None:
                raise ValueError(f"Readiness check of {BotName} failed as the bot is not deployed!")
            response.status_code = status.HTTP_200_OK if bot.is_ready else status.HTTP_503_SERVICE_UNAVAILABLE
            return {"BotName": f"{bot.name}_v{bot.version}", "Ready": bot.is_ready}

    except Exception as e:
        logger.critical(f"Error while checking readiness of the bots: {e}")
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return ExceptionResponse(StatusMessage=f"Error while checking readiness of bot: {e}")


@app.get("/reloadBot", tags=["Bot APIs"], status_code=status.HTTP_200_OK)
def reload_bot(
    response: Response,
    BotName: str = Query(None, max_length=MAX_STR_LEN),
    BotVersion: str = Query(DEFAULT_BOT_VERSION, max_length=MAX_STR_LEN),
) -> ExceptionResponse:
    """Reloads all the deployed bots or a selected bot if a bot name is provided"""

    try:

        # Sanitize input to prevent XSS attacks
        if BotName:
            BotName = escape(BotName)
        if BotVersion:
            BotVersion = escape(BotVersion)

        if BotName == None:
            logger.debug("Received request at /reloadBot. Reloading all bots.")
            app.bots = {}
            create_app()
        else:
            bot: Bot = _get_bot_instance(BotName, BotVersion)
            if bot is None:
                raise ValueError(f"The bot {BotName}/{BotVersion} requested to be reloaded is not deployed!")
            logger.debug(f"Received request at /reloadBot. Reloading {BotName}/{BotVersion}.")
            app.bots[(BotName, BotVersion)] = CreateBots.from_path(bot.config_path)[0]

    except Exception as e:
        logger.critical(f"Exception {e} while reloading bot")
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return ExceptionResponse(StatusMessage=f"Error while reloading bot: {e}")
    return ExceptionResponse(StatusMessage=f"Bot reloaded successfully.")


@app.post("/updateUserContext", tags=["User Context APIs"], status_code=status.HTTP_200_OK)
async def update_user_context(
    Context: Dict[str, Any],
    response: Response,
    UserId: str = Query(max_length=MAX_STR_LEN),
) -> ExceptionResponse:
    """Updates the context of the user at runtime."""

    print(f"Received request JSON at /updateUserContext endpoint for user {UserId}. Context: {Context}")

    try:

        # Sanitize text input to prevent QSS attacks
        UserId = escape(UserId)

        if len(app.bots) < 1:
            raise ValueError("Chat Engine instance is not up!")

        bot = next(iter(app.bots.values()))
        Core.update_context_for_user(store=bot.store_manager, user_id=UserId, context=Context)

    except Exception as e:
        logger.critical(f"Error while updating context for user: {UserId}: {e}")
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return ExceptionResponse(StatusMessage=f"Error while updating context for user {UserId}: {e}")

    return ExceptionResponse(StatusMessage=f"Successfully updated context for user {UserId}.")


@app.post("/setUserContext", tags=["User Context APIs"], status_code=status.HTTP_200_OK, include_in_schema=True)
async def set_user_context(context: UserContext, response: Response) -> ExceptionResponse:
    """Sets the context of the user at runtime. It overwrites any existing context."""

    print(f"Received request JSON at /setUserContext endpoint for user {context.UserId}.")

    try:

        # Sanitize text input to prevent QSS attacks
        if context.UserId:
            context.UserId = escape(context.UserId)

        if len(app.bots) < 1:
            raise ValueError("Chat Engine instance is not up!")

        bot = next(iter(app.bots.values()))
        Core.set_context_for_user(store=bot.store_manager, context=context)

    except Exception as e:
        logger.critical(f"Error while setting context for user: {context.UserId}: {e}")
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return ExceptionResponse(StatusMessage=f"Error while setting context for user {context.UserId}: {e}")

    return ExceptionResponse(StatusMessage=f"Successfully set context for user {context.UserId}.")


@app.get("/getUserContext", tags=["User Context APIs"], status_code=status.HTTP_200_OK, include_in_schema=True)
async def get_user_context(
    response: Response, UserId: str = Query(max_length=MAX_STR_LEN)
) -> Union[UserContext, ExceptionResponse]:
    """Returns the context for a specified user ids."""

    print(f"Received request JSON at /getUserContext endpoint for user {UserId}.")

    try:

        # Sanitize text input to prevent QSS attacks
        UserId = escape(UserId)

        if len(app.bots) < 1:
            raise ValueError("Chat Engine instance is not up!")

        bot = next(iter(app.bots.values()))
        return Core.get_context_for_user(store=bot.store_manager, user_id=UserId)

    except Exception as e:
        logger.critical(f"Error while getting context for user: {UserId}: {e}")
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return ExceptionResponse(StatusMessage=f"Error while getting context for user {UserId}: {e}")


@app.delete("/deleteUserContext", tags=["User Context APIs"], status_code=status.HTTP_200_OK, include_in_schema=True)
async def delete_user_context(response: Response, UserId: str = Query(max_length=MAX_STR_LEN)) -> ExceptionResponse:
    """Deletes the context of the user at runtime."""

    print(f"Received request JSON at /deleteUserContext endpoint for user {UserId}.")

    try:

        # Sanitize text input to prevent QSS attacks
        UserId = escape(UserId)

        if len(app.bots) < 1:
            raise ValueError("Chat Engine instance is not up!")

        bot = next(iter(app.bots.values()))
        Core.delete_context_for_user(store=bot.store_manager, user_id=UserId)

    except Exception as e:
        logger.critical(f"Error while deleting context for user: {UserId}: {e}")
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return ExceptionResponse(StatusMessage=f"Error while deleting context for user {UserId}: {e}")

    return ExceptionResponse(StatusMessage=f"Successfully deleted context for user {UserId}.")


@app.get("/metrics", tags=["Health APIs"])
def get_metrics():
    return Response(content=prometheus_client.generate_latest(), media_type="text/plain")


@app.get("/health", tags=["Health APIs"])
def health_check():
    """
    Perform a Health Check

    Returns 200 when service is up. This does not check the health of downstream services.
    """

    response_message = "Service is up."
    return HealthResponse(message=response_message)


@app.on_event("startup")
def create_app() -> None:
    """
    Entrypoint for chat engine in server mode.
    Creates a FastAPI based app and initializes the bots
    """

    try:
        bots = CreateBots.from_path(json.loads(os.environ.get("config_path", "[]")))
        for bot in bots:
            app.bots[(bot.name, bot.version)] = bot

    except Exception as e:
        logger.critical(
            f"Failed to initialize chat engine core due to error {e}.\nPress Ctrl + C to stop the server gracefully."
        )
        raise e

    print(
        colored(
            f"Bot started in server mode successfully. "
            f"Endpoint {'https' if os.environ.get('ssl', 'False') == 'True' else 'http'}://localhost:{os.environ.get('port', 9000)}/chat is active. "
            f"Use REST API to interact.",
            INFO_COLOR,
        )
    )


@app.on_event("shutdown")
async def stop():
    app.bots = {}
    loop = asyncio.get_event_loop()
    loop.stop()
    print(f"Shutted down the server.")


def handler(signal, frame):
    try:
        global app
        app.bots = {}
        loop = asyncio.get_event_loop()
        loop.stop()
        print(f"Shutted down the server.")
    except Exception as e:
        pass


signal.signal(signal.SIGINT, handler)
signal.signal(signal.SIGTERM, handler)
