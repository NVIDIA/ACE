"""
 copyright(c) 2021 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

import logging
import logging.config
import yaml
import os
import socket
import errno
from datetime import datetime, timezone
from typing import Union
from pathlib import Path

from chat_engine.constants import LOG_CONFIG, LOG_LEVEL

logger = None


class LoggingManager:
    """
    Logging Manager
    Manages the logging instantiation.
    """

    __start_time = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")

    def __init__(
        self, config: Union[str, os.PathLike] = LOG_CONFIG, log_dir="/workspace/log", verbose: bool = True
    ) -> None:
        """constructor
        Arguments:
            config: Path to logger config file
            log_dir: Path to store log files
        """

        self._basedir = log_dir
        self._is_verbose = verbose
        self.start(config)

    def __get_log_path(self, prefix: str) -> Union[str, os.PathLike]:
        """
        returns absolute path to log following name_hostname_stime.log conv

        Arguments:
            prefix {str} : Contains basename in str such as dmEngine
        Output:
            dmEngine_nvidian_20210120-105156.log
        """

        os.makedirs(self._basedir, exist_ok=True)
        log_file = "{}_{}_{}.log".format(prefix, socket.gethostname(), LoggingManager.__start_time)
        log_path = os.path.join(self._basedir, log_file)
        return log_path

    def __create_symlink(self, fname: Union[str, os.PathLike], symlink_name: Union[str, os.PathLike]) -> None:
        """
        Creat a symbolic link for fname as symlink_name
        Arguments:
            fname: path to file whose symlink need to be created
            symlink_name: Symlink name for file fname
        """

        if isinstance(fname, os.PathLike):
            fname = str(fname)
        if isinstance(symlink_name, os.PathLike):
            symlink_name = str(symlink_name)

        try:
            fname = os.path.basename(fname) if self._basedir != "/log" else fname
            Path(symlink_name).symlink_to(Path(fname))
        except OSError as e:
            try:
                if e.errno == errno.EEXIST:
                    Path(symlink_name).unlink()
                    Path(symlink_name).symlink_to(Path(fname))
            except Exception as e:
                logger.info("Unable to create symlink exception : {}".format(e))

    def __update_console_handler(self, log_config):
        """
        check any user specified log level, validate and update console handler
        """
        chat_engine_log_level = os.getenv("CHAT_ENGINE_LOG_LEVEL", "").upper()
        log_config["handlers"]["console"]["level"] = (
            chat_engine_log_level if chat_engine_log_level in LOG_LEVEL else log_config["handlers"]["console"]["level"]
        )
        log_config["handlers"]["nemoguardrails_console"]["level"] = (
            chat_engine_log_level
            if chat_engine_log_level in LOG_LEVEL
            else log_config["handlers"]["nemoguardrails_console"]["level"]
        )

        if not self._is_verbose:
            log_config["handlers"]["console"]["filters"] = ["concise_aceagent"]
            log_config["handlers"]["nemoguardrails_console"]["filters"] = ["concise_colang"]
            log_config["handlers"]["console"]["formatter"] = "simple_with_stream_id"
            log_config["handlers"]["nemoguardrails_console"]["formatter"] = "simple_with_stream_id"

    def start(self, config_path: Union[str, os.PathLike]) -> None:
        """Start logging moudle
        Arguments:
            config_path: Path to logger config file
        """
        global logger
        try:
            with open(config_path, "r") as f:
                config = yaml.safe_load(f.read())
            self.__update_console_handler(config)

            # Rename all log file to format filename_host_time.log and create symlink
            for handler in config["handlers"]:
                if "filename" in config["handlers"][handler]:
                    filename = self.__get_log_path(config["handlers"][handler]["filename"])
                    if os.path.isfile(filename):
                        filename = f"{filename[:-4]}-{os.getpid()}.log"
                    symlink_name = os.path.join(self._basedir, config["handlers"][handler]["filename"] + ".log")
                    config["handlers"][handler]["filename"] = filename
                    self.__create_symlink(filename, symlink_name)
            logging.config.dictConfig(config)
            logger = logging.getLogger("chat_engine")
        except Exception as e:
            print("Exception {} while parsing logging config".format(e))
