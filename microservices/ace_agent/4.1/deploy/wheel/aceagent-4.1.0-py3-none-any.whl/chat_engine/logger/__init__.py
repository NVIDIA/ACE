# Copyright(c) 2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
 Contains logging modules of chat engine.
"""

import logging
import re
from typing import List, Tuple

static_log_information = {"stream_id": ""}


class MessageBasedFilter(logging.Filter):
    def __init__(self, pattern: str, replacements: List[Tuple[str, str]]):
        self.pattern = re.compile(pattern)
        self.replacements = replacements

    def filter(self, record):
        stream_id = static_log_information.get("stream_id", "")
        record.stream_id = f"{stream_id[0:5]}.."

        if not isinstance(record.msg, str):
            return True

        is_match = self.pattern.match(record.msg)

        if record.levelno > logging.INFO:
            return True

        # If we have a match, apply replacements to both the message as well as the arguments
        # For context an example msg="Colang %s :: %s"  and example args=("(main)34sdf98-23","log message")
        if is_match:
            for old, new in self.replacements:
                new_args = []
                for arg in record.args:
                    new_args.append(re.sub(old, new, arg))
                record.args = tuple(new_args)
                record.msg = re.sub(old, new, record.msg)
        return is_match
