# Copyright(c) 2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

""" Typer app exposing arguments to run the chat_engine package """

import json
import os
import signal
from subprocess import run, Popen
from typing import List, Optional, Dict, Any

import typer
from rich import print
from signal import SIGINT, SIGTERM
import asyncio

from uvicorn.workers import UvicornWorker

import chat_engine.gunicorn_config
import chat_engine.interfaces

chat = typer.Typer(
    no_args_is_help=True,
    help="Interfaces to chat with the bot. Interaction can happen using a terminal or web browser.",
    add_completion=False,
)

# Default value of arguments accepted in different modes
SERVER_WORKER_CLASS = "uvicorn.workers.UvicornWorker"
WORKERS = 1
DEBUG = False
PORT = 9000
LOG_PATH = "./log"
TIMEOUT = 120  # in seconds
SSL = False
AUTHENTICATION = False
GUNICORN_CONFIG = chat_engine.gunicorn_config.__file__
CERT_FILE = os.path.join(os.path.dirname(chat_engine.interfaces.__file__), "cert.pem")
KEY_FILE = os.path.join(os.path.dirname(chat_engine.interfaces.__file__), "key.pem")


class CustomUvicornWorker(UvicornWorker):
    """
    A worker class for Gunicorn that interfaces with an ASGI consumer callable,
    rather than a WSGI callable. This uses UvicornWorker as core implementation
    and override CONFIG_KWARGS
    """

    # gunicorn doesn't support way to pass worker config, with nest_asyncio
    # we need to ensure loop is set to asyncio, as default `auto` not necessarily
    # resolve asyncio can can have value of uvloop which is not compaitable.
    # taken from https://github.com/encode/uvicorn/issues/343
    CONFIG_KWARGS: Dict[str, Any] = {"loop": "asyncio", "http": "auto"}


SERVER_WORKER_CLASS = "chat_engine.typer_app.CustomUvicornWorker"


@chat.command(no_args_is_help=True, help="Interact with the bot using terminal.")
def cli(
    config: List[str] = typer.Option(
        ...,
        "-c",
        "--config",
        exists=False,
        help="Path to a directory or multiple directories containing configuration files to use for the bot. Can also point to a single configuration file.",
    ),
    log_level: str = typer.Option(default="warning", help="Control the verbosity level of the chat engine logs."),
    debug: bool = typer.Option(DEBUG, "-db", "--debug", help="Enable verbose logs for the bot."),
    log_path: str = typer.Option(LOG_PATH, hidden=True),
    requirements: str = typer.Option(None, "-r", "--requirements", hidden=True),
    script: str = typer.Option(None, "-script", "--script", hidden=True),
):
    print(f"Starting the chat in new cli mode with config path: {config}.")
    set_dependencies(log_path, log_level, requirements, script)

    from chat_engine.interfaces.cli import main

    asyncio.run(main(config_paths=config, debug=str(debug)))


@chat.command(no_args_is_help=True, help="Deploy the Chat Engine event-driven interface.")
def event(
    event_provider_name: str = "redis",
    event_provider_host: str = "localhost",
    event_provider_port: int = 6379,
    config: List[str] = typer.Option(
        ...,
        "-c",
        "--config",
        exists=False,
        help=(
            "Path to a directory or multiple directories containing configuration files to use for the bot. "
            "Can also point to a single configuration file."
        ),
    ),
    port: Optional[int] = typer.Option(
        PORT, "-p", "--port", help="Port where the HTTP interface of event DM will start."
    ),
    log_level: str = typer.Option(
        default="warning",
        help="If the chat should be verbose and output the logs of chat engine",
    ),
    log_path: str = typer.Option(LOG_PATH, hidden=True),
    ssl: bool = typer.Option(SSL, "-ssl", "--ssl", hidden=True),
    requirements: str = typer.Option(None, "-r", "--requirements", hidden=True),
    script: str = typer.Option(None, "-script", "--script", hidden=True),
    stream_uids: str = typer.Option(
        default="",
        help=(
            "List of stream ids that the DM should be listening to even if there was no stream creation event. "
            "For testing only. Format: 'id_1,id_2,...'"
        ),
    ),
    debug_mode: bool = typer.Option(
        default=False,
        help=("Debugging only. Will start debugpy on port 5678. You can attach to it."),
        hidden=True,
    ),
):
    print(f"Starting the Chat Engine event interface with config '{json.dumps(config)}'.")
    set_dependencies(
        log_path,
        log_level,
        requirements,
        script,
    )

    from chat_engine.interfaces.event import main

    if debug_mode:
        try:
            import debugpy

            debugpy.listen(5678)
            print("Started in DEBUG_MODE: Please attach debugger at port 5678 to continue.")
            debugpy.wait_for_client()
        except ImportError:
            print(
                "[Error] Cannot start debugging mode. Error loading module `debugpy`. "
                "You can install it using `pip install debugpy`"
            )
            debug_mode = False

    # Start HTTP interface that provides isReady endpoint for DM in event mode
    server_cmd = (
        f"'chat_engine.interfaces.event_server:app' --env config_path='{json.dumps(config)}' "
        f"--env port={port} --env ssl={ssl} --env authentication={AUTHENTICATION} "
        f"--env event_provider_name={event_provider_name} --env event_provider_host={event_provider_host} "
        f"--env event_provider_port={event_provider_port}"
    )
    if ssl:
        server_cmd = server_cmd + f"--certfile={CERT_FILE} --keyfile={KEY_FILE}"
    gunicorn_cmd = (
        f"gunicorn {server_cmd} --chdir ./ --worker-class={SERVER_WORKER_CLASS} -w {WORKERS} "
        f"--bind 0.0.0.0:{port} --timeout {TIMEOUT}"
    )

    print(f"Starting gunicorn server with command: {gunicorn_cmd}")
    try:
        # server_process = None
        server_process = Popen(gunicorn_cmd, shell=True, start_new_session=True)

        def end_server_process(sig, frame):
            print("Shutting down DM HTTP server...")
            if server_process:
                group_id = os.getpgid(server_process.pid)
                os.killpg(group_id, signal.SIGTERM)
                server_process.wait()

        signal.signal(signal.SIGINT, end_server_process)
        signal.signal(signal.SIGTERM, end_server_process)

        # Run DM in event mode
        main(
            config,
            event_provider_name,
            event_provider_host,
            event_provider_port,
            stream_uids.split(",") if stream_uids else [],
            debug_mode,
        )
    except Exception as e:
        print(f"DM Event Server stopped. Reason {e}")
    finally:
        # Stop HTTP server
        end_server_process(None, None)


@chat.command(
    no_args_is_help=True,
    help="Deploy the Chat Engine REST API endpoints for text based interaction.",
)
def server(
    config: List[str] = typer.Option(
        ...,
        "-c",
        "--config",
        exists=True,
        help="Path to a directory containing configuration files to use for the bot. Can also point to a single configuration file.",
    ),
    port: Optional[int] = typer.Option(PORT, "-p", "--port", help="Port where the web server will start."),
    workers: Optional[int] = typer.Option(
        WORKERS,
        "-w",
        "--workers",
        help="Number of workers with which the web server will start.",
    ),
    timeout: Optional[int] = typer.Option(
        TIMEOUT,
        "-to",
        "--timeout",
        help="Timeout in seconds for each gunicorn worker.",
        hidden=True,
    ),
    log_level: str = typer.Option(
        default="warning", help="If the chat should be verbose and output the logs of chat engine"
    ),
    ssl: bool = typer.Option(SSL, "-ssl", "--ssl", hidden=True),
    requirements: str = typer.Option(None, "-r", "--requirements", hidden=True),
    script: str = typer.Option(None, "-script", "--script", hidden=True),
    log_path: str = typer.Option(default=LOG_PATH, hidden=True),
):
    print(f"Starting the Chat Engine server with config '{json.dumps(config)}'.")
    print(f"Number of Gunicorn workers: {workers}")
    print(f"Gunicorn workers timeout: {timeout} seconds")

    try:
        set_dependencies(log_path, log_level, requirements, script)

        server_cmd = f"'chat_engine.interfaces.server:app' --env config_path='{json.dumps(config)}' --env port={port} --env ssl={ssl} --env authentication={AUTHENTICATION}"
        if ssl:
            server_cmd = server_cmd + f" --certfile={CERT_FILE} --keyfile={KEY_FILE}"
        gunicorn_cmd = f"gunicorn {server_cmd} --chdir ./ --worker-class={SERVER_WORKER_CLASS} -w {workers} --bind 0.0.0.0:{port} --timeout {timeout} --config {GUNICORN_CONFIG}"
        print(f"Starting gunicorn server with command: {gunicorn_cmd}")
        run(gunicorn_cmd, check=True, shell=True)

    except Exception as e:
        print(f"Chat server stopped. Reason: {e}")


@chat.command(help="Stop any locally deployed chat server.")
def stop():
    print(f"Stopping any running chat servers hosting the bots.")
    server_cmd = [
        "chat_engine.interfaces.server:app",
        "chat_engine.interfaces.event_server:app",
    ]

    for cmd in server_cmd:
        stop_cmd = f"pkill -f '{cmd}'"
        print(f"Stopping chat servers with command: {stop_cmd}")
        run(stop_cmd, shell=True)
    print(f"All natively running chat servers stopped successfully.")


def install_from_requirements_file(path: str):
    import pip

    print(f"Installing custom requirements from: {path}")
    with open(path, "r") as f:
        requirements = f.readlines()
    pip.main(["install"] + requirements)


def execute_script_file(path: str):
    print(f"Installing custom script from: {path}")
    run(f"bash {path}", shell=True, check=True)


def set_dependencies(
    log_path: str,
    log_level: str,
    requirements: str,
    script: str,
):
    os.environ["BOT_LOG_PATH"] = log_path

    if log_level is not None:
        os.environ["CHAT_ENGINE_LOG_LEVEL"] = log_level

    if requirements is not None:
        install_from_requirements_file(requirements)
    if script is not None:
        execute_script_file(script)
