# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import logging
import asyncio
from traceback import print_exc
from typing import List, List, Union, Optional
from threading import Thread
from texttable import Texttable
from termcolor import colored
from urllib.parse import urljoin
from tqdm import tqdm

from chat_engine.bot_factory.bot_parser import BotConfigs
from chat_engine.bot_factory.bot import Bot
from chat_engine.stores.store import Store
from chat_engine.policies.policy_manager import PolicyManager
from chat_engine.policies.slots.slot_manager import SlotManager
from chat_engine.dialog_state_tracker.dialog_state_tracker import DialogStateTracker
from chat_engine.core.health_monitor import HeathMonitor
from chat_engine.constants import PRINT_TRACEBACK, INFO_COLOR, WARNING_COLOR, ERROR_COLOR
from chat_engine.core.health_monitor import NLPendpoint, FMEndpoint

logger = logging.getLogger("chat_engine")

# Initialize a tqdm instance to create a Lock. Done to prevent https://github.com/tqdm/tqdm/issues/457
tqdm(disable=True, total=0)


class CreateBots:
    @classmethod
    def from_path(cls, config_dir: Union[List[str], str], block: Optional[bool] = False) -> List[Bot]:
        """Discovers, parses the bot configurations and initializes the core components of the bots available in the paths provided.
        It also prints a table indicating the list of discovered bots, NLP endoints and FM endpoints.
        Returns a list of bot instances.
        """

        # Support both list and string datatypes while calling this API
        if type(config_dir) == str:
            config_dir = [config_dir]

        # Stores list of all discovered bot
        discovered_bots = []

        for path in config_dir:
            try:
                logger.debug(f"Discovering bots from {path}")
                bots = BotConfigs.from_path(path)
                logger.debug(f"Discovered {len(bots)} bot from {path}")
                discovered_bots.extend(bots)

            except Exception as e:
                logger.critical(f"Error while discovering bots from path {path}: {e}")
                if PRINT_TRACEBACK:
                    print_exc()
                raise e

            try:
                # Initialize each of the returned bots and store it in a map so that we can pick up the required bot at runtime based on name/version
                logger.debug(f"Now triggering the initialization of core components of the bots from {path}..")
                for bot in bots:
                    if not block:
                        Thread(
                            target=cls.run_bot_init,
                            args=(bot,),
                            daemon=True,
                        ).start()
                    else:
                        cls.run_bot_init(bot)
            except Exception as e:
                logger.critical(f"Error while initializing bots: {e}")
                if PRINT_TRACEBACK:
                    print_exc()
                raise e

        logger.info(
            f"Returning the list of discovered bots. Bot initialization is {'in progress' if not block else 'done now'}..\n"
        )

        try:
            # Print the discovered bot details in terminal
            if len(discovered_bots) > 0:
                cls.print_bot_details(discovered_bots)
            else:
                print(
                    colored(
                        'No bot config files found in the provided directory! Please provide a yaml file with name "bot: <bot_name>"',
                        ERROR_COLOR,
                    )
                )
        except Exception as e:
            logger.critical(f"Error while printing details of endpoints: {e}")
            if PRINT_TRACEBACK:
                print_exc()
            raise e

        return discovered_bots

    @classmethod
    def run_bot_init(cls, bot: Bot):
        """Synchronous wrapper over the Asynchronous method to initialize the bot"""

        asyncio.run(cls.initialize_bot(bot))

    async def initialize_bot(bot: Bot) -> None:
        """Async version which Initializes the core components of the provided bot"""
        try:

            # This needs to be a singleton class, we can have a single discoverer instance for all bots
            bot.health_monitor = HeathMonitor(bot=bot)
            bot.health_monitor.run()

            # Initialize the DM store class which is called by modules to store information over sessions
            logger.debug(f"Started initialization of bot: {bot.name}")
            bot.store_manager = Store(bot.storage_configs)
            bot.state_manager = DialogStateTracker(bot=bot)

            # Create Slot Manager instance
            if bot.slot_config:
                bot.slot_manager = SlotManager.create_instance(bot.slot_config, bot.state_manager)
                await bot.slot_manager.initialize(bot)

            # Initialize the required policies
            bot.policy_manager = PolicyManager(bot=bot)
            await bot.policy_manager.initialize()

            CreateBots.print_fm_details(
                name=bot.name,
                version=bot.version,
                endpoint_list=bot.health_monitor.fm_endpoints,
                base_url=bot.configs.plugin_server_url,
            )
            CreateBots.print_nlp_details(
                name=bot.name,
                version=bot.version,
                task_list=bot.health_monitor.nlp_endpoints,
                base_url=bot.configs.nlp_server_url,
            )

            # TODO: This is not needed to be implemented now
            # skip session checker if data is stored in cloud
            # if self._config.storage.name not in [STORE_REDIS, STORE_MONGO]:
            #     SessionChecker(config=self._config, store=self._store, daemon=True).start()
        except Exception as e:
            logger.error(f"Error in Bot initialization for bot {bot.name}: {e}")
            if PRINT_TRACEBACK:
                print_exc()
            raise e

        bot.is_ready = True
        logger.info(f"Completed initialization of bot: {bot.name}")

    def print_bot_details(bots: List[Bot]) -> None:
        """Utilty function to print details of discovered Bots"""

        debug_str = "Discovered Bot details\n\n"
        table = Texttable()
        table.set_cols_align(["c"] * 3)
        table.add_row(["Bot Name", "Bot Version", "Path"])

        for bot in bots:
            table.add_row([bot.name, bot.version, bot.config_path])

        debug_str += table.draw() + "\n\n"
        print(colored(debug_str.replace("\n", "\n\t "), INFO_COLOR))

    def print_nlp_details(name: str, version: str, task_list: List[NLPendpoint], base_url: str) -> None:
        """Utility function to print details of NLP endpoints available from NLP server"""

        if not len(task_list):
            print(colored(f"No NLP server endpoints discovered for {name}/{version}.", WARNING_COLOR))
            return

        debug_str = f"NLP server available endpoints for {name}/{version}\n\n"
        table = Texttable()
        table.set_cols_align(["c"] * 3)
        table.add_row(["Task Name", "Model Name", "URL"])

        for task in task_list:
            table.add_row([task.task_name, task.model_name, urljoin(base_url, task.endpoint)])

        debug_str += table.draw() + "\n\n"
        debug_str = debug_str.replace("\n", "\n\t ")
        logger.info(f"{colored(debug_str, INFO_COLOR)}")
        # By default logger only print this warning and above
        # Always print the fulfillment info on terminal
        print(f"{colored(debug_str, INFO_COLOR)}")

    def print_fm_details(name: str, version: str, endpoint_list: List[FMEndpoint], base_url: str) -> None:
        """Utility function to print details of FM endpoints available in fm server"""

        if not len(endpoint_list):
            print(colored(f"No FM server endpoints discovered for {name}/{version}.", WARNING_COLOR))
            return

        debug_str = f"FM Server Available endpoints for {name}/{version}\n\n"
        table = Texttable()
        table.set_cols_align(["c"] * 3)
        table.add_row(["#", "Name", "Endpoints"])

        for idx, fm in enumerate(endpoint_list):
            table.add_row([idx, fm.name, urljoin(base_url, fm.endpoint)])

        debug_str += table.draw() + "\n\n"
        debug_str = debug_str.replace("\n", "\n\t ")
        logger.info(f"{colored(debug_str, INFO_COLOR)}")
        # By default logger only print this warning and above
        # Always print the fulfillment info on terminal
        print(f"{colored(debug_str, INFO_COLOR)}")
