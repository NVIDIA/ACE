# Copyright(c) 2023 NVIDIA Corporation. All rights reserved

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
This file parses and discovers the passed bot config file paths or bot directory path and stores/validates them as a Pydantic model.
It also exposes python API's to get back the parsed bot configurations.
"""

import os
import yaml
import logging
import json
from pydantic.v1 import BaseModel
from typing import List
from chat_engine.bot_factory.bot import Bot

logger = logging.getLogger("chat_engine")


class BotConfigs(BaseModel):
    """Parses and stores all the configurations for all bots config file"""

    bots: List[Bot]

    @classmethod
    def get_config_paths(cls, path: str) -> List[Bot]:
        """Parses the passed filepath or directory path and returns the list of bot config paths"""

        # Discover directories where bot config files reside and store the mapping between individual bot directory to bot config file name in bot_dir
        bot_dirs = {}

        # If the passed path is a directory we autodiscover the relevant indivisual bot directories
        if os.path.isdir(path):

            # Go over all the files in the specified path
            for root, dirs, files in os.walk(path):
                for file in files:
                    if not file.endswith(".yaml") and not file.endswith(".yml"):
                        continue
                    full_path = os.path.join(root, file)
                    try:
                        # Open the yaml extension based files and check if they have the required keys in them to qualify as bot config file
                        with open(full_path) as f:
                            raw_config = yaml.safe_load(f.read())
                            if "bot" in raw_config or "models" in raw_config:

                                # Check if same directory has multiple bot config files
                                if root in bot_dirs:
                                    raise ValueError(
                                        f"Bot config directory at {full_path} has two entrypoint yaml files. \
                                            There can be only one bot config file at in a directory."
                                    )

                                # Check if same directory has  bot config files in its subdirectories
                                for p in bot_dirs:
                                    if p.startswith(root) or root.startswith(p):
                                        raise ValueError(
                                            f"Bot config files reside in both {root} and {p} which are subdirectories of each other. Individual bots can reside only in distinct directories and should not be subdirectories of each other."
                                        )

                                # If validation passes, add the directory to the list of valid bot directories
                                bot_dirs.update({root: full_path})
                    except (yaml.YAMLError, ValueError, Exception) as e:
                        logger.error(f"Got error while parsing yaml file: {e}")
                        raise e

        # If the passed path is a file, we validate and assume the parent directory as bot directory
        elif os.path.isfile(path):

            # Reject the file path passed if it does not end with yaml format
            if not path.endswith("yaml") and not path.endswith("yml"):
                raise ValueError(
                    f"Invalid bot config file passed: {path}. It must have a valid yaml extension and syntax."
                )

            # Open the file and check if its a valid bot config file by checking the mandatory fields
            try:
                with open(path) as f:
                    raw_config = yaml.safe_load(f.read())

                    # If the passed path is valid add a directory to bot config file mapping to bot_dir
                    if "bot" in raw_config or "models" in raw_config:
                        bot_dirs.update({os.path.dirname(path): path})

            except yaml.YAMLError as e:
                logger.error(f"Got error while parsing yaml file: {e}")
                raise e

        else:
            raise ValueError(f"The passed path: {path} must be a valid bot yaml file or directory.")
        return bot_dirs

    @classmethod
    def from_path(cls, path: str) -> List[Bot]:
        """Parses the passed filepath or directory path and returns the list of parsed bots"""

        bot_dirs = BotConfigs.get_config_paths(path)
        # For each of the bot directories now discover the relevant policy files
        cls.bots = []
        for dir, file in bot_dirs.items():
            logger.debug(f"Parsing bot config: {file}")
            cls.bots.append(Bot.get_bot(bot_dir_path=dir, bot_config_file_path=file))

        # Once the final list of bots are available, iterate and check if there a unique bot-name/version combination
        unique_bot = []
        for bot in cls.bots:
            if (bot.name, bot.version) not in unique_bot:
                unique_bot.append((bot.name, bot.version))
            else:
                raise ValueError(
                    f"You have multiple bots defined with same 'bot: {bot.name}' and 'version: {bot.version}' combination. Please update the 'bot: ' field or 'version: ' field in your bot config file at {bot.config_path}"
                )

        return cls.bots


if __name__ == "__main__":

    def print_config_details(bot_configs):
        for bot in bot_configs:
            print(json.dumps(bot.dict(exclude={"colang_configs"}), indent=4))

    print_config_details(BotConfigs.from_path("./bots/test_bot/"))
    print_config_details(BotConfigs.from_path("./bots/test_bot/guardrail_bot"))
    print_config_details(BotConfigs.from_path("./bots/test_bot/plugin_bot"))
    print_config_details(BotConfigs.from_path("./bots/test_bot/dialog_policy_bot/dialog_bot_config.yaml"))
