# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import logging
import re
import json
from typing import List, Optional
from time import time

from chat_engine.policies.utils import update_llm_context, close_stream
from chat_engine.nlp.response import ResponseRules, BotResponse, Response
from chat_engine.core.core import Core
from nemoguardrails.actions.actions import ActionResult, action
from nemoguardrails.actions.llm.utils import get_last_bot_intent_event
from nemoguardrails.utils import new_event_dict

logger = logging.getLogger("chat_engine")


@action(is_system_action=True)
async def generate_bot_message(events: List[dict], context: dict, confidence_threshold: Optional[float] = 0.5):
    """
    This function is registered as a custom action in Nemoguardrails and is used to support
    ACE Agent legacy Response templates based response formation using Colang
    flows.
    """

    logger.info(f"Overridden system action generate_bot_message")
    bot_messages = {}
    response_templates = []
    final_bot_response = ""
    response_generated = False
    self = generate_bot_message.policy_instance
    bot = generate_bot_message.bot
    user_id = context.get("user_id")
    request_id = context.get("event_id") if context.get("event_id") else context.get("query_id")
    user = Core.fetch_user_data(user_id, request_id)
    event_history = user.dialog_state[user.user_id].event_history.get(self.bot.name, [])

    # We update all the available context variables as a valid llm prompt context
    update_llm_context(generate_bot_message.rails, context=context)

    # First we accumulate all the bot message canonical forms defined in colang config
    bot_messages.update(self._rails.config.bot_messages)

    # Next we try to find the latest bot_intent from events to start formulating the response
    event = get_last_bot_intent_event(events)
    assert event["type"] == "BotIntent"
    bot_intent = event["intent"]
    bot_message_text = ""
    logger.info(f"Generating response for bot intent: {bot_intent}")

    # Once we find the latest BotIntent, we try to find all the response rules/templates corresponding to it
    # bot intent can be either a string or a dict
    if type(event["intent"]) == dict:
        # If bot intent is a dict, then its defined as `bot "response string"` in the colang config
        bot_intent = event.get("intent", {})
        bot_message_text = bot_intent.get("text", "")
        response_templates.append(bot_message_text)

    else:
        # If bot intent is a str, then its defined as a bot canonical form in the colang config
        bot_intent = event.get("intent", "")

        if bot_intent in bot_messages:
            response_templates.extend(bot_messages[bot_intent])
        else:
            logger.info(f"Couldn't find any bot_messages defined in the colang config for BotIntent: {bot_intent}")

            action_result = None

            # We check if LLM model has been defined in the config and continue based on it.
            if self.llm_model_available:
                logger.info("Attempting Nemoguardrails generate_bot_message action")
                try:
                    start = time()
                    action_result = await self._actions.generate_bot_message(events, context)
                    user.latency.llm_models += time() - start
                    logger.debug(
                        f"Latency for Nemoguardrails call for generate_bot_message: {time() - start} seconds."
                    )
                except Exception as e:
                    logger.warning(f"Exception occurred while calling Nemoguardrails generate_bot_message: {e}")
                    event_history.clear()
                    raise e
                    # response_templates.append(str(e))

                if action_result and len(action_result.events) > 0:
                    bot_message = action_result.events[0].get("text", "")
                    if bot_message and bot_message != "general response":
                        if user.colang_streaming_handler and user.colang_streaming_handler.completion:
                            user.colang_streaming_handler.streaming_finished_event.set()
                            await close_stream(user)
                        return action_result

            # perform embedding search on the bot intent to find most relevant bot message
            embedding_search_results = await self.search_bot_embedding_index(
                query=bot_intent, confidence_threshold=confidence_threshold
            )

            bot_message_text = await self.get_embedding_index_bot_message(embedding_search_results)

            if not len(response_templates):
                logger.info(f"Response selected using embedding search: {bot_message_text}")
                response_templates.append(bot_message_text)

    # Once we have all the response rules/templates, we will format them and check if it contains expressions
    random_response_selection = True
    for i in range(len(response_templates)):
        response_template = response_templates[i]
        assert type(response_template) == str

        # we format the response templates to remove '$' character
        # we also remove a pair of {} in case it contains expressions
        if "{" in response_template and "}" in response_template:
            # Avoid formatting jsons

            if not __check_if_response_json(response_template):
                response_template = __format_response_template(response_template)

            # response cannot be randomly selected as resp rules contains expressions
            random_response_selection = False
            response_templates[i] = response_template

    # Once formatting is done, we update user.slots again to add any missing slots
    if user:
        skip_context_keys = ["last_user_message", "last_bot_message", "_last_bot_prompt"]
        for key, value in context.items():
            if key not in skip_context_keys and value and key not in user.slots.keys():
                # We only want list of strings in user slots
                if type(value) == list or type(value) == dict and all(isinstance(item, str) for item in value):
                    user.slots[key] = value
                elif isinstance(value, (int, str, float)):
                    user.slots[key] = [str(value)]

    # Now we convert the response templates into ResponseRules for using them in ACE Agent Response generator
    response_rules = None
    if not random_response_selection:
        responses = []

        for response_template in response_templates:
            if __check_if_response_json(response_template):
                # If response template is a json string
                logger.info(f"Found response json str in response templates: {response_template}")
                response_json = __parse_response_json(response_template, context)
                response = BotResponse(
                    text=response_json["text"],
                    action=response_json["action"],
                    json=response_json["json"],
                    omniverse_json=response_json["omniverse_json"],
                    need_user_response=response_json["need_user_response"],
                    is_partial_response=None,
                )
            else:
                # If response template contains expressions
                response = BotResponse(
                    text=[response_template],
                    action=None,
                    json=None,
                    omniverse_json=None,
                    need_user_response=None,
                    is_partial_response=None,
                )
            if response:
                responses.append(response)
        response_rules = ResponseRules(responses=responses)

    else:
        # If response can be randomly selected from response templates
        response_rules = ResponseRules(
            responses=[
                BotResponse(
                    text=response_templates,
                    action=None,
                    json=None,
                    omniverse_json=None,
                    need_user_response=None,
                    is_partial_response=None,
                )
            ]
        )

    # Finally we the ACE Agent Response generator to get a valid response
    if response_rules and user:
        disambiguated_response = await Response.get_response(response_rules=response_rules, bot=bot, user=user)
        if disambiguated_response:
            final_bot_response = disambiguated_response.text
            if user:
                user.response = disambiguated_response

    # We also populate a context variable if a valid response was generator
    if final_bot_response:
        response_generated = True
        # In streaming mode, push the final response to the streaminghandler and close the stream
        if bot.streaming and user.colang_streaming_handler:
            await user.colang_streaming_handler.push_chunk(final_bot_response)
            await user.colang_streaming_handler.push_chunk(None)
            await close_stream(user)

    logger.info(f"Response formed by overridden generate bot message action: {final_bot_response}")

    # Note: WAR for handling nemoguardrails exception when response was set to empty str
    # if not final_bot_response:
    #     final_bot_response = "I'm not sure what to say."

    return ActionResult(
        events=[new_event_dict("StartUtteranceBotAction", script=final_bot_response)],
        context_updates={"response_generated": response_generated},
    )


def __check_if_response_json(response_template: str) -> bool:
    key_present = False
    response_json_keys = ["text", "action", "json", "omniverse_json", "need_user_response"]
    for key in response_json_keys:
        if key in response_template:
            key_present = True
        else:
            key_present = False
    return key_present


def __parse_response_json(response_template, context):
    response_dict = {}
    pattern = r"\{\{[^}]+\}\}|\S+"
    response_template = response_template[1:-1]
    words = re.findall(pattern, response_template)
    pattern = r"\{\{([^}]*)\}\}"
    for i in range(len(words)):
        val = words[i]
        if re.search(pattern, val):
            val = val.replace("{", "").replace("}", "").replace("$", "")
            val = val.strip()
            val = context.get(val, None)
            words[i] = json.dumps(str(val))

    response_template = " ".join(words)
    try:
        response_dict = json.loads(response_template)
        logger.info(f"Response json after disambiguation of slots: {response_dict}")
    except Exception as e:
        logger.info(f"Exception in parsing response json  from response template {response_template}, {e}")
        response_dict = {}

    return response_dict


def __format_response_template(response_template: str):
    """
    Helper function for generate_bot_message
    """
    # Split the response_template string into individual words
    response_template = response_template.strip()
    pattern = r"\{\{[^}]+\}\}|\S+"
    words = re.findall(pattern, response_template)
    # Iterate over the words and remove $ from variables
    for i in range(len(words)):
        pattern = r"\{\{([^}]+)\}\}"
        expr = re.findall(pattern, words[i])
        if len(expr) != 0:
            expr = expr[0]
            expr = expr.replace("$", "")
            expr = expr.replace("{", "").replace("}", "")
            words[i] = "{" + expr + "}"

    # Join the words back into a single string
    formatted_response_template = " ".join(words)
    return formatted_response_template
