import logging
from typing import List, Optional
from time import time

from chat_engine.core.core import Core
from nemoguardrails.actions.actions import ActionResult, action
from nemoguardrails.actions.llm.utils import get_last_user_intent_event, get_last_bot_intent_event
from nemoguardrails.utils import new_event_dict

logger = logging.getLogger("chat_engine")


@action(is_system_action=True)
async def generate_next_step(events: List[dict], context: dict, confidence_threshold: Optional[float] = 0.7):
    """
    This function is registered as a custom action in Nemoguardrails and is used to Nemoguardrails
    implementation of generate next steps
    """

    logger.info(f"Overridden system action generate_next_step")
    self = generate_next_step.policy_instance
    user_id = context.get("user_id")
    request_id = context.get("event_id") if context.get("event_id") else context.get("query_id")
    user = Core.fetch_user_data(user_id, request_id)

    action_result = None
    return_events = []

    # We check if LLM model has been defined in the config and continue based on it.
    if self.llm_model_available:
        logger.info("Attempting Nemoguardrails generate_next_step action")
        try:
            start = time()
            action_result = await self._actions.generate_next_step(events)
            user.latency.llm_models += time() - start
            logger.debug(f"Latency for Nemoguardrails call for generate_next_steps: {time() - start} seconds.")
        except Exception as e:
            logger.debug(f"Exception occurred while calling Nemoguardrails generate_next_steps: {e}")
        if action_result and len(action_result.events) > 0:
            return action_result

    # Else continue with Embedding search
    logger.info("Attempting embedding search for finding next steps")

    # We get the last event, it should be a UserIntent event only
    last_user_intent = ""
    event = get_last_user_intent_event(events)
    if event and event["type"] == "UserIntent":
        last_user_intent = event["intent"]

    last_bot_intent = ""
    event = get_last_bot_intent_event(events)
    if event and event["type"] == "BotIntent":
        last_bot_intent = event["intent"]

    embedding_search_results = await self.search_flows_embedding_index(
        query=last_user_intent, confidence_threshold=confidence_threshold
    )

    flow_result = await self.get_embedding_index_flows_message(embedding_search_results)
    # we parse the nearest matching flow, split is by '\n' and look at the first line
    flow_result = flow_result.split("\n")
    if flow_result and len(flow_result) > 0:
        flow_result = flow_result[0]
    # based on the first line of the flow, we return the corresponding event as next step
    if flow_result and flow_result.startswith("user "):
        user_intent = flow_result[5:].strip()
        if user_intent != last_user_intent:
            return_events.append(new_event_dict("UserIntent", intent=user_intent))
        else:
            logger.debug(f"Event cycle detected in generate_next_steps for user_intent: {user_intent}")

    elif flow_result and flow_result.startswith("bot "):
        bot_intent = flow_result[4:].strip()
        if bot_intent != last_bot_intent:
            return_events.append(new_event_dict("BotIntent", intent=bot_intent))
        else:
            logger.debug(f"Event cycle detected in generate_next_steps for BotIntent: {bot_intent}")

    elif flow_result and flow_result.startswith("execute "):
        return_events.append(new_event_dict("StartInternalSystemAction", action_name=flow_result[8:].strip()))

    if len(return_events) == 0:
        # We add a fallback bot response if no valid next step was generated
        return_events.append(new_event_dict("BotIntent", intent="general response"))

    logger.info(f"Next steps selected using embedding search: {return_events}")
    return ActionResult(events=return_events)
