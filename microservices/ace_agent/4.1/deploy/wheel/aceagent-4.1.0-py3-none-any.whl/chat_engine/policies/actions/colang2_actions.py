# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import asyncio
import itertools
import os
from collections import deque, OrderedDict
import json
import logging
import re
import aiohttp
import uuid
from typing import Deque, Dict, Optional, Any, List
from urllib.parse import urljoin
from dataclasses import asdict, dataclass

from nemoguardrails.actions.actions import action
from nemoguardrails.colang.v2_x.runtime.flows import InternalEvent
from chat_engine.core.core import Core
from chat_engine.policies.actions.generate_user_intent import generate_user_intent
from nemoguardrails import kb

logger = logging.getLogger("chat_engine")


@action(name="GenerateIntentThenSlotsAction")
async def generate_intent_then_slots_action(
    utterance: str,
    context: Dict[str, Any],
    model_name: Optional[str] = None,
    endpoint: Optional[str] = None,
    confidence_threshold: float = 0.5,
    request_timeout: int = 5,
) -> Any:
    """
    Custom Action to call Intent Slot model used together with Colang 2.0.
    """
    logger.info("Calling GenerateIntentThenSlotsAction with utterance=%s", utterance)
    bot = generate_intent_then_slots_action.bot

    bot.configs.enable_intent_slot = True

    result = await generate_user_intent(
        events=[],
        query=utterance,
        model_name=model_name,
        endpoint=endpoint,
        confidence_threshold=confidence_threshold,
        request_timeout=request_timeout,
        context=context,
        skip_llm=True,
    )

    user_intent = result.events[0]["intent"]
    conf_score = result.events[0]["conf_score"]
    context_slots = result.context_updates

    logger.info("GenerateIntentThenSlotsAction intent=%s, entities=%s", user_intent, context_slots)
    return {"intent": user_intent, "slots": context_slots, "intent_confidence": conf_score}


def _get_plugin_server_url(configured_url: str) -> str:
    if "PLUGIN_SERVER_URL" in os.environ and os.environ.get("PLUGIN_SERVER_URL", ""):
        return os.environ.get("PLUGIN_SERVER_URL", "")
    else:
        return configured_url


@dataclass
class FulfillmentConnectionState:
    is_starting: bool
    in_progress: bool
    is_chunked: bool
    chunks: Deque[str]
    response: Any


fulfillment_connection_state: Dict[str, FulfillmentConnectionState] = OrderedDict()
fulfillment_connection_buffer_size = 100


async def perform_fulfillment_call(
    method: str,
    url: str,
    headers: Optional[dict] = None,
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    timeout: Optional[int] = 10,
):
    connection_instance = FulfillmentConnectionState(
        is_starting=True, in_progress=False, is_chunked=True, chunks=deque(), response=None
    )
    fulfillment_connection_state[url] = connection_instance
    while len(fulfillment_connection_state) > fulfillment_connection_buffer_size:
        logger.debug(
            f"Plugin connection state dictionary size greater than {fulfillment_connection_buffer_size}, pruning state dictionary..."
        )
        fulfillment_connection_state.popitem(last=False)

    args = {}
    if headers:
        args["headers"] = headers
    if params:
        args["params"] = params
    if data:
        args["json"] = data
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
            async with session.request(method=method, url=url, **args) as response:
                response.raise_for_status()
                if response.headers.get("Transfer-Encoding") == "chunked":
                    connection_instance.in_progress = True
                    connection_instance.is_starting = False

                    async for chunk, _ in response.content.iter_chunks():
                        if not chunk:
                            break

                        decoded_chunk = chunk.decode("utf-8")
                        logger.debug("Plugin received chunk : |%s|", decoded_chunk)

                        # WAR Ignore replacement characters that are sent from RAG pipeline due to encoding issue.
                        decoded_chunk = decoded_chunk.replace("\ufffd", "")

                        # If the decoded_chunk is in a JSON format in the Chat Response format, extract only the text
                        # component from the JSON
                        try:
                            decoded_chunk = json.loads(decoded_chunk)["Response"]["Text"]
                            decoded_chunk = decoded_chunk.replace("\ufffd", "")
                        except Exception as e:
                            logger.warning(
                                "Parsing of Plugin response failed. Response was |%s|. Error was %s", decoded_chunk, e
                            )

                            # If we get a parsing error attempt to extract the Text property even from a broken JSON.
                            pattern = r'"Text": "([^"]+?)"'
                            matches = re.findall(pattern, decoded_chunk)
                            if matches:
                                decoded_chunk = "".join(matches)

                        decoded_chunk = decoded_chunk.replace('"', "'").replace("\n", " ")
                        logger.debug("Plugin decoded chunk : |%s|", decoded_chunk)
                        connection_instance.chunks.append(decoded_chunk)

                else:
                    connection_instance.response = await response.json()
                    connection_instance.is_chunked = False
                    connection_instance.is_starting = False

    except Exception as e:
        logger.warning("Could not connect to fulfillment endpoint=%s. Error %e", url, e)
    finally:
        connection_instance.is_starting = False
        connection_instance.in_progress = False


@action(name="InvokeFulfillmentAction")
async def invoke_fulfillment_action(
    endpoint: str,
    request_type: str = "get",
    request_timeout: Optional[int] = 10,
    context: Optional[dict] = {},
    data: Optional[dict] = {},
    additional_context: Optional[dict] = {},
    **kwargs,
) -> Any:

    request_uuid = await invoke_streaming_fulfillment_action(
        endpoint=endpoint,
        request_type=request_type,
        request_timeout=request_timeout,
        context=context,
        data=data,
        additional_context=additional_context,
        **kwargs,
    )

    if request_uuid:
        await asyncio.sleep(0.1)
        result = await streaming_response_fulfillment_action(endpoint=endpoint, request_id=request_uuid)
        return result
    else:
        return None


@action(name="RetrieveRelevantChunksAction")
async def retrieve_relevant_chunks_action(
    context: Optional[dict] = None,
    kb: Optional[kb.kb.KnowledgeBase] = None,
    query: Optional[str] = None,
):
    """Retrieve relevant knowledge chunks and update the context.

    Args:
        context (Optional[dict]): The context for the execution of the action. Defaults to None.
        kb (Optional[KnowledgeBase]): The KnowledgeBase to search for relevant chunks. Defaults to None.

    Returns:
        The relevant chunks as a single string,

    Note:
        This action retrieves relevant chunks from the KnowledgeBase based on the user's last message
        and updates the context with the information.

    Example:
        ```
        result = await retrieve_relevant_chunks(context=my_context, kb=my_knowledge_base)
        print(result.return_value)  # Relevant chunks as a string
        print(result.context_updates)  # Updated context with relevant chunks
        ```
    """

    user_message = None

    if query:
        user_message = query
    else:
        user_message = context.get("last_user_transcript")

    context_updates = {}

    if user_message and kb:
        # Are these needed two needed?
        context_updates["relevant_chunks"] = ""
        context_updates["relevant_chunks_sep"] = []

        context_updates["retrieved_for"] = user_message

        chunks = [chunk["body"] for chunk in await kb.search_relevant_chunks(user_message)]

        context_updates["relevant_chunks"] = " ".join(chunks)
        context_updates["relevant_chunks_sep"] = chunks

    else:
        logger.warning("No KB is set up, we keep the existing relevant_chunks if we have them.")
        # No KB is set up, we keep the existing relevant_chunks if we have them.
        context_updates["relevant_chunks"] = context.get("relevant_chunks", "") + " "
        context_updates["relevant_chunks_sep"] = context.get("relevant_chunks_sep", [])
        context_updates["retrieved_for"] = None

    return context_updates["relevant_chunks"].replace("\n", " ")


@action(name="InvokeStreamingFulfillmentAction")
async def invoke_streaming_fulfillment_action(
    endpoint: str,
    request_type: str = "get",
    request_timeout: Optional[int] = 10,
    context: Optional[dict] = {},
    data: Optional[dict] = {},
    additional_context: Optional[dict] = {},
    **kwargs,
) -> bool:
    """
    This function is registered as a custom action in Nemoguardrails and is used to call
    ACE Agent plugin REST endpoints from Nemoguardrails Colang flows.
    """
    request_uuid = str(uuid.uuid4())
    logger.info("Starting InvokeFulfillmentAction to endpoint : %s, request_id: %s", endpoint, request_uuid)
    logger.debug("kwargs: %s", kwargs)
    logger.debug("Context: %s", context)

    request_parameters_from_context = ["stream_id", "user_id", "session_id"]

    if context is None:
        return False

    if data is None:
        data = {}

    for c in request_parameters_from_context:
        if c not in context:
            logger.info("%s missing from context, skipping fulfillment request.", c)
            return False

    if not endpoint:
        logger.info("No endpoint for fulfillment action, skipping fulfillment request")
        return False

    if not request_type:
        logger.info("No request type provided in fulfillment action, skipping fulfillment request")
        return False

    request_type = request_type.lower()
    if request_type not in ["post", "get"]:
        logger.info("Invalid http request type provided %s, supported request types are GET/POST", request_type)
        return False

    if additional_context:
        context.update(additional_context)

    url = (
        urljoin(_get_plugin_server_url(invoke_streaming_fulfillment_action.bot.configs.plugin_server_url), endpoint)
        + f"?request_id={request_uuid}"
    )
    params = kwargs
    headers = {"accept": "application/json"}

    # Fill default parameters from context
    for r in request_parameters_from_context:
        params[r] = context[r]

    try:
        if request_type == "post":
            data.update({"context": context})

        asyncio.ensure_future(
            perform_fulfillment_call(
                method=request_type,
                url=url,
                headers=headers,
                params=params,
                data=data,
                timeout=request_timeout,
            )
        )
    except asyncio.TimeoutError:
        logger.info("Http request to plugin server endpoint timed out.")
    except aiohttp.ClientConnectionError:
        logger.info("Failed to establish a connection with plugin server")
    except Exception as e:
        logger.info("An error occurred in http request to plugin server endpoint %s", str(e))

    return request_uuid


@action(name="StreamingResponseFulfillmentAction", execute_async=True)
async def streaming_response_fulfillment_action(
    endpoint: str, request_id: str, pattern: Optional[str] = None, timeout: int = 10
):
    url = (
        urljoin(_get_plugin_server_url(streaming_response_fulfillment_action.bot.configs.plugin_server_url), endpoint)
        + f"?request_id={request_id}"
    )

    if url not in fulfillment_connection_state:
        logger.warning("No connection information for %s. Did you forget to call InvokeFulfillmentAction()?", url)
        return ""

    max_tries = int(timeout / 0.01)
    while fulfillment_connection_state[url].is_starting:
        await asyncio.sleep(0.01)
        max_tries -= 1
        if max_tries < 0:
            logger.warning("Fulfillment connection never started for %s.", url)
            return None

    if fulfillment_connection_state[url].is_chunked:
        partial_response = ""
        while fulfillment_connection_state[url].in_progress or len(fulfillment_connection_state[url].chunks) > 0:
            while len(fulfillment_connection_state[url].chunks) > 0:
                new_chunk = fulfillment_connection_state[url].chunks.popleft()
                logger.debug("Streaming Fulfillment pop chunk from queue: |%s|", new_chunk)
                partial_response += new_chunk
                if pattern is not None:
                    matches = re.findall(pattern, partial_response)
                    if matches:
                        splits = re.split(pattern, partial_response)

                        # Add punctuation marks back to the corresponding split
                        splits = [f"{a}{b}" for a, b in itertools.zip_longest(splits, matches, fillvalue="")]

                        if len(splits) > 0:
                            logger.debug(
                                "Streaming Fulfillment response: pattern did split the last chunk: %s", splits
                            )
                            partial_response = splits[0].strip()
                            fulfillment_connection_state[url].chunks.extendleft(reversed(splits[1:]))

                        response = partial_response
                        logger.debug("Streaming Fulfillment response: %s", response)
                        return response
            await asyncio.sleep(0.1)

        if len(partial_response) > 0:
            response = partial_response.strip()
            logger.debug("Streaming Fulfillment response (no data): %s", response)
            return response
        else:
            return None
    else:
        return fulfillment_connection_state[url].response


def create_chat_history(events):
    """
    Create Chat history using NemoGuardrails event"
    """
    CHAT_HISTORY_EVENTS = [
        "PartialUserUtteranceAvailable",
        "StartUtteranceBotAction",
        "UtteranceUserActionFinished",
        "UtteranceBotActionStarted",
    ]
    messages = []
    action_mapping = {}
    bot_response_mapping = {}
    for event in events:
        if not isinstance(event, InternalEvent) and event["type"] in CHAT_HISTORY_EVENTS:
            if event["type"] == "UtteranceUserActionFinished" and event["action_uid"] not in action_mapping:
                messages.append({"role": "user", "content": event["final_transcript"]})
                action_mapping[event["action_uid"]] = len(messages) - 1
            elif (
                event["type"] == "PartialUserUtteranceAvailable"
                and event["utterance_action_uid"] not in action_mapping
            ):
                messages.append({"role": "user", "content": event["transcript"]})
                action_mapping[event["utterance_action_uid"]] = len(messages) - 1
            elif (
                event["type"] == "PartialUserUtteranceAvailable"
                and messages[action_mapping[event["utterance_action_uid"]]]["content"] != event["transcript"]
            ):
                messages = messages[: action_mapping[event["utterance_action_uid"]]]
                messages.append({"role": "user", "content": event["transcript"]})
                action_mapping[event["utterance_action_uid"]] = len(messages) - 1
            elif event["type"] == "StartUtteranceBotAction" and event["action_uid"] not in action_mapping:
                bot_response_mapping[event["action_uid"]] = {"role": "assistant", "content": event["script"]}
            elif event["type"] == "UtteranceBotActionStarted" and event["action_uid"] in bot_response_mapping:
                messages.append(bot_response_mapping[event["action_uid"]])
                action_mapping[event["action_uid"]] = len(messages) - 1
    return messages[:-1]


@action(name="InvokeStreamingChatAction")
async def invoke_streaming_chat_action(
    events: List,
    question: str,
    endpoint: Optional[str],
    chat_history=False,
    request_timeout: Optional[int] = 20,
    context: Optional[dict] = {},
) -> bool:
    """
    This function is registered as a custom action in Nemoguardrails and is used to call
    a Plugin Server Chat endpoint from Nemoguardrails Colang flows.
    """

    if not question:
        logger.warning("Empty question in InvokeStreamingChatAction.")
        return False

    request_json = {
        "Query": question,
        "UserId": context.get("user_id"),
        "Metadata": {"StreamId": context.get("stream_id", ""), "SessionId": context.get("session_id", "")},
    }
    if chat_history:
        request_json["Metadata"]["ChatHistory"] = create_chat_history(events=events)

    return await invoke_streaming_fulfillment_action(
        endpoint=endpoint,
        request_type="post",
        request_timeout=request_timeout,
        context=context,
        data=request_json,
    )


@action(name="StreamingResponseChatAction", execute_async=True)
async def streaming_response_chat_action(
    endpoint: str, request_id: str, pattern: Optional[str] = None, timeout: int = 10
):
    if pattern is None:
        pattern = r"(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<![0-9]\.)(?<![A-Z]\.)(?<=\.|\?|\!)\s"
    return await streaming_response_fulfillment_action(
        endpoint, request_id=request_id, pattern=pattern, timeout=timeout
    )


@action(name="ResetAction")
async def reset_action_colang_2(memory: str = "shortterm", context: Optional[dict] = {}) -> None:
    """
    Reset the slots, chat history, event history and/or create a new session ID based on the memory type
    """
    user_id = context.get("user_id")
    request_id = context.get("event_id") if context.get("event_id") else context.get("query_id")
    user = Core.fetch_user_data(user_id, request_id)
    user.reset_user_memory = memory
