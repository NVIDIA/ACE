import logging
import uuid
from typing import List, Optional

from chat_engine.nlp.embedding_search import EmbeddingSearch, StoreType
from nemoguardrails.embeddings.index import EmbeddingsIndex, IndexItem
from chat_engine.constants import NLU_EMBEDDING_CREATE

logger = logging.getLogger("chat_engine")


class NlpServer(EmbeddingsIndex):
    create_store: Optional[str] = None
    search_path: Optional[str] = None

    def __init__(self, model: str = ""):
        self.model = model
        # append with any char as milvus doesn't allow number as first char
        # associate unique id to create store name to make search request for created obj
        self.uuid: str = f"a{uuid.uuid4()}".replace("-", "")
        self._embedding_search = EmbeddingSearch(bot=self.bot)

    async def add_item(self, item: IndexItem):
        """Adds a new item to the index."""

        # TODO: Expose `add_item` interface, currently NlpServer
        # doesn't have ability to add item once already added
        # NG doesn't use this API directly right now. Once they
        # start using it we need to update it
        pass

    async def add_items(self, item: List[IndexItem]):
        """Adds multiple items to the index."""
        anchors = []
        for i in item:
            anchors.append({"text": i.text, "metadata": i.meta})

        logger.info(f"Creating index in nlp server with id {self.uuid}")
        # We register a callback with health monitor to call this method asynchronously
        self.bot.health_monitor.register_callback(
            fn=self._embedding_search.build_index,
            task_name=NLU_EMBEDDING_CREATE,
            kwargs={
                "store_name": self.uuid,
                "anchors": anchors,
                "store_type": StoreType.NEMOGUARDRAILS_FLOW,
            },
        )

    async def search(self, text: str, max_results: int) -> List[IndexItem]:
        """Searches the index for the closes matches to the provided text."""

        results = []
        try:
            logger.debug(f"Using NLP server embedding store to search for match")
            resp = await self._embedding_search.search(
                text=text,
                top_k=max_results,
                store_name=[self.uuid],
            )
        except Exception as e:
            logger.info(f"Exception {e} while searching match of {text}")

        for r in resp:
            results.append(IndexItem(text=r.get("text"), meta=r.get("metadata")))

        return results
