# Copyright(c) 2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
chat engine policy manager module which execute various supported policies
and finds out appropriate action corresponding to a user query
"""
import logging

from chat_engine.core.userdata import UserData
from chat_engine import Bot
from chat_engine.constants import POLICY_DIALOG
from typing import Optional, List, Any

logger = logging.getLogger("chat_engine")


class PolicyManager:
    """Factory class for initializing and accessing different Policies for a given bot"""

    def __init__(self, bot: Bot):
        """Initialize all registered policies."""

        self.bot = bot
        self._registered_policies = self.__register_policies()

        self._cls_mapping = {cls.name: cls() for cls in self._registered_policies}

        for policy_obj in self._cls_mapping.values():
            policy_obj.set_bot(bot)

        logger.info(f"Registered policies for bot: {self.bot.name}: {[pol.name for pol in self._registered_policies]}")

    async def initialize(self, policy_name: Optional[str] = "", **kwargs):
        if policy_name == "":
            for pol in self._cls_mapping:
                await self._cls_mapping.get(pol).initialize(**kwargs)
        else:
            if policy_name not in self._cls_mapping:
                logger.warning(
                    f"Policy {policy_name} is not registered for bot: {self.bot.name}. Please provide relevant policy files in bot directory and restart the bot."
                )
                return
            await self._cls_mapping.get(policy_name).initialize(**kwargs)

    async def run(self, policy_name: str, user_data: UserData, **kwargs):
        if policy_name not in self._cls_mapping:
            logger.warning(
                f"Policy {policy_name} is not registered for bot: {self.bot.name}. Please provide relevant policy files in bot directory and restart the bot."
            )
            return
        await self._cls_mapping.get(policy_name).run(user_data, **kwargs)

    def __register_policies(self) -> List[Any]:
        """Imports the relevant policy classes based on the bot configs and returns the list of classes"""

        registered_policies = []

        # TODO: Write a check for colang files
        if self.bot.colang_configs is not None:
            from chat_engine.policies.dialog_policy import DialogPolicy

            registered_policies.append(DialogPolicy)

        return registered_policies

    async def execute(self, user_data: UserData):
        """Executes the policies in a given sequence based on registered policies"""

        # If partial response is present skip policy and send next chunk
        if user_data.partial_response.active and user_data.partial_response.chunk_idx:
            return

        logger.debug(f"Executing policies for bot: {self.bot.name}")

        if POLICY_DIALOG in self._cls_mapping:
            await self.run(POLICY_DIALOG, user_data)

        if user_data.response.ready:
            logger.debug(f"Valid response found be executing: {POLICY_DIALOG}.")
            return
