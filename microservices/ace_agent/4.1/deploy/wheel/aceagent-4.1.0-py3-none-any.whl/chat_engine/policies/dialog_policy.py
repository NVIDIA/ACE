# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

"""
    Dialog Policy which uses colang runtime to execute a bot
"""

import logging
import traceback
from typing import Optional, Any

from chat_engine.policies.policy_base import PolicyBase
from chat_engine.constants import (
    POLICY_DIALOG,
    DST_HISTORY_COUNT,
    NLU_EMBEDDING_CREATE,
    NG_EVENT_HISTORY_COUNT,
    PROCESSOR_POSTPROCESSED,
    EVENT_NO_MATCH,
)
from chat_engine.core.userdata import UserData
from chat_engine.nlp.embedding_search import EmbeddingSearch, StoreType
from chat_engine.policies.actions.custom_actions import *
from chat_engine.policies.actions.generate_user_intent import generate_user_intent
from chat_engine.policies.actions.generate_bot_message import generate_bot_message
from chat_engine.policies.actions.generate_next_steps import generate_next_step
from chat_engine.policies.utils import get_system_slots, stream_json
from chat_engine.policies.actions.colang2_actions import (
    streaming_response_fulfillment_action,
    generate_intent_then_slots_action,
    invoke_fulfillment_action,
    invoke_streaming_fulfillment_action,
    invoke_streaming_chat_action,
    streaming_response_chat_action,
    reset_action_colang_2,
    retrieve_relevant_chunks_action,
)
from chat_engine.policies.embedding_search_providers import nlp_server
from nemoguardrails import LLMRails
from nemoguardrails.embeddings.index import IndexItem
from nemoguardrails.actions.llm.utils import flow_to_colang
from nemoguardrails.actions.llm.generation import LLMGenerationActions
from nemoguardrails.utils import new_event_dict, new_uuid
from nemoguardrails.context import streaming_handler_var
from nemoguardrails.llm.providers import register_llm_provider

from chat_engine.policies.llm_wrappers.nvidia_ai_endpoints import Nvidia_Endpoints

logger = logging.getLogger("chat_engine")


class DialogPolicy(PolicyBase):
    name: str = POLICY_DIALOG

    # Action details that will be registered with colang runtime
    action_mapping = {
        "plugin": fulfillment_action,
        "ner": ner_action,
        "eqa": eqa_action,
        "text_classifier": text_classifier_action,
        "reset": reset_action,
        "generate_user_intent": generate_user_intent,
        "generate_bot_message": generate_bot_message,
        "generate_next_step": generate_next_step,
        "chat_plugin": chat_plugin,
        # Add actions for Colang 2.0
        generate_intent_then_slots_action.action_meta["name"]: generate_intent_then_slots_action,
        invoke_fulfillment_action.action_meta["name"]: invoke_fulfillment_action,
        streaming_response_fulfillment_action.action_meta["name"]: streaming_response_fulfillment_action,
        invoke_streaming_fulfillment_action.action_meta["name"]: invoke_streaming_fulfillment_action,
        invoke_streaming_chat_action.action_meta["name"]: invoke_streaming_chat_action,
        streaming_response_chat_action.action_meta["name"]: streaming_response_chat_action,
        reset_action_colang_2.action_meta["name"]: reset_action_colang_2,
        retrieve_relevant_chunks_action.action_meta["name"]: retrieve_relevant_chunks_action,
    }

    llm_wrapper_mapping = {"nvidia-ai-endpoints": Nvidia_Endpoints}

    # embedding search provider mapping that will be registered with colang runtime
    embedding_search_provider = {"nlp-server": nlp_server.NlpServer}

    async def initialize(self):
        self._ready = False
        self._rails = {}
        self._actions = {}
        self.llm_model_available = False

        # Override `is_cuda_available` to always return false to use CPU when started with DM
        import torch

        def is_cuda_available():
            return False

        torch.cuda.is_available = is_cuda_available

        # Skip registering certain actions if specified in config
        if not self.bot.configs.register_ace_agent_intent_generation:
            del self.action_mapping["generate_user_intent"]
        if not self.bot.configs.register_ace_agent_next_step_generation:
            del self.action_mapping["generate_next_step"]
        if not self.bot.configs.register_ace_agent_bot_message_generation:
            del self.action_mapping["generate_bot_message"]

        # Register all dm's llm wrapper with colang runtime
        for name, wrapper in DialogPolicy.llm_wrapper_mapping.items():
            register_llm_provider(name, wrapper)
            wrapper.bot = self.bot

        # WAR: Embedding Search gets initialized with LLMRails, update it's embedding_search_provider
        # register custom embedding search provider from ACE Agent
        self.register_embedding_search_provider()

        # Create the rails instance based on the parsed colang configs
        rail = LLMRails(self.bot.colang_configs)

        if self.bot.streaming and rail.config.models and not rail.config.streaming_supported:
            logger.warning(f"Streaming is not supported for {self.bot.name} bot. Switching to non-streaming mode.")
            self.bot.streaming = False

        # Register all system actions with colang runtime
        for name, fn in DialogPolicy.action_mapping.items():
            rail.register_action(fn, name=name)

        # Disable asynchronous (in the colang sense) execution of Python actions
        if self.bot.configs.colang_disable_async_execution:
            logger.info(
                "Async Colang action execution has been disabled by the config `colang_disable_async_execution`"
            )

        self._rails = rail

        # TODO: Use existing generate actions from rails instead creating new
        # This instance will be used to call LLM engine of colang runtime
        self._actions = LLMGenerationActions(
            config=rail.config,
            llm=rail.llm,
            llm_task_manager=rail.runtime.llm_task_manager,
            get_embedding_search_provider_instance=rail._get_embeddings_search_provider_instance,
            verbose=rail.verbose,
        )

        # If LLM model configurations are available in colang configs we set this flag to true
        if len(rail.config.models) > 0:
            self.llm_model_available = True

        logger.debug(f"Initialized colang runtime.")

        # Build the embeddings data store for the colang files
        await self.build_embedding_index()
        self._ready = True

    async def run(self, user: UserData):
        """Executes the rails specified in the bot and stores the result in user.response"""

        if not self._ready:
            logger.error(
                "Bypassing colang runtime call as there was some error during initialization. Please check the initialization logs."
            )
            return

        # Pass the bot and rails to all registered actions so that they can use them if invoked from colang runtime
        for fn in DialogPolicy.action_mapping.values():
            fn.bot = self.bot
            fn.policy_instance = self
            fn.rails = self._rails
            fn.user_data = user
            fn.configs = self.bot.colang_configs

        # Get existing conversation chat & event history from dialog state
        event_history = user.dialog_state[user.user_id].event_history.get(self.bot.name, [])
        chat_history = user.dialog_state[user.user_id].chat_history.get(self.bot.name, [])
        guardrails_state = user.dialog_state[user.user_id].guardrails_state.get(self.bot.name, None)

        input_events = []
        # We check if a custom event is present. events can be json string or just the event name string
        # We first check if its a json str, if yes, we parse it and send the event dict as it is to Nemoguardrails
        # If its just the event name str, we create a events dict with the received event name and send the dict to Nemoguardrails
        is_using_event_interface = False
        if user.event != EVENT_NO_MATCH and len(user.event) > 0:
            if user.event == "umim_event":
                input_events.append(user.metadata)
                is_using_event_interface = user.metadata.get("tags", {"is_using_event_interface": True}).get(
                    "is_using_event_interface", True
                )
            else:
                input_events.append(new_event_dict(user.event, **user.metadata))

        elif user.user_query:
            if user.request_language != user.language:
                query = user.processed_query[PROCESSOR_POSTPROCESSED]
            else:
                query = user.user_query
            started_event = new_event_dict(
                "UtteranceUserActionStarted",
                source_uid="user_query",
                action_uid=new_uuid(),
            )
            finished_event = new_event_dict(
                "UtteranceUserActionFinished",
                final_transcript=query,
                source_uid="user_query",
                is_success=True,
                action_uid=new_uuid(),
            )
            input_events.extend([started_event, finished_event])
            chat_history.append({"role": "user", "content": user.user_query})
            user.dialog_state[user.user_id].chat_history[self.bot.name] = chat_history

        if len(input_events) == 0:
            logger.warning("No valid query or event found to be processed. Skipping policy execution.")
            return

        # Append system slots and user parameters into colang context
        user_parameter_update = {"type": "ContextUpdate", "data": user.params}
        system_parameter_update = {"type": "ContextUpdate", "data": get_system_slots(self.bot.name, user)}
        event_history.extend([user_parameter_update, system_parameter_update])

        new_events = []
        while len(input_events) > 0:
            events = list(input_events)
            input_events = []
            # We append the newly created events to event history
            event_history.extend(events)

            try:
                if self.bot.configs.use_stateful_guardrails:
                    # If we get a tick event only call nemoguardrails with an empty event list (to give processing time)
                    if (
                        len(events) == 1
                        and events[0].get("type", "") == "CustomEvent"
                        and events[0].get("name", "") == "ace_agent_tick"
                    ):
                        output_events, new_state = await self._rails.process_events_async(
                            [],
                            guardrails_state,
                            blocking=self.bot.configs.colang_disable_async_execution,
                        )
                    else:
                        output_events, new_state = await self._rails.process_events_async(
                            [user_parameter_update, system_parameter_update] + events,
                            guardrails_state,
                            blocking=self.bot.configs.colang_disable_async_execution,
                        )
                    user.dialog_state[user.user_id].guardrails_state[self.bot.name] = new_state
                    guardrails_state = new_state
                elif self.bot.streaming and user.streaming_handler:
                    streaming_handler_var.set(user.colang_streaming_handler)
                    user.stream_handler_task = asyncio.create_task(stream_json(user))
                    output_events = await self._rails.generate_events_async(events=event_history)
                else:
                    output_events = await self._rails.generate_events_async(events=event_history)

                if output_events:
                    new_events.extend(output_events)

                if not is_using_event_interface:
                    for e in output_events:
                        if e["type"] == "StartUtteranceBotAction":
                            input_events.append(
                                new_event_dict(
                                    "UtteranceBotActionFinished",
                                    final_script=e["script"],
                                    source_uid="ace_agent_chat_engine",
                                    is_success=True,
                                    action_uid=e["action_uid"],
                                )
                            )

            except Exception as e:
                logger.debug(
                    f"Exception occurred while trying to get the response: {''.join(traceback.TracebackException.from_exception(e).format())}"
                )

        # Update chat history and store back in dialog state
        if new_events:
            user.current_events = new_events
            event_history.extend(new_events)
            last_bot_utterance = self.get_last_bot_utterance(event_history)

            if last_bot_utterance is not None:
                last_bot_utterance = self.clean_string(last_bot_utterance)
                chat_history.append({"role": "assistant", "content": last_bot_utterance})

            bot_utterances = []
            for event in new_events:
                if event["type"] == "StartUtteranceBotAction":
                    # Check if we need to remove a message
                    if event["script"] == "(remove last message)":
                        bot_utterances = bot_utterances[0:-1]
                    else:
                        bot_utterances.append(event["script"])

            if len(bot_utterances) > 0:
                bot_utterances = [self.clean_string(utterance) for utterance in bot_utterances]
                user.response.text = "\n".join(bot_utterances)
                user.response.ready = True

                # Final fallback response for streaming.
                # This message will only be shared if response was not formed by generate_bot_message()
                if (
                    self.bot.streaming
                    and user.colang_streaming_handler
                    and not user.colang_streaming_handler.streaming_finished_event.is_set()
                ):
                    await user.colang_streaming_handler.push_chunk(user.response.text)
                    await user.colang_streaming_handler.push_chunk(None)

            user.response.events = new_events
        else:
            user.current_events = []
            user.response.events = []

        # Deleting parts of the event history causes crashes in nemoguardrails, if this is required we need a more robust way to do it
        if len(chat_history) > DST_HISTORY_COUNT:
            del chat_history[: len(chat_history) - DST_HISTORY_COUNT]

        if len(event_history) > NG_EVENT_HISTORY_COUNT:
            del event_history[: len(event_history) - NG_EVENT_HISTORY_COUNT]

        nlu_result = user.dialog_state[user.user_id].nlu_result
        if len(nlu_result) > DST_HISTORY_COUNT:
            del nlu_result[: len(nlu_result) - DST_HISTORY_COUNT]

        user.dialog_state[user.user_id].event_history[self.bot.name] = event_history
        user.dialog_state[user.user_id].chat_history[self.bot.name] = chat_history

    def get_last_bot_utterance(self, events: List[dict]):
        """Returns the last bot utterance event from the Nemoguardrails events."""
        for event in reversed(events):
            if event["type"] == "StartUtteranceBotAction":
                return event["script"]
        return None

    def register_embedding_search_provider(self):
        """
        Override `_get_embeddings_search_provider_instance` method of LLMRails to register
        custom embedding search provider by ACE Agent
        """
        # Add bot instance to embedding search providers
        for name, wrapper in DialogPolicy.embedding_search_provider.items():
            wrapper.bot = self.bot

        # Keep a copy of LLMRails `_get_embeddings_search_provider_instance` implementation
        llmrails_esp_instance = LLMRails._get_embeddings_search_provider_instance

        def get_embeddings_search_provider_instance(llmrails, *args, **kwargs):
            """Overidden implementation for nemoguardrails.rails.llm.llmrails.LLMRails
            `_get_embeddings_search_provider_instance` method to make sure ACE Agent's custom embedding
            serach provider are present in embedding_search_providers dict
            """
            logger.debug("Executing LLMRails _get_embeddings_search_provider_instance from ACE Agent")
            # TODO: Explore other ways to register embedding search provider as this will be called multiple times
            # Register embedding search provider from ACE Agent if not present
            for name, wrapper in self.embedding_search_provider.items():
                if name not in llmrails.embedding_search_providers:
                    logger.info(f"Registering {name} as embedding search provider in NeMo Guardrails")
                    llmrails.embedding_search_providers[name] = wrapper

            # Call _get_embeddings_search_provider_instance from nemoguardrails
            return llmrails_esp_instance(llmrails, *args, **kwargs)

        # Updating existing implementation of LLMRails `_get_embeddings_search_provider_instance`
        LLMRails._get_embeddings_search_provider_instance = get_embeddings_search_provider_instance

    def clean_string(self, input_str):
        input_str = input_str.replace("\\n", "\n")
        lines = input_str.strip().split("\n")
        cleaned_lines = [line.strip() for line in lines if line.strip()]
        return "\n".join(cleaned_lines)

    """
    -------------------------------------------------------------------------------------------------
    Public methods for embeddings generation and search used by all system actions.
    -------------------------------------------------------------------------------------------------
    """

    async def build_embedding_index(self):
        """Generate embeddings for user message, bot message and flows"""

        self.use_embedding_search = True  # True = Use NLP server's embedding search
        self.embedding_search = None
        self.user_message_index = None
        self.bot_message_index = None
        self.flows_index = None
        self.embedding_search = EmbeddingSearch(bot=self.bot)

        # If embedding model is deployed this will be initialized else set to None
        embedding_create_endpoint = self.bot.health_monitor.get_nlp_endpoint(NLU_EMBEDDING_CREATE)
        if embedding_create_endpoint is not None:
            logger.debug(
                f"Intializing embeddings for bot: {self.bot.name}.. Using the embedding endpoint of NLP server for embedding generation as it is available."
            )
        else:
            logger.info(
                f"No deployed embedding model found behind NLP server. Initializing local embedding search pipeline."
            )
            self.use_embedding_search = False
            self.user_message_index = self._rails._get_embeddings_search_provider_instance(
                self._rails.config.core.embedding_search_provider
            )
            self.bot_message_index = self._rails._get_embeddings_search_provider_instance(
                self._rails.config.core.embedding_search_provider
            )
            self.flows_index = self._rails._get_embeddings_search_provider_instance(
                self._rails.config.core.embedding_search_provider
            )

        if self._rails.config.colang_version != "2.x":
            logger.debug(f"Generating embeddings for bot {self.bot.name} now.. This may take a while.")
            await self.__generate_user_message_index()
            await self.__generate_bot_message_index()
            await self.__generate_flows_index()

    async def search_user_embedding_index(self, query: str, confidence_threshold: Optional[float]) -> Any:
        """Search similar user query from embedding index"""

        results = []

        if self.skip_user_message_search:
            logger.info(f"No data store found for user messages. Skipping search.")
            return results

        # If NLP server is not available use Sentence transformer
        if self.embedding_search._user_store_available:
            logger.debug(f"Using NLP server embedding store for user messages..")
            results = await self.embedding_search.search(
                text=query,
                top_k=5,
                store_name=[f"{self.bot.name}_user_message"],
            )
            if confidence_threshold is not None:
                results = [r for r in results if r.get("confidence_score") >= confidence_threshold]
        else:
            results = (
                await self.user_message_index.search(text=query, max_results=5)
                if self.user_message_index is not None
                else None
            )

        return results

    async def search_bot_embedding_index(self, query: str, confidence_threshold: Optional[float]) -> Any:
        """Search similar bot message from embedding index"""

        results = []

        if self.skip_bot_message_search:
            logger.info(f"No data store found for user messages. Skipping search.")
            return results

        # If NLP server is not available use Sentence transformer
        if self.embedding_search._bot_store_available:
            logger.debug(f"Using NLP server embedding store for bot messages..")
            results = await self.embedding_search.search(
                text=query,
                top_k=5,
                store_name=[f"{self.bot.name}_bot_message"],
            )
            if confidence_threshold is not None:
                results = [r for r in results if r.get("confidence_score") >= confidence_threshold]
        else:
            results = (
                await self.bot_message_index.search(text=query, max_results=5)
                if self.bot_message_index is not None
                else None
            )

        return results

    async def search_flows_embedding_index(self, query: str, confidence_threshold: Optional[float]) -> Any:
        """Search similar user query from embedding index"""
        results = None
        # If NLP server is not available use Sentence transformer
        if self.embedding_search._flow_store_available:
            logger.debug(f"Using NLP server embedding store for flows..")
            results = await self.embedding_search.search(
                text=query, top_k=5, store_name=[f"{self.bot.name}_flow_index"]
            )
            if confidence_threshold is not None:
                results = [r for r in results if r.get("confidence_score") >= confidence_threshold]
        else:
            results = (
                await self.flows_index.search(text=query, max_results=5) if self.flows_index is not None else None
            )

        return results

    async def get_embedding_index_user_intent(self, embedding_search_results) -> str:
        """return user intent from embedding api result"""
        if embedding_search_results and len(embedding_search_results) > 0:
            if self.embedding_search._user_store_available:
                return embedding_search_results[0].get("metadata", {}).get("intent", "")
            else:
                return embedding_search_results[0].meta.get("intent", "")
        else:
            return ""

    async def get_embedding_index_bot_message(self, embedding_search_results) -> str:
        """return user intent from embedding api result"""
        if embedding_search_results and len(embedding_search_results) > 0:
            if self.embedding_search._bot_store_available:
                return embedding_search_results[0].get("metadata", {}).get("text", "")
            else:
                return embedding_search_results[0].meta.get("text", "")
        else:
            return ""

    async def get_embedding_index_flows_message(self, embedding_search_results) -> str:
        """return user intent from embedding api result"""
        if embedding_search_results and len(embedding_search_results) > 0:
            if self.embedding_search._flow_store_available:
                return embedding_search_results[0].get("metadata", {}).get("flow", "")
            else:
                return embedding_search_results[0].meta.get("flow", "")
        else:
            return ""

    """
    -------------------------------------------------------------------------------------------------
    Helper methods to build embeddings during initialization.
    These needs to be recalled if NLP server indicates that embedding endpoints are up during runtime.
    -------------------------------------------------------------------------------------------------
    """

    async def __generate_user_message_index(self):
        """
        Build index for user message
        If nlp server has embedding search api then use nlp search
        otherwise fallback to ng llm generation
        """
        logger.debug("Generating index for user message")
        items = []
        items_ng = []
        self.skip_user_message_search = False

        for intent, utterances in self._rails.config.user_messages.items():
            for text in utterances:
                # Store in two separate list for BuildIndex and EmbeddingSearch
                # so we don't have to iterate over same data again
                items.append({"text": text, "metadata": {"intent": intent}})  # This is for NLP server based embedding
                items_ng.append(
                    IndexItem(text=text, meta={"intent": intent})
                )  # This is for nemoguardrails based embedded

        # If we have no patterns, we stop.
        if len(items) == 0:
            self.skip_user_message_search = True
            return

        # We register a callback with health monitor to call this method asynchronously
        self.bot.health_monitor.register_callback(
            fn=self.embedding_search.build_index,
            task_name=NLU_EMBEDDING_CREATE,
            kwargs={
                "store_name": f"{self.bot.name}_user_message",
                "anchors": items,
                "store_type": StoreType.USER_MESSAGE,
            },
        )

        # If embedding search api is not up in nlp server fallback to NG
        if not self.use_embedding_search:
            logger.info("Unable to build embedding on NLP Server using NG Search instead")
            await self.user_message_index.add_items(items_ng)
            await self.user_message_index.build()

    async def __generate_bot_message_index(self):
        """
        Build index for bot message
        If nlp server has embedding search api then use nlp search
        otherwise fallback to ng llm generation from ng
        """
        logger.debug("Generating index for bot message")
        items = []
        items_ng = []
        self.skip_bot_message_search = False

        for intent, utterances in self._rails.config.bot_messages.items():
            for text in utterances:
                # Store in two separate list for BuildIndex and EmbeddingSearch
                # so we don't have to iterate over same data again
                items.append({"text": intent, "metadata": {"text": text}})
                items_ng.append(IndexItem(text=intent, meta={"text": text}))

        # If we have no patterns, we stop.
        if len(items) == 0:
            self.skip_bot_message_search = True
            return

        # We register a callback with health monitor to call this method asynchronously
        self.bot.health_monitor.register_callback(
            fn=self.embedding_search.build_index,
            task_name=NLU_EMBEDDING_CREATE,
            kwargs={
                "store_name": f"{self.bot.name}_bot_message",
                "anchors": items,
                "store_type": StoreType.BOT_MESSAGE,
            },
        )

        # If embedding search api is not up in nlp server fallback to NG
        if not self.use_embedding_search:
            logger.info("Unable to build embedding bot message on NLP Server using NG Search instead")
            await self.bot_message_index.add_items(items_ng)
            await self.bot_message_index.build()

    async def __generate_flows_index(self):
        """
        Build index for flows
        If nlp server has embedding search api then use nlp search
        otherwise fallback to ng llm generation from ng
        """

        logger.debug("Generating index for flows")
        items = []
        items_ng = []
        self.skip_flows_search = False

        for flow in self._rails.config.flows:
            # We don't include the default system flows in the index because we don't want
            # the LLM to predict system actions.
            if flow.get("id") in [
                "generate user intent",
                "generate next step",
                "generate bot message",
            ]:
                continue

            colang_flow = flow.get("source_code") or flow_to_colang(flow)

            # We index on the full body for now
            items.append({"text": colang_flow, "metadata": {"flow": colang_flow}})
            items_ng.append(IndexItem(text=colang_flow, meta={"flow": colang_flow}))

        # If we have no patterns, we stop.
        if len(items) == 0:
            self.skip_flows_search = True
            return

        # We register a callback with health monitor to call this method asynchronously
        self.bot.health_monitor.register_callback(
            fn=self.embedding_search.build_index,
            task_name=NLU_EMBEDDING_CREATE,
            kwargs={
                "store_name": f"{self.bot.name}_flow_index",
                "anchors": items,
                "store_type": StoreType.FLOW_MESSAGE,
            },
        )

        # If embedding search api is not up in nlp server fallback to NG
        if not self.use_embedding_search:
            logger.info("Unable to build embedding flows on NLP Server using NG Search instead")
            await self.flows_index.add_items(items_ng)
            await self.flows_index.build()
