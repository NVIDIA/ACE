# Copyright(c) 2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
    -------------------------------------------------------------------------------------------------------------
    This module contains methods called from core to carry out pre and postprocessing of DM request and response
    -------------------------------------------------------------------------------------------------------------
"""

import re
import nltk
import logging
import anyascii
from lxml import etree
from uuid import uuid4
from time import time
from datetime import datetime, timezone

from chat_engine import Bot
from chat_engine.constants import (
    PROCESSOR_PREPROCESSED,
    PROCESSOR_POSTPROCESSED,
    CONTRACTION_DICT,
    CUSTOM_INTENT_RESET,
    CUSTOM_DOMAIN,
    MAX_RESPONSE_TEXT_LENGTH,
    ENABLE_RESPONSE_SPLIT,
    EVENT_NO_MATCH,
    NLU_MACHINE_TRANSLATION_INPUT,
    NLU_MACHINE_TRANSLATION_OUTPUT,
)
from chat_engine.core.userdata import UserData, FormInfo
from chat_engine.nlp.machine_translator import MachineTranslator
from typing import Dict, Any

logger = logging.getLogger("chat_engine")

# Download nltk punkt for sentence tokenizer
nltk.download("punkt")
nltk.download("punkt_tab")


async def preprocess_user_request(request: Dict[str, Any], bot: Bot, user_data: UserData) -> None:
    """Carry out all prebuilt DM preprocessings and
    call all enabled pre processing blocks.
    Returns the userdata after creating it from the request json"""

    await __preprocess_user_request(request, bot, user_data)
    user_data.processed_query[PROCESSOR_POSTPROCESSED] = user_data.processed_query[
        PROCESSOR_PREPROCESSED
    ]  # initializing post processed query with pre processed query
    logger.debug(
        f"Found defined processor: {PROCESSOR_PREPROCESSED}, Processed Query: {user_data.processed_query[PROCESSOR_PREPROCESSED]}"
    )


async def postprocess_dm_response(bot: Bot, user_data: UserData) -> None:
    """Carry out all prebuilt DM postprocessings and call
    all enabled post processing
    1. Calls machine translation service if needed
    2. Update the dialog state
    """

    # Send out empty string as response to avoid better handling for other modules
    if user_data.response.text == None:
        user_data.response.text = ""

    if bot.configs.remove_incomplete_sentences:
        # Remove incomplete sentences
        sentences = nltk.tokenize.sent_tokenize(user_data.response.text)
        # If the last character of the last sentence is not a punctuation mark
        if len(sentences) and sentences[-1][-1] not in [".", "?", "!"]:
            logger.info(
                f"An incomplete sentence was returned by chat engine. Removing the last sentence. Full list of sentences returned were: {sentences}"
            )
            del sentences[-1]
        user_data.response.text = " ".join(sentences)

    # Translate outgoing language of Response-> Text if needed
    if user_data.language != user_data.response_language:
        model_name = ""
        for model_config in bot.nlp_model_configs:
            if model_config.task_name == NLU_MACHINE_TRANSLATION_OUTPUT:
                logger.info(f"Using {model_config.model_name} for output NMT")
                model_name = model_config.model_name
        if not model_name:
            raise ValueError(f"Output NMT model name is missing. Please specify it in the bot config under nlp_models")

        start = time()
        target_text = await __translate_text(
            bot,
            user_data.response.text,
            model_name,
            src_lang=user_data.language,
            tar_lang=user_data.response_language,
        )
        user_data.latency.nlu_machine_translation += time() - start
        if target_text:
            logger.info(f"Translated user response text: {target_text}")
            user_data.response.text = target_text
        else:
            logger.info(
                "Translation service returned no response or is not enabled in bot config file. "
                f"Returning response in DM processed language.."
            )

    # Add the voice name SSML tag to response if available
    if bot.configs.voice_name != "" and user_data.response.text != "":
        user_data.response.text = "<speak>" + user_data.response.text + "</speak>"
        try:
            root = etree.fromstring(user_data.response.text)
            # Check if root tag is "speak"
            if root.tag == "speak":
                voice_elem = etree.Element("voice", name=bot.configs.voice_name)
                root.append(voice_elem)
                user_data.response.text = etree.tostring(root, encoding="unicode")
            else:
                logger.info(f"Root element must be <speak> in the SSML string: {user_data.response.text}")
        except etree.XMLSyntaxError as e:
            logger.info(f"Could not parse SSML tags from response text with exception: {e}")

    # Formulate cleaned up text after removing SSML tags
    user_data.response.cleaned_text = re.sub(re.compile("<.*?>"), "", user_data.response.text)
    logger.debug(
        f"Cleaned up response text after markdown language tags removal is: {user_data.response.cleaned_text}"
    )
    user_data.last_response_time = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")

    for event in user_data.response.events:
        if event["type"] == "StartUtteranceBotAction":
            event["script"] = user_data.response.cleaned_text

    # Enable response split from chat_engine/constants.py directly
    if ENABLE_RESPONSE_SPLIT:
        # If user has partial response to send it will skip policy execution
        # and move here, we check if partial response is present update index
        # and send the next chunk
        if user_data.partial_response.active:
            # Set next chunk as response text and set chunk index to next chunk
            user_data.response.text = user_data.partial_response.chunks[user_data.partial_response.chunk_idx]
            user_data.response.cleaned_text = user_data.partial_response.chunks[user_data.partial_response.chunk_idx]
            user_data.partial_response.chunk_idx += 1
            if user_data.partial_response.chunk_idx >= len(user_data.partial_response.chunks):
                # Deactivate partial response flag when all chunks are send
                user_data.partial_response.active = False
                user_data.response.is_partial_response = False
            else:
                user_data.partial_response.active = True
                user_data.response.is_partial_response = True
            return

        # If response is for bot controller and longer than max response size divide it into chunk
        # stream_id is used to identify request is from chat-controller
        if user_data.stream_id != "" and len(user_data.response.text) > MAX_RESPONSE_TEXT_LENGTH:
            logger.debug("Splitting response into smaller chunck")
            user_data.partial_response.chunks = __split_text(user_data.response.text)
            user_data.response.text = user_data.partial_response.chunks[0]
            user_data.response.cleaned_text = user_data.partial_response.chunks[0]
            # Make sure there are multiple chunks before setting partial response
            if len(user_data.partial_response.chunks) > 1:
                user_data.partial_response.active = True
                # chunk chunk_idx to index of next chunk to send
                user_data.partial_response.chunk_idx = 1
                user_data.response.is_partial_response = True


"""
------------------------------------------------------------
Helper methods to carry out pre and postprocessing of DM
------------------------------------------------------------
"""


async def __translate_text(bot: Bot, query: str, model_name: str, src_lang: str, tar_lang: str) -> str:
    """Perform translation of user request to target language if needed
    and returns the translated text"""

    translator = MachineTranslator(bot.configs.nlp_server_url)
    target_text = ""
    target_text = await translator.translate_text(
        query=query, model_name=model_name, src_lang=src_lang, tar_lang=tar_lang
    )
    return target_text


def __replace_contractions(text: str) -> str:
    """Replace contractions in user query with their expanded version"""

    for old_word, new_word in CONTRACTION_DICT.items():
        if old_word in text.lower().split():
            logger.debug(f'Replacing "{old_word}" with "{new_word}" as part of preprocessing.')
            text = re.sub(r"\b{}\b".format(old_word), new_word, text, flags=re.I)
    return text


def __replace_utf_chars(text: str) -> str:
    """Replace UTF characters in user query with their ascii equivalent"""

    return anyascii(anyascii(text).encode("utf-8").decode("unicode-escape"))


def clean_text(text: str, req_lang: str) -> str:
    """Clean text by replaving UTF characters, stripping spaces, punctuation marks"""

    # Remove any leading or trailing spaces and punctuation marks in text like period '.', '?'
    text = text.strip()

    # Remove UTF characters from text
    if "en-" in req_lang:
        text = __replace_utf_chars(text)
        logger.debug(f"Text after removing unicode characters: {text}")
        text = text.strip(".")
        text = text.strip("?")
        processed_text = text
        # TODO: processed_text = self.remove_special_character(text)
    else:
        processed_text = ""
    text = processed_text if processed_text else text

    return text


async def __preprocess_userquery(user: UserData, query: str) -> str:
    """
    Pre-process user query. Convert to lower case, remove
    unwanted special characters from the query, expand contractions
    and remove profane words.
    """

    # Replace contractions from query
    query = __replace_contractions(query)

    return query


async def __preprocess_user_request(req: Dict[str, Any], bot: Bot, user_data: UserData) -> None:
    """
    Process user request JSON and validate and populate user data with
    relevant parameters based on the request received.
    """
    if not req.get("Query") and req.get("Metadata", {}).get("type", "") == "UtteranceUserActionTranscriptUpdated":
        req["Query"] = req["Metadata"]["interim_transcript"]

    if not req.get("Query") and req.get("Metadata", {}).get("type", "") == "UtteranceUserActionFinished":
        req["Query"] = req["Metadata"]["final_transcript"]

    q = req.get("Query", "")

    if q in ["", None]:
        logger.info('No query provided as part of request json in "Query" field.')

    user_data.user_query = q

    session_id = req.get("SessionId", None)
    query_id = req.get("QueryId", None)

    user_data.language = bot.configs.language
    logger.info(f"Setting bot language from config file as: {user_data.language}")

    user_data.request_language = req.get("Language", "") or req.get("SourceLanguage", "")

    # Set default english language to US if not specified
    if user_data.request_language.strip().lower() == "en":
        user_data.request_language = "en-US"

    if user_data.request_language in ["", None]:
        user_data.request_language = bot.configs.request_language
        logger.debug(
            f'Empty language provided as part of request json in "Language" field. Using bot\'s request_language field: {user_data.request_language} as default'
        )

    user_data.response_language = req.get("ResponseLanguage", "") or req.get("TargetLanguage", "")
    if user_data.response_language in ["", None]:
        user_data.response_language = bot.configs.response_language
        logger.debug(
            f'Empty response language provided as part of request json in "ResponseLanguage" field. Using bot\'s response_language field: {user_data.response_language} as default'
        )

    # If a valid session id is passed:
    # 1. Check if existing session id in userdata matches incoming id
    # 2. If it does not match then clear session slots for the user

    # If no session id is passed
    # 1. Check if any session id is available in userdata
    # 2. If session id is available then use that else create a new one

    # TOBE deprecated: session id is no longer planned to be passed to DM
    if session_id != "" and session_id != None:
        if user_data.session_id != session_id:
            logger.info(f"New session: {session_id} created for user.")
            user_data.reset_form_data()
            bot.state_manager.reset_dialog_state(user_data)
            user_data.session_id = session_id
        else:
            logger.info(f"Existing session: {user_data.session_id} found for the user.")

    elif user_data.session_id == None:
        user_data.session_id = str(uuid4())
        logger.info(f"New session: {user_data.session_id} created for user.")

    else:
        logger.info(f"Existing session: {user_data.session_id} found for the user.")

    # Check if query is a statement or question and store that info in user data
    if user_data.user_query.endswith("?"):
        logger.info(f"User query is a question.")
        user_data.is_question = True

    user_data.processed_query[PROCESSOR_PREPROCESSED] = await __preprocess_userquery(user_data, q)

    logger.debug(f"User query after preprocessing: {user_data.processed_query[PROCESSOR_PREPROCESSED]}")

    user_data.query_id = query_id if query_id != "" and query_id != None else str(uuid4())

    user_data.domain = req.get("Domain", user_data.domain)
    user_data.intent = req.get("Intent", user_data.intent)
    user_data.stream_id = req.get("StreamId", "")

    # Event endpoint specific information parsing
    # Event can be populated either from /processQuery endpoint or /event endpoint
    user_data.event = req.get("Event", user_data.event)
    user_data.event_id = req.get("EventId", None)

    # Insert some required event metadata if not provided explicitly
    if user_data.event != EVENT_NO_MATCH and "source_uid" not in req.get("Metadata", {}):
        user_data.metadata["source_uid"] = "user_event"

    # Cancel form filling if predefined custom domain
    if user_data.form.active and user_data.domain == CUSTOM_DOMAIN and user_data.intent == CUSTOM_INTENT_RESET:
        logger.debug(f"Cancelling form filling due to predefined domain and intent.")
        user_data.form = FormInfo()

    user_data.entities = req.get("Entities", user_data.entities)
    user_data.params.update(req.get("Parameters", {}) or req.get("UserContext", {}))

    # Translate incoming language of user query if needed
    if user_data.language != user_data.request_language:
        model_name = ""
        for model_config in bot.nlp_model_configs:
            if model_config.task_name == NLU_MACHINE_TRANSLATION_INPUT:
                logger.info(f"Using {model_config.model_name} for input NMT")
                model_name = model_config.model_name

        if not model_name:
            raise ValueError(f"Input NMT model name is missing. Please specify it in the bot config under nlp_models")

        start = time()
        target_text = await __translate_text(
            bot,
            q,
            model_name,
            src_lang=user_data.request_language,
            tar_lang=user_data.language,
        )
        user_data.latency.nlu_machine_translation += time() - start
        if target_text:
            logger.info(f"Translated user query to: {target_text}")
            user_data.processed_query[PROCESSOR_PREPROCESSED] = target_text
        else:
            logger.info(
                "Translation service returned no response or is not enabled in bot config file. "
                f"Starting policy execution with original query.."
            )

    if req.get("Metadata", {}).get("type", "") == "UtteranceUserActionTranscriptUpdated":
        req["Metadata"]["interim_transcript"] = user_data.processed_query[PROCESSOR_PREPROCESSED]

    if req.get("Metadata", {}).get("type", "") == "UtteranceUserActionFinished":
        req["Metadata"]["final_transcript"] = user_data.processed_query[PROCESSOR_PREPROCESSED]

    user_data.metadata = req.get("Metadata", {})

    logger.debug(
        f"Request Json: "
        f"SourceLanguage: {user_data.request_language}, "
        f"TargetLanguage: {user_data.response_language}, "
        f"UserId: {user_data.user_id}, "
        f"Query: {user_data.processed_query[PROCESSOR_PREPROCESSED]}, "
        f"QueryId: {user_data.query_id}, "
        f"SessionId: {user_data.session_id}, "
        f"Event: {user_data.event}, "
        f"Context: {user_data.params}"
    )


def __split_text(text: str, max_length: int = 400):
    """Splits a text into chunks of no more than max_length characters.

    Args:
        text: The text to split.
        max_length: The maximum length of each chunk.

    Returns:
        A list of chunks.
    """

    chunks = []
    current_chunk = ""
    sentences = nltk.tokenize.sent_tokenize(text)

    for sentence in sentences:
        if len(current_chunk + sentence) <= max_length:
            current_chunk += sentence
        else:
            chunks.append(current_chunk)
            current_chunk = sentence

    if current_chunk:
        chunks.append(current_chunk)

    return chunks
