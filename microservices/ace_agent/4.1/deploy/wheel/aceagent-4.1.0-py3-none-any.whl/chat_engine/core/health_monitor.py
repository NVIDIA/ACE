"""
 copyright(c) 2023 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

import asyncio
import threading
import logging
from pydantic.v1 import BaseModel
from functools import partial
from urllib.parse import urljoin
from typing import List, Dict, Any, Optional, Callable, Tuple, Union

from chat_engine import Bot
from chat_engine.constants import FM_LIST_ENDPOINT, NLP_MODELS_LIST_ENDPOINT
from chat_engine.core.utils import async_http

logger = logging.getLogger("chat_engine")


class FMEndpoint(BaseModel):
    name: str
    endpoint: str

    @classmethod
    def is_ready(cls, endpoint_list: List["FMEndpoint"], endpoint: str) -> bool:
        """Searches through a list of provided endpoints and returns True if the endpoint is avaiable in that list"""

        for fm in endpoint_list:
            for fm_endpoint in fm.get("endpoints"):
                if fm_endpoint == endpoint:
                    return True
        return False

    @classmethod
    def get_endpoints(cls, endpoint_json: List[Dict[str, List[str]]]) -> List["FMEndpoint"]:
        """Accepts the current available endpoints and returns the list of endpoints wrapped in NLPendpoint"""

        endpoint_list = []
        for fm in endpoint_json:
            for endpoint in fm.get("endpoints"):
                endpoint_list.append(FMEndpoint(name=fm.get("name"), endpoint=endpoint))
        return endpoint_list


class NLPendpoint(BaseModel):
    endpoint: str
    task_name: str
    model_name: str
    model_version: str
    model_type: str
    url: str
    parameters: Dict[str, Any]

    @classmethod
    def is_ready(cls, endpoint_list: List["NLPendpoint"], task_name: str) -> Union[str, None]:
        """Returns the API endpoint of a task name if available in the provided endpoint list"""
        for api in endpoint_list:
            if api.task_name == task_name:
                return api.endpoint

    @classmethod
    def get_endpoints(cls, nlp_endpoint_json: List[Dict[str, Any]]) -> List["NLPendpoint"]:
        """Accepts the current available endpoints returned by NLP server list API and returns the list of endpoints wrapped in NLPendpoint"""

        endpoint_list = []
        for endpoint in nlp_endpoint_json:
            endpoint_list.append(NLPendpoint(**endpoint))
        return endpoint_list


class RegisteredCallback(BaseModel):
    fn: Callable
    task_name: str
    status: Optional[bool] = False
    args: Optional[Tuple[Any, ...]] = ()
    kwargs: Optional[Dict[str, Any]] = {}

    @classmethod
    def get_available_callbacks(
        cls, registered_callbacks: List["RegisteredCallback"], nlp_endpoint_json: List[Dict[str, Any]]
    ) -> List["RegisteredCallback"]:
        """Accepts the current available endpoint json and returns the list of callbacks registered for the provided task_name"""

        endpoint_list: List[NLPendpoint] = NLPendpoint.get_endpoints(nlp_endpoint_json)
        available_registered_callbacks = []

        for callback in registered_callbacks:
            # Check if the registered task name for the callback matches with one of the available task names from nlp server
            if NLPendpoint.is_ready(task_name=callback.task_name, endpoint_list=endpoint_list) is not None:
                available_registered_callbacks.append(callback)

        return available_registered_callbacks


class HeathMonitor:
    """
    This module helps chat engine monitor external services with which it talks with.
    1. It exposes API's which can be called from different modules for checking the status of these services.
    2. It exposes API's to register some callbacks based on endpoint availability
    """

    def __init__(self, bot: Optional[Bot] = None):
        self._bot: Bot = bot

        # Stores the latest raw snapshots of endpoints available in json format
        # These attributes are updated within threads
        self._fm_endpoints = {}
        self._nlp_endpoints = {}

        # Stores the list of registered callbacks taskwise here
        self._registered_callbacks: List[RegisteredCallback] = []

        # This is the polling time, after which we make a call to an endpoint to get latest status
        self._wait_time: int = bot.configs.health_check_interval

        # If this is not set to True, threads will not be triggered in run() method
        self._ready: bool = True

    def __del__(self):
        """Kill the threads, it will come out of while loop if this is set to false"""
        self._ready = False

    def run(self):
        """Entrypoint of the Heath Monitor module which starts threads asynchronously to poll the status of FM and NLP servers"""

        logger.info(f"Starting health monitor module..")

        # Start polling fm server endpoint for available endpoints
        self._fm_thread = threading.Thread(
            name=f"fm_poll_thread_{self._bot.name}",
            target=asyncio.run,
            args=(self.__poll_fm_endpoints(self._bot.configs.plugin_server_url),),
            daemon=True,
        ).start()

        # Start polling nlp server endpoint for available endpoints
        self._nlp_thread = threading.Thread(
            name=f"nlp_poll_thread_{self._bot.name}",
            target=asyncio.run,
            args=(self.__poll_nlp_endpoints(self._bot.configs.nlp_server_url),),
            daemon=True,
        ).start()

    # --------------------------------------------------------------------------
    # Public class properties for Health Monitor module called by other modules
    # --------------------------------------------------------------------------

    @property
    def fm_endpoints(self) -> List[FMEndpoint]:
        """This method returns a snapshot of the latest available endpoints with FM server. This is mainly needed for /status endpoint"""
        return FMEndpoint.get_endpoints(self._fm_endpoints)

    @property
    def nlp_endpoints(self) -> List[NLPendpoint]:
        """This method returns a snapshot of the latest available endpoints with NLP server. This is mainly needed for /status endpoint"""
        return NLPendpoint.get_endpoints(self._nlp_endpoints)

    def get_nlp_endpoint(self, task_name: str) -> Union[str, None]:
        """Called from different policies to get the rest api for a taskname and whether it is available or not."""
        endpoint = NLPendpoint.is_ready(task_name=task_name, endpoint_list=self.nlp_endpoints)
        if endpoint is not None:
            endpoint = urljoin(self._bot.configs.nlp_server_url, endpoint)
        return endpoint

    def register_callback(
        self, fn: Callable, task_name: str, args: Optional[Tuple[Any, ...]] = (), kwargs: Optional[Dict[str, Any]] = {}
    ) -> None:
        """Used to register some callback function based on availability of some NLP endpoints.
        The registered callback function will be executed asynchronously.
        NOTE: The function to be registerd must be async
        """

        if not asyncio.iscoroutinefunction(fn):
            logger.error(
                f"The function {fn.__name__} which is being registered with health monitor is not asynchronous. You need to register a coroutine."
            )
            return

        fn_partial = partial(fn, *args, **kwargs)
        self._registered_callbacks.append(
            RegisteredCallback(fn=fn_partial, task_name=task_name, status=False, args=args, kwargs=kwargs)
        )

    # -----------------------------------------
    # Helper methods for Health Monitor module
    # -----------------------------------------

    @fm_endpoints.setter
    @nlp_endpoints.setter
    def set_endpoints(self, value) -> None:
        logger.error("You cannot modify the endpoints, they can be only updated by Health Monitor threads.")
        return

    async def __poll_fm_endpoints(self, plugin_server_url: str = "") -> None:
        """Polls FM server to get list of endpoints available at periodic intervals"""

        logger.debug(
            f"Starting the polling of FM server for bot: {self._bot.name} in background with wait {self._wait_time} seconds.."
        )
        response = {}
        while self._ready:
            response = await async_http(urljoin(plugin_server_url, FM_LIST_ENDPOINT), timeout=5)
            self._fm_endpoints = response
            await asyncio.sleep(self._wait_time)
        logger.debug("Stopped the polling of FM server.")

    async def __poll_nlp_endpoints(self, nlp_server_url: str = "") -> None:
        """Polls NLP server to get list of endpoints available at periodic intervals
        Spans a thread to asynchoronously executes a registered callback
        """

        logger.debug(
            f"Starting the polling of NLP server for bot: {self._bot.name} in background with wait {self._wait_time} seconds.."
        )
        response = {}
        while self._ready:
            response = await async_http(urljoin(nlp_server_url, NLP_MODELS_LIST_ENDPOINT), timeout=5)
            self._nlp_endpoints = response

            # Check if a registered callbacks needs to be called here. We first check if any callback is registered for the current provided response of NLP server
            callbacks: List[RegisteredCallback] = RegisteredCallback.get_available_callbacks(
                self._registered_callbacks, self._nlp_endpoints
            )

            # Asynchronous callback logic:
            # If some callbacks are available, for each of returned callbacks trigger tasks asynchronously
            for callback in callbacks:
                # If we have already triggered a callback for this task, we don't retriger
                # In a single running DM session, callbacks associated with a specific task can be triggered only once
                if callback.status:
                    continue

                callback.status = True
                self._callback_thread = threading.Thread(
                    name=f"{callback.fn}-callback-thread", target=asyncio.run, args=(callback.fn(),), daemon=True
                ).start()

            # Synchronous callback logic:
            # where each registered callback method gets executed sequentially
            # if len(callbacks) > 0:
            #     self._callback_thread = threading.Thread(
            #         name=f"synchronous-callback-thread", target=asyncio.run, args=(self.execute_registered_callbacks(callbacks=callbacks),), daemon=True
            #     ).start()

            await asyncio.sleep(self._wait_time)

        logger.debug("Stopped the polling of NLP server.")

    async def execute_registered_callbacks(self, callbacks: List[RegisteredCallback]):
        """WAR method to execute each registered callbacks sequentially"""

        for callback in callbacks:
            if callback.status:
                continue
            try:

                resp = await callback.fn()
                callback.status = True  # Execute a callback method only once

            except Exception as e:
                logger.error(f"Got error while executing callback method {callback.fn.func.__name__}: {e}")
