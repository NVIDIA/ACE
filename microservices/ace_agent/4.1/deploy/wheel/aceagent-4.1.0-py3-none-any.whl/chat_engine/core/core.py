# Copyright(c) 2021-2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
    Core module is responsible for orchestrating the complete dialog
    flow for a specific bot at runtime.
    It is responsible for receiving the user query request data with a specific bot,
    extracting user data corresponding to the user query from the bot and drive the
    dialog management runtime with different core components in the bot to find a suitable response.
"""

import logging
import json
import asyncio
from dataclasses import asdict
from time import time
from uuid import uuid4
from traceback import print_exc
from typing import List, Dict, Any
from nemoguardrails.streaming import StreamingHandler

logger = logging.getLogger("chat_engine")

# Import required dm modules for runtime execution of the bot
try:
    from chat_engine.constants import (
        CUSTOM_DOMAIN,
        CUSTOM_INTENT_RESET,
        SHORTTERM_MEMORY,
        LONGTERM_MEMORY,
        SESSION_MEMORY,
        PRINT_TRACEBACK,
    )
    from chat_engine import Bot
    from chat_engine.nlp.response import Response
    from chat_engine.core.userdata import PartialResponseInfo, UserData, DialogState
    from chat_engine.core.processing import preprocess_user_request, postprocess_dm_response
    from chat_engine.stores.store import Store
    from chat_engine.dialog_state_tracker.dialog_state_tracker import DialogStateTracker
    from chat_engine.constants import PRINT_TRACEBACK
    from chat_engine.interfaces.server_schemas import UserContext, ChatFormat
    from chat_engine.policies.utils import close_stream


except Exception as e:
    logger.error(f"Error while importing modules in Core: {e}")
    if PRINT_TRACEBACK:
        print_exc()


class Core:
    current_request_mapping: dict = (
        {}
    )  # Maps a tuple of active userId, requestId to user data, where requestId is either the queryId or EventId

    @classmethod
    def get_response(cls, bot: Bot, req: Dict[str, Any]) -> Dict[str, Any]:

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:  # 'RuntimeError: There is no current event loop...'
            loop = None

        if loop is not None:
            raise RuntimeError(
                "You are using the sync `get_response` inside async code. "
                "You should replace with `await get_response_async(...)."
            )

        response = asyncio.run(cls.get_response_async(bot, req))
        return response

    @classmethod
    def get_event_response(cls, bot: Bot, req: Dict[str, Any]) -> Dict[str, Any]:

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:  # 'RuntimeError: There is no current event loop...'
            loop = None

        if loop is not None:
            raise RuntimeError(
                "You are using the sync `get_event_response` inside async code. "
                "You should replace with `await get_event_response_async(...)."
            )

        response = asyncio.run(cls.get_event_response_async(bot, req))
        return response

    async def get_response_async(
        bot: Bot, req: Dict[str, Any], streaming_handler: StreamingHandler = None
    ) -> Dict[str, Any]:
        """
        Method which is called by different interfaces to send user requests for a specific bot.
        This method is the entrypoint of all requests to chat engine in textual form.
        It drives the overall flow to processes the received user request and generates a JSON
        response.
        """

        # Reject the request if the bot is not ready
        if not bot.is_ready:
            logger.critical(
                f"Bot {bot.name} has not initialized successfully. Please check the logs or wait for the bot to complete its initialization."
            )
            return {}

        start = time()
        try:
            user_data: UserData = Core.__get_user_data(bot.store_manager, req["UserId"])
            if streaming_handler:
                user_data.streaming_handler = streaming_handler
                user_data.colang_streaming_handler = StreamingHandler()

            bot.state_manager.set_dialog_state(user_data.user_id, user_data.dialog_state)

            valid_request = await Core.__validate_user_request(user_data, req)

            await preprocess_user_request(req, bot, user_data)

            if not valid_request:
                logger.warning(
                    f"Invalid request detected to Chat Engine Core with bot: {bot.name}. Returning empty response."
                )
                user_data.streaming_handler = None
                Response.build_response_data(user_data)
                Core.__display_user_data(user_data)
                # TODO: Need to review this
                # SlotManager.get_instance().clear_cache(user_data.user_id)
                bot.state_manager.delete_dialog_state(user_data.user_id)
                return asdict(user_data.core_response)

            request_id = user_data.event_id if user_data.event_id else user_data.query_id
            Core.current_request_mapping[(user_data.user_id, request_id)] = user_data
            await bot.policy_manager.execute(user_data)

            # Postprocess the response formulated by DM
            await postprocess_dm_response(bot, user_data)

            await Core.__update_dialog_state(bot.state_manager, user_data, bot.name)

            user_data.latency.end_to_end = time() - start
            Response.build_response_data(bot, user_data)
            if user_data.streaming_handler:
                await close_stream(user_data)

            Core.__update_dialog_session(bot.state_manager, bot.store_manager, user_data)
            Core.__display_user_data(user_data)
            # TODO: Need to review this
            # SlotManager.get_instance().clear_cache(user_data.user_id)
            bot.state_manager.delete_dialog_state(user_data.query_id)
            del Core.current_request_mapping[(user_data.user_id, request_id)]
            return asdict(user_data.core_response)

        except Exception as e:
            if user_data.streaming_handler:
                await user_data.colang_streaming_handler.push_chunk("An internal error occurred")
                await user_data.colang_streaming_handler.push_chunk(None)
                await close_stream(user_data)
            logger.error(f"Error in Core get_response(): {e}")
            if PRINT_TRACEBACK:
                print_exc()
            return {}

    async def stream_response_async(bot: Bot, req: Dict[str, Any]) -> StreamingHandler:
        """
        Starts the response with a streaming handler as a background task and returns the streaming handler immediately.
        """

        streaming_handler = StreamingHandler()
        asyncio.create_task(Core.get_response_async(bot, req, streaming_handler))
        return streaming_handler

    async def get_event_response_async(
        bot: Bot, req: Dict[str, Any], streaming_handler: StreamingHandler = None
    ) -> Dict[str, Any]:
        """
        Method which is called by different interfaces to send event driven user requests for a specific bot.
        It drives the overall flow to process the event in the received user request and generates a JSON
        response.
        """

        # Preprocess the event request to a chat request format
        reformed_req = {}

        reformed_req["Metadata"] = req.get("Metadata", {})
        reformed_req["BotName"] = req.get("BotName")
        reformed_req["BotVersion"] = req.get("BotVersion")
        reformed_req["UserId"] = req.get("UserId")
        reformed_req["Context"] = req.get("Context", {})
        reformed_req["Event"] = req.get("EventType")
        reformed_req["EventId"] = req.get("EventId", str(uuid4()))
        response = await Core.get_response_async(bot=bot, req=reformed_req, streaming_handler=streaming_handler)
        return response

    async def stream_event_response_async(bot: Bot, req: Dict[str, Any]) -> StreamingHandler:
        """
        Starts the response with a streaming handler as a background task and returns the streaming handler immediately.
        """

        streaming_handler = StreamingHandler()
        asyncio.create_task(Core.get_event_response_async(bot, req, streaming_handler))
        return streaming_handler

    async def __validate_user_request(user: UserData, req: Dict[str, Any]) -> bool:
        """Carries out logical validation of user request as part of preprocessing"""

        if "UserId" not in req or req.get("UserId") == "" or req.get("UserId") == None:
            raise ValueError('Missing required field "UserId" from request json')

        # If query is not available in request json
        # 1. Either one of intent or domain should be provided otherwise dialog cannot be disambiguated
        if req.get("Query") in ["", None]:
            if (
                req.get("Domain", "") in ["", None]
                and req.get("Intent") in ["", None]
                and req.get("Event") in ["", None]
            ):
                if user.partial_response.active:
                    logger.debug(
                        f"Partial state detected in DM with no query. Resuming earlier action from last query."
                    )
                    return True
                if user.colang_streaming_handler:
                    await user.colang_streaming_handler.push_chunk("")
                    await user.colang_streaming_handler.push_chunk(None)
                    await close_stream(user)
                raise ValueError(
                    f'A valid query using "Query" or a valid EventType '
                    f"using /chat or /event endpoint should be provided from request json"
                )
        elif user.partial_response.active:
            logger.debug(f"Discarding partial information state in DM as valid query was passed.")
            user.partial_response = PartialResponseInfo()
            user.reset()
        return True

    def update_context_for_user(store: Store, user_id: str, context: Dict[str, Any]) -> None:
        """Updates any user specific context for different bots. Called from /updateUserContext API."""

        user_data: UserData = Core.__get_user_data(store, user_id)
        user_data.params.update(context)
        store.save_user_data(user_data)

    def set_context_for_user(store: Store, context: UserContext) -> None:
        """Sets any bot specific configurations for user. Called from /setUserContext API.
        This overwrites any existing context or conversation history if available."""

        user_data: UserData = Core.__get_user_data(store, context.UserId)
        user_data.params = context.Context.copy()
        user_data.dialog_state[context.UserId].chat_history = Core.__convert_to_plain_dict(
            input_dict=context.ChatHistory
        )
        user_data.dialog_state[context.UserId].event_history = context.EventHistory.copy()
        store.save_user_data(user_data)

    def get_context_for_user(store: Store, user_id: str):
        """Gets any context for user. Called from /getUserContext API."""

        user_data: UserData = Core.__get_user_data(store, user_id)
        return {
            "UserId": user_id,
            "Context": user_data.params,
            "ChatHistory": user_data.dialog_state[user_id].chat_history,
            "EventHistory": user_data.dialog_state[user_id].event_history,
        }

    def delete_context_for_user(store: Store, user_id: str) -> None:
        """Delete user specific context. Called from /deleteUserContext API."""

        user_data: UserData = Core.__get_user_data(store, user_id)
        user_data.params = {}
        user_data.dialog_state[user_id] = DialogState()
        store.save_user_data(user_data)

    def fetch_user_data(user_id: str, request_id: str) -> UserData:
        """Return the user data corresponding to an active userId and query/event Id"""

        if (user_id, request_id) not in Core.current_request_mapping:
            raise ValueError(f"{(user_id, request_id)} was not registered in the request mapping.")

        return Core.current_request_mapping[(user_id, request_id)]

    def __get_user_data(store: Store, user_id: str, create_user_data: bool = True) -> "UserData":
        """Fetches the user data associated with the current user ID
        from user data store and returns it"""

        try:
            user_data = store.get_user_data(user_id)
        except Exception as e:
            if not create_user_data:
                return
            logger.info(f"No user data available for user id {user_id} " f"Creating new user data instance.")
            user_data = UserData()
            user_data.user_id = user_id
            user_data.dialog_state[user_id] = DialogState()

        user_data.reset()
        user_data.request_time = time()
        return user_data

    async def __update_dialog_state(dst: DialogStateTracker, user_data: "UserData", bot_name: str) -> None:
        """
        Update the dialog state then clear relevant dialog state if:
         1. Predefined custom cancel domain/intent is selected
         2. reset action is passed as part of dialog policy
        """

        # TODO: Implement this once slot manager is up
        # await dst.update_dialog_state(user_data, SlotManager.get_instance())
        await dst.update_dialog_state(user_data)

        if user_data.domain == CUSTOM_DOMAIN and user_data.intent == CUSTOM_INTENT_RESET:
            dst.reset_dialog_state(user_data, bot_name=bot_name)

        # Reset slots
        elif user_data.reset_user_memory in [LONGTERM_MEMORY, SHORTTERM_MEMORY]:
            dst.reset_dialog_state(user_data, memory=user_data.reset_user_memory, bot_name=bot_name)

    def __update_dialog_session(dst: DialogStateTracker, store: Store, user_data: UserData) -> None:
        """
        Update SessionId if reset session is passed as part of dialog policy
        Save updated user data in memory
        """
        if user_data.reset_user_memory in [SESSION_MEMORY]:
            logger.info("Resetting session, clearing existing user form and dialog state ")
            user_data.reset_active_form()
            dst.reset_dialog_state(user_data)
            user_data.session_id = str(uuid4())

        store.save_user_data(user_data)

    def __display_user_data(user_data: UserData):
        """Trim down user data dict for printing"""

        logger.info(json.dumps(asdict(user_data.core_response), indent=4))

    def __convert_to_plain_dict(input_dict: Dict[str, List[ChatFormat]]) -> Dict[str, List[Dict[str, str]]]:
        """Utlity method to convert chat history base model to plain dict for storage"""

        result_dict = {}
        for key, chat_formats in input_dict.items():
            result_dict[key] = []
            for chat_format in chat_formats:
                result_dict[key].append(chat_format.dict())

        return result_dict
