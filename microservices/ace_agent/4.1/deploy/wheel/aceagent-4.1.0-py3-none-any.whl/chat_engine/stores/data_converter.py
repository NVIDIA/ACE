# copyright(c) 2022 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

from typing import Any, Dict
from dataclasses import asdict
from typing import List

import json
import logging
import _pickle as pickle

from chat_engine.core.userdata import UserData


logger = logging.getLogger("chat_engine")


class DataConverter:
    """
    Convert Various dataclass to pickle object and vice versa
    """

    @staticmethod
    def serialise_data(data: "UserData") -> "pickle":
        """
        Convert UserData dataclass to json serialized string
        Args:
            data: UserData Dataclass Object
        Returns:
            str: json serialized string
        """

        return pickle.dumps(data)

    @staticmethod
    def deserialise_data(data: "json") -> "UserData":
        """
        Converts json serialized object of UserData Dataclass
        and convert it into UserData class python object
        Args:
            data: json string of dict created by UserData object
        Returns:
            UserData object converted from data if valid otherwise None
        """
        try:
            res = pickle.loads(data)
            return res
        except Exception as e:
            logger.error(f"Exception while re-creating UserData {e}")
            return None
