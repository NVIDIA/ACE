# Copyright(c) 2022-2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
chat engine core module which interacts with various modules inside
chat engine.
"""

import logging
from typing import Dict

from chat_engine.core.userdata import UserData
from chat_engine.constants import STORE_CACHE, STORE_REDIS, STORE_MONGO, STORE_LOCAL_FILE, SUPPORTED_STORE_LIST
from chat_engine.stores.store_cache import StoreCache
from chat_engine.stores.store_mongo import MongoStore
from chat_engine.stores.store_redis import RedisStore
from chat_engine.stores.store_local_file import StoreFileSystem

logger = logging.getLogger("chat_engine")


class Store:
    """Top level class to store any user data or other information"""

    def __init__(self, storage_config: "StorageConfig") -> None:
        """
        Initialize and create object of storage class
        specified in agent config
        Args:
            storage_config: StorageConfig object contains storage type and params
        """

        if storage_config.name is None:
            return

        if storage_config.name not in SUPPORTED_STORE_LIST:
            raise ValueError(f"Unsupported store type {storage_config.name}")

        if storage_config.name == STORE_CACHE:
            self._store = StoreCache(storage_config)
        elif storage_config.name == STORE_LOCAL_FILE:
            self._store = StoreFileSystem(storage_config)
        elif storage_config.name == STORE_REDIS:
            self._store = RedisStore(storage_config)
        elif storage_config.name == STORE_MONGO:
            self._store = MongoStore(storage_config)

    def reset_active_user(self):
        """Remove active user data from memory"""

        self._store.reset_active_user()

    def get_active_user_data(self) -> Dict[str, float]:
        """
        Get list of active user ids
        """
        # TODO: getting all active user is not memory efficient
        # convert it to yield function
        return self._store.get_active_user_data()

    def get_user_data(self, user_id: str) -> UserData:
        """
        Check if user data corresponding to user_id is available with store
        Raise exception if no user data corresponding to the user_id has
        been available in the store

        Args:
            user_id: user_id whose information needs to be extracted
        Returns
            UserData Object for corresponding user
        Raise
            ValueError is user information is not available
        """

        return self._store.get_user_data(user_id)

    def save_user_data(self, data: UserData) -> None:
        """
        Check if user id corresponding to the user data is already available
        in the store. If yes then update the corresponding user_data with
        new userdata. Otherwise create a new user data entry and store it.
        Args:
            data: UserData object to be stored in storage unit
        """

        self._store.save_user_data(data)

    def delete_user_data(self, user_id: str) -> None:
        """
        Delete user data corresponding to user_id in the store
        Args:
            user_id: user_id of user whose information needs to be removed from storage
        """

        self._store.delete_user_data(user_id)

    def rename_user(self, current_user_id: str, new_user_id: str) -> None:
        """
        Replace userdata of current_user_id to new_user_id
        Common method for all store class
        """
        if current_user_id == new_user_id:
            # Skip renaming when same userid is used
            logger.debug(
                f"UserId: {current_user_id} is already associated with current SessionId. Not carrying over dialog state."
            )
            return
        try:
            userdata = self._store.get_user_data(current_user_id)
        except:
            logger.warning(f"User does not exist for id: {current_user_id}")
            raise ValueError(f"User does not exist for id: {current_user_id}")
        userdata.user_id = new_user_id
        # copy dialog state to new_user_id
        # This is needed as in userdata dialog_state is stored as dict <user_id: dialog_state>
        # We're removing old user_id from userdata and copying that info with on new_user_id
        userdata.dialog_state[new_user_id] = userdata.dialog_state[current_user_id]
        # Remove dialog state for current_user_id
        del userdata.dialog_state[current_user_id]

        self._store.save_user_data(userdata)
        self._store.delete_user_data(current_user_id)

    def get_user_for_session(self, session_id: str) -> str:
        """
        Return list of users in given session_id
        Args:
            session_id: session_id whose user_id needs to be extracted
        """

        return self._store.get_user_for_session(session_id)
