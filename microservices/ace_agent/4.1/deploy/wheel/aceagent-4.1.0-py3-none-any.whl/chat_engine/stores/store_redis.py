# copyright(c) 2022 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import redis
import logging
from typing import Dict
import re

from chat_engine.core.userdata import UserData
from chat_engine.stores.data_converter import DataConverter
from chat_engine.stores.constants import REDIS_DEFAULT_HOST, REDIS_DEFAULT_PORT
from chat_engine.stores.store_base import StoreBase

logger = logging.getLogger("chat_engine")


class RedisStore(StoreBase):
    """Storage class for redis storage"""

    def __init__(self, storage_config: "StorageConfig") -> None:

        host, port = REDIS_DEFAULT_HOST, REDIS_DEFAULT_PORT
        if storage_config.url.strip() != "":
            p = "(?:http.*://)?(?P<host>[^:/ ]+).?(?P<port>[0-9]*).*"

            m = re.search(p, storage_config.url)
            host = m.group("host")
            port = m.group("port")

        self._user_data = redis.Redis(
            host=host,
            port=port,
            db=0,
            password=storage_config.parameters.get("password", None),
        )

        self._active_user_data = redis.Redis(
            host=host,
            port=port,
            db=1,
            password=storage_config.parameters.get("password", None),
        )

        self._user_in_session = redis.Redis(
            host=host, port=port, db=2, password=storage_config.parameters.get("password", None), decode_responses=True
        )

        try:
            self._user_data.ping()
            self._active_user_data.ping()
            self._user_in_session.ping()
        except:
            logger.error("Unable to connect redis server. ")
            raise

    def reset_active_user(self):

        self._active_user_data.flushdb()

    def get_active_user_data(self) -> Dict[str, float]:
        """
        Get list of active user ids
        """
        # Update this implementation
        # logic to handle larger scale use yield
        active_users = {}
        keys = self._active_user_data.keys("*")
        for key in keys:
            active_users[key] = float(self._active_user_data.get(key))
        return active_users

    def get_user_data(self, user_id: str) -> UserData:
        """
        Check if user data corresponding to user_id is available with store
        Raise exception if no user data corresponding to the user_id has
        been available in the store
        """
        try:
            user_data = self._user_data.get(user_id)
            if user_data is None:
                raise
            return DataConverter.deserialise_data(user_data)
        except Exception:
            raise ValueError(f"Invalid user id {user_id}")

    def save_user_data(self, data: UserData) -> None:
        """
        Check if user id corresponding to the user data is already available
        in the store. If yes then update the corresponding user_data with
        new userdata. Otherwise create a new user data entry and store it.
        """

        self._user_data.set(data.user_id, DataConverter.serialise_data(data))
        self._active_user_data.set(data.user_id, data.request_time)
        self._user_in_session.set(data.session_id, data.user_id)

    def delete_user_data(self, user_id: str) -> None:
        """
        Delete user data corresponding to user_id in the store
        """

        self._user_data.delete(user_id)

    def get_user_for_session(self, session_id: str) -> str:
        """
        Return list of users in given session_id
        Args:
            session_id: session_id whose user_id needs to be extracted
        """
        try:
            return self._user_in_session.get(session_id) or ""
        except Exception:
            logger.info(f"No session exist with id {session_id}")
        return ""
