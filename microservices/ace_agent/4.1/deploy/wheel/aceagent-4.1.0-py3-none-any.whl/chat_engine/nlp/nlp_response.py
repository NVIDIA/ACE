# Copyright(c) 2021-2023 NVIDIA Corporation. All rights reserved

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
template related to Natural language understanding module results
"""

from dataclasses import dataclass, field
from typing import List, Dict

from chat_engine.constants import DOMAIN_NO_MATCH, INTENT_NO_MATCH


@dataclass
class Classification:
    """Classification response containing class name and score"""

    class_name: str
    score: float


@dataclass
class TokenClassValue:
    """Used to correlate an input token with its classification results"""

    token: str
    label: "Classification"
    span: Dict[str, int] = field(default_factory=lambda: {})
    is_fm_slot: bool = False


@dataclass
class TokenClassResponse:
    """
    Class to store results corresponding to NER & other entity
    recognition modules.
    """

    slots: List["TokenClassValue"] = field(default_factory=lambda: [])


@dataclass
class AnalyzeIntentResponse:
    """Class to store results corresponding to Joint Intent & Slot module"""

    domain: "Classification" = field(default_factory=lambda: Classification(DOMAIN_NO_MATCH, 1.0))
    intent: "Classification" = field(default_factory=lambda: Classification(INTENT_NO_MATCH, 1.0))
    slots: "TokenClassResponse" = field(default_factory=lambda: TokenClassResponse())


@dataclass
class NaturalQueryResponse:
    """Response corresponding to natural query & answering module"""

    results: List["NaturalQueryResult"] = field(default_factory=lambda: [])


@dataclass
class NaturalQueryResult:
    """Individual results for natural query & answering module"""

    answer: str
    score: float


@dataclass
class InformationRetrievalResponse:
    """Response corresponding to information retrieval module"""

    results: List["InformationRetrievalResult"] = field(default_factory=lambda: [])
    num_results: int = 0


@dataclass
class InformationRetrievalResult:
    """Individual results for information retrieval module"""

    ir_type: str
    source_path: str
    title: str
    score: float
    ir_result: Dict[str, str] = field(default_factory=lambda: {})


@dataclass
class SemanticSimilarityResult:
    """Individual results for Semantic similarity module"""

    token: str = ""
    closest_match: str = ""
    score: float = 0.0
    slot: str = ""
    intent: str = ""
    domain: str = ""


@dataclass
class EntailmentResult:
    """Individual results for Enttailment module"""

    token: str = ""
    closest_match: str = ""
    score: float = 0.0
    intent: str = ""
    domain: str = ""


@dataclass
class QueryParaphrasingResponse:
    """Individual results for Query paraphrasing module"""

    input: str = ""
    output: str = ""
    score: float = 0.0
    prompt: str = ""


@dataclass
class ResponseParaphrasingResponse:
    """Individual results for Response paraphrasing module"""

    input: str = ""
    output: str = ""
    score: float = 0.0
    prompt: str = ""


@dataclass
class AnchorResponse:
    """Response type of every entity of EmbeddingSearchResponse list"""

    text: str
    metadata: dict
    confidence_score: float


@dataclass
class EmbeddingSearchResponse:
    """Response from Embedding search API"""

    results: List[AnchorResponse] = field(default_factory=lambda: [])


@dataclass
class NluResponse:
    """Class consisting of all available NLU module results"""

    query: str = ""
    intent_slot_result: AnalyzeIntentResponse = field(default_factory=AnalyzeIntentResponse)
    ner_result: "TokenClassResponse" = field(default_factory=TokenClassResponse)
    qna_result: "NaturalQueryResponse" = field(default_factory=NaturalQueryResponse)
    slot_lookup_result: "TokenClassResponse" = field(default_factory=TokenClassResponse)
    slot_regex_result: "TokenClassResponse" = field(default_factory=TokenClassResponse)
    semantic_similarity_result: List["SemanticSimilarityResult"] = field(default_factory=lambda: [])
    entailment_result: List["EntailmentResult"] = field(default_factory=lambda: [])
    ir_result: "InformationRetrievalResponse" = field(default_factory=InformationRetrievalResponse)
    text_classifier_result: List["Classification"] = field(default_factory=lambda: [])
    query_paraphrasing_result: List["QueryParaphrasingResponse"] = field(default_factory=lambda: [])
    response_paraphrasing_result: List["ResponseParaphrasingResponse"] = field(default_factory=lambda: [])
