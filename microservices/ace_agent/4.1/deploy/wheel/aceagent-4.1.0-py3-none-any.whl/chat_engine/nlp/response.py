# Copyright(c) 2022-2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
chat engine core module which interacts with various modules inside
chat engine.
"""

import logging
import ast
import re
from typing import List, Dict, Any, Tuple
from random import choice
from time import time
from dataclasses import dataclass

from chat_engine import Bot
from chat_engine.core.userdata import SlotData, UserData, UserResponse
from chat_engine.constants import (
    SYSTEM_SLOTS_POLICY_PREFIX,
    SYSTEM_SLOTS_PREFIX,
    PROCESSOR_POSTPROCESSED,
    HTTP_STATUS_DICT,
)
from chat_engine.nlp.response_data import (
    EntailmentResult,
    ResponseData,
    Entity,
    Classification,
    SemanticSimilarityResult,
    SessionSlot,
    GlobalSlot,
    FulfillmentInfo,
    Slot,
    SlotValue,
    TextClassifierResult,
    QueryParaphrasingResult,
    ResponseParaphrasingResult,
    InformationRetrievalResult,
)

logger = logging.getLogger("chat_engine")


@dataclass
class BotResponse:
    """TODO Docstring"""

    text: List[str]
    action: str
    json: str
    need_user_response: bool
    omniverse_json: str
    is_partial_response: bool


@dataclass
class ResponseRules:
    """TODO Docstring"""

    responses: List[BotResponse]


class Response:
    """
    Response generator module is responsible for doing generating valid response from
    given response rules and dialog state. It is responsible for replacing
    slot and fulfillment slot values in the response rules to generate the
    unique final response.
    """

    @staticmethod
    async def get_response(
        response_rules: ResponseRules, bot: Bot, user: UserData, response: UserResponse = UserResponse()
    ) -> "UserResponse":

        if response != UserResponse():
            logger.debug(f"Forwarded Response object to response action: {response}")

        # Set default value of forwarded response if available
        if response.need_user_response is None:
            response.need_user_response = bot.configs.need_user_response

        valid_response = None

        # Populate all available response templates for a dialog
        for resp in response_rules.responses:
            user.response_templates.append({"text": resp.text, "json": resp.json, "action": resp.action})

        # Filter out valid responses from all response templates
        for resp in response_rules.responses:

            possible_responses = []
            valid_response = None

            # Iterate over all texts across a single response
            for res in resp.text:
                text = await Response.__process_response_text(user, res)
                if text is not None:
                    possible_responses.append(text)

            if len(possible_responses):
                logger.debug(f"Possible text responses are: {possible_responses}")

            json = Response.__process_json(user, resp.json)

            # If both text and json are present
            if len(resp.text) and resp.json != None:
                if len(possible_responses) and json != None:
                    valid_response = BotResponse(
                        choice(possible_responses),
                        resp.action,
                        json,
                        resp.need_user_response,
                        resp.omniverse_json,
                        resp.is_partial_response,
                    )
                    break

            # If just text is present
            elif len(resp.text) and resp.json == None:
                if len(possible_responses):
                    valid_response = BotResponse(
                        choice(possible_responses),
                        resp.action,
                        json,
                        resp.need_user_response,
                        resp.omniverse_json,
                        resp.is_partial_response,
                    )
                    break

            # If just json is present
            elif not len(resp.text) and resp.json != None:
                if json != None:
                    valid_response = BotResponse(
                        None, resp.action, json, resp.need_user_response, resp.omniverse_json, resp.is_partial_response
                    )
                    break

            # If just action is present
            elif not len(resp.text) and resp.json == None and resp.action != None:
                valid_response = BotResponse(
                    None, resp.action, json, resp.need_user_response, resp.omniverse_json, resp.is_partial_response
                )
                break

        logger.debug(f"Selected Valid response: {valid_response}")

        # If not valid response is found, pass on the forwarded response
        if valid_response is None:
            return response

        return UserResponse(
            text=valid_response.text if valid_response.text != None else response.text,
            action=valid_response.action if valid_response.action != None else response.action,
            json=valid_response.json if valid_response.json != None else response.json,
            omniverse_json=valid_response.omniverse_json
            if valid_response.omniverse_json != None
            else response.omniverse_json,
            ready=True,
            need_user_response=valid_response.need_user_response
            if valid_response.need_user_response != None
            else response.need_user_response,
            is_partial_response=valid_response.is_partial_response
            if valid_response.is_partial_response != None
            else response.is_partial_response,
        )

    @staticmethod
    def build_response_data(bot: Bot, user_data: UserData) -> ResponseData:
        """Utility function that builds the response object
        send out from core"""

        resp = ResponseData()
        resp.reset()

        resp.BotName = bot.name
        resp.BotVersion = bot.version
        resp.UserId = user_data.user_id
        resp.SessionId = user_data.session_id
        resp.DialogId = user_data.dialog_id
        resp.Query = user_data.user_query
        resp.ProcessedQuery = user_data.processed_query[PROCESSOR_POSTPROCESSED]
        resp.QueryId = user_data.query_id
        resp.Language = user_data.request_language
        resp.ResponseLanguage = user_data.response_language
        resp.Domain = user_data.domain
        resp.Intent = user_data.intent
        resp.Entities = user_data.entities
        resp.Event = user_data.event
        resp.StreamId = user_data.stream_id
        resp.Slots = Response.__format_slots(user_data.slots)
        resp.MissingSlots = user_data.form.missing_fields
        resp.Parameters = user_data.params
        resp.PolicyName = user_data.policy

        # Populate event api specific response data
        if user_data.event_id is not None:
            resp.EventId = user_data.event_id
            resp.EventType = user_data.event
            resp.Events = user_data.current_events

        """ Populate NLU Response """

        if user_data.nlu_result.intent_slot_result is not None:
            resp.NlpResult.Domain = Classification(
                Name=user_data.nlu_result.intent_slot_result.domain.class_name,
                ConfidenceScore=user_data.nlu_result.intent_slot_result.domain.score,
            )
            resp.NlpResult.Intent = Classification(
                Name=user_data.nlu_result.intent_slot_result.intent.class_name,
                ConfidenceScore=user_data.nlu_result.intent_slot_result.intent.score,
            )
            Response.__set_nlu_entity(resp, "IntentSlot", user_data.nlu_result.intent_slot_result.slots.slots)

        if user_data.nlu_result.slot_lookup_result is not None:
            Response.__set_nlu_entity(resp, "Lookup", user_data.nlu_result.slot_lookup_result.slots)

        if user_data.nlu_result.slot_regex_result is not None:
            Response.__set_nlu_entity(resp, "Regex", user_data.nlu_result.slot_regex_result.slots)

        if user_data.nlu_result.ner_result is not None:
            Response.__set_nlu_entity(resp, "NER", user_data.nlu_result.ner_result.slots)

        if user_data.nlu_result.qna_result is not None:
            resp.NlpResult.NaturalQuery = user_data.nlu_result.qna_result.results

        if user_data.nlu_result.ir_result is not None:
            resp.NlpResult.InformationRetrieval = InformationRetrievalResult(
                Results=user_data.nlu_result.ir_result.results, NumResults=user_data.nlu_result.ir_result.num_results
            )

        resp.NlpResult.SemanticSimilarity = Response.__set_semantic_similarity_results(
            user_data.nlu_result.semantic_similarity_result
        )

        resp.NlpResult.QueryParaphrasing = [
            QueryParaphrasingResult(Query=result.input, Score=result.score, Result=result.output, Prompt=result.prompt)
            for result in user_data.nlu_result.query_paraphrasing_result
        ]

        resp.NlpResult.ResponseParaphrasing = [
            ResponseParaphrasingResult(
                ResponseText=result.input, Score=result.score, Result=result.output, Prompt=result.prompt
            )
            for result in user_data.nlu_result.response_paraphrasing_result
        ]

        resp.NlpResult.Entailment = Response.__set_entailment_results(user_data.nlu_result.entailment_result)
        resp.NlpResult.TextClassifier = [
            TextClassifierResult(
                Text=result.class_name,
                Score=result.score,
            )
            for result in user_data.nlu_result.text_classifier_result
        ]

        """ Populate Fulfillment Response """
        for module_dict in user_data.fulfillment_response:
            module_name = list(module_dict.keys())[0]
            module = module_dict[module_name]
            fm_status = HTTP_STATUS_DICT.get(module["Status"], "Failure")
            if module["StatusDetails"] != "":
                fm_status = f"{fm_status} - {module['StatusDetails']}"
            resp.Fulfillment.append(
                FulfillmentInfo(
                    Module=module_name,
                    Status=fm_status,
                    FulfillmentSlots=Response.__format_slots(module["FulfillmentSlots"]),
                    Slots=Response.__format_slots(module["Slots"]),
                    CustomData=module["CustomData"],
                    InvalidSlots=module["InvalidSlots"],
                )
            )

        """ Populate User Response """
        resp.Response.Text = user_data.response.text if user_data.response.text != None else ""
        resp.Response.CleanedText = user_data.response.cleaned_text if user_data.response.cleaned_text != None else ""
        resp.Response.Json = user_data.response.json
        resp.Response.OmniverseJson = user_data.response.omniverse_json
        resp.Response.NeedUserResponse = (
            user_data.response.need_user_response
            if user_data.response.need_user_response is not None
            else bot.configs.need_user_response
        )
        resp.Response.IsFinal = not (
            user_data.response.is_partial_response if user_data.response.is_partial_response is not None else False
        )

        """ Populate dialog state info """
        _dst = bot.state_manager.get_dialog_state(user_data.user_id)
        for s in _dst.session_slots:
            slots = _dst.session_slots[s]
            resp.DialogState.SessionSlot.append(
                SessionSlot(
                    Name=slots.name,
                    RemainingTurn=slots.max_turn - slots.last_conv_turn_idx + 1,
                    RemainingTime=slots.max_duration - (time() - slots.last_conv_time),
                    Values=Response.__format_slot_attributes(slots.values[-1].value),
                )
            )
        for s in _dst.global_slots:
            slots = _dst.global_slots[s]
            resp.DialogState.GlobalSlot.append(
                GlobalSlot(Name=slots.name, Values=Response.__format_slot_attributes(slots.values[-1].value))
            )

        """ Populate Latency of various module """
        resp.Latency.IntentSlotModel = int(user_data.latency.nlu_intent_slot * 1000)  # converting to ms
        resp.Latency.NaturalQueryModel = int(user_data.latency.nlu_qna * 1000)  # converting to ms
        resp.Latency.InformationRetrievalModel = int(user_data.latency.nlu_ir * 1000)  # converting to ms
        resp.Latency.EntailmentModel = int(user_data.latency.nlu_entailment * 1000)  # converting to ms
        resp.Latency.NERModel = int(user_data.latency.nlu_ner * 1000)  # converting to ms
        resp.Latency.MachineTranslation = int(user_data.latency.nlu_machine_translation * 1000)  # converting to ms
        resp.Latency.SemanticSimilarityModel = int(
            user_data.latency.nlu_semantic_similarity * 1000
        )  # converting to ms
        resp.Latency.TextClassifierModel = int(user_data.latency.nlu_text_classifier * 1000)  # converting to ms
        resp.Latency.QueryParaphrasingModel = int(user_data.latency.nlu_query_paraphrasing * 1000)  # converting to ms
        resp.Latency.PluginPolicy = int(user_data.latency.plugin_policy * 1000)  # converting to ms
        resp.Latency.ResponseParaphrasingModel = int(
            user_data.latency.nlu_response_paraphrasing * 1000
        )  # converting to ms
        resp.Latency.Fulfillment = int(user_data.latency.fulfillment * 1000)  # converting to ms
        resp.Latency.EndToEnd = int(user_data.latency.end_to_end * 1000)  # converting to ms
        resp.Latency.NLPModels = round(
            (
                user_data.latency.nlu_intent_slot
                + user_data.latency.nlu_qna
                + user_data.latency.nlu_ir
                + user_data.latency.nlu_ner
                + user_data.latency.nlu_semantic_similarity
                + user_data.latency.nlu_machine_translation
                + user_data.latency.nlu_text_classifier
            )
            * 1000
        )
        resp.Latency.LLMModels = round(user_data.latency.llm_models * 1000)
        dm_latency = (
            user_data.latency.end_to_end
            - user_data.latency.nlu_intent_slot
            - user_data.latency.fulfillment
            - user_data.latency.nlu_qna
            - user_data.latency.nlu_ir
            - user_data.latency.nlu_entailment
            - user_data.latency.nlu_ner
            - user_data.latency.nlu_semantic_similarity
            - user_data.latency.nlu_machine_translation
            - user_data.latency.nlu_text_classifier
            - user_data.latency.nlu_query_paraphrasing
            - user_data.latency.nlu_response_paraphrasing
            - user_data.latency.plugin_policy
            - user_data.latency.llm_models
        )
        resp.Latency.DialogManager = round(dm_latency * 1000)
        resp.Latency.TimeUnit = "ms"

        user_data.core_response = resp

    @staticmethod
    def __format_slots(slots: Dict[str, Any]):
        """Format slots to Slot response schema"""
        if not isinstance(slots, dict):
            raise ValueError("Invalid format for Slot Values")
        formatted_slots = []
        for name, values in slots.items():
            formatted_slots.append(Slot(Name=name, Values=Response.__format_slot_attributes(values)))
        return formatted_slots

    @staticmethod
    def __format_slot_attributes(slot_values: List[Any]):
        """Format Slot Values to SlotValue response schema"""
        attr_list = []
        for slot_value in slot_values:
            if isinstance(slot_value, SlotData):
                slot_value = slot_value.value
            if type(slot_value) != dict:
                attr_list.append(slot_value)
            else:
                attr_list.append(
                    SlotValue(
                        Text=slot_value.get("original_text", [""])[0],
                        Attributes=Response.__format_slots(
                            {key: value for key, value in slot_value.items() if key != "original_text"}
                        ),
                    )
                )
        return attr_list

    @staticmethod
    def __set_nlu_entity(resp: Dict[str, Any], nluType: str, slots: Dict[str, Any]):
        for entity in slots:
            resp.NlpResult.Entities.append(
                Entity(
                    Token=entity.token,
                    EntityName=entity.label.class_name,
                    ConfidenceScore=entity.label.score,
                    NluType=nluType,
                    Span=entity.span,
                    IsFmEntity=entity.is_fm_slot,
                )
            )

    @staticmethod
    def __get_expressions(response_text: str) -> List[str]:
        if response_text is None:
            return []
        return re.findall(r".*?{(.*?)}.*?", response_text.strip())

    @staticmethod
    def __get_nested_expressions(response_text: str) -> List[str]:
        """Fetch all valid placeholders which may be nested inside {}"""

        if response_text is None:
            return []

        if response_text.startswith("{") and response_text.endswith("}"):
            response_text = response_text[1:-1]

        expressions = []
        expr = ""
        collect = False
        for ch in response_text:
            if ch == "{" and not collect:
                collect = True
                continue
            elif ch == "{" and collect:
                expr = ""
                continue
            elif ch == "}" and collect:
                expressions.append(expr)
                expr = ""
                collect = False
                continue
            elif ch == "}" and not collect:
                expr = ""
            if collect:
                expr += ch

        return expressions

    @staticmethod
    async def __process_response_text(user: "UserData", response_text: str) -> str:

        if response_text is None:
            return None

        response_text = response_text.strip()
        capitalize = False
        expressions = Response.__get_expressions(response_text)
        _FM_response_cache = {}
        for expr in expressions:
            expr = expr.strip()

            # TOBE deprecated as we no longer support fulfillment v1
            executable_in_expr = False
            # fm_endpoints = Response.__get_fm_endpoints_in_response_expr(expr)
            # executable_in_expr = True if len(fm_endpoints) else False
            # if executable_in_expr:
            #     eval_expr, resp = await Response.__process_executables(fm_endpoints, _FM_response_cache, user, expr)
            #     if not eval_expr:
            #         logger.debug(
            #             f"Skipping response as some error occured while getting response from Fulfillment for expression:{expr}"
            #         )
            #         return None
            #     response_text = response_text.replace(expr, eval_expr)
            #     expr = eval_expr

            if Response.__is_conditional_expr(expr, response_text):
                if Response.__check_conditional_expr(user, expr, executable_in_expr) == False:
                    logger.debug(f"Checking pythonic conditional statement for expr: {expr}")
                    if Response.__check_pythonic_conditional_expr(user, expr, executable_in_expr) == False:
                        logger.debug(f"Skipping response as conditional statement: {expr} is False")
                        return None
                response_text = response_text.replace(f"{{{expr}}}", "").strip()
            else:
                if not executable_in_expr or isinstance(resp, (list, dict)):
                    expr_val = Response.__execute_expr(user.slots, user.fulfillment_slots, user.linked_slots, expr)
                    if expr_val is None:
                        return None
                else:
                    expr_val = expr
                response_text = response_text.strip()
                if response_text.startswith(f"{{{expr}}}"):
                    capitalize = True

                response_text = response_text.replace(f"{{{expr}}}", expr_val)
                if capitalize:
                    response_text = response_text[0].upper() + response_text[1:]
        return response_text

    @staticmethod
    def __process_json(user: "UserData", json_dict: Dict[str, Any]) -> Dict[str, Any]:

        if json_dict is None:
            return None

        json_text = str(json_dict)
        expressions = Response.__get_nested_expressions(json_text)
        for expr in [valid_exp for valid_exp in expressions if len(valid_exp.split()) == 1]:
            expr = expr.strip()
            if Response.__is_conditional_expr(expr, json_text):
                if Response.__check_conditional_expr(user, expr) == False:
                    return None
                json_text = json_text.replace(f"{{{expr}}}", "")
            else:
                expr_val = Response.__execute_expr(user.slots, user.fulfillment_slots, user.linked_slots, expr)
                if expr_val is None:
                    return None
                json_text = json_text.replace(f"{{{expr}}}", expr_val)

        return ast.literal_eval(json_text.strip())

    @staticmethod
    def __get_slot_value(user, expr) -> str:
        expr = expr.lower()
        expr_val = None

        f_expr = re.match("fulfillment\.", expr, re.I)
        if f_expr:
            expr = expr.replace(f_expr.group(0), "")  # Removing "fulfillment." tag
            expr_val = user.get_slot_value(expr, fulfillment=True)
        else:
            expr_val = user.get_slot_value(expr)

        return expr_val

    """ Methods used to evaluate conditional placeholders expression value """

    @staticmethod
    def __is_conditional_expr(expr: str, response_text: str) -> bool:
        """
        A placeholder is termed as conditional if it contains any supported
        conditional operators available in it.
        The list of valid operators are ==, != and !! and len() based conditions.
        Conditional expressions should also occur at the start of responses.
        """

        cond = False
        if "==" in expr or "!=" in expr or "!!" in expr:
            cond = True

        if "len" in expr and any(ele in expr for ele in [">", "<", "<=", ">=", "==", "!="]):
            cond = True

        if cond and response_text.startswith(f"{{{expr}}}"):
            return True

        if cond:
            logger.error(
                f"Invalid conditional expression '{{{expr}}}' in "
                f"'{response_text}'. Conditional statements should be at "
                f"the start of response texts as a placeholder enclosed by {{}}"
            )

        return False

    @staticmethod
    def __check_conditional_expr(user: "UserData", expr: str, executable_in_expr: bool = False) -> bool:
        """
        Executes the conditional placeholder and returns a boolean value
        denoting its truthfulness
        """

        # Return values for length based conditional placeholders
        if "len" in expr:
            return Response.__get_len_expr_value(user, expr)

        if "==" in expr:
            expr_val = Response.__process_expression(expr, "==")
            if len(expr_val) == 2:
                expr_val_0 = Response.__get_expr_value(user, expr_val[0])
                if expr_val_0 is None and executable_in_expr:
                    expr_val_0 = expr_val[0]
                if expr_val_0 and expr_val_0.lower() == expr_val[1].lower():
                    return True
            if len(expr_val) != 2:
                raise ValueError(f"Invalid conditional expression {expr}")

        if "!=" in expr:
            expr_val = Response.__process_expression(expr, "!=")
            if len(expr_val) == 2:
                expr_val_0 = Response.__get_expr_value(user, expr_val[0])
                if expr_val_0 is None and executable_in_expr:
                    expr_val_0 = expr_val[0]
                if expr_val_0 and expr_val_0.lower() != expr_val[1].lower():
                    return True
            if len(expr_val) != 2:
                raise ValueError(f"Invalid conditional expression {expr}")

        if "!!" in expr:
            expr_val = Response.__process_expression(expr, "!!")
            if len(expr_val) == 1 and Response.__get_expr_value(user, expr_val[0]) != None:
                return True
            if len(expr_val) != 1:
                raise ValueError(f"Invalid conditional expression {expr}")

        return False

    @staticmethod
    def __check_pythonic_conditional_expr(user: "UserData", expr: str, executable_in_expr: bool = False) -> bool:
        """
        Executes the conditional placeholder and returns a boolean value
        denoting its truthfulness
        """

        expr_mod = expr
        slots = {}
        slots = user.slots
        slots = {k.replace(".", ""): v for k, v in slots.items()}
        # Remove "." from dict keys as dict keys cannot have them
        while "fulfillment." in expr_mod:
            expr_mod = expr.replace("fulfillment.", "fulfillment")

        while "similar." in expr_mod:
            expr_mod = expr.replace("similar.", "similar")

        # Convert "system.policy.anchor" to "systempolicyanchor" to get the correct slot value
        while SYSTEM_SLOTS_POLICY_PREFIX in expr_mod:
            modified_policy_prefix = SYSTEM_SLOTS_POLICY_PREFIX.replace(".", "")
            expr_mod = expr.replace(SYSTEM_SLOTS_POLICY_PREFIX, modified_policy_prefix)

        while SYSTEM_SLOTS_PREFIX in expr_mod:
            expr_mod = expr.replace(SYSTEM_SLOTS_PREFIX, SYSTEM_SLOTS_PREFIX[0:-1])

        # Convert similar slot values from a SlotValue type to str.
        parsed_similar_slots = {}
        for slot_name, slot_values in user.linked_slots.items():
            parsed_similar_slots[slot_name] = []
            for value in slot_values:
                if isinstance(value, SlotData):
                    parsed_similar_slots[slot_name].append(value.linked_value)
                else:
                    parsed_similar_slots[slot_name].append(value)

        locals().update(slots)
        locals().update({"similar" + key: values for key, values in parsed_similar_slots.items()})

        fulfillment_slots_mod = {}
        for key, values in user.fulfillment_slots.items():
            fulfillment_slots_mod["fulfillment" + key] = values
        locals().update(fulfillment_slots_mod)
        try:
            _value = bool(eval(expr_mod))
            return _value
        except Exception as e:
            logger.info(f"Pythonic Value of: {expr} cannot be disambiguated. Returning false.")
            return False

        return False

    # TOBE deprecated as we no longer support FM v1
    # @staticmethod
    # def __get_fm_endpoints_in_response_expr(expr: str):
    #     """utility function that extracts all function calls
    #     in the response text to the FM engine
    #     The Executable should be of the format fulfillment.method()
    #     with no parameters
    #     Example: Weather.get_celsius_to_farhenheit_ratio()
    #     """
    #     endpoints = {}
    #     expressions = re.findall("[a-zA-Z0-9_]+\s*\.\s*[a-zA-Z0-9_]+\s*\(\s*\)", expr)
    #     for expression in expressions:
    #         fm_endpoint = ""
    #         for x in expression:
    #             if x != " " and x != "(" and x != ")":
    #                 fm_endpoint += x
    #         endpoints[expression] = fm_endpoint
    #     if expr.strip().startswith("GET") or expr.strip().startswith("POST") or expr.strip().startswith("/"):
    #         endpoints[expr] = expr
    #     return endpoints

    @staticmethod
    def __process_expression(expr: str, token: str) -> List[str]:
        return [e.strip() for e in expr.split(token) if e.strip() != ""]

    @staticmethod
    def __get_expr_value(user: "UserData", expr: str) -> str:

        idx, expr = Response.__get_expr_index(expr)
        expr_val = Response.__get_slot_value(user, expr)
        return str(expr_val[idx]) if expr_val and len(expr_val) and abs(idx) < len(expr_val) else None

    @staticmethod
    def __get_expr_index(expr: str) -> Tuple[int, str]:
        """Utility method to extract an index and seperate
        it out from slot name.
        Example: location[2] will return (2, location)
        """

        index = re.findall("\[(\-\d{1,}|\d{1,})\]$", expr)
        if len(index) == 1:
            expr = expr.split("[")[0]

        return (0, expr) if not len(index) == 1 else (int(index[0]), expr)

    @staticmethod
    def __get_len_expr_value(user, expr) -> bool:
        """Utility method to check syntax of length based conditional expressions
        and returns its value.
        Return None in case the placeholder dismambiguation fails or an integer
        denoting the value of the expression"""

        reg = "^(len\((\S{1,})\)[ ]{,1}(==|>=|<=|!=|<|>){1,1}[ ]{,1}[\d]{1,})$"

        if not re.match(reg, expr.strip()):
            logger.error(
                f"Invalid conditional expression '{{{expr}}}'. "
                f"Allowed syntax for length based conditional "
                f"placeholders is: {{len(slot_tag) "
                f"<comparision_operator> <integer>}}"
            )
            return False

        expr_tag = re.search("\(([^)]+)", expr).group(1)  # Extract the slot_tag inside len(*)
        expr_val_0 = Response.__get_slot_value(user, expr_tag)
        if expr_val_0 is not None:
            expr = expr.replace(expr_tag, str(expr_val_0))
            return bool(eval(expr))
        return False

    """ Methods used to evaluate non-conditional placeholders expression value """

    @staticmethod
    def __execute_expr(slots, fulfillment_slots, similar_slots, expr: str) -> str:
        """Utilty method to evaluate and return values of placeholders expressions
        cond = True"""

        _value = None
        expr_mod = expr

        slots = {k.replace(".", ""): v for k, v in slots.items()}
        # Remove "." from dict keys as dict keys cannot have them
        while "fulfillment." in expr_mod:
            expr_mod = expr.replace("fulfillment.", "fulfillment")

        while "similar." in expr_mod:
            expr_mod = expr.replace("similar.", "similar")

        # Convert "system.policy.anchor" to "systempolicyanchor" to get the correct slot value
        while SYSTEM_SLOTS_POLICY_PREFIX in expr_mod:
            modified_policy_prefix = SYSTEM_SLOTS_POLICY_PREFIX.replace(".", "")
            expr_mod = expr.replace(SYSTEM_SLOTS_POLICY_PREFIX, modified_policy_prefix)

        while SYSTEM_SLOTS_PREFIX in expr_mod:
            expr_mod = expr.replace(SYSTEM_SLOTS_PREFIX, SYSTEM_SLOTS_PREFIX[0:-1])

        # Convert similar slot values from a SlotValue type to str.
        parsed_similar_slots = {}
        for slot_name, slot_values in similar_slots.items():
            parsed_similar_slots[slot_name] = []
            for value in slot_values:
                if isinstance(value, SlotData):
                    parsed_similar_slots[slot_name].append(value.linked_value)
                else:
                    parsed_similar_slots[slot_name].append(value)

        # Update local variables in scope with slots and fulfillment slots as variables
        locals().update(slots)
        locals().update({"fulfillment" + key: values for key, values in fulfillment_slots.items()})
        locals().update({"similar" + key: values for key, values in parsed_similar_slots.items()})

        try:
            _value = eval(expr_mod)
            if isinstance(_value, list) and not len(_value):
                logger.info(f"Value of: {expr} is an empty list. Skipping response.")
                return None
        except Exception as e:
            logger.info(f"Value of: {expr} cannot be disambiguated. Skipping response.")
            return None

        return Response.__postprocess_expr_value(_value)

    @staticmethod
    def __postprocess_expr_value(expr_val: Any, is_conditional_expr=False) -> str:
        """Utilty method to postprocess the evaluate non-conditional expressions results in str representation
        1. If value is primitive data type do not manipulate it in any way
        2. If value is list of primittive data type, return comma seperated string with the last value `and` seperated.
        Example: [`red`, `green`, `blue`] -> "red, green and blue"
                 [`red`, `green`] -> "red and green"
        3. If value is anything else invalidate it
        """

        if is_conditional_expr:
            if isinstance(expr_val, list):
                if len(expr_val) == 1:
                    return str(expr_val[0])

        if type(expr_val) in [int, str, float]:
            return str(expr_val)

        if isinstance(expr_val, list):
            if all(type(elem) in [str, int, float] for elem in expr_val):
                if len(expr_val) == 1:
                    return str(expr_val[0])
                else:
                    elem_val = [str(elem) for elem in expr_val]
                    return " and ".join([", ".join(elem_val[:-1]), elem_val[-1]] if len(elem_val) > 2 else elem_val)

        return None

    @staticmethod
    def __set_semantic_similarity_results(resp: List[Any]) -> List[SemanticSimilarityResult]:
        semantic_similarity_results = []
        for match in resp:
            semantic_similarity_results.append(
                SemanticSimilarityResult(
                    Text=match.token,
                    LinkedAnchor=match.closest_match,
                    ConfidenceScore=match.score,
                    SimilarIntent=match.intent,
                    SimilarDomain=match.domain,
                    SimilarSlot=match.slot,
                )
            )
        return semantic_similarity_results

    @staticmethod
    def __set_entailment_results(resp: List[Any]) -> List[EntailmentResult]:
        entailment_results = []
        for match in resp:
            entailment_results.append(
                EntailmentResult(
                    Text=match.token,
                    LinkedAnchor=match.closest_match,
                    ConfidenceScore=match.score,
                    SimilarIntent=match.intent,
                    SimilarDomain=match.domain,
                )
            )
        return entailment_results
