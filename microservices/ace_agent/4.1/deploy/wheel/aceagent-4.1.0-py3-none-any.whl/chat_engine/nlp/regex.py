"""
 copyright(c) 2021 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""
import re
from typing import List, Dict
import logging

from chat_engine.nlp.nlp_response import TokenClassResponse, TokenClassValue, Classification
from chat_engine.nlp.nlp_utils import find_spans

logger = logging.getLogger("chat_engine")


class Regex:
    """
    find slot entity in a query given a regex dict
    """

    @staticmethod
    def process_query(query: str, regex_dict: Dict[str, List[str]]) -> "TokenClassResponse":
        """
        return dict of entity matched with regex
        Input
        e.g query : my email address is user@nvidia.com
        regex :  {"user_email" : ["[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+"]}
        Output
        TokenClassResponse
        """

        result = TokenClassResponse()
        for ent in regex_dict:
            if not len(regex_dict[ent]):
                continue
            for r in regex_dict[ent]:
                if r == "":
                    continue
                tokens = Regex._find_pattern(query, r)
                for token in tokens:
                    for span in find_spans(query, token):
                        result.slots.append(TokenClassValue(token=token, span=span, label=Classification(ent, 1.0)))

        logger.info(f"Regex NLP module result: {result}")
        return result

    @staticmethod
    def _find_pattern(query: str, regex: str) -> List[str]:
        """
        Input
        query : my email address is user@nvidia.com and alternate is cust@google.com
        regex : [a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+
        Output
        result = ['user@nvidia.com', 'cust@google.com']
        """

        p = re.compile(regex)
        result = ["".join(x) for x in re.findall(p, query)]  # Result contains list of all regex match
        return result
