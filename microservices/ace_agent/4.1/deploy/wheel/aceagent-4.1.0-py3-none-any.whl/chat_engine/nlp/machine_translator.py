# Copyright(c) 2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
Translation service to translate text from given source language to a
target language
"""

import logging
import requests
import json
from urllib.parse import urljoin
from typing import Optional
from chat_engine.constants import NLU_MACHINE_TRANSLATION_ENDPOINT

logger = logging.getLogger("chat_engine")


class MachineTranslator:
    def __init__(self, nlp_server_url: str) -> None:
        """Initialization method corresponding to Translation service"""
        self._nlp_server_url = nlp_server_url

    async def translate_text(
        self,
        query: Optional[str] = "",
        model_name: Optional[str] = "",
        endpoint: Optional[str] = "",
        src_lang: Optional[str] = "",
        tar_lang: Optional[str] = "",
        request_timeout: Optional[int] = 5,
    ) -> str:
        """
        Text Translation
        """
        headers = {"accept": "application/json", "Content-Type": "application/json"}
        data = {}
        data["texts"] = []
        if query:
            data["texts"] = [query.replace("?", "")]

        if not len(data["texts"]) > 0:
            logger.warning("Empty query found, skipping text translation request")
            return ""

        data["source_language"] = src_lang

        if not data["source_language"]:
            logger.warning("Empty source_language found, skipping text translation request")
            return ""

        data["target_language"] = tar_lang

        if not data["target_language"]:
            logger.warning("Empty target_language found, skipping text translation request")
            return ""

        if model_name:
            data["model_name"] = model_name

        response = None
        request_timeout = int(request_timeout)

        url = ""
        if endpoint:  # For custom provided endpoint from colang
            url = urljoin(self._nlp_server_url, endpoint)

        else:  # We automatically find the url from health monitor
            url = urljoin(self._nlp_server_url, NLU_MACHINE_TRANSLATION_ENDPOINT)

        if url is None:
            logger.warning("NMT model is not deployed behind NLP server yet. Skipping this action.")
            return ""

        try:
            response = requests.post(url, headers=headers, data=json.dumps(data), timeout=request_timeout)
            response.raise_for_status()
            logger.info(f"Response received from NLP server for text translation request: {response.json()}")
        except requests.exceptions.Timeout:
            logger.info("Http request to NLP server text translation model endpoint timed out.")
        except requests.exceptions.RequestException as e:
            logger.info(f"An error occurred in http request to NLP server NMT model endpoint {str(e)}")

        if response and response.json():
            translated_texts = response.json().get("translated_texts", [])
            if not len(translated_texts) > 0:
                logger.info("Translated text not found in the text translation response returned by NLP server")
                return ""
            return translated_texts[0]
        else:
            logger.info(f"Invalid or empty response returned by the NLP server NMT model endpoint {response}")
            return ""
