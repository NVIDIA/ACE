# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import os
import glob
from dataclasses import dataclass, field, fields
from model_utils.base.task import BaseTask
from model_utils.utils.path_utils import PathUtils


@dataclass
class DownloadTask(BaseTask):
    """
    Base module for Downloading Model, Bot and Resources
    """

    task_name: str = field(
        default="task.download", metadata={"help": "Download Model / Resource from NGC", "suppress": True}
    )


@dataclass
class DownloadModel(DownloadTask):
    """
    Download Model
    """

    task_name: str = field(
        default="task.download.model", metadata={"help": "Download Model from NGC", "suppress": True}
    )
    ngc_path: str = field(
        default=None,
        metadata={"help": "NGC path of the model", "validation_func": PathUtils.valid_ngc_path},
    )
    download_path: str = field(
        default=f"{os.environ.get('CACHE_PATH', './cache')}/ace_agent",
        metadata={
            "help": "Directory path for downloading the model, default to $CACHE_PATH/ace_agent",
            "validation_func": PathUtils.create_dir,
        },
    )
    download_model_path: str = field(
        init=False, default=None, metadata={"help": "File path of the downloaded NGC model"}
    )

    def execute_task(self):
        """
        Download model from NGC
        """
        from .ngc_module import NGCModule

        # create unique cache location path for each ngc path
        self.download_path = os.path.join(self.download_path, self.ngc_path.replace("/", "_").replace(":", "_"))
        PathUtils.create_dir(self.download_path)
        download_model_dir = NGCModule.download(self, registry_command="model")
        model_paths = []
        for model_type in ["rmir", "riva", "tlt", "tar.gz"]:
            model_paths.extend(glob.glob(f"{download_model_dir}/*.{model_type}"))
        if len(model_paths) == 1:
            self.download_model_path = model_paths[0]
        else:
            raise ValueError(
                f"Expected 1 model of allowed format RMIR, RIVA, TLT, TRT_PLANS, Found {len(model_paths)} models at {self.ngc_path}"
            )


@dataclass
class DownloadBot(DownloadTask):
    """
    Download Bot
    """

    task_name: str = field(default="task.download.bot", metadata={"help": "Download Bot from NGC", "suppress": True})
    ngc_path: str = field(
        default=None,
        metadata={"help": "NGC path of the Bot", "validation_func": PathUtils.valid_ngc_path},
    )
    download_path: str = field(
        default=f"{os.environ.get('CACHE_PATH', './cache')}/ace_agent",
        metadata={
            "help": "Directory path for downloading the Bot, default to $CACHE_PATH/ace_agent",
            "validation_func": PathUtils.create_dir,
        },
    )
    download_bot_path: str = field(
        init=False, default=None, metadata={"help": "Directory path of the downloaded NGC Bot"}
    )

    def execute_task(self):
        """
        Download model from NGC
        """
        from .ngc_module import NGCModule

        self.download_bot_path = NGCModule.download(self, registry_command="resource")
