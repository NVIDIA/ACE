# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import os
import argparse
from dataclasses import dataclass, field, fields

try:
    from utils.path_utils import PathUtils
except ModuleNotFoundError:
    from model_utils.utils.path_utils import PathUtils


@dataclass
class BaseTask:
    """
    Base Task Module
    - Define CLI ArgumentParser
    - Register tasks
    - Helper functions for validation, parsing arguments etc.
    """

    task_name: str = field(init=False, default="task", metadata={"help": "Select Task from ACE Agent Model Utils"})

    cache_path: str = field(
        init=False,
        default=os.environ.get("CACHE_PATH", "./cache"),
        metadata={
            "help": "Directory for caching downloaded NGC models/resources, Pretrained Language model checkpoints for training etc. For custom cache directory, modify cache_dir in docker_args.yaml in Quickstart Scripts (QSS).",
            "validation_func": PathUtils.create_dir,
            "suppress": True,
        },
    )

    task_registry = {}

    def __init_subclass__(cls, **kwargs):
        """
        Add subtasks in task_registry
        """
        super().__init_subclass__(**kwargs)
        cls.task_registry[cls.task_name.default] = cls

    @classmethod
    def get_task(cls, name):
        """
        Get task class from registry with given name
        """
        return cls.task_registry[name]

    @classmethod
    def get_all_task_names(cls):
        """
        Get names for all tasks from task registry
        """
        return cls.task_registry.keys()

    @classmethod
    def get_all_tasks(cls):
        """
        Get all tasks list from task registry
        """
        return cls.task_registry.values()

    @classmethod
    def get_subtasks(cls, name):
        """
        Get subtasks for given task name
        """
        return list(
            task
            for task_name, task in cls.task_registry.items()
            if task_name.startswith(f"{name}.") and len(task_name.split(".")) == len(name.split(".")) + 1
        )

    @classmethod
    def get_field(cls, name):
        """
        Get field from given task class with given name
        """
        for f in fields(cls):
            if f.name == name:
                return f
        return None

    @classmethod
    def configure_argparse(cls, parser):
        """
        Using registered tasks, configure ArgumentParser for CLI
        """
        subtasks = cls.get_subtasks(cls.task_name)
        if len(subtasks) == 0:
            for f in fields(cls):
                if f.init and f.metadata.get("override", True):
                    action = f.metadata.get("action", None)
                    kwargs = {}
                    if action is not None:
                        kwargs["action"] = action
                    elif f.type == bool:
                        kwargs["action"] = "store_false" if f.default else "store_true"
                    elif f.type == list:
                        kwargs["nargs"] = f.metadata.get("nargs", "+")
                    else:
                        kwargs["type"] = f.type
                    if f.metadata.get("choices", None):
                        kwargs["choices"] = f.metadata["choices"]

                    parser.add_argument(
                        f"--{f.name}",
                        required=f.metadata.get("required", False),
                        default=f.default,
                        help=f.metadata.get("help", "") if not f.metadata.get("suppress", None) else argparse.SUPPRESS,
                        **kwargs,
                    )
        else:
            subparsers = parser.add_subparsers(
                help=f"{cls.get_field('task_name').metadata.get('help', '')}", dest=cls.task_name
            )
            subparsers.required = True
            for subtask in subtasks:
                subtask_parser = subparsers.add_parser(
                    subtask.task_name.split(".")[-1],
                    formatter_class=argparse.ArgumentDefaultsHelpFormatter,
                    allow_abbrev=False,
                    help=subtask.get_field("task_name").metadata.get("help", ""),
                )
                subtask.configure_argparse(subtask_parser)

    def validate_config(self):
        """
        Validate arguments for given Task using metadata
        """
        for f in fields(self):
            # missing required arguments
            if f.metadata.get("required", False) and getattr(self, f.name) is None:
                raise ValueError(
                    f"Validation failed for {self.task_name}.{f.name} with error : Missing required argument"
                )

            if f.metadata.get("choices", None) and getattr(self, f.name) not in f.metadata.get("choices", None):
                raise ValueError(
                    f"Validation failed for {self.task_name}.{f.name} with error : Invalid value {getattr(self, f.name)}"
                )
            # Type casting if required
            try:
                if f.init and getattr(self, f.name):
                    current_value = getattr(self, f.name)
                    if type(current_value) != f.type:
                        if f.type == int:
                            current_value = int(current_value)
                        elif f.type == str:
                            current_value = str(current_value)
                        elif f.type == float:
                            current_value = float(current_value)
                        else:
                            raise ValueError("Can't convert to required type")
                        setattr(self, f.name, current_value)
            except:
                raise ValueError(
                    f"Validation failed for {self.task_name}.{f.name} with error : Failed to change type from {type(current_value)} to required {f.type}"
                )

            val_func = f.metadata.get("validation_func", None)
            if val_func:
                try:
                    setattr(self, f.name, val_func(getattr(self, f.name), **f.metadata.get("validation_args", {})))
                except Exception as e:
                    raise ValueError(f"Validation failed for {self.task_name}.{f.name} with error : {e}")

    @classmethod
    def from_arguments(cls, parsed_args):
        """
        Generate valid arguments from parsed_args and Return Task instance
        """
        all_keys = set([f.name for f in fields(cls) if f.init])
        kwargs = {k: parsed_args[k] for k in all_keys if k in parsed_args}
        return cls(**kwargs)

    def __post_init__(self):
        """
        Validating arguments and Setting up environment,
        Override function for custom logic
        """
        self.validate_config()

    def execute_task(self):
        """
        Execute core logic of task with given arguments
        """
        raise NotImplementedError()
