# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import platform

from .task_export_dataset import ExportTextClassificationDataset
from .task_export_model import TextClassificationExportRMIR

if platform.machine() == "x86_64":
    from .task_train import TextClassificationTraining
    from .task_evaluate import TextClassificationEvaluation
    from .task_export_model import TextClassificationExportRIVA
    from .task_infer import TextClassificationInference
