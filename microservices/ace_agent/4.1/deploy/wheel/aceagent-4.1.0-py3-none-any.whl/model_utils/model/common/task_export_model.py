# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
import os
import logging
import tarfile
from dataclasses import dataclass, field, fields

from model_utils.base.task import BaseTask
from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils

logger = logging.getLogger("__main__." + __name__)


@dataclass
class ExportModel(BaseTask):
    """
    Export trained Models to RIVA, RMIR, TRT_PLANS format
    """

    task_name: str = field(
        default="task.export_model",
        metadata={
            "help": "Export trained Models to RIVA, RMIR, TRT_PLANS format",
            "suppress": True,
        },
    )


@dataclass
class ExportRIVAModel(ExportModel):
    """
    Export trained TLT Model to RIVA format
    """

    task_name: str = field(
        default="task.export_model.RIVA",
        metadata={"help": "Export TLT model to RIVA format", "suppress": True},
    )
    # model metadata
    model_name: str = field(
        default=None,
        metadata={
            "required": True,
            "help": "Name of the model, will be used for creating export directory and RIVA filename",
            "validation_func": ValidationUtils.exclude_regex,
            "validation_args": {"regex_pattern": r"\W+"},
        },
    )
    version: str = field(
        default="1",
        metadata={
            "help": "Version string for the exported model, will be used for creating export directory",
            "validation_func": ValidationUtils.nonempty_value,
        },
    )
    tlt_model_path: str = field(
        default=None,
        metadata={
            "required": True,
            "help": "File path for trained TLT model checkpoint (.tlt)",
            "validation_func": PathUtils.exists_path,
        },
    )
    # results and logs path
    result_path: str = field(
        default="./results",
        metadata={
            "help": "Base directory where resulting models to be stored",
            "validation_func": PathUtils.create_dir,
        },
    )
    unique_result_path: str = field(
        init=False,
        metadata={
            "help": "Unique result directory for each model name and verison, will default to `{result_path}/{model_name}/{version}`"
        },
    )
    export_logs_path: str = field(
        init=False,
        metadata={"help": "Directory which will store export logs, will default to `{unique_result_path}/export` "},
    )
    riva_model_path: str = field(
        default=None,
        init=False,
        metadata={
            "help": "File path for exported RIVA model",
        },
    )
    # tao params
    gpus: int = field(
        default=1,
        metadata={
            "help": "Number of gpus to be used during model export",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    model_encryption_key: str = field(
        default="tlt_encode",
        metadata={"help": "Encryption key used for models during training"},
    )

    def __post_init__(self):
        """
        Custom validation logic for Model Export
        """

        super().__post_init__()

        self.unique_result_path = PathUtils.create_dir(os.path.join(self.result_path, self.model_name, self.version))
        self.export_logs_path = PathUtils.create_or_clean_path(os.path.join(self.unique_result_path, "export"))
        self.riva_model_path = PathUtils.create_dir(
            os.path.join(self.unique_result_path, "model", f"{self.task_name.split('.')[-1]}_{self.model_name}.riva"),
            path_type="file",
        )

        # create nltk cache path
        self.nltk_cache_path = PathUtils.create_dir(os.path.join(self.cache_path, "nltk"))


@dataclass
class ExportRMIRModel(ExportModel):
    """
    Export trained RIVA Model to RMIR format
    """

    task_name: str = field(
        default="task.export_model.RMIR",
        metadata={"help": "Export RIVA model to RMIR format", "suppress": True},
    )

    # model metadata
    model_name: str = field(
        default=None,
        metadata={
            "required": True,
            "help": "Name of the model, will be used for creating export directory and RMIR filename. This will be used for setting domain_name in RMIR config wherever required",
            "validation_func": ValidationUtils.exclude_regex,
            "validation_args": {"regex_pattern": r"\W+"},
        },
    )
    version: str = field(
        default="1",
        metadata={
            "help": "Version string for the exported model, will be used for creating export directory",
            "validation_func": ValidationUtils.nonempty_value,
        },
    )
    riva_model_path: str = field(
        default=None,
        metadata={
            "required": True,
            "help": "File path for RIVA model checkpoint (.riva)",
            "validation_func": PathUtils.exists_path,
        },
    )
    # results and logs path
    result_path: str = field(
        default="./results",
        metadata={
            "help": "Base directory where resulting models to be stored",
            "validation_func": PathUtils.create_dir,
        },
    )
    unique_result_path: str = field(
        init=False,
        metadata={
            "help": "Unique result directory for each model name and verison, will default to `{result_path}/{model_name}/{version}`"
        },
    )
    rmir_model_path: str = field(
        init=False,
        metadata={
            "help": "File path for the exported RMIR model",
        },
    )
    gpus: str = field(
        default="1",
        metadata={
            "help": 'GPUS to be used for model export, allowed formats - "3"[use total 3 gpus], '
            '"device=0,1"[use device 0 & 1], "all"[use all gpus]'
        },
    )
    model_encryption_key: str = field(
        default="tlt_encode",
        metadata={"help": "Encryption key used for models during training"},
    )

    def __post_init__(self):
        """
        Custom validation logic for Model Export
        """

        super().__post_init__()

        self.unique_result_path = PathUtils.create_dir(os.path.join(self.result_path, self.model_name, self.version))
        self.rmir_model_path = PathUtils.create_dir(
            os.path.join(self.unique_result_path, "model", f"{self.task_name.split('.')[-1]}_{self.model_name}.rmir"),
            path_type="file",
        )


@dataclass
class ExportTRTPlans(ExportModel):
    """
    Export RMIR Model to TRT Plans
    """

    task_name: str = field(
        default="task.export_model.TRT_PLANS",
        metadata={"help": "Export RMIR model to TensorRT model plans for current GPU platform", "suppress": True},
    )

    # model metadata
    model_name: str = field(
        default=None,
        metadata={
            "required": True,
            "help": "Name of the model, will be used for creating export directory and TRT plans tar filename",
            "validation_func": ValidationUtils.exclude_regex,
            "validation_args": {"regex_pattern": r"\W+"},
        },
    )
    version: str = field(
        default="1",
        metadata={
            "help": "Version string for the exported model, will be used for creating export directory",
            "validation_func": ValidationUtils.nonempty_value,
        },
    )
    rmir_model_path: str = field(
        default=None,
        metadata={
            "required": True,
            "help": "Path for RMIR model file",
            "validation_func": PathUtils.exists_path,
        },
    )
    # results and logs path
    result_path: str = field(
        default="./results",
        metadata={
            "help": "Base directory where resulting models to be stored",
            "validation_func": PathUtils.create_dir,
        },
    )
    unique_result_path: str = field(
        init=False,
        metadata={
            "help": "Unique result directory for each model name and verison, will default to `{result_path}/{model_name}/{version}`"
        },
    )
    plans_model_path: str = field(
        init=False,
        metadata={
            "help": "Path of exported TRT model plans, TensorRT plans are specific to GPU platforms",
        },
    )
    gpus: str = field(
        default="1",
        metadata={
            "help": 'GPUS to be used for model export, allowed formats - "3"[use total 3 gpus], '
            '"device=0,1"[use device 0 & 1], "all"[use all gpus]'
        },
    )
    model_encryption_key: str = field(
        default="tlt_encode",
        metadata={"help": "Encryption key used for models during training"},
    )

    def __post_init__(self):
        """
        Custom validation logic for Model Export
        """

        super().__post_init__()

        self.unique_result_path = PathUtils.create_dir(os.path.join(self.result_path, self.model_name, self.version))
        self.model_repository_path = PathUtils.create_or_clean_path(os.path.join(self.unique_result_path, "trt_plans"))
        self.plans_model_path = PathUtils.create_dir(
            os.path.join(
                self.unique_result_path,
                "model",
                f"plans_{os.path.basename(self.rmir_model_path).split('.')[0]}.tar.gz",
            ),
            path_type="file",
        )

    def execute_task(self):
        """
        Export RMIR model to TRT plans
        """
        from .riva_skills import RivaSkills

        try:
            RivaSkills.riva_deploy(self, model_path=self.rmir_model_path)
            with tarfile.open(self.plans_model_path, "w:gz") as tar:
                tar.add(os.path.join(self.model_repository_path, "models"), arcname=".")
        except:
            raise ValueError(f"Failed to generate TRT plans for model {self.rmir_model_path}")
        else:
            logger.info(f"Succussfully exported TRT plans at {self.plans_model_path}")
