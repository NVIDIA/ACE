# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

from dataclasses import dataclass, field, fields

from model_utils.model.common.task_export_model import ExportRIVAModel, ExportRMIRModel
from model_utils.utils.validation_utils import ValidationUtils


@dataclass
class TextClassificationExportRIVA(ExportRIVAModel):
    """
    Export Text Classification TLT Model to RIVA format
    """

    task_name: str = field(
        default="task.export_model.RIVA.text_classification",
        metadata={"help": "Export Text Classification TLT model to RIVA format", "suppress": True},
    )

    def execute_task(self):

        from .text_classification_model import TextClassificationModel

        return TextClassificationModel.export_riva(self)


@dataclass
class TextClassificationExportRMIR(ExportRMIRModel):
    """
    Export Text Classification RIVA Model to RMIR format
    """

    task_name: str = field(
        default="task.export_model.RMIR.text_classification",
        metadata={"help": "Export Text Classification RIVA model to RMIR format", "suppress": True},
    )

    batch_size: int = field(
        default=8,
        metadata={
            "help": "Batch size to be used during Inference in Triton Server",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    max_seq_length: int = field(
        default=128,
        metadata={
            "help": "Maximum sequence length to be used during inference for BERT/ DistilBERT models",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )

    def execute_task(self):

        from .text_classification_model import RivaSkillsTextClassification

        RivaSkillsTextClassification.riva_build(self)
