# Copyright (c) 2021 - 2022, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

from dataclasses import dataclass, field, fields

from model_utils.base.task import BaseTask
from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils


@dataclass
class DeploymentTask(BaseTask):
    """
    Task for Deploying models using Riva Skills
    """

    task_name: str = field(
        default="task.deploy", metadata={"help": "Task for deploying models required for the Bot", "suppress": True}
    )

    model_config_path: str = field(
        default=None,
        metadata={
            "help": "Path of Model Config for deployment. Allowed formats:- local model config path and NGC bot resource path",
            "validation_func": PathUtils.exists_local_ngc_path,
        },
    )
    model_repository_path: str = field(
        default="./model_repository",
        metadata={
            "help": "Path where optimized models will be stored for Triton Inference Server",
            "validation_func": PathUtils.create_dir,
        },
    )
    nocache: bool = field(
        default=False,
        metadata={"help": "By default cached triton model plans are used, Set flag to True to rebuild triton plans"},
    )
    speech: bool = field(default=False, metadata={"help": "Deploy speech models from Model Config"})
    model_encryption_key: str = field(
        default="tlt_encode",
        metadata={"help": "Encryption key used for models during training"},
    )
    # evaluation hyperparameters
    gpus: str = field(
        default="1",
        metadata={
            "help": 'GPUS to be used for deployment, allowed formats - "3"[use total 3 gpus], '
            '"device=0,1"[use device 0 & 1]'
        },
    )
    skip_riva_models: bool = field(default=False, metadata={"help": "Skip Riva Speech Server models"})

    def __post_init__(self):
        """
        Validate arguments and Setup Env
        """
        # validate arguments
        super().__post_init__()

        # If missing --model_config_path argument, use existing model repository
        if self.model_config_path or self.nocache:
            PathUtils.clean_path(self.model_repository_path, ignore_errors=True)

    def execute_task(self):
        """
        Start Deploying Models
        """
        from .deployment_module import DeploymentModule

        DeploymentModule.deploy_models(self)
