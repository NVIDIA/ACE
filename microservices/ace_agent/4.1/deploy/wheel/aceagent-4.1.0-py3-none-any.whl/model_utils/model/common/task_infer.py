# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import os
import yaml
import logging
from dataclasses import dataclass, field
from model_utils.base.task import BaseTask

from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils

logger = logging.getLogger("__main__." + __name__)


@dataclass
class InferTask(BaseTask):
    """
    Base module for Model Inference Task
    """

    task_name: str = field(
        init=False,
        default="task.infer",
        metadata={"help": "Task for running inference using trained TLT model on sample queries"},
    )

    # model metadata
    model_name: str = field(
        default=None,
        metadata={
            "required": True,
            "help": "Name of the model, will be used for creating result directory",
            "validation_func": ValidationUtils.exclude_regex,
            "validation_args": {"regex_pattern": r"\W+"},
        },
    )
    version: str = field(
        default="1",
        metadata={
            "help": "Version string for the model, will be used for creating result directory",
            "validation_func": ValidationUtils.nonempty_value,
        },
    )
    tlt_model_path: str = field(
        default=None,
        metadata={
            "help": "File path for TLT model checkpoint (.tlt) to be used for Inference",
            "required": True,
            "validation_func": PathUtils.exists_path,
        },
    )
    queries: list = field(
        default=None,
        metadata={
            "help": "Queries for Inference, List of strings or text files containing one query per line",
            "required": True,
        },
    )

    # result and logs dir
    result_path: str = field(
        default="./results",
        metadata={
            "help": "Base Directory where resulting logs and inference results to be stored",
            "validation_func": PathUtils.create_dir,
        },
    )
    unique_result_path: str = field(
        init=False,
        metadata={
            "help": "Unique result directory for each model name and verison, will default to `{result_path}/{model_name}/{version}`"
        },
    )
    infer_logs_path: str = field(
        init=False,
        metadata={"help": "Directory which will store infer logs, will default to `{unique_result_path}/infer` "},
    )
    # evaluation hyperparameters
    gpus: int = field(
        default=1,
        metadata={
            "help": "Number of gpus to be used for Inference",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    model_encryption_key: str = field(
        default="tlt_encode",
        metadata={"help": "Encryption key used for models during training"},
    )

    def __post_init__(self):
        """
        Custom validation and Env Setup for Infer mode
        """
        # validate arguments
        super().__post_init__()

        # create unique result path
        self.unique_result_path = PathUtils.create_dir(os.path.join(self.result_path, self.model_name, self.version))
        self.infer_logs_path = PathUtils.create_or_clean_path(os.path.join(self.unique_result_path, "infer"))

        # create nltk cache path
        self.nltk_cache_path = PathUtils.create_dir(os.path.join(self.cache_path, "nltk"))

        queries = []
        for query in self.queries:
            try:
                query_file = PathUtils.exists_path(query)
                with open(query_file) as f:
                    queries.extend(filter(None, (line.rstrip() for line in f)))
            except:
                if query.strip():
                    queries.append(query.strip())
        logger.info(f"Inferencing total {len(queries)} queries")

        self.queries_yaml = os.path.join(self.infer_logs_path, "queries.yaml")
        logger.debug(f"Inference Queries TLT Spec: {self.queries_yaml}")

        with open(self.queries_yaml, "w") as yamlfile:
            yaml.dump({"input_batch": queries}, yamlfile)
