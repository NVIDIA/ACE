"""
 copyright(c) 2021 - 2022 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

import os
import glob
import yaml
import time
import json
import shutil
import platform
import logging
import tarfile
import requests
import subprocess

from model_utils.config.constants import TRITON
from model_utils.utils.path_utils import PathUtils
from model_utils.ngc.ngc_module import NGCModule
from model_utils.utils.path_utils import PathUtils
from model_utils.ngc.task_download import DownloadModel, DownloadBot
from .riva_skills import RivaSkills

logger = logging.getLogger("__main__." + __name__)


class DeploymentModule:
    @staticmethod
    def deploy_models(config):
        """
        Deploy models using Riva Skills, Triton Server
        """
        RivaSkills.riva_stop()
        if platform.machine() == "x86_64":
            # Triton not supported for aarch64
            DeploymentModule.nlp_triton_stop()

        config.model_config_path = DeploymentModule.validate_model_config(config.model_config_path)
        riva_gpus, triton_gpus = DeploymentModule.validate_gpu_configs(config.gpus)
        riva_models, triton_models = DeploymentModule.get_model_paths(config)
        for model_path in riva_models:
            if model_path.endswith(".rmir"):
                DeploymentModule.deploy_rmir_plans(
                    config=config, rmir_model_path=model_path, gpus=riva_gpus, mode="riva"
                )
            else:
                logger.info(f"Deploying model {model_path} using Riva Speech Skills")
                shutil.unpack_archive(model_path, os.path.join(config.model_repository_path, "models"))

        for model_path in triton_models:
            if model_path.endswith(".rmir"):
                DeploymentModule.deploy_rmir_plans(
                    config=config, rmir_model_path=model_path, gpus=triton_gpus, mode="triton"
                )
            else:
                logger.info(f"Deploying model {model_path} using Triton")
                shutil.unpack_archive(model_path, os.path.join(config.model_repository_path, "models_triton"))

        RivaSkills.riva_start(config, gpus=riva_gpus)
        DeploymentModule.list_deployed_models(server_name="Riva Speech", triton_port="8000")
        if platform.machine() == "x86_64":
            # Triton not supported for aarch64
            DeploymentModule.deploy_nlp_triton(config, gpus=triton_gpus)
            DeploymentModule.list_deployed_models(server_name="Triton", triton_port="8003")

    @staticmethod
    def prepare_model_repo(config):
        """
        Prepare Model Repository for Riva Skills
        - Download Models
        - Extract TRT model plans
        - Copy RMIRs for ServiceMaker TRT conversion
        """
        config.model_config_path = DeploymentModule.validate_model_config(config.model_config_path)
        riva_models, triton_models = DeploymentModule.get_model_paths(config)
        rmir_repo_path = os.path.join(config.model_repository_path, "rmir")
        PathUtils.create_or_clean_path(rmir_repo_path)
        for model_path in riva_models:
            if model_path.endswith(".rmir"):
                copy_path = os.path.join(rmir_repo_path, os.path.basename(model_path))
                if copy_path != model_path:
                    shutil.copyfile(model_path, copy_path)
            else:
                logger.info(f"Deploying model {model_path} using Riva Speech Skills")
                shutil.unpack_archive(model_path, os.path.join(config.model_repository_path, "models"))

        for model_path in triton_models:
            if model_path.endswith(".rmir"):
                copy_path = os.path.join(rmir_repo_path, os.path.basename(model_path))
                if copy_path != model_path:
                    shutil.copyfile(model_path, copy_path)
            else:
                logger.info(f"Deploying model {model_path} using Triton")
                shutil.unpack_archive(model_path, os.path.join(config.model_repository_path, "models_triton"))

    @staticmethod
    def validate_gpu_configs(gpu_args):
        "Get valid GPU arguments for Riva Speech server and triton"
        if platform.machine() == "x86_64":
            if "device" in gpu_args:
                device_ids = gpu_args[7:].split(",")
            elif gpu_args.isnumeric():
                device_ids = list(range(0, int(gpu_args)))
            else:
                raise ValueError(
                    'Invalid format for --gpus, allowed formats - "3"[use total 3 gpus], "device=0,1"[use device 0 & 1]'
                )

            if len(device_ids) == 0:
                raise ValueError(
                    'No valid GPU device found in --gpus, allowed formats - "3"[use total 3 gpus], "device=0,1"[use device 0 & 1]'
                )
            elif len(device_ids) == 1:
                return f"device={device_ids[0]}", f"device={device_ids[0]}"
            else:
                return f"device={device_ids[0]}", f"device={device_ids[1]}"
        return gpu_args, gpu_args

    @staticmethod
    def deploy_rmir_plans(config, rmir_model_path, gpus, mode):
        """
        Check cache for rmir model plans and recreate if not available or cache invalid
        """
        cache_path = os.path.join(
            os.path.dirname(rmir_model_path), os.path.basename(rmir_model_path).split(".")[0] + "_triton_cache"
        )
        if mode == "riva":
            servicemaker_image = RivaSkills.get_riva_config("image_init_speech")
            model_repository_path = os.path.join(config.model_repository_path, "models")
        elif mode == "triton":
            servicemaker_image = TRITON.SERVICEMAKER_IMAGE
            model_repository_path = os.path.join(config.model_repository_path, "models_triton")
        else:
            raise ValueError(f"unsupported argument mode {mode}")
        riva_skills_version = servicemaker_image.split(":")[-1].replace("-servicemaker", "")
        cache_info_path = os.path.join(cache_path, "info.json")
        # cache invalidation
        cache_invalid = True
        if os.path.exists(cache_info_path):
            with open(cache_info_path) as f:
                cache_info = json.load(f)
            if (
                cache_info["last_modified"] == str(os.stat(rmir_model_path).st_mtime)
                and cache_info["riva_skills_version"] == riva_skills_version
            ):
                cache_invalid = False

        # Regenerate Model Plans
        if cache_invalid or config.nocache:
            PathUtils.create_or_clean_path(cache_path)
            RivaSkills.riva_deploy(
                config,
                model_path=rmir_model_path,
                gpus=gpus,
                model_repository_path=cache_path,
                riva_servicemaker_image=servicemaker_image,
            )
            with open(cache_info_path, "w") as f:
                json.dump(
                    {
                        "last_modified": str(os.stat(rmir_model_path).st_mtime),
                        "riva_skills_version": riva_skills_version,
                    },
                    f,
                )
        else:
            logger.info(f"Using cached Triton Model plans for RMIR model {rmir_model_path}")

        # Copying Triton Model Plans
        shutil.copytree(
            os.path.join(cache_path, "models"),
            model_repository_path,
            dirs_exist_ok=True,
            symlinks=True,
        )

    @staticmethod
    def validate_model_config(model_config_path):
        """
        Get valid model_config.yaml
        """
        if os.path.exists(model_config_path) and model_config_path.endswith(("model_config.yaml", "model_config.yml")):
            return os.path.abspath(model_config_path)
        elif os.path.exists(model_config_path) and os.path.isdir(model_config_path):
            config_paths = glob.glob(f"{model_config_path}/*model_config.yaml")
            if len(config_paths) == 1:
                return os.path.abspath(config_paths[0])
            else:
                raise ValueError(f"Expected 1 model config at {config_paths}, found {len(config_paths)}")
        elif not os.path.exists(model_config_path) and NGCModule.exists_registry_path(
            model_config_path, registry_command="resource"
        ):
            bot_download = DownloadBot.from_arguments({"ngc_path": model_config_path})
            bot_download.execute_task()
            config_paths = glob.glob(f"{bot_download.download_bot_path}/*model_config.yaml")
            if len(config_paths) == 1:
                return config_paths[0]
            else:
                raise ValueError(f"Expected 1 model config at {config_paths}, found {len(config_paths)}")
        else:
            raise ValueError(f"Invalid model config path {model_config_path}")

    @staticmethod
    def get_model_paths(config):
        """
        Get valid local model paths from model_config.yaml
        """
        logger.info(f"Getting models from model config {config.model_config_path}")
        with open(config.model_config_path, "r") as f:
            try:
                model_config = yaml.safe_load(f)
            except yaml.YAMLError as e:
                raise ValueError(f"Failed to load model config YAML file {config.model_config_path}")
        pipeline_types = ["nlp_models"]
        if config.speech:
            pipeline_types.append("speech_models")
        else:
            logger.info("Skipping Speech models for deployment")
        riva_models, triton_models = [], []
        for model_server in model_config.get("model_servers", []):
            for pipeline_type in pipeline_types:
                model_paths = model_server.get(pipeline_type, [])
                if len(model_paths) == 0:
                    continue
                elif model_server["name"] == "riva" and not config.skip_riva_models:
                    riva_models.extend(model_paths)
                elif model_server["name"] == "triton":
                    triton_models.extend(model_paths)
        return DeploymentModule.get_local_paths(
            riva_models, config.model_config_path
        ), DeploymentModule.get_local_paths(triton_models, config.model_config_path)

    @staticmethod
    def get_local_paths(model_paths, model_config_path):
        """
        Get local model paths
        - Download NGC bot
        - Get abs path for local models
        """
        local_paths = []
        for model_path in model_paths:
            if os.path.exists(os.path.join(os.path.dirname(model_config_path), model_path)):
                local_paths.append(os.path.join(os.path.dirname(model_config_path), model_path))
            elif PathUtils.valid_ngc_path(model_path):
                model_download = DownloadModel.from_arguments({"ngc_path": model_path})
                model_download.execute_task()
                local_paths.append(model_download.download_model_path)
            else:
                raise ValueError(f"Invalid model path {model_path} in model_config {model_config_path}")
        return local_paths

    @staticmethod
    def deploy_nlp_triton(config, gpus):
        """
        Deploy Triton models
        """
        if (
            not os.path.exists(os.path.join(config.model_repository_path, "models_triton"))
            or len(glob.glob(f"{config.model_repository_path}/models_triton/**/*.pbtxt", recursive=True)) == 0
        ):
            logger.info("No models found for deployment with Triton Server")
            return

        logger.info("Starting TRITON Server ...")

        try:
            command = [
                "docker",
                "run",
                "-d",
                "-u",
                f"{os.getuid()}:{os.getgid()}",
                "--shm-size=1G",
                "-p",
                f"{TRITON.HTTP_PORT}:8000",
                "-p",
                f"{TRITON.GRPC_PORT}:8001",
                "--gpus",
                str(gpus),
                "--name",
                TRITON.CONTAINER_NAME,
                "-v",
                f"{config.model_repository_path}/models_triton:/data/models",
                TRITON.IMAGE,
                "/opt/tritonserver/bin/tritonserver",
                "--model-repository=/data/models",
            ]

            subprocess.run(command, check=True)
            if not DeploymentModule.is_nlp_triton_up():
                subprocess.run(["docker", "logs", TRITON.CONTAINER_NAME], check=True)
                raise ValueError("Failed to deploy Triton Server, Check logs")
        except Exception as e:
            raise ValueError(f"Failed to deploy Triton Server, {e}")

    @staticmethod
    def is_nlp_triton_up(wait_timeout=10):
        """
        Check if Triton Server is ready
        """
        for i in range(10):
            try:
                resp = requests.get(url=f"http://localhost:{TRITON.HTTP_PORT}/v2/health/ready", timeout=wait_timeout)
                if resp.ok:
                    logger.info("Triton Server is up and ready to process queries!")
                    return True
                else:
                    logger.info("Waiting for Triton Server...")
            except:
                logger.info("Waiting for Triton Server...")
            time.sleep(wait_timeout)
        return False

    @staticmethod
    def nlp_triton_stop():
        """
        Stop NLP Triton Server
        """
        logger.info("Stopping and Removing existing NLP Triton Server ...")
        subprocess.run(
            ["docker", "rm", "-f", TRITON.CONTAINER_NAME],
            stdout=subprocess.DEVNULL,
            check=True,
        )

    @staticmethod
    def list_deployed_models(server_name, triton_host="localhost", triton_port="8000"):
        """
        Get list of models deployed on Riva Speech and Triton NLP Server
        """
        try:
            resp = requests.get(url=f"http://{triton_host}:{triton_port}/v2/health/ready", timeout=10)
            if not resp.ok:
                raise ValueError(f"Triton Server http://{triton_host}:{triton_port}/ is not up.")
        except:
            logger.warning(f"{server_name} Server is not up, unable to list the models.")
            return
        try:
            resp = requests.post(url=f"http://{triton_host}:{triton_port}/v2/repository/index", timeout=10)
            if resp.ok:
                data = json.loads(resp.content)
                pretty_data = "--------------------------------------------------------------------------------\n"
                pretty_data += "| MODEL NAME                                                        | VERSION  |\n"
                pretty_data += "--------------------------------------------------------------------------------\n"
                for model_info in data:
                    pretty_data += f"| {model_info['name']} {' '*(64-len(model_info['name']))} |     {model_info['version']}    |\n"
                pretty_data += "--------------------------------------------------------------------------------\n"
                logger.info(f"{server_name} Server deployed models :\n{pretty_data}")
                return True
            else:
                raise ValueError("Failed to list available models for Triton Server")
        except:
            raise ValueError("Failed to list available models for Triton Server")
