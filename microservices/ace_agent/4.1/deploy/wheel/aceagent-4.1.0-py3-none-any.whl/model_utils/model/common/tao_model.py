# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import os
import json
import shutil
import logging

from time import sleep

logger = logging.getLogger("__main__." + __name__)


class TAOToolkit:
    """
    Base Module for TAO Toolkit releated functionality
    """

    TAO_MOUNT_CONFIG_PATH = os.path.expanduser("~/.tao_mounts.json")
    TAO_DOCKER_IMAGE = "nvcr.io/nvidia/tao/tao-toolkit-pyt:v3.21.11-py3"

    @staticmethod
    def update_tao_mounts(mount_paths):
        """
        Update tao_mounts.json
        """
        mounts = []
        for source, target in mount_paths.items():
            mounts.append({"source": source, "destination": target})

        tao_mount_json = {
            "Mounts": mounts,
            "DockerOptions": {"shm_size": "2G", "user": f"{os.getuid()}:{os.getgid()}"},
        }

        with open(TAOToolkit.TAO_MOUNT_CONFIG_PATH, "w") as f:
            json.dump(tao_mount_json, f, indent=4)
        logger.debug("tao mount json: {}".format(json.dumps(tao_mount_json, indent=4)))

    @staticmethod
    def run_on_ngc(command, mounts, num_gpus, gpu_memory):
        """
        Run given command using NGC Batch inside Tao Container
        """
        from model_utils.ngc.ngc_module import NGCModule, NGCJobParams

        # create NGC datasets
        dataset_id_mount_paths = {}
        for mount in mounts:
            if mount["type"] == "dataset":
                data_id = NGCModule.upload_dataset(mount["source"])
                logger.info(f"Uploaded dataset with id {data_id}")
                dataset_id_mount_paths[data_id] = f"/data{mount['target']}"
                command = f"cp -r /data{mount['target']} {mount['target']} && {command}"
        job_config = NGCJobParams(
            image=TAOToolkit.TAO_DOCKER_IMAGE,
            command=command,
            dataset_mounts=dataset_id_mount_paths,
            result_path="/result",
            num_gpus=num_gpus,
            ports=["6006"],
            gpu_memory=gpu_memory,
        )
        job_id = NGCModule.create_ngc_batch_job(job_config)

        logger.info(f"Created NGC job with id {job_id}, Waiting for NGC job to start...")
        while True:
            status = NGCModule.get_job_info(job_id)["jobStatus"]["status"]
            logger.debug(f"Job {job_id} status : {status}")
            if status == "FAILED":
                raise ValueError("NGC job execution failed")
            elif status == "RUNNING" or status == "FINISHED_SUCCESS":
                break
            else:
                sleep(10)

        logger.info(f"NGC job {job_id} is running ...")
        NGCModule.get_ngc_job_logs(job_id)

        while True:
            status = NGCModule.get_job_info(job_id)["jobStatus"]["status"]
            logger.debug(f"Job {job_id} status : {status}")
            if status == "FAILED":
                raise ValueError("NGC job execution failed")
            elif status == "FINISHED_SUCCESS":
                break
            else:
                sleep(10)
        logger.info(f"NGC job {job_id} is successfully completed")

        # download results
        for mount in mounts:
            if mount["type"] == "result":
                if not mount["target"].startswith("/result"):
                    raise ValueError("NGC job results should be stored at /result/** for download")
                NGCModule.download_results(job_id, mount["target"][7:], mount["source"])

    @staticmethod
    def train(config):
        """
        Train model using TAO Toolkit
        """
        pass

    @staticmethod
    def evaluate(config):
        """
        Evaluate model using TAO Toolkit
        """
        pass

    @staticmethod
    def infer(config):
        """
        Inference model using TAO Toolkit
        """
        pass

    @staticmethod
    def export_riva(config):
        """
        Export TLT model to RIVA model
        """
        pass
