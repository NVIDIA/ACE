# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import subprocess
import logging
import os

from model_utils.model.common.tao_model import TAOToolkit
from model_utils.model.common.riva_skills import RivaSkills

logger = logging.getLogger("__main__." + __name__)


class TextClassificationModel(TAOToolkit):
    """
    Text Classification Model using TAO
    """

    @staticmethod
    def train(config):
        """
        Train Text Classification Model
        """
        logger.info(f"Starting Text Classification {config.platform} training using TAO..\n")

        num_domains = len(
            [
                line
                for line in open(os.path.join(config.dataset_path, config.labels_filename)).readlines()
                if line.strip() != ""
            ]
        )

        command = [
            "tao",
            "text_classification",
            "train",
            "-e /workspace/tlt/samples/nlp/text_classification/experiment_specs/train.yaml",
            f"-g {config.gpus}",
            f"-r /result/{os.path.relpath(config.train_logs_path, config.result_path)}",
            f"-k {config.model_encryption_key}",
            "training_ds.file_path=/dataset/train.tsv",
            "validation_ds.file_path=/dataset/dev.tsv",
            f"model.class_labels.class_labels_file=/dataset/{config.labels_filename}",
            f"model.dataset.num_classes={num_domains}",
            f"model.dataset.class_balancing={config.class_balancing}",
            f"model.language_model.pretrained_model_name={config.pretrained_model_name}",
            f"model.dataset.max_seq_length={config.max_seq_length}",
            f"model.classifier_head.num_output_layers={config.num_head_output_layers}",
            f"optim.lr={config.lr}",
            f"optim.weight_decay={config.weight_decay}",
            f"trainer.max_epochs={config.epochs}",
            f"training_ds.batch_size={config.batch_size}",
            f"trainer.amp_level={config.training_amp_level}",
            f"trainer.precision={config.training_precision}",
        ]

        logger.debug(f"Text classification Training TAO COMMAND :  {' '.join(command)} \n")
        if config.platform == "local":
            tao_mount_paths = {
                config.dataset_path: "/dataset",
                config.result_path: "/result",
                config.cache_path: "/.cache",
                config.nltk_cache_path: "/nltk_data",
            }
            TextClassificationModel.update_tao_mounts(tao_mount_paths)
            subprocess.run(command, check=True)
        elif config.platform == "ngc":
            ngc_mount_paths = [
                {"type": "dataset", "source": config.dataset_path, "target": "/dataset"},
                {
                    "type": "result",
                    "source": config.tlt_model_path,
                    "target": f"/result/{os.path.relpath(config.tlt_model_path, config.result_path)}",
                },
            ]
            TextClassificationModel.run_on_ngc(
                command=" ".join(command[1:]),
                mounts=ngc_mount_paths,
                num_gpus=config.gpus,
                gpu_memory=config.gpu_memory,
            )
        else:
            raise ValueError(f"Invalid Training Platform {config.platform}")

        if not os.path.exists(config.tlt_model_path):
            raise ValueError("Unable to locate trained TLT model, Training failed")
        else:
            logger.info(f"Trained TLT model saved at {config.tlt_model_path}")

    @staticmethod
    def evaluate(config):
        """
        Evaluate Text Classification Model
        """
        logger.info("Evaluating Text Classification Model using TAO")

        command = [
            "tao",
            "text_classification",
            "evaluate",
            "-e /workspace/tlt/samples/nlp/text_classification/experiment_specs/evaluate.yaml",
            f"-g {config.gpus}",
            "-m /model/trained-model.tlt",
            "-r /result/logs",
            f"-k {config.model_encryption_key}",
            f"test_ds.file_path=/dataset/{config.test_file_prefix}.tsv",
            f"test_ds.batch_size={config.batch_size}",
        ]

        logger.debug(f"Text Classification Evaluate COMMAND :  {' '.join(command)} \n")
        if config.platform == "local":
            tao_mount_paths = {
                config.evaluate_logs_path: "/result/logs",
                config.dataset_path: "/dataset",
                config.tlt_model_path: "/model/trained-model.tlt",
                config.cache_path: "/.cache",
                config.nltk_cache_path: "/nltk_data",
            }
            TextClassificationModel.update_tao_mounts(tao_mount_paths)
            subprocess.run(command, check=True)
        elif config.platform == "ngc":
            ngc_mount_paths = [
                {"type": "dataset", "source": config.dataset_path, "target": "/dataset"},
                {"type": "dataset", "source": config.tlt_model_path, "target": "/model/"},
                {"type": "result", "source": config.evaluate_logs_path, "target": f"/result/logs"},
            ]
            TextClassificationModel.run_on_ngc(
                command=" ".join(command[1:]),
                mounts=ngc_mount_paths,
                num_gpus=config.gpus,
                gpu_memory=config.gpu_memory,
            )
        else:
            raise ValueError(f"Invalid Evaluation Platform {config.platform}")

    @staticmethod
    def infer(config):
        """
        Inference Text Classification Model
        """
        logger.info("Text Classification Model inference using TAO")

        command = [
            "tao",
            "text_classification",
            "infer",
            "-e /dataset/queries.yaml",
            f"-g {config.gpus}",
            "-m /model/trained-model.tlt",
            "-r /result/logs",
            f"-k {config.model_encryption_key}",
        ]
        logger.debug(f"Text Classification Inference COMMAND :  {' '.join(command)} \n")
        tao_mount_paths = {
            config.infer_logs_path: "/result/logs",
            config.queries_yaml: "/dataset/queries.yaml",
            config.tlt_model_path: "/model/trained-model.tlt",
            config.cache_path: "/.cache",
            config.nltk_cache_path: "/nltk_data",
        }
        TextClassificationModel.update_tao_mounts(tao_mount_paths)
        subprocess.run(command, check=True)

    @staticmethod
    def export_riva(config):
        """
        Export Text Classification TLT Model to RIVA
        """
        logger.info("Exporting Text Classification Model to RIVA..\n")

        tao_mount_paths = {
            config.result_path: "/result",
            config.tlt_model_path: "/trained-model.tlt",
            config.cache_path: "/.cache",
            config.nltk_cache_path: "/nltk_data",
        }
        TextClassificationModel.update_tao_mounts(tao_mount_paths)

        command = [
            "tao",
            "text_classification",
            "export",
            "-e /workspace/tlt/samples/nlp/text_classification/experiment_specs/export.yaml",
            f"-g {config.gpus}",
            f"-r /result/{os.path.relpath(config.export_logs_path, config.result_path)}",
            f"-k {config.model_encryption_key}",
            f"-m /trained-model.tlt",
            "export_format=RIVA",
            f"export_to=/result/{os.path.relpath(config.riva_model_path, config.result_path)}",
        ]

        logger.debug(f"Text Classification RIVA export COMMAND :  {' '.join(command)} \n")
        subprocess.run(command, check=True)

        if not os.path.exists(config.riva_model_path):
            raise ValueError("Unable to locate RIVA model, TLT to RIVA export failed")
        else:
            logger.info(f"Exported RIVA model saved at {config.riva_model_path}")


class RivaSkillsTextClassification(RivaSkills):
    @staticmethod
    def riva_build(config):
        logger.info("\n\nExporting RIVA model to RMIR using ServiceMaker..")
        subprocess.run(
            [
                "docker",
                "run",
                "-it",
                "--rm",
                "-u",
                f"{os.getuid()}:{os.getgid()}",
                "--gpus",
                "all",
                "-v",
                f"{os.path.dirname(config.riva_model_path)}:/models",
                RivaSkills.get_riva_config("image_init_speech"),
                "riva-build",
                "text_classification",
                "--domain_name",
                "domain",
                "--max_batch_size",
                str(config.batch_size),
                f"/models/{os.path.basename(config.rmir_model_path)}:{config.model_encryption_key}",
                f"/models/{os.path.basename(config.riva_model_path)}:{config.model_encryption_key}",
                "-f",
            ],
            check=True,
        )
        if not os.path.exists(config.rmir_model_path):
            raise ValueError("Unable to locate RMIR model, RIVA to RMIR export failed")
        else:
            logger.info(f"Exported RMIR model saved at {config.rmir_model_path}")
