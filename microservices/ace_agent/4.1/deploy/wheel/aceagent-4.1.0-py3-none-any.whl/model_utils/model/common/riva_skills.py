"""
 copyright(c) 2020 - 2021 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

import os
import glob
import logging
import subprocess
import platform
from pathlib import Path


logger = logging.getLogger("__main__." + __name__)


class RivaSkills:
    """
    Module for utilizing Riva Skills Quickstart scripts
    """

    ROOT_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)), "../../")
    QUICKSTART_PATH = (
        "/home/ace-agent/riva-api/quickstart"
        if Path("/home/ace-agent/riva-api/quickstart").is_dir()
        else os.path.join(ROOT_PATH, "riva-api/quickstart")
    )
    QUICKSTART_CONFIG = os.path.abspath(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "../../config",
            "riva_skills_config.sh",
        )
    )

    @staticmethod
    def get_riva_config(config_name):
        """
        Get value for given key from QUICKSTART_CONFIG path
        """
        output = subprocess.check_output(
            f"source {RivaSkills.QUICKSTART_CONFIG} && echo ${config_name}",
            shell=True,
            executable="/bin/bash",
        )
        config_value = output.decode().splitlines()[0].strip()
        if config_value == "":
            raise ValueError(f"No value found for {config_name} in Riva Skills config {RivaSkills.QUICKSTART_CONFIG}")
        return config_value

    @staticmethod
    def riva_build(config):
        """
        riva_build command for creating RMIR Model from Riva Model
        Should be implemented for each model type seperately
        """
        raise NotImplementedError

    @staticmethod
    def riva_deploy(config, model_path, model_repository_path, gpus, riva_servicemaker_image):
        """
        Generate Triton plans for given model_path
        """
        # Generate model plan for given path
        logger.info("Preparing Triton Model Plan for {}".format(model_path))
        try:
            command = [
                "docker",
                "run",
                "--init",
                "--rm",
                "-u",
                f"{os.getuid()}:{os.getgid()}",
                "--runtime=nvidia" if platform.machine() == "aarch64" else "--gpus",
                "" if platform.machine() == "aarch64" else f"{str(gpus)}",
                "-v",
                f"{model_repository_path}:/data",
                "-v",
                f"{model_path}:/model.rmir",
                riva_servicemaker_image,
                "riva-deploy",
                "-f",
                f"/model.rmir:{config.model_encryption_key}",
                "/data/models",
            ]
            subprocess.run(
                [c for c in command if len(c.strip())],
                check=True,
            )
        except:
            raise ValueError("Failed to generate Triton model plans")

    @staticmethod
    def riva_start(config, gpus):
        """
        Start Riva Speech Server using Riva Skills Quickstart scripts
        """
        logger.info("Deploying Riva Skills model repository {}".format(config.model_repository_path))
        if (
            not os.path.exists(os.path.join(config.model_repository_path, "models"))
            or len(glob.glob(f"{config.model_repository_path}/models/**/*.pbtxt", recursive=True)) == 0
        ):
            logger.info("No models found for deployment in model repository")
            return

        logger.info("Starting TRITON & RIVA API server..")
        try:
            riva_env = os.environ.copy()
            riva_env["TRITON_MODEL_REPO"] = config.model_repository_path
            riva_env["MODEL_ENCRYPTION_KEY"] = config.model_encryption_key
            riva_env["GPU_TO_USE"] = gpus

            riva_start_cmd = " ".join(
                [
                    f"{RivaSkills.QUICKSTART_PATH}/riva_start.sh",
                    RivaSkills.QUICKSTART_CONFIG,
                    "-s",
                ]
            )

            subprocess.run(["bash", "-c", riva_start_cmd], check=True, env=riva_env)
        except:
            raise ValueError(f"Failed to deploy Triton and Speech API server")
        logger.info("Successfully deployed Riva Speech Server")

    @staticmethod
    def riva_stop():
        """
        Stop Riva Skills Speech Server
        """
        logger.info("Stopping and Removing existing Riva Speech Server ...")
        subprocess.run(
            ["docker", "rm", "-f", RivaSkills.get_riva_config("riva_daemon_speech")],
            stdout=subprocess.DEVNULL,
            check=True,
        )
