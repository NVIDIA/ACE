# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import os
from dataclasses import dataclass, field, fields

from model_utils.model.common.task_train import TrainingTask
from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils


@dataclass
class NERTraining(TrainingTask):
    """
    Train NER Model
    """

    task_name: str = field(
        default="task.train.ner",
        metadata={"help": "Train Named Entity Recogination (NER) Model", "suppress": True},
    )
    dataset_path: str = field(
        default=None,
        metadata={
            "help": "Directory path for Nemo format NER dataset",
            "required": True,
            "validation_func": PathUtils.exists_path,
        },
    )
    # training hyperparameters
    epochs: int = field(
        default=50,
        metadata={
            "help": "Max number of epochs for training to be executed",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    lr: float = field(
        default=5e-5,
        metadata={
            "help": "Learning rate to be used for training",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0.0, "less_than": 1.0},
        },
    )
    batch_size: int = field(
        default=32,
        metadata={
            "help": "Batch size used for training",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    weight_decay: float = field(
        default=0.0,
        metadata={
            "help": "Weight decay to be used with optimizer during training",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_equal": 0.0, "less_equal": 1.0},
        },
    )
    pretrained_model_name: str = field(
        default="bert-base-uncased",
        metadata={
            "help": "Name of pretrained langauge model for training, recommended bert-base-uncased and distilbert-base-uncased",
            "validation_func": ValidationUtils.nonempty_value,
        },
    )
    class_balancing: str = field(
        default="weighted_loss",
        metadata={
            "help": "Use weighted_loss for using class weights for training loss, Recommended for imbalanced training datasets",
            "choices": ["null", "weighted_loss"],
        },
    )
    max_seq_length: int = field(
        default=128,
        metadata={
            "help": "Maximum sequence length to be used for BERT/ DistilBERT models during training",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )

    def execute_task(self):
        """
        Start training NER model
        """
        from .ner_model import NERModel

        return NERModel.train(self)
