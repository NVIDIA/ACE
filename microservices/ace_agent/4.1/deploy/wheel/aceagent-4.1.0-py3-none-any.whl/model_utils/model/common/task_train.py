# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import os
from dataclasses import dataclass, field, fields
from model_utils.base.task import BaseTask

from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils


@dataclass
class TrainingTask(BaseTask):
    """
    Base Task class for Training models
    """

    task_name: str = field(init=False, default="task.train", metadata={"help": "Task for Training models using TLT"})

    # model metadata
    model_name: str = field(
        default=None,
        metadata={
            "required": True,
            "help": "Name of the model, will be used for creating result directory",
            "validation_func": ValidationUtils.exclude_regex,
            "validation_args": {"regex_pattern": r"\W+"},
        },
    )
    version: str = field(
        default="1",
        metadata={
            "help": "Version string for the generated model, will be used for creating result directory",
            "validation_func": ValidationUtils.nonempty_value,
        },
    )
    platform: str = field(
        default="local",
        metadata={
            "help": "Platform for running model training, use ngc platfrom for training using NGC Batch",
            "choices": ["local", "ngc"],
        },
    )
    # result and logs dir
    result_path: str = field(
        default="./results",
        metadata={
            "help": "Base directory where resulting models to be stored, default to ./results",
            "validation_func": PathUtils.create_dir,
        },
    )
    unique_result_path: str = field(
        init=False,
        metadata={
            "help": "Unique result directory for each model name and verison, will default to `{result_path}/{model_name}/{version}`"
        },
    )
    train_logs_path: str = field(
        init=False,
        metadata={
            "help": "Directory which will store training checkpoints and logs, will default to `{unique_result_path}/train` "
        },
    )
    tlt_model_path: str = field(
        init=False,
        metadata={
            "help": "Path for the saved trained TLT model (.tlt), will default to `{train_logs_path}/checkpoints/trained-model.tlt"
        },
    )
    # training hyperparameters
    gpus: int = field(
        default=1,
        metadata={
            "help": "Number of gpus to be used for training",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    model_encryption_key: str = field(
        default="tlt_encode",
        metadata={"help": "Key which will be used for encrypting trained model"},
    )
    training_precision: str = field(
        default="16",
        metadata={
            "help": "Precision for model training, set to 16 for mixed precision training",
            "choices": ["16", "32"],
        },
    )
    training_amp_level: str = field(
        default="O1",
        metadata={
            "help": "For mixed precision use O1 and O2 amp_level to enable the AMP",
            "choices": ["O0", "O1", "O2"],
        },
    )
    gpu_memory: str = field(
        default="32",
        metadata={
            "help": "Optional flag for training on NGC platform, GPU memory required per instance for NGC Jobs. Check NGC Batch for available choices"
        },
    )

    def __post_init__(self):
        """
        Custom validation logic
        """
        super().__post_init__()

        self.unique_result_path = PathUtils.create_or_clean_path(
            os.path.join(self.result_path, self.model_name, self.version)
        )
        self.train_logs_path = PathUtils.create_or_clean_path(os.path.join(self.unique_result_path, "train"))
        self.tlt_model_path = os.path.join(self.train_logs_path, "checkpoints", "trained-model.tlt")

        # create nltk cache path
        self.nltk_cache_path = PathUtils.create_dir(os.path.join(self.cache_path, "nltk"))
