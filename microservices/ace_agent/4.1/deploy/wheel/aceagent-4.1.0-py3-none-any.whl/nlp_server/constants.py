# copyright(c) 2022-2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

""" nlu constants """
import os

QNA_CONTEXT_LEN = 240
STRIDE_WORD_COUNT = QNA_CONTEXT_LEN // 2

# Defined valid model_types for different NLU models which are exposed to user
RIVA_MODEL = "riva"
TRITON_MODEL = "triton"
CUSTOM_MODEL = "custom"
# Internal Model Types
EMBEDDING_SEARCH_MODEL = "embedding_search"


DOMAIN_NO_MATCH = "none"
INTENT_NO_MATCH = "none"

# Timeout in seconds for calls to different model API's
NLP_TRITON_SIMCSE_SERVER_TIMEOUT = 30
NLP_RIVA_SERVER_TIMEOUT = 5
NLP_RIVA_QA_SERVER_TIMEOUT = 10


ENDPOINT_TASK_MAPPING = {
    "/nlp/model/joint_intent_slot": "intent_slot",
    "/nlp/model/ner": "ner",
    "/nlp/model/text_classification": "text_classifier",
    "/nlp/model/generate_embedding": "embedding",
    "/nlp/model/extractive_qa": "qna",
    "/nlp/embedding_search/create_store": "embedding_create_store",
    "/nlp/embedding_search/search": "embedding_search_store",
    "/nlp/embedding_search/delete_store": "embedding_delete_store",
}


class PytritonConfig:
    HTTP_PORT = 8006
    GRPC_PORT = 8007
    METRICS_PORT = 8008
