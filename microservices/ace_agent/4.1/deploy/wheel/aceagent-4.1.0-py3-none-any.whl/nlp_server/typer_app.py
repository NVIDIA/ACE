# Copyright(c) 2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

""" Typer app exposing arguments to run the NLP server package """

import os
import typer
from enum import Enum
from rich import print
from subprocess import run
from typing import Optional

nlp_server = typer.Typer(
    no_args_is_help=True,
    help="Deploy or stop the RESTful interfaces to interact with the deployed models.",
    add_completion=False,
)


class LogLevel(str, Enum):
    CRITICAL = "CRITICAL"
    FATAL = "FATAL"
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"
    DEBUG = "DEBUG"


# Default value of arguments accepted
CUSTOM_MODEL_DIR = None
PORT = 9003
WORKERS = 4
TIMEOUT = 300  # seconds


@nlp_server.command(
    help="Bring up the REST API's for NLP server. Interact with the deployed models using these API's."
)
def deploy(
    config: Optional[str] = typer.Option(
        None,
        "-c",
        "--config",
        exists=True,
        help="Relative path to the present working directory containing the model config yaml file.",
    ),
    custom_model_dir: Optional[str] = typer.Option(
        CUSTOM_MODEL_DIR, "-d", "--custom_model_dir", help="Directory containing custom model clients for NLP Server"
    ),
    log_level: LogLevel = typer.Option(default="INFO", help="Control the verbosity level of the NLP Server logs."),
    port: Optional[int] = typer.Option(PORT, "-p", "--port", help="Port where the nlp server will start."),
    workers: Optional[int] = typer.Option(
        WORKERS, "-w", "--workers", help="Number of workers to start the nlp server."
    ),
    timeout: Optional[int] = typer.Option(
        TIMEOUT, "-to", "--timeout", help="Maximum time the server can take to initialize."
    ),
):

    print(f"Starting the NLP server with config {config} and custom model directory {custom_model_dir}.")
    if config:
        os.environ["CONFIG_PATH"] = config
    if custom_model_dir:
        os.environ["CUSTOM_MODEL_DIR"] = custom_model_dir
    os.environ["NLP_SERVER_LOG_LEVEL"] = log_level

    server_cmd = f"gunicorn 'nlp_server.main:app' --worker-class uvicorn.workers.UvicornWorker --bind 0.0.0.0:{port} --timeout {timeout} -w {workers} --preload"

    print(f"Starting gunicorn server with command: {server_cmd}")
    run(server_cmd, shell=True, check=True)


@nlp_server.command(help="Stop any locally running NLP server.")
def stop():
    print(f"Stopping any running NLP server.")
    server_cmd = f"pkill -f 'nlp_server.main:app'"

    print(f"Stopping gunicorn nlp server with command: {server_cmd}")
    run(server_cmd, shell=True)
    print(f"All NLP servers stopped successfully.")
