"""
copyright(c) 2022-2023 NVIDIA Corporation.All rights reserved.

NVIDIA Corporation and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto.Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA Corporation is strictly prohibited.
"""

import inspect
import logging

logger = logging.getLogger(__name__)


class ModelManager:
    @staticmethod
    async def is_ready_model_api(model_info):
        if not model_info.func_ready:
            logger.error(f"Model Readiness function not available for {model_info.model_name}")
            return True
        try:
            if inspect.iscoroutinefunction(model_info.func_ready):
                return await model_info.func_ready(
                    model_name=model_info.model_name, model_version=model_info.model_version
                )
            else:
                return model_info.func_ready(model_name=model_info.model_name, model_version=model_info.model_version)
        except Exception as e:
            logger.error(
                f"Error while readiness check for model {model_info.model_name} for endpoint {model_info.endpoint}"
            )
            raise e

    @staticmethod
    async def execute_model_api(model_info, *args, **kwargs):
        try:
            if inspect.isfunction(model_info.func):
                model_info.func.model_info = model_info
            else:
                model_info.func.__dict__["model_info"] = model_info
            if inspect.iscoroutinefunction(model_info.func):
                return await model_info.func(*args, **kwargs)
            else:
                return model_info.func(*args, **kwargs)
        except Exception as e:
            logger.error(
                f"Error while inference request for model {model_info.model_name} for endpoint {model_info.endpoint}"
            )
            raise e
