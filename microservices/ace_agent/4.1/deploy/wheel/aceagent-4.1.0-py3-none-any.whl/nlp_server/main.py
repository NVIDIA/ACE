# copyright(c) 2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import os
import sys
import logging
import prometheus_client

# fastapi imports
from fastapi import FastAPI, Response
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from contextlib import asynccontextmanager
from multiprocessing import Value

# add NLP Server to sys.path
sys.path.append("..")

from nlp_server.core.config_manager import ConfigManager
from nlp_server.core.model_registry import ModelRegistry
from nlp_server.package_info import __version__

# Default NLP Model APIs
from nlp_server.api import (
    registry_api,
    intent_slot,
    text_classification,
    ner,
    embedding,
    extractive_qa,
    nmt,
    tts,
)


# setup loggers
handler = logging.StreamHandler()
handler.setFormatter(
    logging.Formatter(
        r"%(asctime)s.%(msecs)03d [%(process)d] [%(levelname)s] logger=%(name)s %(funcName)s() L%(lineno)-4d %(message)s",
        datefmt=r"%Y-%m-%d %H:%M:%S",
    )
)
logging.basicConfig(level=os.environ.get("NLP_SERVER_LOG_LEVEL", "INFO"), handlers=[handler])

# get root logger
logger = logging.getLogger(__name__)

tags_metadata = [
    {
        "name": "Health APIs",
        "description": "APIs for checking Server Health Status",
    },
    {"name": "Registry APIs", "description": "APIs for getting model metadata for available models"},
    {"name": "Model APIs", "description": "Low Level Model APIs for NLP Server"},
    {"name": "Embedding Search APIs", "description": "APIs for Embedding Search"},
    {
        "name": "Language Translation APIs",
        "description": "APIs for translating text from source language to target language",
    },
    {
        "name": "Speech APIs",
        "description": "APIs for integrating Speech models and 3rd party APIs such as ASR and TTS",
    },
    {"name": "Custom APIs", "description": "User created APIs for NLP Server"},
]

server_flag = Value("i", 0)  # Used for setting lock for onetime execution


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create Model Registry Instance
    ModelRegistry.create_instance()
    # Create NLP Config Manager Instance
    config_manager = ConfigManager(app=app)
    server_worker = False
    with server_flag.get_lock():
        if server_flag.value == 0:
            # Create triton context for this worker
            server_flag.value = 1
            server_worker = True
            # Server Pytriton models
            config_manager.initialize_pytriton()
    # Registering Models
    await config_manager.initalize_model_servers()
    # Check if any valid model available in registry
    if len(ModelRegistry.get_instance().list_models()) == 0:
        logger.error(
            "No valid models for inference in NLP Server, Please specify models using --config or --custom_model_dir"
        )
    yield
    # Stop the triton server,  and Clean Up
    if server_worker:
        config_manager.stop_pytriton()
        # reset lock
        with server_flag.get_lock():
            server_flag.value == 0


# FastAPI app object
app = FastAPI(
    title="NVIDIA ACE Agent NLP Server",
    docs_url="/docs",
    version=__version__,
    lifespan=lifespan,
    openapi_tags=tags_metadata,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Default route
@app.get("/status", tags=["Health APIs"])
async def root():
    """
    Health Check Endpoint
    """
    return {}


@app.get("/metrics", tags=["Health APIs"])
def get_metrics():
    return Response(content=prometheus_client.generate_latest(), media_type="text/plain")


# NLP Model Registry APIs
app.include_router(registry_api.router)
# NLP Low Level APIs
app.include_router(intent_slot.router)
app.include_router(text_classification.router)
app.include_router(ner.router)
app.include_router(embedding.router)
app.include_router(extractive_qa.router)
# NMT APIs
app.include_router(nmt.router)

# Speech APIs
app.include_router(tts.router)
