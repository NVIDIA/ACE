# Copyright(c) 2021-2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
Utility methods used by several NLU and Policy modules
"""

import os
import json
import logging
import numpy as np
from re import finditer, escape, findall, sub, IGNORECASE
from typing import List, Dict, Any
from nlp_server.model.nlp_response import (
    Classification,
    TokenClassValue,
)

from nltk import pos_tag
from nltk.tree import Tree
from nltk.chunk import conlltags2tree
import nltk

nltk.download("averaged_perceptron_tagger", download_dir=os.path.join(os.getcwd(), "nltk_data"))
nltk.download("averaged_perceptron_tagger_eng", download_dir=os.path.join(os.getcwd(), "nltk_data"))
nltk.data.path.append(os.path.join(os.getcwd(), "nltk_data"))

logger = logging.getLogger(__name__)


# HACK : combine like slots to avoid incorrect
#        detection by fulfillment
def combine_adjacent_slots(slots: Any, query: str) -> None:
    """
    Combines Adjacent Slots that belong to same class
    """
    init_slot = None
    for slot in list(slots):
        if not init_slot:
            init_slot = slot
            continue
        if init_slot.label.class_name == slot.label.class_name:
            new_token = get_adjacent_token(init_slot.token, slot.token, query)
            if len(new_token):
                slot.token = new_token
                slot.label.score = (slot.label.score + init_slot.label.score) / 2.0
                slots.remove(init_slot)
                init_slot = slot
        else:
            init_slot = slot


def get_adjacent_token(first_token: str, next_token: str, query: str) -> str:
    """
    Return new token if two tokens are adjacent
    to each other w.r.t. query otherwise empty string
    """
    pattern = r"\b(?:" + escape(first_token) + r"\W*(?:\w+\W+){0}?" + escape(next_token) + r")\b"
    res = findall(pattern, query)
    return res[0] if len(res) else ""


def restore_slots_case(slots, query):
    """
    Restores slots from lower case to the case present in the original query
    """
    for slot in slots:
        matches = (
            list(finditer(escape(str(slot["Token"])), query, IGNORECASE))
            if isinstance(slot, dict)
            else list(finditer(escape(str(slot.token)), query, IGNORECASE))
        )
        if len(matches):
            s = matches[0].start()
            e = matches[0].end()
            if isinstance(slot, dict):
                slot["Token"] = query[s:e]
            else:
                slot.token = query[s:e]
            query = query[:s] + query[e + 1 :]


def find_spans(query: str, token: str) -> List[Dict[str, int]]:
    """Method to find all the spans of token inside query.
    Example:
    input:
    query: Add one large french fries and one large pizza, token: large

    output:
    [{"start": 8, "end": 12}, {"start": 35, "end": 39}]
    """

    spans = []

    def update_spans_list(query: str, token: str):
        """util method to get list of spans for token inside given query without modification"""

        # Avoid finding spans of tokens which are substring of a word in the original query
        query = " " + query + " "

        # Use 'escape' to search strings that contain special characters in regex
        # like +, ?, etc
        for match in finditer(escape(str(" " + str(token) + " ")), query):
            curr_span = {"start": match.span()[0], "end": match.span()[1] - 3}
            if curr_span not in spans:
                spans.append(curr_span)

        # WAR to add capability to provide spans for partially tagged tokens with apostropes
        # Example: "who is {john}[user_name]'s manager", here only  "john" is tagged
        for match in finditer(escape(str(" " + str(token) + "'s ")), query):
            curr_span = {"start": match.span()[0], "end": match.span()[1] - 5}
            if curr_span not in spans:
                spans.append(curr_span)

    update_spans_list(query, token)

    # # Replace punctuation like ".,;:?" to with a space to tag span properly
    pattern = r"(?<!\d)[.,;:?](?!\d)"
    update_spans_list(sub(pattern, " ", query, 0), token)

    if not len(spans):
        logger.debug(f"For token: {token} in query: {query}, no span found. Disregarding the entity.")
    return spans


def postprocess_qa_response(resp: dict) -> None:
    """process response from qna module"""

    for a in resp:
        if "answer" in a:
            res = a["answer"].split("\n")
            if len(res) > 1:
                logger.debug(f"newline detected in qna response: {a['answer']}")
            res = list(filter(lambda x: x.strip() != "", res))
            if len(res) > 0:
                a["answer"] = res[0]
            else:
                a["answer"] = None


def convert_iob(tokens, scores, tags):
    # tag each token with pos
    pos_tags = [pos for token, pos in pos_tag(tokens)]
    # convert the BIO / IOB tags to tree
    conlltags = [
        (json.dumps({"token": token, "score": score}), pos, tg)
        for token, score, pos, tg in zip(tokens, scores, pos_tags, tags)
    ]
    ne_tree = conlltags2tree(conlltags)
    # parse the tree to get our original text
    original_text = []
    for subtree in ne_tree:
        # checking for 'O' tags
        if type(subtree) == Tree:
            original_label = subtree.label()
            tokens = []
            scores = []
            for item, pos in subtree.leaves():
                item_dict = json.loads(item)
                tokens.append(item_dict["token"])
                scores.append(item_dict["score"])
            original_string = " ".join([token for token in tokens])
            original_score = np.average(scores)
            original_text.append(
                TokenClassValue(
                    token=original_string,
                    label=Classification(class_name=original_label, score=original_score),
                )
            )
    return original_text
