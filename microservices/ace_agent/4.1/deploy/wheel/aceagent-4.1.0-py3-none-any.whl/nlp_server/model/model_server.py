import re
import asyncio
import inspect
import logging

from nlp_server.core.model_registry import ModelInfo, ModelRegistry

logger = logging.getLogger(__name__)


class ModelServer:
    def __init__(self, config):
        self.name = config.get("name", "custom")
        self.url = config.get("url", None)
        self._models = []

    async def is_ready(self):
        raise NotImplementedError()

    async def initalize_server(self, retry=10):
        server_status = False
        for _ in range(retry):
            server_status = await self.is_ready()
            if server_status:
                break
            await asyncio.sleep(1)
        if not server_status:
            raise ValueError(f"Health check failed for Model Server {self.name} with url {self.url}")
        # list all models
        self._models = await self.list_models()
        # Register Model APIs
        for _, method in inspect.getmembers(self, inspect.ismethod):
            if hasattr(method, "decorator_tag") and method.decorator_tag == "model_api":
                await self.register_model_api(method)

    async def list_models(self):
        raise NotImplementedError()

    async def is_model_ready(self, model_name, model_version):
        raise NotImplementedError()

    async def get_model_config(self, model_name, model_version):
        raise NotImplementedError()

    async def search_models(self, patterns, model_version=""):
        """
        Search all models to given regex patterns
        """
        valid_models = []
        for pattern in patterns:
            for instance in self._models:
                match = re.match(pattern, instance["name"])
                if (
                    match
                    and match.string[match.start() : match.end()] == instance["name"]
                    and (model_version == "" or model_version == instance.get("version", ""))
                ):
                    valid_models.append(instance)
        return valid_models

    async def register_model_api(self, model_func):
        """
        Register given model_api if avaiable with this model server
        """
        model_registry = ModelRegistry.get_instance()
        if inspect.ismethod(model_func) or inspect.isfunction(model_func):
            model_patterns = model_func.api_meta["model_name"]
            if model_func.api_meta["model_list_func"]:
                list_model_func = getattr(self, model_func.api_meta["model_list_func"])
                if inspect.iscoroutinefunction(list_model_func):
                    model_patterns.extend(await list_model_func())
                else:
                    model_patterns.extend(list_model_func())

            found_models = await self.search_models(model_patterns, model_func.api_meta["model_version"])
            for model_instance in found_models:
                model_registry.register_model_info(
                    ModelInfo(
                        model_name=model_instance["name"],
                        endpoint=model_func.api_meta["endpoint"],
                        task_name=model_func.api_meta["task_name"],
                        model_version=model_instance.get("version", ""),
                        model_type=self.name,
                        func=model_func,
                        url=self.url,
                        func_ready=self.is_model_ready,
                        parameters=model_func.api_meta.get("parameters", {}),
                    )
                )
            if found_models:
                return True
        return False
