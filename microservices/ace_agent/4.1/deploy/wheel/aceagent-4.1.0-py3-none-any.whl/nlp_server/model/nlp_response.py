# Copyright(c) 2021-2023 NVIDIA Corporation. All rights reserved

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
template related to Natural language understanding module results
"""

from dataclasses import dataclass, field
from typing import List, Dict

from nlp_server.constants import DOMAIN_NO_MATCH, INTENT_NO_MATCH


@dataclass
class Classification:
    """Classification response containing class name and score"""

    class_name: str
    score: float


@dataclass
class TokenClassValue:
    """Used to correlate an input token with its classification results"""

    token: str
    label: "Classification"
    span: Dict[str, int] = field(default_factory=lambda: {})


@dataclass
class TokenClassResponse:
    """
    Class to store results corresponding to NER & other entity
    recognition modules.
    """

    entities: List["TokenClassValue"] = field(default_factory=lambda: [])


@dataclass
class AnalyzeIntentResponse:
    """Class to store results corresponding to Joint Intent & Slot module"""

    domain: "Classification" = field(default_factory=lambda: Classification(DOMAIN_NO_MATCH, 1.0))
    intent: "Classification" = field(default_factory=lambda: Classification(INTENT_NO_MATCH, 1.0))
    entities: "TokenClassResponse" = field(default_factory=lambda: TokenClassResponse())


@dataclass
class NaturalQueryResponse:
    """Response corresponding to natural query & answering module"""

    results: List["NaturalQueryResult"] = field(default_factory=lambda: [])


@dataclass
class NaturalQueryResult:
    """Individual results for natural query & answering module"""

    answer: str
    score: float
