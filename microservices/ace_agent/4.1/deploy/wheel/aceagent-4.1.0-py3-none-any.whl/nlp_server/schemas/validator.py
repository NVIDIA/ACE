# Copyright(c) 2021-2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

""" 
    NLP Server schema file validator.
    Requires: pip3 install pykwalify==1.8.0
"""

import os
from pykwalify.core import Core
from pykwalify.errors import SchemaError
import logging


logger = logging.getLogger("__name__")


class SchemaValidator:
    NLP_SERVER_CONFIG_SCHEMA = [os.path.join(os.path.dirname(__file__), "nlp_server_config_schema.yaml")]

    @staticmethod
    def validate_file(source_file, schema_files):
        """Method to validate yaml config files of DM"""

        try:
            c = Core(source_file, schema_files)
            c.validate(raise_exception=True)
            logger.debug(f"Validation successful for yaml file {source_file}.")

        except SchemaError as error:
            raise ValueError(f"Validation failed for file {source_file} with error : {error}")
