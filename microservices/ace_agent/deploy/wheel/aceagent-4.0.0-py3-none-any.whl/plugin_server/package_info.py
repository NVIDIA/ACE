# Copyright(c) 2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.


MAJOR = 4
MINOR = 0
PATCH = 0

# Use the following formatting: (major, minor, patch)
VERSION = (MAJOR, MINOR, PATCH)

__version__ = ".".join(map(str, VERSION[:3]))
__description__ = "ACE Agent Plugin Server"
__keywords__ = "ACE Agent, Plugin Server"
__package_name__ = "plugin_server"
