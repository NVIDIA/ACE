# copyright(c) 2024 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import os
import sys
import yaml
import logging
import importlib
import prometheus_client
from pathlib import Path
from typing import List, Dict, Union
from traceback import print_exc

import uvicorn
from fastapi import FastAPI, APIRouter, Response
from fastapi.routing import APIRoute

from plugin_server.package_info import __version__
from plugin_server.utils import set_store
from plugin_server.stores.userdata import StorageConfig
from plugin_server.stores.store import Store

logger = logging.getLogger("plugin")

logger.info("Starting Plugin server")
# FastAPI app object
fastapi = FastAPI(title="NVIDIA ACE Agent Plugin Server", docs_url="/docs", version=__version__)

from dataclasses import dataclass, field
from fastapi import FastAPI

# path to default plugins
DEFAULT_FM = os.path.join(os.path.dirname(__file__), "plugin_config.yaml")


# fulfillment request and response
@dataclass
class FulfillmentRequest:
    """class to store fulfillment request"""

    UserId: str
    Domain: str
    Intent: str
    Language: str
    Query: str
    QueryId: str
    ProcessedQuery: str
    SessionId: str
    StreamId: str
    QueryId: str
    Event: str = None
    NlpResp: dict = field(default_factory=lambda: {})
    Slots: dict = field(default_factory=lambda: {})
    LinkedSlots: dict = field(default_factory=lambda: {})
    FulfillmentSlots: dict = field(default_factory=lambda: {})
    Parameters: dict = field(default_factory=lambda: {})
    History: dict = field(default_factory=lambda: {})
    Memory: dict = field(default_factory=lambda: {})


@dataclass
class UserResponse:
    """
    Response text, action and possibly other information which is generated
    by the chat engine after processing the user query
    """

    text: str = None
    cleaned_text: str = None
    action: str = None
    json: str = None
    ready: bool = False
    omniverse_json: str = None
    need_user_response: bool = None
    is_partial_response: bool = None


@dataclass
class FulfillmentResponse:
    """class to store fulfillment response"""

    UserResponse: dict = field(default_factory=UserResponse)
    Status: str = ""
    FulfillmentSlots: dict = field(default_factory=lambda: {})
    CustomData: dict = field(default_factory=lambda: {})
    InvalidSlots: list = field(default_factory=lambda: [])
    Slots: dict = field(default_factory=lambda: {})
    StatusDetails: str = ""
    Memory: dict = field(default_factory=lambda: {})


# Default route
@fastapi.get("/status", tags=["Health APIs"])
async def status():
    """
    Health Check Endpoint
    """
    return {}


@fastapi.get("/name")
async def name():
    logger.info("name api from fulfillment")
    return {"Name": "fulfillment_v2"}


@fastapi.get("/list")
def get_fulfillment_list() -> List[Dict[str, Union[str, List[str]]]]:
    resp = []
    try:
        # Get the list of API routes
        api_routes = [route.path for route in fastapi.routes if isinstance(route, APIRoute)]
        # iterate over all the specified endpoint and
        # add endpoint returned by fastapi.routes in the list
        for name, endpoints in fastapi.fm_info.items():
            active_endpoints = []
            for endpoint in endpoints:
                if endpoint in api_routes:
                    active_endpoints.append(endpoint)
                else:
                    logger.info(f"Discarding: {endpoint}")
            resp.append({"name": name, "endpoints": active_endpoints})
    except Exception as e:
        logger.error(f"Exception {e} while reloading plugin server")
        return resp
    return resp


@fastapi.get("/metrics", tags=["Health APIs"])
def get_metrics():
    return Response(content=prometheus_client.generate_latest(), media_type="text/plain")


# Create app and register plugin server
def create_app():
    # Create Fulfillment app Instance
    config_path = os.getenv("CONFIG_PATH", default=None)
    if config_path is None:
        raise Exception("Plugin Server config file not provided")

    try:
        # Validate config file schema
        default_fm_config = __load_default_config()
        path = os.path.abspath(config_path)
        logger.info(f"Starting plugin server using config: {config_path}")
        __register_fulfillment_config(config_path=path, default_config=default_fm_config)
        logger.info("plugin server started")
    except Exception as e:
        logger.error(f"Exception {e} while initializing plugin server")
        return None
    return fastapi


def __load_default_config():
    try:
        default_fm = {}
        logger.info(f"Loading prebuilt plugins from path: {DEFAULT_FM}")
        with open(DEFAULT_FM, "r") as f:
            config = yaml.load(f, Loader=yaml.SafeLoader).get("plugins", [])

        for fulfillment in config:
            try:
                default_fm[fulfillment.get("name")] = {
                    "prefix": fulfillment.get("prefix", None) or fulfillment.get("name"),
                    "tags": fulfillment.get("tags", None) or [fulfillment.get("name")],
                    "path": fulfillment.get("path"),
                    "parameters": fulfillment.get("parameters", {}),
                }
            except Exception as e:
                logger.error(f"Failed to initialize {fulfillment.get('name')} fulfillment exception {e}")
        return default_fm
    except Exception as e:
        raise ValueError(f"Parsing failed for plugin server config yaml {DEFAULT_FM} with error : {e} ")


def __register_fulfillment_config(config_path: str, default_config: str):
    """
    Parse plugin server Config and register models with Model Registry
    """

    fastapi.fm_info = {}  # contains fulfillmen name: endpoints mapping
    try:
        # TODO: Add schema validation
        with open(config_path, "r") as f:
            raw_config = yaml.load(f, Loader=yaml.SafeLoader)
            config = raw_config.get("plugins", [])

    except Exception as e:
        raise ValueError(f"Parsing failed for plugin server config yaml {config_path} with error : {e} ")

    # Fetch the storage section from config, create a store object and set it in utils
    storage_config = StorageConfig(**raw_config.get("storage", {}))
    store = Store(storage_config)
    set_store(store)

    create_parameter(config=config)
    for fulfillment in config:
        try:
            path = fulfillment.get("path", None)
            prefix = ""
            tags = []
            if path is None:
                # If path is not present it's default fulfillment
                if fulfillment.get("name") in default_config:
                    fm_dict = default_config.get(fulfillment.get("name"), {})
                    path = fm_dict.get("path", None)
                    prefix = fulfillment.get("prefix", None) or fm_dict.get("prefix", None) or fulfillment.get("name")
                    tags = fulfillment.get("tags", None) or fm_dict.get("tags", None) or [fulfillment.get("name")]
                else:
                    logger.error(f"Skipping {fulfillment.get('name')} as no path find for fulfillment")
                    continue
            else:
                prefix = fulfillment.get("prefix", None) or fulfillment.get("name")
                tags = fulfillment.get("tags", None) or [fulfillment.get("name")]
            __register_fulfillment(config_path, path, tags, prefix, fulfillment.get("name"))
        except Exception as e:
            logger.error(f"Failed to initialize {fulfillment.get('name')} fulfillment exception {e}")
            print_exc()


def __register_fulfillment(config_path: str, path: str, tags: List[str], prefix: str, name: str):
    """
    Register custom fulfillment with FastAPI app
    """
    orig_path = path  # Relative path mentioned in fulfillment config
    actual_path = ""  # Disambiguated path based on actual file location

    if not path.endswith(".py"):
        logger.error(f"Expecting Python Module for Custom Model APIs, found {path}")
        raise ValueError(f"Expecting Python Module for Custom Model APIs, found {path}")

    logger.info(f"\n\nLoading fulfillment module from path: {path}")
    default_path = os.path.join(os.path.dirname(__file__), path)
    relpath_default = os.path.relpath(os.path.abspath(default_path), os.getcwd())
    logger.debug(f"relpath_default = {relpath_default}")
    relpath_custom = os.path.join(os.path.dirname(config_path), path)
    logger.debug(f"relpath_custom = {relpath_custom}")

    if Path(relpath_default).is_file():
        path = relpath_default[:-3].replace("/", ".")
        actual_path = relpath_default
        logger.debug(f"Found prebuilt fulfillment for the defined path.")
    elif Path(relpath_custom).is_file():
        path = relpath_custom[:-3].replace("/", ".")
        actual_path = relpath_custom
        logger.debug(f"Found custom fulfillment for the defined path.")
    else:
        logger.error(f"Invalid fulfillment path {path} skipping it's deployment")
        ValueError(f"Invalid fulfillment path {path} skipping it's deployment")

    logger.debug(f"Module to be imported is: {orig_path}, path: {actual_path}")
    sys.path.append(os.path.dirname(actual_path))
    spec = importlib.util.spec_from_file_location(orig_path, actual_path)
    imported = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(imported)
    logger.debug(f"Successfully imported module: {imported}")
    for item in dir(imported):
        if not item.startswith("__") and isinstance(getattr(imported, item), APIRouter):
            fastapi.include_router(imported.router, prefix=f"/{prefix}", tags=tags)
            logger.info(f"Imported fastapi endpoints: {imported.router.routes}")
            # Creating dict with name: endpoints
            fastapi.fm_info[name] = set()
            for route in imported.router.routes:
                fastapi.fm_info[name].add(f"/{prefix}{route.path}")


def create_parameter(config):
    """
    Read parameters from config.yaml file and create a parameters.py file
    """
    param = {}
    for fulfillment in config:
        param[fulfillment.get("name")] = fulfillment.get("parameters", {})

    with open("parameters.py", "w") as f:
        f.write(f"param = {param}")


if __name__ == "__main__":
    create_app()
    uvicorn.run(fastapi, host="0.0.0.0", port=9000)
