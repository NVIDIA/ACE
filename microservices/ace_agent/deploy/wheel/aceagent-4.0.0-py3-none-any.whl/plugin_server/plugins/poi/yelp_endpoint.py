"""
 copyright(c) 2023 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""
import logging
from typing import Optional, List
from fastapi import APIRouter
import os
import sys

from plugin_server.main import FulfillmentRequest, FulfillmentResponse
from parameters import param

sys.path.append(os.path.dirname(__file__))
from yelp import YelpPOI

router = APIRouter()
logger = logging.getLogger("plugin")

api_key = param.get("poi", {}).get("api-key", None) or os.getenv("YELP_API_KEY", "")
yelp = YelpPOI({"api-key": api_key})


@router.post("/processQuery", response_model=FulfillmentResponse)
def process_query(request_data: FulfillmentRequest) -> FulfillmentResponse:
    """Call process query of yelp fulfillment and return a dict with complete business details"""

    if not isinstance(request_data, dict):
        request_data = {k: v for k, v in request_data.__dict__.items()}
    resp = yelp.process_query(request_data)
    return resp


@router.get("/get_rating")
def get_rating(
    poiplace: str,
    location: str,
    cuisinetype: Optional[str] = None,
    sort_criteria: str = "best_match",
    distance_unit: str = "miles",
) -> Optional[float]:
    """
    Get rating for poiplace at location
    """
    try:
        req = {
            "location": location,
            "poiplace": poiplace,
            "poisortcriteria": sort_criteria,
            "distanceunit": distance_unit,
            "cuisinetype": cuisinetype,
            "distance": 16093,
        }
        resp = yelp.query_api(params=req)
        return resp.get("businessRating", [None])[0]
    except Exception as e:
        logger.error(f"Exception {e} while getting rating")
    return None


@router.get("/get_contact_info")
def get_phone_number(
    poiplace: str,
    location: str,
    cuisinetype: Optional[str] = None,
    sort_criteria: str = "best_match",
    distance_unit: str = "miles",
) -> Optional[str]:
    """
    Get contact info for poiplace at location
    """
    try:
        req = {
            "location": location,
            "poiplace": poiplace,
            "poisortcriteria": sort_criteria,
            "distanceunit": distance_unit,
            "cuisinetype": cuisinetype,
            "distance": 16093,
        }
        resp = yelp.query_api(params=req)
        return resp.get("businessPhone", [None])[0]
    except Exception as e:
        logger.error(f"Exception {e} while getting contact info")
    return None


@router.get("/get_address")
def get_address(
    poiplace: str,
    location: str,
    cuisinetype: Optional[str] = None,
    sort_criteria: str = "best_match",
    distance_unit: str = "miles",
) -> Optional[str]:
    """
    Get address for poiplace at location
    """
    try:
        req = {
            "location": location,
            "poiplace": poiplace,
            "poisortcriteria": sort_criteria,
            "distanceunit": distance_unit,
            "cuisinetype": cuisinetype,
            "distance": 16093,
        }
        resp = yelp.query_api(params=req)
        return resp.get("businessAddress", [None])[0]
    except Exception as e:
        logger.error(f"Exception {e} while getting address")
    return None


@router.get("/get_distance")
def get_distance(
    poiplace: str,
    location: str,
    cuisinetype: Optional[str] = None,
    sort_criteria: str = "best_match",
    distance_unit: str = "miles",
) -> Optional[float]:
    """
    Get Distance to business place
    """
    try:
        req = {
            "location": location,
            "poiplace": poiplace,
            "poisortcriteria": sort_criteria,
            "distanceunit": distance_unit,
            "cuisinetype": cuisinetype,
            "distance": 16093,
        }
        resp = yelp.query_api(params=req)
        return resp.get("businessDistance", [None])[0]
    except Exception as e:
        logger.error(f"Exception {e} while getting distance")
    return None


@router.get("/get_place_info")
def get_place_info(
    poiplace: str,
    location: str,
    cuisinetype: Optional[str] = None,
    sort_criteria: str = "best_match",
    distance_unit: str = "miles",
) -> Optional[str]:
    """
    find place with given search criteria
    """
    try:
        req = {
            "location": location,
            "poiplace": poiplace,
            "poisortcriteria": sort_criteria,
            "distanceunit": distance_unit,
            "cuisinetype": cuisinetype,
            "distance": 16093,
        }
        resp = yelp.query_api(params=req)
        return resp.get("businessName", [None])[0] + " located at " + resp.get("businessAddress", [None])[0]
    except Exception as e:
        logger.error(f"Exception {e} while getting place info")
    return None
