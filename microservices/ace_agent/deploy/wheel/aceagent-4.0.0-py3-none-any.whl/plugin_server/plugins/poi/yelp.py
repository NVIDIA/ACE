"""
 copyright(c) 2022-23 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""
"""
Copyright © 2016 Yelp

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""

#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Yelp Fusion API code sample.

This program demonstrates the capability of the Yelp Fusion API
by using the Search API to query for businesses by a search term and location,
and the Business API to query additional information about the top result
from the search query.

Please refer to http://www.yelp.com/developers/v3/documentation for the API
documentation.

This program requires the Python requests library, which you can install via:
`pip install -r requirements.txt`.

Sample usage of the program:
`python sample.py --term="bars" --location="San Francisco, CA"`
"""

import json
import requests
import logging

from word2number import w2n

logger = logging.getLogger("plugin")

from urllib.parse import quote

# Yelp Fusion no longer uses OAuth as of December 7, 2017.
# You no longer need to provide Client ID to fetch Data
# It now uses private keys to authenticate requests (API Key)
# You can find it on
# https://www.yelp.com/developers/v3/manage_app


# API constants, you shouldn't have to change these.
API_HOST = "https://api.yelp.com"
SEARCH_PATH = "/v3/businesses/search"
BUSINESS_PATH = "/v3/businesses/"  # Business ID will come after slash.


# Defaults for our simple example.
SEARCH_LIMIT = 1
MAX_ALLOWED_RADIUS = 40000  # meters

prefetched_intents = ["navigation.getrating", "navigation.getnumber", "navigation.isclosed"]


def to_number(d):
    if isinstance(d, (int, float)):
        return d
    return w2n.word_to_num(d)


def km_to_meters(d):
    d = to_number(d)
    return d * 1000


def miles_to_meters(d):
    d = to_number(d)
    return d * 1609.34


def meters_to_km(d):
    d = to_number(d)
    return d / 1000.0


def meters_to_miles(d):
    d = to_number(d)
    return d / 1609.34


class YelpPOI:

    SUCCESS_CODE = "200"
    ERROR_CODE = "406"

    def __init__(self, headers=None):
        self._api_key = headers.get("api-key", "")
        mock = headers.get("mock", False)
        if mock and not self._api_key:
            self._api_key = "key"
        self._visualizer = headers.get("visualizer", False)

        self.online_response = {}
        self._session = requests.Session()
        self.timeout = 20
        self.warmup_module()

    def is_ready(self):
        return True

    def warmup_module(self):
        self.search(self._api_key, {"location": "santa clara,us"})
        print("YELP module warmup done..")

    def process_query(self, request):
        resp = {
            "Response": {"Text": None, "Action": None, "Json": None, "Ready": False, "NeedUserResponse": False},
            "Status": self.ERROR_CODE,
            "CustomData": {},
            "Slots": {},
            "InvalidSlots": [],
            "FulfillmentSlots": {},
            "StatusDetails": "",
        }

        logger.debug(f"\n\nrequest :: {request}")

        try:
            if self._api_key == "":
                resp["Response"]["Text"] = (
                    f"Failed to get POI information from yelp.com "
                    f"as the API key has not been populated in the bot-config."
                )
                resp["Response"]["Ready"] = True
                resp["StatusDetails"] = "Yelp returned error due to missing API key"
                resp["Status"] = self.SUCCESS_CODE
                return resp

            if request["Domain"] != "poi":
                logger.error("Expected domain is poi. Domain is set to {}.".format(request["domain"]))
                resp["StatusDetails"] = f"Invalid domain: {request['Domain']} set."
                return resp

            if "location" not in request["Slots"]:
                resp["StatusDetails"] = "Mandatory slot location missing."
                return resp

            # Use the first value of all slots tagged in user query
            for slot in request["Slots"]:
                request["Slots"][slot] = request["Slots"][slot][0]
            for slot in request["FulfillmentSlots"]:
                request["FulfillmentSlots"][slot] = request["FulfillmentSlots"][slot][0]

            result = None

            if request["Intent"] in prefetched_intents and "businessCity" in request["FulfillmentSlots"]:
                if request["Slots"]["location"] == request["FulfillmentSlots"]["businessCity"].lower():
                    logger.info(f"Response already available. Skipping api call.")
                    result = request["FulfillmentSlots"]
                    result["Status"] = self.SUCCESS_CODE
                    result["StatusDetails"] = "Utilized Fulfillment slots for response."

            if result is None:
                result = self.query_api(request["Slots"], request["Intent"])

            if result["Status"] == self.ERROR_CODE:
                resp["StatusDetails"] = result.get("StatusDetails", "")
                if "error" in self.online_response and self.online_response["error"]["code"] == "LOCATION_NOT_FOUND":
                    resp["Response"][
                        "Text"
                    ] = f"I can't find any location with the name, {request['Slots']['location'].title()}."
                    resp["Response"]["Ready"] = True
                    resp["Status"] = self.SUCCESS_CODE
                return resp

            resp["Status"] = self.SUCCESS_CODE
            resp["StatusDetails"] = result.get("StatusDetails", "")
            resp["FulfillmentSlots"] = result

            return resp

        except Exception as e:
            logger.error(f"Exception: {e} in process query of YELP module.")
            resp["Status"] = self.ERROR_CODE
            return resp

    def request(self, host, path, api_key, url_params=None):
        """Given your API_KEY, send a GET request to the API.

        Args:
            host (str): The domain host of the API.
            path (str): The path of the API after the domain.
            API_KEY (str): Your API Key.
            url_params (dict): An optional set of query parameters in the request.

        Returns:
            dict: The JSON response from the request.

        Raises:
            HTTPError: An error occurs from the HTTP request.
        """
        url_params = url_params or {}
        url = "{0}{1}".format(host, quote(path.encode("utf8")))
        headers = {
            "Authorization": "Bearer %s" % api_key,
        }

        logger.info("Querying {0} ...".format(url))

        response = self._session.request("GET", url, headers=headers, params=url_params, timeout=self.timeout)

        return response.json()

    def search(self, api_key, params=None):
        """Query the Search API by a search term and location.

        Args:
            term (str): The search term passed to the API.
            location (str): The search location passed to the API.

        Returns:
            dict: The JSON response from the request.
        """

        url_params = params or {}
        """
        url_params = {
            'term': term.replace(' ', '+'),
            'location': location.replace(' ', '+'),
            'limit': SEARCH_LIMIT
        }
        """
        return self.request(API_HOST, SEARCH_PATH, api_key, url_params=url_params)

    def get_business(self, api_key, business_id):
        """Query the Business API by a business ID.

        Args:
            business_id (str): The ID of the business to query.

        Returns:
            dict: The JSON response from the request.
        """
        business_path = BUSINESS_PATH + business_id

        return self.request(API_HOST, business_path, api_key)

    def query_api(self, params=None, intent=None):
        """Queries the API by the input values from the user.

        Args:
            term (str): The search term to query.
            location (str): The location of the business to query.
        """

        logger.debug("query params :: {}".format(params))

        yelp_params = {}
        resp = {}
        resp["StatusDetails"] = f"Found business places matching search criteria."
        resp["Status"] = self.SUCCESS_CODE

        if not ("location" in params and "poiplace" in params):
            logger.error('Required slot "location" or "poiplace" is not available.')
            resp["StatusDetails"] = 'Required slot "location" or "poiplace" is not available.'
            resp["Status"] = self.ERROR_CODE
            return resp

        yelp_params["location"] = params["location"]
        yelp_params["term"] = params["poiplace"]
        if "cuisinetype" in params and params["cuisinetype"] != None:
            yelp_params["term"] += ", " + params["cuisinetype"]

        if "poisortcriteria" in params:
            if params["poisortcriteria"] == "price":
                yelp_params["sort_by"] = "best_match"
                yelp_params["price"] = "4"
            elif params["poisortcriteria"] == "best_match":
                yelp_params["sort_by"] = "best_match"
            elif params["poisortcriteria"] == "distance":
                yelp_params["sort_by"] = "distance"
            elif params["poisortcriteria"] == "rating":
                yelp_params["sort_by"] = "rating"
            else:
                yelp_params["sort_by"] = "best_match"

        if "distanceunit" in params:
            if params["distanceunit"] == "kilometers":
                yelp_params["radius"] = int(km_to_meters(params["distance"]))
            elif params["distanceunit"] == "miles":
                yelp_params["radius"] = int(miles_to_meters(params["distance"]))
            elif params["distanceunit"] == "meters":
                yelp_params["radius"] = to_number(params["distance"])

        if not "radius" in yelp_params or yelp_params["radius"] > MAX_ALLOWED_RADIUS:
            yelp_params["radius"] = MAX_ALLOWED_RADIUS

        yelp_params["limit"] = SEARCH_LIMIT

        logger.debug(f"Request to yelp: {json.dumps(yelp_params, indent=4)}")

        result = {"businesses": [], "total": 0}
        result = self.search_online(yelp_params)

        if "total" in self.online_response and self.online_response["total"] > 0:
            result = self.online_response

        logger.debug(f"Response from yelp: {json.dumps(result, indent=4)}")

        businesses = result.get("businesses")

        if not businesses:
            logger.error("No businesses for {0} in {1} found.".format(yelp_params["term"], yelp_params["location"]))
            resp["StatusDetails"] = f"No businesses for {yelp_params['term']} in {yelp_params['location']} found."
            resp["Status"] = self.ERROR_CODE
            return resp

        limit = min(yelp_params["limit"], len(businesses))
        count = 0

        # Form the fulfillment slots for top 3 results
        resp["businessName"] = []
        resp["businessAddress"] = []
        resp["businessCity"] = []
        resp["businessLatitude"] = []
        resp["businessLongitude"] = []
        resp["businessDistance"] = []
        resp["businessPhone"] = []
        resp["businessRating"] = []
        resp["businessURL"] = []
        resp["businessReviewCount"] = []

        for business in businesses:
            # logger.debug("Search response JSON:{}".format(json.dumps(business, indent = 4)))
            count += 1
            resp["businessName"].append(business["name"])
            resp["businessAddress"].append(" ".join(business["location"]["display_address"]))
            resp["businessCity"].append(business["location"]["city"])
            resp["businessLatitude"].append(business["coordinates"]["latitude"])
            resp["businessLongitude"].append(business["coordinates"]["longitude"])
            businessDistance = business.get("distance", None)
            if "distanceunit" in params:
                resp["distance_unit"] = params["distanceunit"]
                if params["distanceunit"] == "kilometers":
                    resp["businessDistance"].append(round(meters_to_km(businessDistance), 1))
                elif params["distanceunit"] == "miles":
                    resp["businessDistance"].append(round(meters_to_miles(businessDistance), 1))
                else:
                    resp["businessDistance"].append(int(businessDistance))

            resp["businessPhone"].append(business.get("display_phone", None))
            resp["businessRating"].append(business.get("rating", None))
            resp["businessURL"].append(business.get("url", None))
            resp["businessReviewCount"].append(business.get("review_count", None))

            if count >= limit:
                break

        return resp

    def search_online(self, params):
        """Send search request to online site

        Args:
            params (str) : search parameters
            event : Condition event to signal search completion
        """

        response = self.search(self._api_key, params)
        return response
