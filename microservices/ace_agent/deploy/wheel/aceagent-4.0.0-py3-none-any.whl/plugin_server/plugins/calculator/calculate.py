# Copyright(c) 2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import logging
from fastapi import APIRouter

logger = logging.getLogger("plugin")
router = APIRouter()

logger.info("Starting Calculator plugin server")


@router.get("/add")
def add(num1: int, num2: int) -> int:
    """
    Add two numbers
    """
    logger.info(f"Executing add operation between {num1} & {num2}")
    return num1 + num2


@router.get("/multiply")
def mul(num1: int, num2: int) -> int:
    """
    Multiply two numbers
    """
    logger.info(f"Executing multiplication operation between {num1} & {num2}")
    return num1 * num2


@router.get("/subtract")
def sub(num1: int, num2: int) -> int:
    """
    Subtract two numbers
    """
    logger.info(f"Executing subtraction operation between {num1} & {num2}")
    return num1 - num2


@router.get("/div")
def sub(num1: int, num2: int) -> float:
    """
    Multiply two numbers
    """
    logger.info(f"Executing division operation between {num1} & {num2}")
    if num2 != 0:
        return num1 / num2
    logger.error("Denominator can not be 0")
    return 0
