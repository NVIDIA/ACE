"""
 copyright(c) 2023 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

"""Utility functions used by weatherstack"""
import sys
import logging
import os
from typing import Dict, Any

sys.path.append(os.path.dirname(__file__))

SUCCESS_CODE = "200"
ERROR_CODE = "406"

logger = logging.getLogger("plugin")


f_units = {"name": "fahrenheit", "shortcut": "F", "param": "f", "speed": "miles per hour"}
c_units = {"name": "celsius", "shortcut": "C", "param": "m", "speed": "kilometres per hour"}

default_units = f_units


def make_lowercase(obj):
    """
    Converts strings, dicts(only values), lists, etc. to lowercase
    param
        Args:
            obj: string/dict/list, etc. to be converted to lowercase

        Returns:
            lowercase string/dict/list, etc.
    """

    if isinstance(obj, dict):
        # dictionary
        ret = {}
        for k, v in obj.items():
            ret[k] = make_lowercase(v)
        return ret
    elif isinstance(obj, str):
        # string
        return obj.lower().strip()
    elif isinstance(obj, list):
        # list
        ret = []
        for item in obj:
            ret.append(make_lowercase(item))
        return ret
    else:
        # anything else
        return obj


def process_request(request_data) -> Dict[str, Any]:
    """
    Process DM request and return resp template
    """
    resp = {
        "Response": {"Text": None, "Action": None, "Json": None, "Ready": False, "NeedUserResponse": False},
        "Status": ERROR_CODE,
        "Slots": {},
        "FulfillmentSlots": {},
        "CustomData": {},
        "InvalidSlots": [],
        "StatusDetails": "",
    }

    logger.debug(f"\n\nrequest :: {request_data}")

    # converting slots to lowercase
    request_data["Slots"] = make_lowercase(request_data["Slots"])

    try:

        if "location" not in request_data["Slots"]:
            logger.error("Missing mandatory slot location.")
            resp["StatusDetails"] = "Missing mandatory slot location."
            return resp

        # Use the last value of all slots tagged in user query
        for slot in request_data["Slots"]:
            if slot.startswith("system."):
                continue
            request_data["Slots"][slot] = request_data["Slots"][slot][-1]

        request_data["FulfillmentSlots"] = {}

        if "temperatureunit" in request_data["Slots"]:
            if request_data["Slots"]["temperatureunit"] == "celsius":
                logger.debug("Setting temperature unit to celsius.")
                default_units = c_units
            if request_data["Slots"]["temperatureunit"] == "fahrenheit":
                logger.debug("Setting temperature unit to fahrenheit.")
                default_units = f_units

    except Exception as e:
        logger.error(f"Exception: {e} in process query of weatherstack module.")
        resp["Status"] = ERROR_CODE

    return resp


def create_response(request_data, resp, details, status):
    """create fulfillment response for DM using extracted slot value"""

    if details.get("code", None) != None and details.get("code") == 615:
        logger.debug("Invalid city name detected in slot: {}".format(request_data["Slots"]["location"]))
        resp["InvalidSlots"] = ["location"]
        resp["Response"]["Text"] = (
            f"I could not find any valid city with name "
            f"{request_data['Slots']['location']}. Can you tell me a different city name?"
        )
        resp["Response"]["Ready"] = True
        resp["Response"]["NeedUserResponse"] = True
        resp["StatusDetails"] = "Weatherstack returned error due to invalid city name."
        resp["Status"] = SUCCESS_CODE
        resp["CustomData"] = details
        return resp

    if details.get("code", None) != None and details.get("type") == "missing_access_key":
        resp["Response"]["Text"] = (
            f"Failed to get weather information from weather-stack.com "
            f"as the API key has not been populated in the bot-config."
        )
        resp["Response"]["Ready"] = True
        resp["StatusDetails"] = "Weatherstack returned error due to missing API key"
        resp["Status"] = SUCCESS_CODE
        resp["CustomData"] = details
        return resp

    resp["Status"] = status
    resp["CustomData"] = details
    resp["FulfillmentSlots"] = request_data["FulfillmentSlots"]
    return resp


def get_feeling(temperature, units):
    """Return weather condition based on temperature"""
    if units == c_units:  # celsius
        if temperature >= 25:
            return "hot"
        elif temperature >= 10:
            return "normal"
        else:
            return "very cold"
    else:  # fahrenheit
        if temperature >= 77:
            return "hot"
        elif temperature >= 50:
            return "nice"
        else:
            return "cold"


def is_xxxing(xxx, condition):
    return xxx in condition.lower()
