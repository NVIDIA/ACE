"""
 copyright(c) 2022-23 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

import json
import requests
import datetime

from http.server import BaseHTTPRequestHandler, HTTPServer
from html import escape
import socket
import re
from threading import Thread


class MockServerRequestHandler(BaseHTTPRequestHandler):
    USERS_PATTERN = re.compile(r"/current")
    FORECAST = re.compile(r"/forecast")
    HISTORICAL = re.compile(r"/historical")

    def do_GET(self):
        try:
            req = self.path.split("&")[1]
            place = req.replace("+", " ").replace("query=", "").split("%2C")[0]
            place = escape(place)
        except Exception as e:
            place = "santa clara"
        if re.search(self.USERS_PATTERN, self.path):
            # Add response status code.
            self.send_response(requests.codes.ok)

            # Add response headers.
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()

            response = {}
            response["location"] = {"country": "USA", "name": place, "region": place}
            response["location"]["localtime"] = "2022-08-29 22:20"
            response["current"] = {"weather_descriptions": ["Partly Cloudy"]}
            response["current"]["temperature"] = 41
            response["current"]["humidity"] = 1
            response["current"]["wind_speed"] = 5
            response["current"]["precip"] = 20
            response["current"]["weather_icons"] = ["Invalid Icon"]
            # Add response content.
            response_content = json.dumps(response)
            self.wfile.write(response_content.encode("utf-8"))
            return

        if re.search(self.FORECAST, self.path):
            self.send_response(requests.codes.ok)

            # Add response headers.
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()

            response = {}
            response["location"] = {"country": "USA", "name": place, "region": place}
            response["location"]["localtime"] = "3:00AM"
            response["forecast"] = {}
            for i in range(365):
                response["forecast"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")] = {
                    "mintemp": 17,
                    "maxtemp": 24,
                }
                response["forecast"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")] = {
                    "mintemp": 17,
                    "maxtemp": 24,
                }
                response["forecast"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                    "hourly"
                ] = [{} for j in range(8)]
                response["forecast"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                    "hourly"
                ] = [{} for j in range(8)]
                for j in range(8):
                    response["forecast"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["weather_descriptions"] = ["Partly cloudy"]
                    response["forecast"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["temperature"] = 11
                    response["forecast"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["humidity"] = 11
                    response["forecast"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["precip"] = 21
                    response["forecast"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["wind_speed"] = 7
                    response["forecast"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["weather_icons"] = ["Invalid Icon"]
                    response["forecast"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["weather_descriptions"] = ["Partly cloudy"]
                    response["forecast"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["temperature"] = 11
                    response["forecast"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["humidity"] = 11
                    response["forecast"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["precip"] = 21
                    response["forecast"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["wind_speed"] = 7
                    response["forecast"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["weather_icons"] = ["Invalid Icon"]
            response_content = json.dumps(response)
            self.wfile.write(response_content.encode("utf-8"))
            return

        if re.search(self.HISTORICAL, self.path):
            self.send_response(requests.codes.ok)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()

            # Creating response
            response = {}
            response["location"] = {"country": "USA", "name": place, "region": place}
            response["location"]["localtime"] = "3:00AM"
            response["current"] = {"weather_icons": ["Invalid Icon"]}
            response["historical"] = {}
            for i in range(365):
                response["historical"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")] = {
                    "mintemp": 17,
                    "maxtemp": 24,
                }
                response["historical"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")] = {
                    "mintemp": 17,
                    "maxtemp": 24,
                }
                response["historical"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                    "hourly"
                ] = [{} for j in range(8)]
                response["historical"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                    "hourly"
                ] = [{} for j in range(8)]
                for j in range(8):
                    response["historical"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["weather_descriptions"] = ["Partly cloudy"]
                    response["historical"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["temperature"] = 11
                    response["historical"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["humidity"] = 11
                    response["historical"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["precip"] = 21
                    response["historical"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["wind_speed"] = 7
                    response["historical"][(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["weather_icons"] = ["Invalid Icon"]
                    response["historical"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["weather_descriptions"] = ["Partly cloudy"]
                    response["historical"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["humidity"] = 11
                    response["historical"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["temperature"] = 11
                    response["historical"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["precip"] = 21
                    response["historical"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["wind_speed"] = 7
                    response["historical"][(datetime.date.today() + datetime.timedelta(days=i)).strftime("%Y-%m-%d")][
                        "hourly"
                    ][j]["weather_icons"] = ["Invalid Icon"]

            response_content = json.dumps(response)
            self.wfile.write(response_content.encode("utf-8"))
            return


def get_free_port():
    s = socket.socket(socket.AF_INET, type=socket.SOCK_STREAM)
    s.bind(("localhost", 0))
    address, port = s.getsockname()
    s.close()
    return port


def start_mock_server(port):
    mock_server = HTTPServer(("localhost", port), MockServerRequestHandler)
    mock_server_thread = Thread(target=mock_server.serve_forever)
    mock_server_thread.setDaemon(True)
    mock_server_thread.start()
