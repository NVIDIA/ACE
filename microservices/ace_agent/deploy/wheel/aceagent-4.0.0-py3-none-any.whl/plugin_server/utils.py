# copyright(c) 2024 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

from functools import wraps
import asyncio
import logging
from typing import Dict, Any, Optional

from plugin_server.stores.store import Store
from plugin_server.stores.userdata import UserData

logger = logging.getLogger("plugin")

data_store: Store = None


def memory_handler(func):
    @wraps(func)
    async def wrapper(context: Optional[Dict[str, Any]] = None, *args, **kwargs):
        """
        Fetch userdata from the data store based on the user_id and session_id in the context.
        Save the updated userdata in the data store.
        """

        if context is None:
            logger.error(f"Memory handling requires context to be present in the function prototype!")
            context = {}

        # Handle differences in FastAPI typing and JSON resolution
        # Based on the type mentioned for context and memory in the endpoint,
        # FastAPI may pack just the "context" into the argument, or the entire JSON payload
        if "context" in context and "user_id" not in context:
            context = context["context"]

        user_id = context.get("user_id", "")
        session_id = context.get("session_id", "")

        try:
            user_data = data_store.get_user_data(user_id)
            memory = user_data.memory
            logger.info(f"Extracted memory: {memory}")
        except Exception as e:
            logger.info(f"No user data found for {user_id}. Creating a new user.")
            memory = {}
            user_data = UserData(user_id=user_id, session_id=session_id, memory=memory)

        kwargs["memory"] = memory
        kwargs["context"] = context

        # Check if the decorated function is sync or async
        if asyncio.iscoroutinefunction(func):
            result = await func(*args, **kwargs)
        else:
            result = func(*args, **kwargs)

        # Store the updated memory in the data_store
        user_data.memory = memory
        data_store.save_user_data(user_data)

        return result

    return wrapper


def set_store(store):
    global data_store
    data_store = store
