# Copyright(c) 2024 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
Base class for all Storage modules like
mongo, redis, local_file_system, cache
"""

from typing import Dict, List

from plugin_server.stores.userdata import UserData


class StoreBase:
    def reset_active_user(self):
        """Remove active user data from memory"""

        raise NotImplemented(f"reset_active_user has not been implemented")

    def get_active_user_data(self) -> Dict[str, float]:
        """
        Get list of active user ids
        """

        raise NotImplemented(f"get_active_user_data has not been implemented")

    def get_user_data(self, user_id: str) -> UserData:
        """
        Check if user data corresponding to user_id is available with store
        Raise exception if no user data corresponding to the user_id has
        been available in the store

        Args:
            user_id: user_id whose information needs to be extracted
        Returns
            UserData Object for corresponding user
        Raise
            ValueError is user information is not available
        """

        raise NotImplemented(f"get_user_data has not been implemented")

    def save_user_data(self, data: UserData) -> None:
        """
        Check if user id corresponding to the user data is already available
        in the store. If yes then update the corresponding user_data with
        new userdata. Otherwise create a new user data entry and store it.
        Args:
            data: UserData object to be stored in storage unit
        """

        raise NotImplemented(f"save_user_data has not been implemented")

    def delete_user_data(self, user_id: str) -> None:
        """
        Delete user data corresponding to user_id in the store
        Args:
            user_id: user_id of user whose information needs to be removed from storage
        """

        raise NotImplemented(f"delete_user_data has not been implemented")

    def rename_user(self, current_user_id: str, new_user_id: str):
        """
        Replace userdata of current_user_id to new_user_id
        """

        raise NotImplemented(f"rename_user has not been implemented")

    def get_user_for_session(self, session_id: str) -> List[str]:
        """
        Return list of users in given session_id
        Args:
            session_id: session_id whose user_id needs to be extracted
        """

        raise NotImplemented(f"get_user_for_session has not been implemented")
