# Copyright(c) 2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import os
import typer

# Set NGC_API_KEY env variable if NGC_CLI_API_KEY available
if not os.getenv("NGC_API_KEY", None) and os.getenv("NGC_CLI_API_KEY", None):
    os.environ["NGC_API_KEY"] = os.getenv("NGC_CLI_API_KEY")

app = typer.Typer(no_args_is_help=True, add_completion=False)

try:
    from chat_engine.typer_app import chat

    app.add_typer(chat, name="chat")
except ModuleNotFoundError:
    pass

try:
    from plugin_server.typer_app import plugin_server

    app.add_typer(plugin_server, name="plugin-server")
except ModuleNotFoundError:
    pass

try:
    from nlp_server.typer_app import nlp_server

    app.add_typer(nlp_server, name="nlp-server")
except ModuleNotFoundError:
    pass

try:
    from model_utils.typer_app import model_server

    app.add_typer(model_server, name="models")
except ModuleNotFoundError:
    pass
