# Copyright (c) 2022, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import os
import sys
import logging
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap
from dataclasses import dataclass, field, fields

from .task import BaseTask
from model_utils.utils.path_utils import PathUtils
from model_utils.config.constants import PIPELINE_TEMPLATE
from model_utils.utils.validation_utils import ValidationUtils

logger = logging.getLogger("__main__." + __name__)


@dataclass
class TemplateTask(BaseTask):
    """
    Generate Template yaml for tasks to be used in pipeline mode
    """

    task_name: str = field(
        default="task.template",
        metadata={
            "help": "Generate template pipeline yaml for sequence of tasks from ACE Agent Model Utils",
            "suppress": True,
        },
    )

    pipeline_name: str = field(
        default="test",
        metadata={"help": "Name for the generated pipeline", "validation_func": ValidationUtils.nonempty_value},
    )

    tasks: list = field(
        default=None,
        metadata={
            "required": True,
            "help": "List of tasks in order of execution for which pipeline need to be generated",
        },
    )

    output_path: str = field(
        default="",
        metadata={
            "help": "YAML filepath for dumping generated pipeline. If output_path not specified, will be dumped to stdout."
        },
    )

    def __post_init__(self):
        """
        Custom validation logic for Template task
        """
        super().__post_init__()

        # validate given task names
        all_available_tasks = self.get_all_task_names()
        for task_name in self.tasks:
            if task_name not in all_available_tasks:
                raise ValueError(f"Invalid task {task_name}, Available tasks : {','.join(all_available_tasks)}")

        if self.output_path and not self.output_path.endswith((".yaml", ".yml")):
            raise ValueError(f"Invalid output path {self.output_path}")

    @staticmethod
    def get_argument_doc(arg):
        """
        Get all details for given argument and create documentation
        """
        arg_doc_string = f"# type: {arg.type.__name__}"
        if arg.metadata.get("choices", None):
            arg_doc_string += f"\n    # choices: {arg.metadata['choices']}"
        if arg.metadata.get("help", None):
            arg_doc_string += f"\n    # help: {arg.metadata['help']}"
        return arg_doc_string

    @staticmethod
    def get_output_param_doc(arg, task_id):
        """
        Get all details for given argument and create documentation
        """
        arg_doc_string = f"    # Output Param: {task_id}.{arg.name}\n    # type: {arg.type.__name__}"
        if arg.metadata.get("choices", None):
            arg_doc_string += f"\n    # choices: {arg.metadata['choices']}"
        if arg.metadata.get("help", None):
            arg_doc_string += f"\n    # help: {arg.metadata['help']}"
        return arg_doc_string

    def execute_task(self):
        """
        Get all tasks documentation and generate pipeline yaml sequentially
        """
        yaml = YAML()
        yaml.indent(mapping=4, sequence=4, offset=2)
        with open(PIPELINE_TEMPLATE, "r") as f:
            yaml_data = yaml.load(f)

        yaml_data["pipeline_name"] = self.pipeline_name

        for index, task_name in enumerate(self.tasks):
            task_class = self.get_task(task_name)
            task_yaml = CommentedMap()
            task_yaml["_name"] = f"{task_name.replace('.', '_')}_{index}"
            last_key, last_comment = "", ""
            for f in fields(task_class):
                if f.init:
                    if f.default is None:
                        task_yaml[f.name] = "{UPDATE}"
                    else:
                        task_yaml[f.name] = f.default
                    last_key, last_comment = f.name, TemplateTask.get_argument_doc(f)
                    task_yaml.yaml_add_eol_comment(last_comment, key=f.name)

            output_param_doc = []
            for f in fields(task_class):
                if not f.init and f.metadata.get("help", None) and not f.metadata.get("suppress", None):
                    output_param_doc.append(TemplateTask.get_output_param_doc(f, task_yaml["_name"]))

            task_yaml.yaml_add_eol_comment(
                last_comment + "\n\n" + "\n\n".join(output_param_doc) + "\n\n", key=last_key
            )
            yaml_data["tasks"].append(task_yaml)

        if not self.output_path:
            yaml.dump(yaml_data, sys.stdout)
        else:
            self.output_path = PathUtils.get_abs_path(self.output_path)
            os.makedirs(os.path.dirname(self.output_path), exist_ok=True)
            with open(self.output_path, "w") as f:
                yaml.dump(yaml_data, f)
