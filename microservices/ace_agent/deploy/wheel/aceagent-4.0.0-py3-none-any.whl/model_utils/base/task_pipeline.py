# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import argparse
import yaml
import logging
from dataclasses import dataclass, field, fields
from collections import OrderedDict

from .task import BaseTask
from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils

logger = logging.getLogger("__main__." + __name__)


@dataclass
class PipelineTask(BaseTask):
    """
    Pipeline Task module for allow sequencing multiple tasks using config YAML
    """

    task_name: str = field(
        default="task.pipeline",
        metadata={"help": "Run sequence of tasks from ACE Agent Model Utils", "suppress": True},
    )

    config_yaml: str = field(
        default=None,
        metadata={
            "required": True,
            "help": "YAML Configuration filepath for pipeline tasks, Can be created manually or generated using template mode",
            "validation_func": PathUtils.exists_path,
            "validation_args": {"path_type": "file"},
        },
    )

    global_configs = {}
    task_args = OrderedDict()
    task_instances = OrderedDict()

    def __post_init__(self):
        """
        Custom validation logic for Pipeline Mode tasks
        """
        super().__post_init__()

        # TODO validate pipeline yaml schema
        try:
            with open(self.config_yaml, "r") as f:
                pipeline_config = yaml.load(f, Loader=yaml.SafeLoader)
        except Exception as e:
            raise ValueError(f"Parsing failed for pipeline config yaml {self.config_yaml} with error : {e} ")

        self.global_configs = pipeline_config.get("global", {})
        self.task_args = {}
        for task_config in pipeline_config["tasks"]:
            task_class = self.get_task(task_config["task_name"])
            all_keys = set([f.name for f in fields(task_class) if f.init])
            required_keys = set([f.name for f in fields(task_class) if f.init and f.metadata.get("required", False)])

            missing_keys = set(
                [key for key in required_keys if key not in task_config and key not in self.global_configs]
            )
            if len(missing_keys) > 0:
                raise ValueError(f"Missing required arguments for task {task_config['_name']} : {missing_keys}")

            unknown_keys = set([key for key in task_config.keys() if key not in all_keys and key != "_name"])
            if len(unknown_keys) > 0:
                raise ValueError(f"Unknown arguments for task {task_config['_name']} : {unknown_keys}")

            self.task_args[task_config["_name"]] = {}
            for key in all_keys:
                if key in task_config:
                    self.task_args[task_config["_name"]][key] = task_config[key]
                elif key in self.global_configs:
                    self.task_args[task_config["_name"]][key] = self.global_configs[key]

    def resolve_reference(self, val):
        if not val.startswith("$"):
            return val
        elif val.count(".") == 0:
            return self.global_configs.get(val[1:], None)
        elif val.count(".") == 1:
            instance, instance_var = val[1:].split(".")
            return getattr(self.task_instances[instance], instance_var)
        else:
            raise ValueError(f"Invalid reference {val}")

    def execute_task(self):
        """
        Create all tasks instance and execute tasks in given pipeline sequentially
        """

        logger.info(f"Running total {len(self.task_args)} tasks from pipeline config {self.config_yaml}\n")
        for name, config in self.task_args.items():
            # resolve arguments references
            for arg, val in config.items():
                try:
                    if type(val) == str and "{UPDATE}" in val:
                        raise ValueError(f"Update value for argument {arg}")
                    elif type(val) == str and val.startswith("$"):
                        config[arg] = self.resolve_reference(val)
                    elif type(val) == list:
                        new_val = []
                        for index, list_val in enumerate(val):
                            if type(list_val) == str and "{UPDATE}" in list_val:
                                raise ValueError(f"Update value for argument {arg}")
                            dref = self.resolve_reference(list_val)
                            if list_val.count(":") == 1:
                                prefix, sufix = list_val.split(":")
                                dref = f"{prefix}:{self.resolve_reference(sufix)}"
                            new_val.append(dref)
                        config[arg] = new_val
                except Exception as e:
                    raise ValueError(f"Unable to parse reference for {arg} for task {name} : {e}")

            logger.info(f"\n\n{'#'*80}\nRunning task {name} with type {config['task_name']}\n{'#'*80}\n")
            self.task_instances[name] = self.get_task(config["task_name"]).from_arguments(config)
            self.task_instances[name].execute_task()
