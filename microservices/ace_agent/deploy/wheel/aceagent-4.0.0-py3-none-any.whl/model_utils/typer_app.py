# Copyright(c) 2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

""" Typer app exposing arguments to run the model utils package which can be used to deploy models """

import os
import typer
from rich import print
from subprocess import run
from typing import Optional

import model_utils

builder_entrypoint_path = os.path.join(os.path.dirname(model_utils.__file__), "builder_entrypoint.py")
default_model_repo_path = os.path.join(os.getcwd(), "model_repository")

model_server = typer.Typer(
    no_args_is_help=True,
    help="Deploy the models for your Bot. Also deploy the NLP Server which brings up the RESTful endpoints to interact with your deployed models.",
    add_completion=False,
)


@model_server.command(
    no_args_is_help=True,
    help="Optimize and deploy the models using triton servers and riva skills. Also launch the NLP server which will expose RESTful interfaces over the deployed models.",
)
def deploy(
    config: Optional[str] = typer.Option(
        ...,
        "-c",
        "--config",
        help="Relative path to the present working directory containing the model config yaml file.",
        exists=True,
    ),
    model_repository_path: str = typer.Option(
        default_model_repo_path,
        "-path",
        "--model-repository-path",
        help="Path where optimized models will be stored for Triton Inference Server.",
    ),
    no_cache: bool = typer.Option(
        False, help="By default cached triton model plans are used, Set flag to True to rebuild triton plans."
    ),
    gpus: str = typer.Option(
        default="1",
        help="""GPUS to be used for deployment, allowed formats - "3"[use total 3 gpus], ''"device=0,1"[use device 0 & 1]'""",
    ),
    speech: bool = typer.Option(False, help="Set flag to True to deploy speech models ( ASR and TTS )."),
):
    args = "" if not no_cache else " --no_cache"
    args = args + f" --gpus {gpus}"
    args = args + f" --speech" if speech else args
    deploy_cmd = (
        f"python3 {builder_entrypoint_path} deploy --model_config_path {config} --model_repository_path {model_repository_path}"
        + args
    )
    nlp_server_deploy_cmd = f"aceagent nlp-server deploy -c {config}"
    os.environ["BUILDER_ROOT"] = os.getcwd()
    print(f"Setting builder root to {os.environ['BUILDER_ROOT']}.")
    print(f"Starting the triton model servers with command {deploy_cmd}.")
    run(deploy_cmd, shell=True, check=True)

    print(f"Deploying the NLP server. NLP server will expose RESTful interfaces over the deployed models.")
    run(nlp_server_deploy_cmd, shell=True, check=True)

    # TODO: Deploy IR server if IR models are defined in the model config file


@model_server.command(help="Kill the locally deployed triton optimized models and NLP server.")
def stop():
    print(f"Stopping any running triton servers hosting the models.")
    server_cmd = f"docker kill nlp_triton & docker kill riva-speech-server"
    nlp_server_cmd = f"aceagent nlp-server stop"

    print(f"Stopping model servers with command: {server_cmd}")
    run(server_cmd, shell=True)
    print(f"All triton model servers stopped successfully.")
    run(nlp_server_cmd, shell=True, check=True)
