# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import sys
import logging
import argparse

# add model_utils
sys.path.append("..")

from model_utils.base.task import BaseTask


logger = logging.getLogger()
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


def builder_cli():
    """
    Entrypoint for ACE Agent Model Utils tool
    """
    # Parse CLI Args
    full_parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        allow_abbrev=False,
        description=f"ACE Agent Model Utils tool",
    )
    BaseTask.configure_argparse(full_parser)
    args = full_parser.parse_args(sys.argv[1:])

    # Create Task Instance and Execute Task
    task_class = BaseTask.get_task(args.task_name)
    task_instance = task_class.from_arguments(vars(args))
    task_instance.execute_task()


if __name__ == "__main__":
    try:
        builder_cli()
    except Exception as e:
        logger.error("ACE Agent Model Utils failed with error : {}".format(e))
        exit(1)
