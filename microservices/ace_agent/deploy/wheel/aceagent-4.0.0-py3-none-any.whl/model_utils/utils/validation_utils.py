# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import re


class ValidationUtils:
    """
    Common validation functions
    """

    @staticmethod
    def valid_range(val, greater_than=None, greater_equal=None, less_than=None, less_equal=None):
        """
        Check if given int/float is in expected range
        """
        if greater_than is not None and val <= greater_than:
            raise ValueError(f"Value should be greater than {greater_than}")
        if greater_equal is not None and val < greater_equal:
            raise ValueError(f"Value should be greater than or equal to {greater_equal}")
        if less_than is not None and val >= less_than:
            raise ValueError(f"Value should be less than {less_than}")
        if less_equal is not None and val > less_equal:
            raise ValueError(f"Value should be less than or equal to {less_equal}")
        return val

    @staticmethod
    def nonempty_value(val):
        """
        Check if given value in non-null
        """
        if val is None or len(val) == 0:
            raise ValueError("Blank/None value not allowed")
        return val

    @staticmethod
    def exclude_regex(val, regex_pattern):
        """
        check if value is not present in regex given for invalid values
        """
        if len(val) > 0 and re.search(regex_pattern, val) is None:
            return val
        raise ValueError(f"Invalid value {val}")

    @staticmethod
    def validate_list(value_list, val_func, **kwargs):
        """
        Validate each value of the given list using val_func
        """
        if value_list is None:
            return []

        for index, val in enumerate(value_list):
            value_list[index] = val_func(val, **kwargs)
        return value_list
