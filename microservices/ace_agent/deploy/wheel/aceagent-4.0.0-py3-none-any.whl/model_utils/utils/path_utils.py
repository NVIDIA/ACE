# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import os
import re
import shutil
import logging
from pathlib import Path

logger = logging.getLogger("__main__." + __name__)


class PathUtils:
    """
    Util class for managing path related validations
    """

    @staticmethod
    def get_abs_path(path):
        """
        Validate and return absolute path
        """
        if path is None or len(path) == 0:
            raise ValueError("Blank/None value not allowed")

        abs_path = None
        if path.startswith("/"):
            abs_path = os.path.abspath(path)
        else:
            builder_root_path = os.environ.get("BUILDER_ROOT")
            if not builder_root_path or not os.path.exists(builder_root_path):
                raise ValueError(f"Invalid BUILDER_ROOT ENV variable {builder_root_path}")
            abs_path = os.path.abspath(os.path.join(builder_root_path, path))
        return abs_path

    @staticmethod
    def exists_path(path, path_type=None):
        """
        Check if path exists and return absolute path
        """
        abs_path = PathUtils.get_abs_path(path)
        # check if path exists
        if not os.path.exists(abs_path):
            raise ValueError(f"Invalid path {abs_path}, path doesn't exist")
        elif path_type == "file" and not os.path.isfile(abs_path):
            raise ValueError(f"Invalid path type for {abs_path}, expected file")
        elif path_type == "directory" and not os.path.isdir(abs_path):
            raise ValueError(f"Invalid path type for {abs_path}, expected directory")
        return abs_path

    @staticmethod
    def clean_path(path, ignore_errors=False):
        """
        Clean existing file or directory path and return absolute path
        Directory path will still exists, but it will be empty
        """
        abs_path = PathUtils.exists_path(path)
        try:
            if os.path.isfile(abs_path):
                Path(abs_path).unlink()
            else:
                for filename in os.listdir(abs_path):
                    file_path = os.path.join(abs_path, filename)
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        Path(file_path).unlink()
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path, ignore_errors=ignore_errors)
        except Exception as e:
            if ignore_errors:
                logger.warning(f"Unable to clean directory {path} with error : {e}")
            else:
                raise ValueError(f"Unable to clean directory {path} with error : {e}")
        return abs_path

    @staticmethod
    def create_dir(path, path_type="directory"):
        """
        Create directory for given path and return abs_path
        """
        abs_path = PathUtils.get_abs_path(path)
        try:
            if path_type == "file":
                os.makedirs(os.path.dirname(abs_path), exist_ok=True)
            else:
                Path(abs_path).mkdir(parents=True, exist_ok=True)
        except Exception as e:
            raise ValueError(f"Unable to create directory at {path}, with error : {e}")
        return abs_path

    @staticmethod
    def create_or_clean_path(path, path_type="directory"):
        """
        Create directory or clean existing path
        """
        abs_path = PathUtils.get_abs_path(path)
        if os.path.exists(abs_path):
            return PathUtils.clean_path(abs_path)
        else:
            return PathUtils.create_dir(abs_path, path_type=path_type)

    @staticmethod
    def exists_local_ngc_path(path):
        """
        Check if given path is existing local path or NGC path
        """
        try:
            return PathUtils.exists_path(path)
        except:
            try:
                return PathUtils.valid_ngc_path(path)
            except:
                raise ValueError(f"Provided path {path} is not valid local or ngc path")

    @staticmethod
    def valid_ngc_path(path, allow_none=False):
        """
        Check if given path is valid NGC path
        """
        if path is None or path.strip() == "":
            if allow_none:
                return None
            raise ValueError("Blank/None value not allowed")
        elif not re.match(r"^([\w-]+/){1,2}([\w-]+)(:[\w.-]+){0,1}$", path):
            raise ValueError(f"Invalid format for NGC path {path}")
        return path
