# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

from dataclasses import dataclass, field

from model_utils.model.common.task_evaluate import EvaluateTask
from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils


@dataclass
class TextClassificationEvaluation(EvaluateTask):
    """
    Evaluate Text Classification Model
    """

    task_name: str = field(
        default="task.evaluate.text_classification",
        metadata={"help": "Evaluate Text Classification Model", "suppress": True},
    )
    dataset_path: str = field(
        default=None,
        metadata={
            "help": "Directory path for Nemo format Text Classification dataset",
            "required": True,
            "validation_func": PathUtils.exists_path,
        },
    )
    test_file_prefix: str = field(
        default="test",
        metadata={
            "help": "File prefix used for test dataset files, Expected test files {prefix}.tsv",
            "validation_func": ValidationUtils.exclude_regex,
            "validation_args": {"regex_pattern": r"\W+"},
        },
    )

    def execute_task(self):
        """
        run evaluation for Text Classification model
        """
        from .text_classification_model import TextClassificationModel

        return TextClassificationModel.evaluate(self)
