"""
 copyright(c) 2020 - 2021 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""
import os
import logging


logger = logging.getLogger("__main__." + __name__)


class TextClassificationDataset:
    """
    Text Classification Dataset functionalities
    """

    def __init__(self, config):
        self._config = config

    def export_dataset(self, ignore_first_line=True):
        """
        Combine multiple Intent Slot datasets and create text classification NeMo dataset
        """
        logger.info("Creating domain classifier dataset with domains: {}".format(self._config.domain_datasets))
        # create labels dict
        labels_dict = {domain: label_id for label_id, domain in enumerate(self._config.domain_datasets.keys())}
        # dump labels dict
        with open(os.path.join(self._config.nemo_export_path, self._config.labels_filename), "w") as labels_file:
            labels_file.write("\n".join(labels_dict.keys()))
        # create train and dev file
        for filename in ["train.tsv", "dev.tsv"]:
            with open(os.path.join(self._config.nemo_export_path, filename), "w") as merge_file:
                for domain in labels_dict:
                    domain_file = os.path.join(self._config.domain_datasets[domain], filename)
                    for line in open(domain_file).readlines()[ignore_first_line:]:
                        merge_file.write(line.split("\t")[0].strip() + "\t" + str(labels_dict[domain]) + "\n")
        logger.info("Sucessfully created domain classifier dataset at {}".format(self._config.nemo_export_path))
