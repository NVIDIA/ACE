# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
import os
import logging
from dataclasses import dataclass, field, fields

from model_utils.model.common.task_export_dataset import DatasetExport
from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils

logger = logging.getLogger("__main__." + __name__)


@dataclass
class ExportTextClassificationDataset(DatasetExport):
    """
    Export multiple Intent Slot datasets to Single NeMo text classification dataset format
    """

    task_name: str = field(
        default="task.export_dataset.text_classification",
        metadata={
            "help": "Export multiple Intent Slot datasets as Single Text Classification dataset",
            "suppress": True,
        },
    )
    domain_dataset_paths: list = field(
        default=None,
        metadata={
            "required": True,
            "help": "List of NeMo format Intent Slot dataset paths, format `domain_name:dataset_path`",
        },
    )
    labels_filename: str = field(
        default="dict.labels.csv", metadata={"help": "File name of storing labels for domain classifier"}
    )
    nemo_export_path: str = field(
        init=False,
        metadata={"help": "Directory path for exported Text Classification dataset in NEMO format"},
    )

    def __post_init__(self):
        """
        Custom validation logic
        """
        super().__post_init__()

        self.nemo_export_path = self.unique_result_path
        self.domain_datasets = {}
        for domain_data in self.domain_dataset_paths:
            if len(domain_data.split(":")) != 2:
                raise ValueError(
                    "Invalid format for domain_dataset_paths, expected format `domain_name:domain_dataset_path`"
                )
            domain, dataset = domain_data.split(":")
            self.domain_datasets[domain] = PathUtils.exists_path(dataset)

    def execute_task(self):
        """
        Create text classification dataset
        """
        from .dataset import TextClassificationDataset

        return TextClassificationDataset(config=self).export_dataset()
