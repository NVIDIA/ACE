# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import os
from dataclasses import dataclass, field, fields

from model_utils.model.common.task_evaluate import EvaluateTask
from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils


@dataclass
class NEREvaluation(EvaluateTask):
    """
    Evaluate NER Model
    """

    task_name: str = field(
        default="task.evaluate.ner",
        metadata={"help": "Evaluate Named Entity Recogination (NER) Model", "suppress": True},
    )
    dataset_path: str = field(
        default=None,
        metadata={
            "help": "Directory path for Nemo format NER dataset",
            "required": True,
            "validation_func": PathUtils.exists_path,
        },
    )

    def execute_task(self):
        """
        run evaluation for Intent Slot model
        """
        from .ner_model import NERModel

        return NERModel.evaluate(self)
