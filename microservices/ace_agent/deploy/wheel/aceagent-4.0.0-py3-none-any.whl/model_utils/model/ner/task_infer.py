# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

from dataclasses import dataclass, field

from model_utils.model.common.task_infer import InferTask


@dataclass
class NERInference(InferTask):
    """
    Inference NER Model
    """

    task_name: str = field(
        default="task.infer.ner",
        metadata={"help": "Inference Named Entity Recogination (NER) Model", "suppress": True},
    )

    def execute_task(self):
        """
        run inference for NER model
        """
        from .ner_model import NERModel

        return NERModel.infer(self)
