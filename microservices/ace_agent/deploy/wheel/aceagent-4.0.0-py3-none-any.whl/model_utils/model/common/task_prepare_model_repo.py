# Copyright (c) 2021 - 2022, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import glob
from dataclasses import dataclass, field, fields

from model_utils.base.task import BaseTask
from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils


@dataclass
class PrepareModelRepoTask(BaseTask):
    """
    Task for Preparing Model repo for Riva Skills
    Download RMIR Models and TRT Plans, Extract TRT Plans into Model repo
    Copy RMIR models to rmir directory inside Model repo
    """

    task_name: str = field(
        default="task.prepare_model_repo",
        metadata={
            "help": "Prepare Model Repository by downloading RMIR and TRT model plans, Can be used with Riva Speech Skills QSS for deployment",
            "suppress": True,
        },
    )

    model_config_path: str = field(
        default=None,
        metadata={
            "help": "Path of Model Config for deployment. Allowed formats:- local model config path and NGC bot resource path",
            "validation_func": PathUtils.exists_local_ngc_path,
        },
    )
    model_repository_path: str = field(
        default="./model_repository",
        metadata={
            "help": "Directory path for model repository, which will have RMIR directory for storing RMIR models and models directory for storing optimized TRT plans",
            "validation_func": PathUtils.create_dir,
        },
    )
    speech: bool = field(default=False, metadata={"help": "Deploy speech models from Bot Config"})
    skip_riva_models: bool = field(default=False, metadata={"help": "Skip Riva Speech Server models"})

    def __post_init__(self):
        """
        Validate arguments and Setup Env
        """
        # validate arguments
        super().__post_init__()

        # Remove older models from model_repo
        PathUtils.clean_path(self.model_repository_path)

        if not self.model_config_path:
            if len(glob.glob(f"{self.model_repository_path}/**/*.pbtxt", recursive=True)) == 0:
                raise ValueError("No models found for deployment")

    def execute_task(self):
        """
        Preparing Model Repository
        """
        from .deployment_module import DeploymentModule

        DeploymentModule.prepare_model_repo(self)
