# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
import os
import logging
import tarfile
from dataclasses import dataclass, field, fields

from model_utils.base.task import BaseTask
from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils

logger = logging.getLogger("__main__." + __name__)


@dataclass
class DatasetExport(BaseTask):
    """
    Export datasets from one format to another format
    """

    task_name: str = field(
        default="task.export_dataset",
        metadata={"help": "Task for exporting the dataset to different formats", "suppress": True},
    )
    dataset_name: str = field(
        default=None,
        metadata={
            "required": True,
            "help": "Name of the dataset, will be used for creating export directory",
            "validation_func": ValidationUtils.exclude_regex,
            "validation_args": {"regex_pattern": r"\W+"},
        },
    )
    version: str = field(
        default="1",
        metadata={
            "help": "Version string for the exported dataset, will be used for creating export directory",
            "validation_func": ValidationUtils.nonempty_value,
        },
    )
    result_path: str = field(
        default="./exported_datasets",
        metadata={
            "help": "Result directory where exported datasets to be stored",
            "validation_func": PathUtils.create_dir,
        },
    )
    unique_result_path: str = field(
        default=None,
        init=False,
        metadata={
            "help": "Unique result directory for each dataset name and verison, will default to `{result_path}/{dataset_name}/{version}`",
        },
    )

    def __post_init__(self):
        """
        Custom validation logic
        """
        super().__post_init__()

        self.unique_result_path = PathUtils.create_or_clean_path(
            os.path.join(self.result_path, self.dataset_name, self.version)
        )
