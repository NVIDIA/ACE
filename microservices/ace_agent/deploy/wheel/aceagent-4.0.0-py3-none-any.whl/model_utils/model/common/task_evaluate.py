# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import os
from dataclasses import dataclass, field, fields
from model_utils.base.task import BaseTask

from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils


@dataclass
class EvaluateTask(BaseTask):
    """
    Base module for Model Evaluation Task
    """

    task_name: str = field(init=False, default="task.evaluate", metadata={"help": "Task for evaluating trained model"})

    # model metadata
    model_name: str = field(
        default=None,
        metadata={
            "required": True,
            "help": "Name of the model for evaluation, will be used for creating result directory",
            "validation_func": ValidationUtils.exclude_regex,
            "validation_args": {"regex_pattern": r"\W+"},
        },
    )
    version: str = field(
        default="1",
        metadata={
            "help": "Version string for the model, will be used for creating result directory",
            "validation_func": ValidationUtils.nonempty_value,
        },
    )
    platform: str = field(
        default="local", metadata={"help": "Platform for running model evaluation", "choices": ["local", "ngc"]}
    )
    tlt_model_path: str = field(
        default=None,
        metadata={
            "help": "File path for TLT model checkpoint to be used for evaluation",
            "required": True,
            "validation_func": PathUtils.exists_path,
        },
    )

    # result and logs dir
    result_path: str = field(
        default="./results",
        metadata={
            "help": "Base directory where resulting models and logs to be stored",
            "validation_func": PathUtils.create_dir,
        },
    )
    unique_result_path: str = field(
        init=False,
        metadata={
            "help": "Unique result directory for each model name and verison, will default to `{result_path}/{model_name}/{version}`"
        },
    )
    evaluate_logs_path: str = field(
        init=False,
        metadata={
            "help": "Directory which will store evaluation logs, will default to `{unique_result_path}/evaluate` "
        },
    )
    # evaluation hyperparameters
    gpus: int = field(
        default=1,
        metadata={
            "help": "Number of gpus to be used for evaluation, Only integer value allowed",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    batch_size: int = field(
        default=32,
        metadata={
            "help": "Batch size to be used for evaluation run",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    model_encryption_key: str = field(
        default="tlt_encode",
        metadata={"help": "Encryption key used for models during training"},
    )
    gpu_memory: str = field(
        default="32",
        metadata={
            "help": "Optional flag for evaluation on NGC platform, GPU memory required per instance for NGC Jobs. Check NGC Batch for available choices"
        },
    )

    def __post_init__(self):
        """
        Custom validation and Env Setup for Evaluate mode
        """
        # validate arguments
        super().__post_init__()

        # create unique result path
        self.unique_result_path = PathUtils.create_dir(os.path.join(self.result_path, self.model_name, self.version))
        self.evaluate_logs_path = PathUtils.create_or_clean_path(os.path.join(self.unique_result_path, "evaluate"))

        # create nltk cache path
        self.nltk_cache_path = PathUtils.create_dir(os.path.join(self.cache_path, "nltk"))
