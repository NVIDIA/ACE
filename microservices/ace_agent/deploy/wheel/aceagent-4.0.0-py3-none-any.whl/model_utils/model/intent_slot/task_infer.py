# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

from dataclasses import dataclass, field

from model_utils.model.common.task_infer import InferTask


@dataclass
class IntentSlotInference(InferTask):
    """
    Inference Intent Slot Classification Model
    """

    task_name: str = field(
        default="task.infer.intent_slot",
        metadata={"help": "Inference Intent Slot Classification Model", "suppress": True},
    )

    def execute_task(self):
        """
        run inference for Intent Slot model
        """
        from .intent_slot_model import IntentSlotModel

        return IntentSlotModel.infer(self)
