# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
import os
import logging
from dataclasses import dataclass, field, fields

from model_utils.model.common.task_export_dataset import DatasetExport
from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils

logger = logging.getLogger("__main__." + __name__)


@dataclass
class ExportIntentSlotDataset(DatasetExport):
    """
    Export multiple Intent Slot datasets to Single NeMo or YAML dataset format
    """

    task_name: str = field(
        default="task.export_dataset.intent_slot",
        metadata={
            "help": "Export multiple Intent Slot datasets as Single dataset. Both NeMo / YAML format will be saved",
            "suppress": True,
        },
    )
    dataset_paths: list = field(
        default=None,
        metadata={
            "required": True,
            "help": "List of dataset paths, which need to exported as single dataset. Allowed formats : NEMO and YAML format Intent Slot Datasets",
            "validation_func": ValidationUtils.validate_list,
            "validation_args": {"val_func": PathUtils.exists_path},
        },
    )
    validation_split: float = field(
        default=0.1,
        metadata={
            "help": "Fraction of the data to be used as validation set, only used when dev yaml dataset not provided. Split will be done for each dataset_path individually",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_equal": 0.0, "less_equal": 1.0},
        },
    )
    max_validation_examples: int = field(
        default=10000,
        metadata={
            "help": "Maximum examples per intent used for validation set, will be used during validation split to limit number of validation examples",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    min_validation_examples: int = field(
        default=1,
        metadata={
            "help": "Minimum examples per intent used for validation set, Make sure you have good number of training examples",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    nemo_export_path: str = field(
        init=False,
        metadata={"help": "Directory path for exported Intent Slot dataset in NEMO format"},
    )
    yaml_export_path: str = field(
        init=False,
        metadata={"help": "Directory path for exported Intent Slot dataset in YAML format"},
    )

    def __post_init__(self):
        """
        Custom validation logic
        """
        super().__post_init__()

        self.nemo_export_path = PathUtils.create_or_clean_path(os.path.join(self.unique_result_path, "nemo"))
        self.yaml_export_path = PathUtils.create_or_clean_path(os.path.join(self.unique_result_path, "yaml"))

    def execute_task(self):
        """
        Export NeMo and YAML dataset
        """
        from .dataset import IntentSlotDataset

        return IntentSlotDataset(config=self).export_dataset()
