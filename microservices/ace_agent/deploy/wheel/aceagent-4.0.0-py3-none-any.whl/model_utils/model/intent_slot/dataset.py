"""
 copyright(c) 2021 - 2022 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""
import os
import json
import sys
import re
import string
import yaml
import glob
import shutil
import numpy as np
import logging
from collections import namedtuple

from model_utils.schemas.validator import SchemaValidator

logger = logging.getLogger("__main__." + __name__)

# SLOT and Training example
SLOT_REGEX = re.compile(r"\[(?P<slot_value>[^\]]+?)\]\{(?P<slot_name>[^\}]+?)\}")
TrainingExample = namedtuple("TrainingExample", ["intent_name", "utterance", "slots"])
SlotExample = namedtuple("SlotExample", ["slot_name", "slot_value", "start_index", "end_index"])


class IntentSlotDataset:
    """
    Intent Slot Dataset which accepts both YAML and NeMo format
    """

    def __init__(self, config):
        self._config = config

    def export_dataset(self):
        """
        Combine multiple datasets and write in NeMo and YAML format
        """
        datasets_data = []
        for source_path in self._config.dataset_paths:
            datasets_data.append(self.read_dataset(source_path))

        all_examples = IntentSlotDataset.merge_examples(datasets_data)
        all_unique_examples = IntentSlotDataset.remove_duplicate_examples(all_examples)

        # create nemo result path
        logger.info("### Writing Nemo dataset ###")
        NeMoProcessor.write_dataset(all_unique_examples, self._config.nemo_export_path)

        logger.info("### Writing YAML dataset ###")
        self.write_dataset(all_unique_examples, self._config.yaml_export_path)

    def read_dataset(self, dataset_path):
        """
        Read combination of NeMo and YAML dataset and create Training Examples
        """
        yaml_files = []
        if dataset_path.endswith((".yml", ".yaml")):
            yaml_files.append(dataset_path)
        else:
            yaml_files.extend(glob.glob("{}/*.yml".format(dataset_path)) + glob.glob("{}/*.yaml".format(dataset_path)))

        # yaml_files should contain train, dev, test in order
        for name in ["test", "dev", "train"]:
            for yaml_file in yaml_files:
                if os.path.basename(yaml_file) in [f"{name}.yml", f"{name}.yaml"]:
                    yaml_files.remove(yaml_file)
                    yaml_files.insert(0, yaml_file)

        annotators = {}  # All annotators present in dev and train yaml

        yaml_datasets = []
        for dataset_path_iter in yaml_files:
            mode = os.path.basename(dataset_path_iter).split(".")[0]
            if mode not in ["train", "dev", "test"]:
                mode = "train_dev"
            yaml_datasets.append({mode: self.__parse_yaml(dataset_path_iter)})

        all_examples = IntentSlotDataset.merge_examples(yaml_datasets)

        if "train_dev" in all_examples:
            split_examples = self.__split_train_validation_data(all_examples["train_dev"])
            del all_examples["train_dev"]
            all_examples = IntentSlotDataset.merge_examples([split_examples, all_examples])

        # check if any nemo files are present in same directory
        if NeMoProcessor.valid_nemo_dataset(dataset_path):
            nemo_examples = NeMoProcessor.read_dataset(dataset_path)
            all_examples = IntentSlotDataset.merge_examples([all_examples, nemo_examples])

        unique_examples = IntentSlotDataset.remove_duplicate_examples(all_examples)
        return unique_examples

    def __split_train_validation_data(self, examples_data):
        """
        Split examples into training and dev set
        """
        train_examples, dev_examples = {}, {}
        for intent_name in examples_data.keys():
            utterances_count = len(examples_data[intent_name])
            if utterances_count <= self._config.min_validation_examples:
                raise ValueError(
                    f"Intent {intent_name} have {utterances_count} queries, "
                    f"Minimum {self._config.min_validation_examples+1} queries required"
                )
            dev_example_count = min(
                max(int(utterances_count * self._config.validation_split), self._config.min_validation_examples),
                self._config.max_validation_examples,
            )
            dev_idxs = np.random.choice(utterances_count, dev_example_count, replace=False)
            train_examples[intent_name] = [
                examples_data[intent_name][ind] for ind in range(utterances_count) if ind not in dev_idxs
            ]
            dev_examples[intent_name] = [examples_data[intent_name][ind] for ind in dev_idxs]
        return {"train": train_examples, "dev": dev_examples}

    def __parse_yaml(self, yaml_file):
        """
        Read YAML format dataset
        """
        logger.info(f" Parsing YAML dataset file {yaml_file}")
        SchemaValidator.validate_file(yaml_file, SchemaValidator.YAML_DOMAIN_DATASET_SCHEMA)

        with open(yaml_file, "r") as f:
            try:
                yaml_data = yaml.safe_load(f)
            except yaml.YAMLError as e:
                raise ValueError("Failed to load YAML file {}".format(yaml_file))
        examples_data = {}
        annotators = {}
        if "nlu" not in yaml_data or yaml_data["nlu"] is None:
            raise ValueError("Missing NLU in yaml data {}".format(yaml_file))
        for item in yaml_data["nlu"]:
            if "intent" in item.keys():
                intent_name, intent_examples = self.__parse_intent_yaml(item)
                if intent_name is None or intent_examples is None:
                    continue
                elif intent_name is examples_data:
                    logger.warning("Duplicate intent sections with name {} detected".format(intent_name))
                    examples_data[intent_name].extend(intent_examples)
                else:
                    examples_data[intent_name] = intent_examples
            elif "slot" in item.keys():
                self.__parse_slot_yaml(item, annotators)
            else:
                raise ValueError("Unknown NLU item in training yaml: {}".format(item))

        # Annotate slots
        self.__annotate_slots(examples_data, annotators)
        return examples_data

    def __parse_intent_yaml(self, item):
        if not item:
            logger.warning("Unable to parse blank item for Intent data")
            return None, None

        intent_name = item.get("intent", None)
        if not intent_name or intent_name.strip() == "":
            raise ValueError("Missing or Blank intent name encounterd at {}".format(item))

        utterances = item.get("queries", None)
        if not utterances or len(utterances) == 0:
            raise ValueError("No queries provided for intent {}".format(intent_name))
        elif not isinstance(utterances, str) and not isinstance(utterances, list):
            raise ValueError("Invalid format for queries, Expected multiline string or list format")
        elif isinstance(utterances, str):
            # multiline string
            utterance_list = []
            for utterance in utterances.splitlines():
                if not utterance.startswith("-"):
                    raise ValueError("Invalid format encounterd for query {}".format(utterance))
                utterance_list.append(utterance[1:])
            utterances = utterance_list

        intent_examples = []
        for utterance in utterances:
            # remove unnecessary spaces
            clean_utterance = " ".join(utterance.split())
            if clean_utterance == "":
                logger.warning("Ignoring blank query for intent {}".format(intent_name))
            slots = []
            processed_index = offset = 0
            for match in re.finditer(SLOT_REGEX, clean_utterance):
                slot_name = match.groupdict()["slot_name"]
                slot_value = match.groupdict()["slot_value"]

                start_index = match.start() - offset
                end_index = start_index + len(slot_value)
                offset += len(match.group(0)) - len(slot_value)
                if slot_name.strip() == "" or slot_value.strip() == "":
                    raise ValueError("Invalid format for slot, query {}".format(utterance))
                slots.append(
                    SlotExample(
                        slot_name=slot_name, slot_value=slot_value, start_index=start_index, end_index=end_index
                    )
                )
            # remove slot tagging
            plain_utterance = re.sub(SLOT_REGEX, lambda m: m.groupdict()["slot_value"], clean_utterance)
            intent_examples.append(TrainingExample(intent_name=intent_name, utterance=plain_utterance, slots=slots))
        if len(intent_examples) == 0:
            logger.warning("No valid query found for intent {}".format(intent_name))
            return None, None
        return intent_name, intent_examples

    def write_dataset(self, examples_data, result_path):
        """
        Write dataset in yaml format
        """
        if os.path.exists(result_path):
            shutil.rmtree(result_path, ignore_errors=True)
        os.makedirs(result_path, exist_ok=True)

        for mode in examples_data:
            yaml_data = {}
            yaml_data["domain"] = self._config.dataset_name
            yaml_data["version"] = self._config.version
            yaml_data["nlu"] = []
            for intent_name in examples_data[mode].keys():
                utternace_list = []
                for example in examples_data[mode][intent_name]:
                    utterance = example.utterance
                    tagged_slots = example.slots
                    tagged_slots.sort(key=lambda x: x.start_index)

                    utter_slots = []
                    processed_index = 0
                    for slot_example in tagged_slots:
                        utter_slots.append(utterance[processed_index : slot_example.start_index])
                        utter_slots.append(f"[{slot_example.slot_value}]{{{slot_example.slot_name}}}")
                        processed_index = slot_example.end_index
                    utter_slots.append(utterance[processed_index:])
                    utternace_list.append("".join(utter_slots).strip())
                yaml_data["nlu"].append({"intent": intent_name, "queries": utternace_list})
            with open(os.path.join(result_path, f"{mode}.yaml"), "w") as f:
                yaml.dump(yaml_data, f, sort_keys=False)
        logger.info(f"Yaml dataset saved at {result_path}")

    def __parse_slot_yaml(self, item, annotators):
        if not item:
            logger.warning("Unable to parse blank item for slot data")
            return

        slot_name = item.get("slot", None)
        if not slot_name or slot_name.strip() == "":
            raise ValueError("Missing or Blank Slot name encounterd at {}".format(item))

        if slot_name not in annotators:
            annotators[slot_name] = []
        for key in item.keys():
            if key == "regex":
                annotators[slot_name].extend(self.__valid_regex_annotators(item.get("regex", None)))
            elif key == "lookup":
                annotators[slot_name].extend(self.__valid_lookup_annotators(item.get("lookup", None)))
            elif key == "slot":
                continue
            else:
                raise ValueError(f"Unknown key {key} found for slot {slot_name}")

        if len(annotators[slot_name]) == 0:
            logger.warning("No valid lookup / regex annotators provided for slot {}".format(slot_name))

    def __valid_regex_annotators(self, regex_patterns):
        if not regex_patterns:
            return
        valid_patterns = []
        for pattern in regex_patterns:
            try:
                compiled_regex = re.compile(pattern)
            except:
                logger.error("Encountered Invalid regex pattern {}".format(pattern))
                raise
            else:
                valid_patterns.append(pattern)
        return valid_patterns

    def __valid_lookup_annotators(self, lookup_words):
        if not lookup_words:
            return
        valid_lookups = []
        for word in lookup_words:
            if re.search(r"[^\w\s-]", word) is None:
                valid_lookups.append(word.strip())
            else:
                raise ValueError("Invalid lookup word {}".format(word))
        if len(valid_lookups) == 0:
            return []
        return [r"\b({})\b".format("|".join(valid_lookups))]

    def __annotate_slots(self, examples_data, annotators):
        for slot_name in annotators.keys():
            for pattern in annotators[slot_name]:
                complied_regex = re.compile(pattern, re.IGNORECASE)  # case is ignored
                for intent_name in examples_data.keys():
                    for example in examples_data[intent_name]:
                        for match in re.finditer(complied_regex, example.utterance):
                            match_slot = SlotExample(
                                slot_name=slot_name,
                                slot_value=match.group(),
                                start_index=match.start(),
                                end_index=match.end(),
                            )
                            # check if complete word match
                            ignore_slot = False
                            context = example.utterance[max(0, match_slot.start_index - 1) : match_slot.end_index + 1]
                            if not re.search(r"\b({})\b".format(match_slot.slot_value), context):
                                ignore_slot = True
                                logger.warning(
                                    f"Invalid slot '{match_slot.slot_name}' detected with value "
                                    f"'{match_slot.slot_value}' with regex pattern '{pattern}' "
                                    f"in query : {example.utterance}"
                                )

                            # check if no overlap with existing slots
                            slot_overlap = False
                            for slot in example.slots:
                                max_start = max(match_slot.start_index, slot.start_index)
                                min_end = min(match_slot.end_index, slot.end_index)
                                if max_start < min_end:
                                    slot_overlap = True
                                    if (
                                        match_slot.slot_name != slot.slot_name
                                        or match_slot.slot_value != slot.slot_value
                                    ):
                                        logger.warning(
                                            f"Ignorning annotation for slot '{match_slot.slot_name}' with "
                                            f"value '{match_slot.slot_value}' due to overlap with slot "
                                            f"'{slot.slot_name}' with value '{slot.slot_value}' "
                                        )
                                    break
                            if not ignore_slot and not slot_overlap:
                                example.slots.append(match_slot)

    @staticmethod
    def merge_examples(all_data_examples):
        """
        Merge multiple datasets into one
        """
        merged_examples = {}
        for examples in all_data_examples:
            for mode in examples:
                if mode not in merged_examples:
                    merged_examples[mode] = {}
                for intent_name in examples[mode]:
                    merged_examples[mode].setdefault(intent_name, []).extend(examples[mode][intent_name])
        return merged_examples

    @staticmethod
    def remove_duplicate_examples(data_examples):
        """
        Remove duplicate training examples
        """
        unique_examples = {}
        unique_utterances = {}
        conflict_utterances = False

        for mode in data_examples:
            mode_examples = {}
            for intent_name in data_examples[mode].keys():
                mode_examples[intent_name] = []
                for example in data_examples[mode][intent_name]:
                    # get lowercase utterance
                    utterance = example.utterance.lower()
                    # add space around punctuations
                    utterance = utterance.translate(
                        str.maketrans({key: " {0} ".format(key) for key in string.punctuation})
                    )
                    # remove extra whitespaces
                    utterance = " ".join(utterance.split())
                    if utterance in unique_utterances:
                        if example.intent_name != unique_utterances[utterance].intent_name:
                            conflict_utterances = True
                            logger.warning(
                                f"Found duplicate utterances with different intent names \n"
                                f"\t intent {example.intent_name} : {example.utterance}\n"
                                f"\t intent {unique_utterances[utterance].intent_name} : {unique_utterances[utterance].utterance} \n"
                            )
                        else:
                            logger.debug(
                                f"Removing duplicate utterance for intent {example.intent_name} : {example.utterance}"
                            )
                    else:
                        unique_utterances[utterance] = example
                        mode_examples[intent_name].append(example)
            unique_examples[mode] = mode_examples
        if conflict_utterances:
            raise ValueError("Found duplicate utterances with different intent names")
        return unique_examples


class NeMoProcessor:
    """
    NeMo dataset processing
    """

    DATASET_FILENAMES = [
        "dict.intents.csv",
        "dict.slots.csv",
        "train.tsv",
        "dev.tsv",
        "train_slots.tsv",
        "dev_slots.tsv",
    ]

    @staticmethod
    def valid_nemo_dataset(dataset_path):
        """
        Check if given dataset in valid nemo datasets
        """
        return os.path.isdir(dataset_path) and all(
            os.path.exists(os.path.join(dataset_path, filename)) for filename in NeMoProcessor.DATASET_FILENAMES
        )

    @staticmethod
    def read_dataset(source_path):
        """
        Read NeMo datasets into training examples
        """
        logger.info(f" ### Parsing Nemo dataset from {source_path} ###")
        # load label and slots dict
        with open(os.path.join(source_path, "dict.intents.csv")) as f:
            intents_dict = {index: line.strip() for index, line in enumerate(f.readlines())}
        with open(os.path.join(source_path, "dict.slots.csv")) as f:
            slots_dict = {index: line.strip() for index, line in enumerate(f.readlines())}
        # load train / dev / test dataset
        examples_data = {}
        for mode in ["train", "dev", "test"]:
            intents_tsv = os.path.join(source_path, f"{mode}.tsv")
            slots_tsv = os.path.join(source_path, f"{mode}_slots.tsv")
            if not os.path.exists(intents_tsv) or not os.path.exists(slots_tsv):
                logger.warning(f"Skipping {mode} mode due to missing files in {source_path}")
                continue
            examples_data[mode] = {}
            for example_line, slot_line in zip(open(intents_tsv).readlines()[1:], open(slots_tsv).readlines()):
                if example_line.strip() == "":
                    continue
                utterance, intent_index = example_line.split("\t")
                utterance = " ".join(utterance.split())
                intent_name = intents_dict[int(intent_index.strip())]
                slots = []
                processed_index, prev_slot, slot_text = 0, "O", ""
                for word, tag in zip(utterance.split(), slot_line.split()):
                    tag = int(tag.strip())
                    if (slots_dict[tag] == "O" or slots_dict[tag][2:] != prev_slot) and slot_text.strip() != "":
                        slots.append(
                            SlotExample(
                                slot_name=prev_slot,
                                slot_value=slot_text.strip(),
                                start_index=processed_index,
                                end_index=processed_index + len(slot_text.strip()),
                            )
                        )
                        slot_text, processed_index = "", processed_index + len(slot_text.strip()) + 1
                    if slots_dict[tag] == "O":
                        slot_text, prev_slot, processed_index = "", "O", processed_index + len(word) + 1
                    else:
                        slot_text, prev_slot = slot_text + word + " ", slots_dict[tag][2:]
                if slot_text.strip() != "":
                    slots.append(
                        SlotExample(
                            slot_name=prev_slot,
                            slot_value=slot_text.strip(),
                            start_index=processed_index,
                            end_index=processed_index + len(slot_text.strip()),
                        )
                    )
                if intent_name not in examples_data[mode]:
                    examples_data[mode][intent_name] = []
                examples_data[mode][intent_name].append(
                    TrainingExample(intent_name=intent_name, utterance=utterance, slots=slots)
                )
        return examples_data

    @staticmethod
    def write_dataset(data_dict, result_path):
        """
        Write Intent Slot examples into NeMo's BIO format
        """
        if os.path.exists(result_path):
            shutil.rmtree(result_path, ignore_errors=True)
        os.makedirs(result_path, exist_ok=True)

        outfiles = {}
        intents_dict = {}
        slots_dict = {}
        slots_dict_all = {}

        outfiles["dict_intents"] = open(os.path.join(result_path, "dict.intents.csv"), "w")
        outfiles["dict_slots"] = open(os.path.join(result_path, "dict.slots.csv"), "w")

        outfiles["dict_slots"].write("O\n")
        slots_dict["O"] = 0
        slots_dict_all["O"] = 0

        for mode in data_dict.keys():
            outfiles[mode] = open(os.path.join(result_path, "{}.tsv".format(mode)), "w")
            outfiles[mode].write("sentence\tlabel\n")
            outfiles[mode + "_slots"] = open(os.path.join(result_path, "{}_slots.tsv".format(mode)), "w")

            intents_data = data_dict[mode]
            for intent_name in intents_data.keys():
                if intent_name not in intents_dict:
                    intents_dict[intent_name] = len(intents_dict)
                    outfiles["dict_intents"].write(f"{intent_name}\n")

                for example in intents_data[intent_name]:
                    utterance = example.utterance

                    tagged_slots = example.slots
                    tagged_slots.sort(key=lambda x: x.start_index)
                    slots_indexes = []
                    processed_index = 0
                    processed_utterance = []  # used to add spaces in utterances
                    for slot_example in tagged_slots:
                        if slot_example.slot_name not in slots_dict:
                            slots_dict[slot_example.slot_name] = len(slots_dict)
                            slots_dict_all[f"B-{slot_example.slot_name}"] = len(slots_dict_all)
                            slots_dict_all[f"I-{slot_example.slot_name}"] = len(slots_dict_all)
                            outfiles["dict_slots"].write(f"B-{slot_example.slot_name}\n")
                            outfiles["dict_slots"].write(f"I-{slot_example.slot_name}\n")
                        # convert to slots indexes
                        if slot_example.start_index > processed_index:
                            words_text = utterance[processed_index : slot_example.start_index].strip()
                            if words_text != "":
                                processed_utterance.append(words_text)
                                slots_indexes.extend([str(slots_dict_all["O"])] * len(words_text.split()))
                        words_text = utterance[slot_example.start_index : slot_example.end_index].strip()
                        processed_utterance.append(words_text)
                        slots_indexes.append(str(slots_dict_all[f"B-{slot_example.slot_name}"]))
                        slots_indexes.extend(
                            [str(slots_dict_all[f"I-{slot_example.slot_name}"])] * (len(words_text.split()) - 1)
                        )
                        processed_index = slot_example.end_index

                    if processed_index < len(utterance):
                        words_text = utterance[processed_index:].strip()
                        if words_text != "":
                            processed_utterance.append(words_text)
                            slots_indexes.extend([str(slots_dict_all["O"])] * len(words_text.split()))

                    outfiles[mode].write(f'{" ".join(processed_utterance)}\t {str(intents_dict[intent_name])}\n')
                    outfiles[mode + "_slots"].write(" ".join(slots_indexes) + "\n")

            outfiles[mode + "_slots"].close()
            outfiles[mode].close()

        outfiles["dict_slots"].close()
        outfiles["dict_intents"].close()
        logger.info(f"Exported Nemo dataset at {result_path}")
