# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import os
from dataclasses import dataclass, field, fields

from model_utils.model.common.task_train import TrainingTask
from model_utils.utils.path_utils import PathUtils
from model_utils.utils.validation_utils import ValidationUtils


@dataclass
class IntentSlotTraining(TrainingTask):
    """
    Train Intent Slot Classification Model
    """

    task_name: str = field(
        default="task.train.intent_slot",
        metadata={"help": "Train Intent Slot Classification Model", "suppress": True},
    )
    dataset_path: str = field(
        default=None,
        metadata={
            "help": "Directory path for Nemo format Intent Slot Classification dataset",
            "required": True,
            "validation_func": PathUtils.exists_path,
        },
    )
    # training hyperparameters
    epochs: int = field(
        default=50,
        metadata={
            "help": "Max number of epochs for training to be executed",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    lr: float = field(
        default=5e-5,
        metadata={
            "help": "Learning rate to be used for the training",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0.0, "less_than": 1.0},
        },
    )
    batch_size: int = field(
        default=32,
        metadata={
            "help": "Batch size used for the training",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    weight_decay: float = field(
        default=0.0,
        metadata={
            "help": "Weight decay to be used with optimizer during training",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_equal": 0.0, "less_equal": 1.0},
        },
    )
    pretrained_model_name: str = field(
        default="bert-base-uncased",
        metadata={
            "help": "Name of pretrained langauge model for training, recommended bert-base-uncased and distilbert-base-uncased",
            "validation_func": ValidationUtils.nonempty_value,
        },
    )
    max_seq_length: int = field(
        default=128,
        metadata={
            "help": "Maximum sequence length to be used for BERT/ DistilBERT models during training",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_than": 0},
        },
    )
    intent_loss_weight: float = field(
        default=0.6,
        metadata={
            "help": "Parameter indicating balance of training loss between intent and slot losses. Increase to give more weightage to Intent Classification, Slot classification might degrade",
            "validation_func": ValidationUtils.valid_range,
            "validation_args": {"greater_equal": 0.0, "less_equal": 1.0},
        },
    )
    num_head_output_layers: int = field(
        default=1,
        metadata={
            "help": "Number of dense layers to be used for LM classifier head",
            "choices": [1, 2],
        },
    )
    class_balancing: str = field(
        default="weighted_loss",
        metadata={
            "help": "Use weighted_loss for using class weights for training loss, Recommended for imbalanced training datasets",
            "choices": ["null", "weighted_loss"],
        },
    )

    def execute_task(self):
        """
        Start training Intent Slot model
        """
        from .intent_slot_model import IntentSlotModel

        return IntentSlotModel.train(self)
