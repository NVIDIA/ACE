# Copyright(c) 2021 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

""" ACE Agent Model Utils schema file validator
    Requires: pip3 install pykwalify==1.8.0
"""
import os
import json
import logging
from typing import Dict, Any, Text
from pykwalify.core import Core
from pykwalify.errors import SchemaError


logger = logging.getLogger("__main__." + __name__)


class SchemaValidator:

    YAML_DOMAIN_DATASET_SCHEMA = ["schemas/training_data_schema.yaml"]

    @staticmethod
    def validate_file(source_file, schema_files):
        """Method to validate yaml config files of DM"""

        try:
            c = Core(source_file, schema_files)
            c.validate(raise_exception=True)
            logger.info(f"Validation successful for yaml file {source_file}.")

        except SchemaError as error:
            raise ValueError(f"Validation failed for file {source_file} with error : {error}")

    @staticmethod
    def validate_json(source_data: Dict[Text, Any], schema_files):
        """Method to validate json input to schema defined"""

        try:
            if not isinstance(source_data, dict):
                source_data = json.loads(source_data)
            c = Core(source_data=source_data, schema_files=schema_files)
            c.validate(raise_exception=True)
        except SchemaError as e:
            raise ValueError(f"Validation failed for json {source_data}: {e}")
