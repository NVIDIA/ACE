# Copyright (c) 2021-2022, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
import os


class TRITON:
    IMAGE = "nvcr.io/nvidia/riva/riva-speech:2.14.0"
    SERVICEMAKER_IMAGE = "nvcr.io/nvidia/riva/riva-speech:2.14.0-servicemaker"
    CONTAINER_NAME = "nlp_triton"
    HTTP_PORT = "8003"
    GRPC_PORT = "8004"


# Base template for generating pipeline yaml
PIPELINE_TEMPLATE = os.path.join(os.path.dirname(os.path.realpath(__file__)), "pipeline_template.yaml")
