import os
import re
import yaml
import json
import shutil
import logging
import subprocess

from datetime import datetime
from time import sleep
from dataclasses import dataclass, field, fields

logger = logging.getLogger("__main__." + __name__)


class NGCModule:
    """
    NGC related functions
    """

    NGC_CONFIG_PATH = os.path.expanduser("~/.ngc/config")

    @staticmethod
    def set_ngc_cli_config():
        """
        Set NGC CLI Config
        """
        logger.info("############## SET NGC CONFIG ##############")
        try:
            subprocess.run(["ngc", "config", "set"], check=True, timeout=100)
        except:
            raise ValueError("Setting NGC CLI config failed")

    @staticmethod
    def get_ngc_cli_config():
        """
        Get NGC CLI Config using NGC_CONFIG_PATH
        """
        config = {}
        try:
            if not os.path.exists(NGCModule.NGC_CONFIG_PATH):
                NGCModule.set_ngc_cli_config()

            with open(NGCModule.NGC_CONFIG_PATH) as f:
                for line in f.readlines():
                    if line.startswith("apikey"):
                        config["api_key"] = line.split("=")[1].strip()
                    elif line.startswith("org"):
                        config["org"] = line.split("=")[1].strip()
                    elif line.startswith("team"):
                        config["team"] = line.split("=")[1].strip()
                    elif line.startswith("ace"):
                        config["ace"] = line.split("=")[1].strip()
        except Exception as e:
            raise ValueError(f"Unable to read NGC config with error: {e}")
        return config

    @staticmethod
    def create(config, registry_command="model"):
        """
        Create NGC model / resource with given config
        """
        ngc_model_name = config.ngc_path.split(":")[0]
        logger.info(f"Creating NGC {registry_command} at {ngc_model_name}")
        try:
            command = [
                "ngc",
                "registry",
                registry_command,
                "create",
                ngc_model_name,
                "--application",
                config.application,
                "--format",
                config.model_format,
                "--framework",
                config.framework,
                "--precision",
                config.precision,
                "--short-desc",
                config.short_desc,
            ]
            if config.publisher:
                command.extend(["--publisher", config.publisher])
            subprocess.run(command, check=True)
        except subprocess.CalledProcessError as error:
            raise ValueError(f"NGC {registry_command} creation at {ngc_model_name} failed")

    @staticmethod
    def remove_version(config, registry_command="model"):
        """
        Remove NGC model or resource version
        """
        logger.info(f"Removing existing NGC {registry_command} version {config.ngc_path}")
        try:
            if config.remove_old_version:
                subprocess.run(["ngc", "registry", registry_command, "remove", "-y", config.ngc_path], check=True)
            else:
                subprocess.run(["ngc", "registry", registry_command, "remove", config.ngc_path], check=True)
        except subprocess.CalledProcessError as error:
            raise ValueError(f"Failed to remove the existing NGC {registry_command} version {config.ngc_path}")

    @staticmethod
    def upload_model_version(config):
        """
        Upload NGC model version
        """
        try:
            logger.info(f"Uploading model at {config.ngc_path} from {config.model_path}")
            subprocess.run(
                [
                    "ngc",
                    "registry",
                    "model",
                    "upload-version",
                    config.ngc_path,
                    "--source",
                    config.model_path,
                ],
                check=True,
            )
        except subprocess.CalledProcessError as error:
            raise ValueError("Failed to upload the NGC model {} from {}".format(config.ngc_path, config.model_path))
        else:
            logger.info("Successfully uploaded model at {}".format(config.ngc_path))

    @staticmethod
    def upload_bot_version(config):
        """
        Upload NGC Bot version
        """
        try:
            logger.info(f"Uploading bot at {config.ngc_path} from {config.bot_path}")
            subprocess.run(
                [
                    "ngc",
                    "registry",
                    "resource",
                    "upload-version",
                    config.ngc_path,
                    "--source",
                    config.bot_path,
                ],
                check=True,
            )
        except subprocess.CalledProcessError as error:
            raise ValueError("Failed to upload the NGC Bot {} from {}".format(config.ngc_path, config.bot_path))
        else:
            logger.info("Successfully uploaded bot at {}".format(config.ngc_path))

    @staticmethod
    def info(ngc_path, registry_command="model"):
        """
        Get info for NGC model or resource
        """
        try:
            info_result = subprocess.check_output(
                ["ngc", "registry", registry_command, "info", "--format_type", "json", ngc_path]
            )
        except:
            raise ValueError("NGC {} path {} doesn't exist".format(registry_command, ngc_path))
        return json.loads(info_result)

    @staticmethod
    def download(config, registry_command="model"):
        """
        Download NGC model or resource at given path
        """
        logger.info(f"Downloading the NGC {registry_command} {config.ngc_path}")
        model_info_json = NGCModule.info(config.ngc_path, registry_command)
        model_name = config.ngc_path.split("/")[-1].split(":")[0]
        version = model_info_json.get("versionId", None)
        if not version and "latestVersionIdStr" in model_info_json:
            version = model_info_json["latestVersionIdStr"]
        if not model_name or not version:
            # NGC doesn't have any model version for download
            raise ValueError("Please provide valid NGC model path and version, provided {}".format(config.ngc_path))

        local_model_path = os.path.join(config.download_path, "{}_v{}".format(model_name, version))
        local_info_path = os.path.join(local_model_path, "info.json")
        # check if model already exist
        if os.path.exists(local_model_path) and os.path.exists(local_info_path):
            latest_timestamp = model_info_json.get("updatedDate", None) or model_info_json.get("createdDate", None)
            with open(local_info_path, "r") as f:
                old_info = json.load(f)
            old_timestamp = old_info.get("updatedDate", None) or old_info.get("createdDate", None)
            if latest_timestamp and old_timestamp and latest_timestamp == old_timestamp:
                logger.info("Found exisiting downloaded {} for {}".format(registry_command, config.ngc_path))
                logger.info(
                    f"Successfully downloaded the NGC {registry_command} {config.ngc_path} at {local_model_path}"
                )
                return local_model_path
            else:
                shutil.rmtree(local_model_path, ignore_errors=True)
        try:
            subprocess.run(
                [
                    "ngc",
                    "registry",
                    registry_command,
                    "download-version",
                    config.ngc_path,
                    "--dest",
                    config.download_path,
                ],
                check=True,
            )
        except:
            raise ValueError("Failed to download the NGC {} {}".format(registry_command, config.ngc_path))
        else:
            # dump info
            with open(local_info_path, "w") as f:
                json.dump(model_info_json, f, indent=4)
            logger.info(f"Successfully downloaded the NGC {registry_command} {config.ngc_path} at {local_model_path}")
            return local_model_path

    @staticmethod
    def exists_registry_path(ngc_registry_path, registry_command="model"):
        """
        Check if NGC path exists or not
        """
        try:
            subprocess.run(
                ["ngc", "registry", registry_command, "info", ngc_registry_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=True,
            )
        except:
            logger.debug("Not found NGC {} at {}".format(registry_command, ngc_registry_path))
            return False
        return True

    @staticmethod
    def upload_dataset(nemo_dataset_path):
        """
        Upload Local dataset to NGC
        """
        logger.info(f"Uploading NeMo dataset {nemo_dataset_path} to NGC.")
        timestamp_str = str(datetime.now()).replace(":", "_").replace(" ", "_").replace(".", "_")
        dataset_id = None
        try:
            proc_out = subprocess.check_output(
                [
                    "ngc",
                    "dataset",
                    "upload",
                    "--source",
                    nemo_dataset_path,
                    "--format_type",
                    "json",
                    f"ace-agent-custom-dataset-{timestamp_str}",
                ]
            )
        except Exception as e:
            raise ValueError(f"Failed to upload dataset to NGC with error : {e}")
        logger.debug(f"NGC dataset creation output : {json.loads(proc_out)}")
        return json.loads(proc_out)["transfer_id"]

    @staticmethod
    def download_results(job_id, source_path, download_path, max_wait_time=200):
        """
        Download NGC Batch Job Results.
        """
        logger.info(f"Downloading results for NGC job id : {job_id}")
        try:
            # clean tmp download path
            tmp_download_path = "/tmp"
            if os.path.exists(f"{tmp_download_path}/{job_id}"):
                shutil.rmtree(f"{tmp_download_path}/{job_id}")
            # remove existing content at download path
            if os.path.exists(download_path):
                if os.path.isfile(download_path):
                    os.remove(download_path)
                else:
                    shutil.rmtree(download_path)
            else:
                os.makedirs(os.path.dirname(download_path), exist_ok=True)
            # check if results are ready
            for _ in range(0, max_wait_time, 10):
                proc_status = subprocess.check_output(["ngc", "result", "info", str(job_id), "--format_type", "json"])
                if json.loads(proc_status)["status"] == "FETCHED":
                    break
                else:
                    logger.debug("Waiting for NGC job results to be fetched")
                    sleep(10)
            else:
                raise ValueError(f"NGC results download for job {job_id} timeout, results are not fetched yet")

            if source_path is None:
                source_path = ""
                proc = subprocess.run(
                    ["ngc", "result", "download", str(job_id), "--dest", tmp_download_path], check=True
                )
            elif "." in os.path.basename(source_path):
                proc = subprocess.run(
                    ["ngc", "result", "download", str(job_id), "--dest", tmp_download_path, "--file", source_path],
                    check=True,
                )
            else:
                proc = subprocess.run(
                    ["ngc", "result", "download", str(job_id), "--dest", tmp_download_path, "--dir", source_path],
                    check=True,
                )

            # move to expected download path
            tmp_download_path = f"{tmp_download_path}/{job_id}{source_path}"
            shutil.move(tmp_download_path, download_path)
        except Exception as e:
            raise ValueError(f"NGC result download for job id {job_id} failed with error : {e}")

    @staticmethod
    def create_ngc_batch_job(job_config):
        """
        Create NGC Job for training and evaluation tasks
        """
        logger.info("Creating NGC job ...")
        timestamp_str = str(datetime.now()).replace(":", "_").replace(" ", "_").replace(".", "_")
        dataset_command = []
        for dataset_id in job_config.dataset_mounts:
            dataset_command.extend(["--datasetid", f"{dataset_id}:{job_config.dataset_mounts[dataset_id]}"])
        ports_command = []
        for port in job_config.ports:
            ports_command.extend(["--port", str(port)])
        job_id = None
        try:
            proc_out = subprocess.check_output(
                [
                    "ngc",
                    "batch",
                    "run",
                    "--name",
                    f"ace-agent-{timestamp_str}",
                    "--image",
                    job_config.image,
                    "--instance",
                    f"dgx1v.{job_config.gpu_memory}g.{job_config.num_gpus}.norm",
                    "--result",
                    job_config.result_path,
                    *dataset_command,
                    *ports_command,
                    "--commandline",
                    job_config.command,
                    "--format_type",
                    "json",
                ]
            )
        except Exception as e:
            raise ValueError(f"NGC Batch job creation failed with error : {e}")
        logger.debug(f"NGC job creation output: {json.loads(proc_out)}")
        return json.loads(proc_out)["id"]

    @staticmethod
    def get_job_info(job_id, max_retry=3):
        """
        Check status of NGC Job
        """
        while max_retry > 0:
            try:
                proc_out = subprocess.check_output(["ngc", "batch", "info", "--format_type", "json", str(job_id)])
                return json.loads(proc_out)
            except Exception as e:
                max_retry -= 1
                if max_retry == 0:
                    raise ValueError(f"NGC Job status check failed for job id {job_id} with error {e}")
                else:
                    logger.error(f"NGC Job status check failed for job id {job_id} with error {e}")

    @staticmethod
    def get_ngc_job_logs(job_id):
        """
        Attach to NGC Job logs
        """
        logger.info(f"Getting logs for NGC job {job_id}")
        try:
            proc = subprocess.run(["ngc", "batch", "attach", str(job_id)])
        except Exception as e:
            raise ValueError(f"Unable to get NGC logs for job {job_id}")


@dataclass
class NGCJobParams:
    """
    Parameters for creating NGC job
    """

    image: str  # docker image for running job
    command: str  # command for running inside job
    gpu_memory: int = field(default="32")  # GPU memory required per instance
    num_gpus: int = field(default="1")  # number of GPUs
    dataset_mounts: dict = field(default_factory=dict)  # dict containing dataset_id and mount path as key value pair
    result_path: str = field(default="/result")  # where resulting model, logs will be saved
    ports: list = field(default_factory=list)  # list of ports to be opened
