"""
Copyright(c) 2022-2023 NVIDIA Corporation.All rights reserved.

NVIDIA Corporation and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto.Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA Corporation is strictly prohibited.
"""

import logging
import riva.client.proto.riva_nmt_pb2 as riva_nmt
import riva.client.proto.riva_nmt_pb2_grpc as riva_nmt_srv
from riva.client import Auth

from nlp_server.model.triton_model import BaseTriton
from nlp_server.api.nmt import NMTRequest, NMTResponse
from nlp_server.decorators import model_api

logger = logging.getLogger(__name__)


class RivaServer(BaseTriton):
    """
    Handles interaction with all Riva language understanding models
    """

    def __init__(self, config) -> None:
        """Initialization method of Riva Model interface"""
        super().__init__(config=config)
        self._lang = "en-US"

        self.auth = Auth(uri=config.get("riva_url")) if config.get("riva_url") else None
        # Initialize NMT client
        # `NeuralMachineTranslationClient` is for sending translate requests.
        self.riva_nmt_stub = riva_nmt_srv.RivaTranslationStub(self.auth.channel) if self.auth else None

    # -----------------------------------------------------------------
    # Helper methods for raw inference on different skills model
    # -----------------------------------------------------------------
    def list_nmt_models(self):
        """
        List all available NMT models for model registration
        """
        if not self.riva_nmt_stub:
            return []
        else:
            req = riva_nmt.AvailableLanguageRequest()
            response = self.riva_nmt_stub.ListSupportedLanguagePairs(req, metadata=self.auth.get_auth_metadata())
        return [model for model in response.languages]

    @model_api(endpoint="/nmt/translate", model_name=[], model_list_func="list_nmt_models")
    def nmt_infer(self, request: NMTRequest) -> NMTResponse:
        """
        Model Client for Riva NMT Models
        """
        req = riva_nmt.TranslateTextRequest(
            texts=request.texts,
            model=request.model_name,
            source_language=request.source_language,
            target_language=request.target_language,
        )

        response = self.riva_nmt_stub.TranslateText(req, metadata=self.auth.get_auth_metadata())

        # response.translations is a list of all translations - Each entry corresponds to the
        # corresponding entry in the texts attribute of TranslateTextRequest (nmt_request.texts) from above.
        return NMTResponse(translated_texts=[response.translations[0].text for i in range(len(request.texts))])
