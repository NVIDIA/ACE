"""
Copyright(c) 2022-2023 NVIDIA Corporation.All rights reserved.

NVIDIA Corporation and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto.Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA Corporation is strictly prohibited.
"""

import logging
import asyncio
import numpy as np
from fnmatch import fnmatch
from typing import List, Any, Dict
from string import punctuation
import tritonclient.grpc.aio
from tritonclient.utils import InferenceServerException

from nlp_server.constants import (
    QNA_CONTEXT_LEN,
    STRIDE_WORD_COUNT,
    NLP_RIVA_SERVER_TIMEOUT,
    NLP_RIVA_QA_SERVER_TIMEOUT,
    NLP_TRITON_SIMCSE_SERVER_TIMEOUT,
)
from nlp_server.model.nlp_utils import (
    find_spans,
    combine_adjacent_slots,
    restore_slots_case,
    postprocess_qa_response,
    convert_iob,
)
from nlp_server.model.model_server import ModelServer
from nlp_server.decorators import model_api
from nlp_server.api.embedding import EmbeddingRequest, EmbeddingResponse
from nlp_server.model.nlp_response import (
    AnalyzeIntentResponse,
    Classification,
    NaturalQueryResponse,
    TokenClassValue,
    TokenClassResponse,
)
from nlp_server.api.intent_slot import IntentSlotRequest
from nlp_server.api.ner import NERRequest
from nlp_server.api.extractive_qa import ExtractiveQARequest
from nlp_server.api.text_classification import TextClassificationRequest

logger = logging.getLogger(__name__)


class BaseTriton(ModelServer):
    def __init__(self, config):
        super().__init__(config=config)
        self.http_url = config.get("http_url", "")

        if not self.url:
            raise ValueError("Triton GRPC URL is mandatory for Triton models")

        try:
            self._client = tritonclient.grpc.aio.InferenceServerClient(url=self.url, verbose=False)
            logger.info(f"Initialized Triton GRPC Stub interface at: {self.url}")
        except Exception as e:
            raise ValueError(f"Could not initialize Triton Stub interface at: {self.url}. Error: {e}")

    async def list_models(self):
        """
        List all available models in Triton Server
        """
        resp = await self._client.get_model_repository_index(as_json=True)
        return resp["models"]

    async def is_ready(self):
        """
        Check if Triton Server is up
        """
        return await self._client.is_server_ready()

    async def get_model_config(self, model_name, model_version=""):
        """
        Get config for Model
        """
        resp = await self._client.get_model_config(model_name, model_version, as_json=True)
        return resp["config"]

    async def is_model_ready(self, model_name, model_version=""):
        """
        Check if model is ready
        """
        return await self._client.is_model_ready(model_name=model_name, model_version=model_version)


class TritonServer(BaseTriton):
    """
    Handles interaction with all Triton models
    """

    def __init__(self, config) -> None:
        """Initialization method of Triton Model interface"""
        super().__init__(config=config)

        self._lang = "en-US"

    # -----------------------------------------------------------------
    # Helper methods for raw inference on different TRITON GRPC model
    # -----------------------------------------------------------------
    @model_api(endpoint="/nlp/model/generate_embedding", model_name=["simcse-bert-base"])
    async def get_simcse_embeddings(self, request: EmbeddingRequest) -> EmbeddingResponse:
        """
        Generate Embedding using simcse model
        """
        model_config = await self.get_model_config(model_name=self.get_simcse_embeddings.model_info.model_name)
        max_batch_size = model_config["max_batch_size"]

        if len(request.queries) == 0:
            return EmbeddingResponse()

        embeddings_batches = []
        for index in range(0, len(request.queries), max_batch_size):
            batch_embedding = await self.__calculate_embeddings_for_batch(
                request.queries[index : index + max_batch_size], self.get_simcse_embeddings.model_info.model_name
            )
            embeddings_batches.append(batch_embedding)
        embeddings = np.concatenate(embeddings_batches, axis=0)
        embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
        return EmbeddingResponse(queries=request.queries, embeddings=embeddings.tolist())

    @model_api(
        endpoint="/nlp/model/joint_intent_slot", model_name=["riva_text_classification_domain", "riva_intent_.*"]
    )
    async def get_intent_slot(self, request: IntentSlotRequest) -> "AnalyzeIntentResponse":
        """
        Take nlu_req dict as argument and returns nlu_result dict
        nlu_req contains query, previousIntent, previousDomain
        nlu_resp in case of failure return none domain
        """

        # Avoid passing empty query to intent slot server
        if len(request.query) == 0:
            logger.warning(f"Empty queries received for intent/slot inference")
            return AnalyzeIntentResponse()

        resp = AnalyzeIntentResponse()

        try:
            if self.get_intent_slot.model_info.model_name == "riva_text_classification_domain":

                input_str = np.array([[request.query.lower()]]).astype(object)

                input0 = tritonclient.grpc.aio.InferInput("CLASSIFY_STR_IN__0", input_str.shape, "BYTES")
                input0.set_data_from_numpy(input_str)
                output0 = tritonclient.grpc.aio.InferRequestedOutput(name="CLASSIFY_SEQ_CLS_OUT__0", class_count=1)
                response = await self._client.infer(
                    model_name=self.get_intent_slot.model_info.model_name,
                    inputs=[input0],
                    outputs=[output0],
                    client_timeout=NLP_RIVA_SERVER_TIMEOUT,
                )
                domain_response = response.as_numpy("CLASSIFY_SEQ_CLS_OUT__0")[0][0].decode().split(":")
                domain = domain_response[2]
                resp.domain = Classification(class_name=domain_response[2], score=float(domain_response[0]))
            else:
                # model format riva_intent_{domain}
                domain = self.get_intent_slot.model_info.model_name[12:]
                resp.domain = Classification(class_name=domain, score=1.0)

            intent_slot_model_name = f"riva_intent_{domain}"

            input_str = np.array([[request.query.lower()]]).astype(object)

            input0 = tritonclient.grpc.aio.InferInput("CLASSIFY_STR_IN__0", input_str.shape, "BYTES")
            input0.set_data_from_numpy(input_str)
            output0 = tritonclient.grpc.aio.InferRequestedOutput(name="CLASSIFY_SEQ_CLS_OUT__0", class_count=1)
            output1 = tritonclient.grpc.aio.InferRequestedOutput(name="CLASSIFY_TOK_CLS_OUT__1")
            output2 = tritonclient.grpc.aio.InferRequestedOutput(name="CLASSIFY_TOK_SEQ_LEN__2")
            output3 = tritonclient.grpc.aio.InferRequestedOutput(name="CLASSIFY_TOK_TOK_STR__3")
            output4 = tritonclient.grpc.aio.InferRequestedOutput(name="CLASSIFY_TOK_CLS_SCR__4")

            response = await self._client.infer(
                model_name=intent_slot_model_name,
                inputs=[input0],
                outputs=[output0, output1, output2, output3, output4],
                client_timeout=NLP_RIVA_SERVER_TIMEOUT,
            )

            intent_response = response.as_numpy("CLASSIFY_SEQ_CLS_OUT__0")[0][0].decode().split(":")
            resp.intent = Classification(class_name=intent_response[2], score=float(intent_response[0]))
            seq_len = int(response.as_numpy("CLASSIFY_TOK_SEQ_LEN__2")[0][0])
            tags = [tag.decode() for tag in response.as_numpy("CLASSIFY_TOK_CLS_OUT__1")[0][:seq_len]]
            tokens = [token.decode() for token in response.as_numpy("CLASSIFY_TOK_TOK_STR__3")[0][:seq_len]]
            scores = [float(score) for score in response.as_numpy("CLASSIFY_TOK_CLS_SCR__4")[0][:seq_len]]
            resp.entities = convert_iob(tokens, scores, tags)

        except InferenceServerException as e:
            status_details = e.message()

            # HACK:
            # 1. Suppress error when intent model is not found for the domain detected by domain classifier.
            # 2. Get the domain name from the returned error message
            # 3. Set domain and intent name same as domain name in such a case
            if fnmatch(status_details, "Request for unknown model: 'riva_intent_*' is not found"):
                extracted_domain_name = (
                    [word for word in status_details.split() if fnmatch(word, "'riva_intent_*'")][0]
                    .replace("'riva_intent_", "")
                    .rstrip("'")
                )

                if extracted_domain_name != "":
                    logger.debug(
                        f"No intent model detected for domain label: {extracted_domain_name}. Setting domain and intent name same.."
                    )
                    return AnalyzeIntentResponse(
                        domain=Classification(class_name=extracted_domain_name, score=1.0),
                        intent=Classification(class_name=extracted_domain_name, score=1.0),
                    )
                else:
                    logger.error(
                        f"Error during GRPC call to intent slot model with domain: {domain}. "
                        f"Message: {status_details}"
                    )
            else:
                logger.error(
                    f"Error during GRPC call to intent slot model with domain: {domain}. " f"Message: {status_details}"
                )

        except Exception as e:
            logger.error(f"Failed to get intent due to error {e}")
            return AnalyzeIntentResponse()
        else:
            # HACK: Set intent name and confidence score same as domain when intent name is absent
            if resp.intent.class_name == "":
                logger.debug("Setting intent name same as domain name")
                resp.intent.class_name = resp.domain.class_name
                resp.intent.score = resp.domain.score

            # HACK : Avoid detecting underscore as a slot
            for slot in list(resp.entities):
                if slot.token not in request.query.lower():
                    resp.entities.remove(slot)

            # HACK : combine like slots to avoid incorrect
            #        detection by fulfillment
            combine_adjacent_slots(resp.entities, request.query.lower())
            restore_slots_case(resp.entities, request.query)

            # Form spans for all returned slots using span_finder util
            slots_with_span = []
            unique_tokens = set()
            for slot in resp.entities:
                if slot.token in unique_tokens:
                    continue
                unique_tokens.add(slot.token)

                for span in find_spans(request.query, slot.token):
                    slots_with_span.append(
                        TokenClassValue(
                            token=slot.token,
                            span=span,
                            label=Classification(class_name=slot.label.class_name, score=slot.label.score),
                        )
                    )

            return AnalyzeIntentResponse(
                domain=Classification(class_name=resp.domain.class_name, score=resp.domain.score),
                intent=Classification(class_name=resp.intent.class_name.lower(), score=resp.intent.score),
                entities=TokenClassResponse(entities=slots_with_span),
            )

    @model_api(endpoint="/nlp/model/ner", model_name="riva_ner")
    async def get_ner(self, request: NERRequest) -> "TokenClassResponse":
        """
        Method which can be called to request execution of any of the NLU
        modules.
        """

        # Avoid passing empty query to ner server
        if len(request.query) == 0:
            logger.warning(f"Empty query received at ner endpoint")
            return TokenClassResponse()
        try:
            texts = [[request.query.lower()]]
            input_str = np.array(texts).astype(object)

            input0 = tritonclient.grpc.aio.InferInput("CLASSIFY_STR_IN__0", input_str.shape, "BYTES")
            input0.set_data_from_numpy(input_str)
            output0 = tritonclient.grpc.aio.InferRequestedOutput(name="CLASSIFY_TOK_CLS_OUT__1")
            output1 = tritonclient.grpc.aio.InferRequestedOutput(name="CLASSIFY_TOK_SEQ_LEN__2")
            output2 = tritonclient.grpc.aio.InferRequestedOutput(name="CLASSIFY_TOK_TOK_STR__3")
            output3 = tritonclient.grpc.aio.InferRequestedOutput(name="CLASSIFY_TOK_CLS_SCR__4")
            response = await self._client.infer(
                model_name=self.get_ner.model_info.model_name,
                model_version=self.get_ner.model_info.model_version,
                inputs=[input0],
                outputs=[output0, output1, output2, output3],
                client_timeout=NLP_RIVA_SERVER_TIMEOUT,
            )
            seq_len = int(response.as_numpy("CLASSIFY_TOK_SEQ_LEN__2")[0][0])
            tags = [tag.decode() for tag in response.as_numpy("CLASSIFY_TOK_CLS_OUT__1")[0][:seq_len]]
            tokens = [token.decode() for token in response.as_numpy("CLASSIFY_TOK_TOK_STR__3")[0][:seq_len]]
            scores = [float(score) for score in response.as_numpy("CLASSIFY_TOK_CLS_SCR__4")[0][:seq_len]]
            entities = convert_iob(tokens, scores, tags)

        except Exception as e:
            logger.error(f"Failed to get NER slots due to error {e}")
            return TokenClassResponse()
        else:
            # # HACK : combine like slots to avoid incorrect
            # #        detection by fulfillment
            combine_adjacent_slots(entities, request.query.lower())

            restore_slots_case(entities, request.query)

            # Form spans for all returned slots using span_finder util
            slots_with_span = []
            unique_tokens = set()
            for slot in entities:
                if slot.token in unique_tokens:
                    continue
                unique_tokens.add(slot.token)

                for span in find_spans(request.query, slot.token):
                    slots_with_span.append(
                        TokenClassValue(
                            token=slot.token,
                            span=span,
                            label=Classification(class_name=slot.label.class_name, score=slot.label.score),
                        )
                    )

            return TokenClassResponse(entities=slots_with_span)

    @model_api(endpoint="/nlp/model/text_classification", model_name="riva_text_classification_.*")
    async def get_text_classification(self, request: TextClassificationRequest) -> "Classification":
        """
        Pass the query through the text classifier model, and return the output.
        """

        # Avoid passing empty query to Toxicity classifier
        if len(request.query) == 0:
            logger.warning(f"Empty query received for text classification inference")
            return Classification("", 0.0)

        texts = [[request.query.lower()]]
        input_str = np.array(texts).astype(object)

        input0 = tritonclient.grpc.aio.InferInput("CLASSIFY_STR_IN__0", input_str.shape, "BYTES")
        input0.set_data_from_numpy(input_str)
        output0 = tritonclient.grpc.aio.InferRequestedOutput(name="CLASSIFY_SEQ_CLS_OUT__0", class_count=1)

        try:
            response = await self._client.infer(
                model_name=self.get_text_classification.model_info.model_name,
                model_version=self.get_text_classification.model_info.model_version,
                inputs=[input0],
                outputs=[output0],
                client_timeout=NLP_RIVA_SERVER_TIMEOUT,
            )
            response = response.as_numpy("CLASSIFY_SEQ_CLS_OUT__0")[0][0].decode().split(":")
            logger.debug(f"Query: {request.query} was classified as {response[2]}")
            return Classification(class_name=response[2], score=float(response[0]))
        except Exception as e:
            logger.error(f"GRPC call to text classification model with query: {request.query} failed with error: {e}")
        return Classification("", 0.0)

    @model_api(endpoint="/nlp/model/extractive_qa", model_name="riva_qa")
    async def get_eqa_result(self, request: ExtractiveQARequest) -> NaturalQueryResponse:
        """
        process query for qna module and return top 1 response
        with score
        """

        document = "\n".join(request.documents)

        if not document:
            logger.error(f"Failed to get QA response. Context is empty")
            return NaturalQueryResponse([])

        if document.strip().startswith("0XFFF9-0XFFF9"):
            pattern = "0XFFF9-0XFFF9"
            documents = list(filter(None, document.split(pattern)))
        else:
            documents = self._get_documents(document)
        all_results = await self._get_qa_answer(
            request.query, documents, self.get_eqa_result.model_info.model_name, request.top_n
        )
        if all_results:
            mystring = all_results[0]["answer"].strip(punctuation)
            all_results[0]["answer"] = mystring
            return NaturalQueryResponse([all_results[0]])
        return NaturalQueryResponse([])

    # ----------------------------------------
    # Helper methods for qna skills model
    # -----------------------------------------

    def _get_documents(self, document):
        document = document.split()
        return [" ".join(document[i : i + QNA_CONTEXT_LEN]) for i in range(0, len(document), STRIDE_WORD_COUNT)]

    async def __send_qa_request(self, query: str, context: str, top_n: int, model_name: str):
        try:
            query = [[query]]
            query_str = np.array(query).astype(object)
            passage = [[context]]
            passage_str = np.array(passage).astype(object)

            input0 = tritonclient.grpc.aio.InferInput("IN_QUERY_STR__0", query_str.shape, "BYTES")
            input0.set_data_from_numpy(query_str)
            input1 = tritonclient.grpc.aio.InferInput("IN_PASSAGE_STR__1", passage_str.shape, "BYTES")
            input1.set_data_from_numpy(passage_str)

            output0 = tritonclient.grpc.aio.InferRequestedOutput(name="ANSWER_SPANS__0")
            output1 = tritonclient.grpc.aio.InferRequestedOutput(name="ANSWER_SCORES__1")

            response = await self._client.infer(
                model_name=model_name,
                inputs=[input0, input1],
                outputs=[output0, output1],
                client_timeout=NLP_RIVA_QA_SERVER_TIMEOUT,
            )
            spans = response.as_numpy("ANSWER_SPANS__0")[0][:top_n]
            scores = response.as_numpy("ANSWER_SCORES__1")[0][:top_n]
            resp = []
            for i in range(len(spans)):
                resp.append({"answer": spans[i].decode(), "score": float(scores[i])})
        except Exception as e:
            logger.warning(f"Unable to get qna response due to exception {e}")
            return None
        return resp

    async def _get_qa_answer(
        self, query: str, document: List[str], model_name: str, top_n: int
    ) -> List[Dict[str, Any]]:
        """
        Takes query and document list as input and return list of
        possible answers with score
        Input:
            query: What is your name?
            document: ["My name is Misty", "I like rain."]
        Output:
            [{'answer': 'Misty', 'score': 0.675097}]
        """
        if not len(document):
            return None

        # Avoid passing empty query to qna server
        if len(query) == 0:
            logger.warning(f"Empty queries received at qna endpoint")
            return None

        result = []
        responses = await asyncio.gather(
            *[self.__send_qa_request(query, doc, top_n, model_name) for doc in document],
            return_exceptions=True,
        )
        for resp in responses:
            nqa_response_list = resp
            # Hack: Remove newline from response
            postprocess_qa_response(nqa_response_list)
            if (
                len(nqa_response_list)
                and "answer" in nqa_response_list[0]
                and nqa_response_list[0]["answer"] != None
                and "score" in nqa_response_list[0]
            ):
                result.append(nqa_response_list[0])
        if len(result):
            result = sorted(result, key=lambda kv: kv["score"], reverse=True)
            return result
        return None

    # -----------------------------------------
    # Helper methods for simCSE triton model
    # -----------------------------------------

    async def __calculate_embeddings_for_batch(self, queries: List[str], model_name: str) -> np.ndarray:
        """
        Encode tags associated with a slot lookup into embeddings and update the dict.
        """

        if len(queries) == 0:
            return []

        input_str = np.array(queries, dtype=np.object_)
        input_str = np.expand_dims(input_str, axis=1)

        input0 = tritonclient.grpc.aio.InferInput("CLASSIFY_STR_IN__0", input_str.shape, "BYTES")
        input0.set_data_from_numpy(input_str)
        output0 = tritonclient.grpc.aio.InferRequestedOutput("EMBEDDINGS_SEQ_OUT__0")
        try:
            response = await self._client.infer(
                model_name=model_name,
                inputs=[input0],
                outputs=[output0],
                client_timeout=NLP_TRITON_SIMCSE_SERVER_TIMEOUT,
            )

            embeddings = response.as_numpy("EMBEDDINGS_SEQ_OUT__0")

        except Exception as e:
            logger.warning(f"Something went wrong while calculating embeddings using {model_name} model. Error: {e}")
            raise ValueError(f"Something went wrong while calculating embeddings using {model_name} model")

        return embeddings
