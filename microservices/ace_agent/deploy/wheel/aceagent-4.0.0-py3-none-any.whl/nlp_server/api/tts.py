from dataclasses import dataclass
from fastapi import APIRouter, HTTPException

from nlp_server.core.model_manager import ModelManager
from nlp_server.core.model_registry import ModelRegistry

router = APIRouter()


@dataclass
class TTSRequest:
    """
    Text to Speech request parameters
    """

    text: str
    voice_name: str
    model_name: str = ""
    model_version: str = ""
    language_code: str = "en-US"
    sample_rate_hz: int = 44100


@router.post("/speech/text_to_speech", tags=["Speech APIs"])
async def text_to_speech(input_request: TTSRequest):
    """
    Text to Speech API
    """
    models_list = ModelRegistry.get_instance().query_models(
        endpoint="/speech/text_to_speech",
        model_name=input_request.model_name,
        model_version=input_request.model_version,
    )
    if len(models_list) == 0:
        raise HTTPException(
            status_code=404,
            detail="No model available for the request, Unable to execute request",
        )
    elif len(models_list) > 1:
        raise HTTPException(
            status_code=422,
            detail="Multiple models available for the request, Unable to execute request",
        )
    model_info = models_list[0]
    return await ModelManager.execute_model_api(model_info, input_request)
