# copyright(c) 2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import logging
from fastapi import APIRouter, HTTPException

from nlp_server.core.model_manager import ModelManager
from nlp_server.core.model_registry import ModelRegistry

logger = logging.getLogger(__name__)

router = APIRouter()

# Model Registry routes
@router.get("/model/is_ready", tags=["Registry APIs"])
async def is_model_ready(model_name: str, endpoint: str, model_version: str = None):
    """
    Check status of model in Model Registry
    """
    models_list = ModelRegistry.get_instance().query_models(
        endpoint=endpoint, model_name=model_name, model_version=model_version
    )
    if len(models_list) > 1:
        raise HTTPException(
            status_code=422, detail="Multiple models available for the request, Unable to execute request"
        )
    try:
        if len(models_list) == 1 and await ModelManager.is_ready_model_api(model_info=models_list[0]):
            return "Success"
    except Exception as e:
        logger.error(f"Readiness Check for model {model_name} for endpoint {endpoint} failed with error: {e}")
    return "Failure"


# Model Registry routes
@router.get("/model/list_models", tags=["Registry APIs"])
async def list_models():
    """
    List all models in Model Registry
    """
    return ModelRegistry.get_instance().list_models()
