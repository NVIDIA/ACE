# copyright(c) 2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import logging
from fastapi import APIRouter, HTTPException
from typing import List
from dataclasses import dataclass, field

from nlp_server.core.model_manager import ModelManager
from nlp_server.core.model_registry import ModelRegistry

logger = logging.getLogger(__name__)

router = APIRouter()


@dataclass
class EmbeddingRequest:
    queries: List[str]
    model_name: str = None
    model_version: str = None


@dataclass
class EmbeddingResponse:
    """Embedding response containing queries and embeddings"""

    queries: List[str] = field(default_factory=lambda: [])
    embeddings: List[List[float]] = field(default_factory=lambda: [])


@router.post("/nlp/model/generate_embedding", tags=["Model APIs"], response_model=EmbeddingResponse)
async def process_embeddings(input_request: EmbeddingRequest) -> EmbeddingResponse:
    """
    Embedding Model API
    """
    models_list = ModelRegistry.get_instance().query_models(
        endpoint="/nlp/model/generate_embedding",
        model_name=input_request.model_name,
        model_version=input_request.model_version,
    )
    if len(models_list) == 0:
        raise HTTPException(status_code=404, detail="No model available for the request, Unable to execute request")
    elif len(models_list) > 1:
        raise HTTPException(
            status_code=422, detail="Multiple models available for the request, Unable to execute request"
        )
    model_info = models_list[0]
    return await ModelManager.execute_model_api(model_info, input_request)
