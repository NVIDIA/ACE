# copyright(c) 2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import logging
from fastapi import APIRouter, HTTPException
from dataclasses import dataclass
from typing import List

from nlp_server.core.model_manager import ModelManager
from nlp_server.core.model_registry import ModelRegistry
from nlp_server.model.nlp_response import NaturalQueryResponse

logger = logging.getLogger(__name__)

router = APIRouter()


@dataclass
class ExtractiveQARequest:
    query: str
    documents: List[str]
    top_n: int
    model_name: str = None
    model_version: str = None


@router.post("/nlp/model/extractive_qa", tags=["Model APIs"], response_model=NaturalQueryResponse)
async def process_eqa(input_request: ExtractiveQARequest) -> NaturalQueryResponse:
    """
    Extractive QA Model API
    """
    models_list = ModelRegistry.get_instance().query_models(
        endpoint="/nlp/model/extractive_qa",
        model_name=input_request.model_name,
        model_version=input_request.model_version,
    )
    if len(models_list) == 0:
        raise HTTPException(status_code=404, detail="No model available for the request, Unable to execute request")
    elif len(models_list) > 1:
        raise HTTPException(
            status_code=422, detail="Multiple models available for the request, Unable to execute request"
        )
    model_info = models_list[0]
    return await ModelManager.execute_model_api(model_info, input_request)
