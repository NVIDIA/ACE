# copyright(c) 2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.
import logging
from typing import Dict, List
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class ModelInfo:
    """
    Dataclass for Model Information
    """

    model_name: str  # Model Name
    endpoint: str  # NLP Server Endpoint
    task_name: str  # NLP Server Task description
    model_version: str  # Model Version
    model_type: str  # Model Type
    url: str  # Model Server URL
    func: object  # Function for Model inference
    func_ready: object  # Function for checking model readiness state
    parameters: Dict  # Model parameters


class ModelRegistry:
    """
    Model Registry which maintains list of available models for NLP Server
    """

    __instance = None

    @staticmethod
    def get_instance():
        if ModelRegistry.__instance is None:
            raise Exception('You must call create_instance before calling "get_instance" of Model Registry')
        return ModelRegistry.__instance

    @staticmethod
    def create_instance():
        if ModelRegistry.__instance is None:
            ModelRegistry()
        else:
            raise Exception(
                "An instance has already been created. Creation of "
                "second instance of singleton class Model Registry is "
                "not allowed"
            )
        return ModelRegistry.get_instance()

    def __init__(self) -> None:
        """Initialization method of ModelRegistry"""

        if ModelRegistry.__instance is not None:
            raise Exception(
                "ModelRegistry is a singleton class. Use get_instance to get access to the ModelRegistry object"
            )
        else:
            ModelRegistry.__instance = self
            self.model_instances = []

    def register_model_info(self, model_info: ModelInfo):
        """
        Check if given model is not already register and update the registry with model info
        """
        found_model_info = False
        for model_instance in self.model_instances:
            if (
                model_instance.endpoint == model_info.endpoint
                and model_instance.model_name == model_info.model_name
                and model_instance.model_version == model_info.model_version
            ):
                logger.warning(
                    f"Found existing model in registry with endpoint {model_info.endpoint}, model_name {model_info.model_name}, version {model_info.model_version}"
                )
                found_model_info = True
                continue

        if not found_model_info:
            self.model_instances.append(model_info)
            logger.info(
                f"Successfully registered model in registry with endpoint {model_info.endpoint}, model_name {model_info.model_name}, version {model_info.model_version}"
            )

    def query_models(self, endpoint: str, model_name: str = None, model_version: str = None) -> List[ModelInfo]:
        """
        Query model registry for models with given endpoint and model info
        """
        instance_list = []
        for model_instance in self.model_instances:
            if (
                model_instance.endpoint == endpoint.strip()
                and (model_name is None or model_name == "" or model_instance.model_name == model_name.strip())
                and (
                    model_version is None
                    or model_version == ""
                    or model_instance.model_version == model_version.strip()
                )
            ):
                instance_list.append(model_instance)
        return instance_list

    def list_models(self):
        """
        List all available models
        """
        model_list = []
        for instance in self.model_instances:
            model_list.append(
                {
                    "endpoint": instance.endpoint,
                    "task_name": instance.task_name,
                    "model_name": instance.model_name,
                    "model_version": instance.model_version,
                    "model_type": instance.model_type,
                    "url": instance.url,
                    "parameters": instance.parameters,
                }
            )
        return model_list
