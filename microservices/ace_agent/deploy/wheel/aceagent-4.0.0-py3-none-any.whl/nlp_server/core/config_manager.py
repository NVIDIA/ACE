"""
copyright(c) 2023 NVIDIA Corporation.All rights reserved.

NVIDIA Corporation and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto.Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA Corporation is strictly prohibited.
"""


import os
import yaml
import logging
import importlib
import inspect
from fastapi import APIRouter

from nlp_server.decorators import DecoratorUtils
from nlp_server.core.model_registry import ModelInfo, ModelRegistry
from nlp_server.model.triton_model import TritonServer
from nlp_server.schemas.validator import SchemaValidator
from nlp_server.model.riva_nlu import RivaServer
from nlp_server.constants import (
    TRITON_MODEL,
    RIVA_MODEL,
    CUSTOM_MODEL,
    EMBEDDING_SEARCH_MODEL,
    PytritonConfig,
)

logger = logging.getLogger(__name__)


class ConfigManager:
    def __init__(self, app):
        self.app = app
        self.custom_model_paths = []
        self.data_stores_config = {}

        self.model_server_configs = []
        self.model_server_instances = []

        # Get User config
        config_path = os.getenv("CONFIG_PATH", default=None)
        custom_model_dir = os.getenv("CUSTOM_MODEL_DIR", default=None)

        if config_path and os.path.exists(config_path):
            self.__parse_model_config(config_path)
        elif config_path:
            logger.warning(f"NLP server invalid model config path {config_path}")
        if custom_model_dir and os.path.exists(custom_model_dir):
            self.custom_model_paths.append(custom_model_dir)
        elif custom_model_dir:
            logger.warning(f"NLP server invalid custom model directory {custom_model_dir}")

        # Pytriton Config
        self.triton = None
        # Pytriton Model Server Config
        self.model_server_configs.append(
            {
                "name": TRITON_MODEL,
                "url": f"localhost:{PytritonConfig.GRPC_PORT}",
                "http_url": f"http://localhost:{PytritonConfig.HTTP_PORT}",
            }
        )

    def __parse_model_config(self, config_path):
        """
        Register models for NLP Server
        """
        try:
            SchemaValidator.validate_file(config_path, SchemaValidator.NLP_SERVER_CONFIG_SCHEMA)
            with open(config_path, "r") as f:
                config = yaml.load(f, Loader=yaml.SafeLoader)
        except Exception as e:
            raise ValueError(f"Parsing failed for nlp server config yaml {config_path} with error : {e} ")
        for model_server in config.get("model_servers", []):
            if model_server["name"] == CUSTOM_MODEL:
                for path in model_server.get("nlp_models", []):
                    if not os.path.exists(os.path.join(os.path.dirname(config_path), path)):
                        raise ValueError(f"Invalid custom model path {path}")
                    self.custom_model_paths.append(os.path.join(os.path.dirname(config_path), path))
            elif model_server["name"] in [RIVA_MODEL, TRITON_MODEL]:
                self.model_server_configs.append(model_server)
            else:
                raise ValueError(f"Model Server type {model_server['name']} not supported")

    def initialize_pytriton(self):
        """
        Run all @pytriton functions
        """
        try:
            from pytriton.triton import Triton, TritonConfig
        except:
            logger.warning("nvidia-pytriton not installed, @pytriton decorated functions will be skipped")
            return
        self.triton = Triton(
            config=TritonConfig(
                http_port=PytritonConfig.HTTP_PORT,
                grpc_port=PytritonConfig.GRPC_PORT,
                metrics_port=PytritonConfig.METRICS_PORT,
            )
        )
        models_count = 0
        for path in self.custom_model_paths:
            if os.path.isfile(path) and path.endswith(".py"):
                pytriton_funcs = DecoratorUtils._load_clients_from_module(path, decorator_name="pytriton")
            elif os.path.isdir(path):
                pytriton_funcs = DecoratorUtils._find_clients(path, decorator_name="pytriton")
            else:
                raise ValueError(f"Invalid path {path} for registering @pytriton functions")
            for pytrion_func in pytriton_funcs:
                try:
                    pytrion_func(self.triton)
                    models_count += 1
                except:
                    logger.error(f"Failed to serve pytriton model {pytrion_func.__name__} from path {path}")

        # start the triton server
        if models_count > 0:
            logger.info("Serving Pytriton Models ...")
            self.triton.run()
        else:
            self.stop_pytriton()

    def stop_pytriton(self):
        """
        Stop Pytriton Server
        """
        if self.triton:
            logger.info("Stopping Pytriton Server ...")
            self.triton.stop()
            self.triton = None

    async def initalize_model_servers(self):
        """
        Register models using model servers
        """
        for server_config in self.model_server_configs:
            if server_config["name"] == TRITON_MODEL:
                try:
                    server = TritonServer(config=server_config)
                    await server.initalize_server()
                    self.model_server_instances.append(server)
                except Exception as e:
                    logger.error(
                        f"Model Server {server_config['name']} with url {server_config['url']} initialization failed with error {e}"
                    )
            elif server_config["name"] == RIVA_MODEL:
                try:
                    server = RivaServer(config=server_config)
                    await server.initalize_server()
                    self.model_server_instances.append(server)
                except Exception as e:
                    logger.error(
                        f"Model Server {server_config['name']} with url {server_config['url']} initialization failed with error {e}"
                    )

        # Running Custom models
        for path in self.custom_model_paths:
            self.__register_custom_api(path, self.app)
            await self.__register_custom_model_apis(path)

    def __register_custom_api(self, path: str, app):
        """
        Register custom API with FastAPI app
        """
        custom_modules = []
        if not os.path.exists(path) or (os.path.isfile(path) and not path.endswith(".py")):
            raise ValueError(f"Invalid path {path} for Custom NLP APIs")
        elif os.path.isdir(path):
            # Loop through all files in the directory and its subdirectories
            for root, dirs, files in os.walk(path):
                for filename in files:
                    if filename.endswith(".py"):
                        custom_modules.append(os.path.join(root, filename))
        else:
            custom_modules.append(path)

        for filepath in custom_modules:
            try:
                spec = importlib.util.spec_from_file_location(os.path.basename(filepath), filepath)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                for name, obj in inspect.getmembers(module):
                    if not name.startswith("__") and isinstance(obj, APIRouter):
                        app.include_router(obj, prefix="/custom", tags=["Custom APIs"])
            except Exception as e:
                logger.error(f"Unable to register custom apis from module {filepath} due to exception {e}")

    async def __register_custom_model_apis(self, path: str):
        """
        Registering model clients with @model_api decorated functions
        """
        if os.path.isfile(path) and path.endswith(".py"):
            model_api_funcs = DecoratorUtils._load_clients_from_module(path, decorator_name="model_api")
        elif os.path.isdir(path):
            model_api_funcs = DecoratorUtils._find_clients(path, decorator_name="model_api")
        else:
            raise ValueError(f"Invalid path {path} for registering the model apis")

        for model_func in model_api_funcs:
            for model_name in model_func.api_meta["model_name"]:
                if model_func.api_meta["model_type"] in [TRITON_MODEL, RIVA_MODEL]:
                    registered = False
                    for model_server in self.model_server_instances:
                        if model_server.name == model_func.api_meta["model_type"]:
                            registered = await model_server.register_model_api(model_func)
                        if registered:
                            break
                    if not registered:
                        logger.warning(
                            f"Skipping registration of @model_api {model_func.__name__} as model {model_func.api_meta['model_name']} with type {model_func.api_meta['model_type']} not found"
                        )
                else:
                    ModelRegistry.get_instance().register_model_info(
                        ModelInfo(
                            model_name=model_name,
                            endpoint=model_func.api_meta["endpoint"],
                            task_name=model_func.api_meta["task_name"],
                            model_version=model_func.api_meta["model_version"],
                            model_type=model_func.api_meta["model_type"],
                            url="",
                            parameters=model_func.api_meta.get("parameters", {}),
                            func=model_func,
                            func_ready=None,
                        )
                    )
