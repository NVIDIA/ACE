# copyright(c) 2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.


import os
import inspect
import logging
import importlib.util
from typing import Dict, Optional, List, Union
from nlp_server.constants import ENDPOINT_TASK_MAPPING

logger = logging.getLogger(__name__)

# A decorator that sets a property on the function to indicate if it's a model client or not.
def model_api(
    endpoint: str,
    model_name: Union[str, List[str]],
    model_list_func: object = None,
    model_type: Optional[str] = "custom",
    model_version: Optional[str] = "",
    parameters: Optional[Dict] = {},
):
    """
    Decorator for registering model api clients
    """

    def decorator(fn_or_cls):
        # decorator_tag is used to identify the functions
        fn_or_cls.decorator_tag = "model_api"
        fn_or_cls.api_meta = {
            "endpoint": endpoint,
            "task_name": ENDPOINT_TASK_MAPPING.get(endpoint, ""),
            "model_name": [model_name] if isinstance(model_name, str) else model_name,
            "model_list_func": model_list_func,
            "model_type": model_type,
            "model_version": model_version,
            "parameters": parameters,
        }
        fn_or_cls.model_info = None
        return fn_or_cls

    return decorator


def pytriton():
    """
    Decorator for registering pytrion server functions
    """

    def decorator(fn_or_cls):
        fn_or_cls.decorator_tag = "pytriton"
        return fn_or_cls

    return decorator


class DecoratorUtils:
    """
    Utils class for registering functions based on decorator tag
    """

    @staticmethod
    def _load_clients_from_module(filepath: str, decorator_name: str):
        """
        Loads the decorated functions for the specified decorator from python module.
        """
        decorated_funcs = []
        filename = os.path.basename(filepath)

        try:
            logger.debug(f"Analyzing file {filename} for @{decorator_name}")

            # Import the module from the file
            spec = importlib.util.spec_from_file_location(filename, filepath)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Loop through all members in the module and check for the `@client` decorator
            # If class has client decorator is_client class member is true
            for name, obj in inspect.getmembers(module):
                if inspect.isfunction(obj) and hasattr(obj, "decorator_tag") and obj.decorator_tag == decorator_name:
                    logger.info(f"Found @{decorator_name} function with name {obj.__name__}")
                    decorated_funcs.append(obj)
        except Exception as e:
            logger.error(f"Failed to register @{decorator_name} functions in {filename} in due to exception {e}")

        return decorated_funcs

    @staticmethod
    def _find_clients(directory: str, decorator_name: str) -> Dict:
        """
        Loop through all the subdirectories and check for the class with @decorator_name
        decorator
        """
        decorator_funcs = []

        if not os.path.exists(directory):
            raise ValueError(f"Invalid path {directory} to load @{decorator_name} decorated functions")

        # Loop through all files in the directory and its subdirectories
        for root, dirs, files in os.walk(directory):
            for filename in files:
                if filename.endswith(".py"):
                    filepath = os.path.join(root, filename)
                    decorator_funcs.extend(DecoratorUtils._load_clients_from_module(filepath, decorator_name))

        return decorator_funcs
