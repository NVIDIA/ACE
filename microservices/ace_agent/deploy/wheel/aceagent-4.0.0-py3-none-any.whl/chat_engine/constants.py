# Copyright(c) 2021-2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
Chat Engine core constants used by all modules
"""
import os

# Chat Engine Policy Module constants
POLICY_DIALOG = "dialog_policy"


# Chat Engine NLU Module constants
NLU_INTENT_SLOT = "intent_slot"
NLU_NER = "ner"
NLU_QNA = "qna"
NLU_MACHINE_TRANSLATION_ENDPOINT = "nmt/translate"
NLU_TEXT_CLASSIFIER = "text_classifier"

# Embedding tasks
NLU_EMBEDDING_SEARCH = "embedding_search_store"
NLU_EMBEDDING_DELETE = "embedding_delete_store"
NLU_EMBEDDING_CREATE = "embedding_create_store"

# Model name to be used for embedding tasks, this is a HACK need to be better handled in future
EMBEDDING_MODEL_NAME = "simcse-bert-base"

# NMT
NLU_MACHINE_TRANSLATION_INPUT = "translate_user_query"
NLU_MACHINE_TRANSLATION_OUTPUT = "translate_bot_response"

# Chat Engine Processor Module constants
PROCESSOR_PREPROCESSED = (
    "preprocessed"  # punctuation removed and lower case. TODO: Make this functionality as a processor
)
PROCESSOR_POSTPROCESSED = "postprocessed"  # final post-processed query from different processors are stored here

STORE_CACHE = "cache"
STORE_LOCAL_FILE = "local_file_system"
STORE_REDIS = "redis"
STORE_MONGO = "mongo"
SUPPORTED_STORE_LIST = [STORE_CACHE, STORE_LOCAL_FILE, STORE_REDIS, STORE_MONGO]
LOCAL_STORE_PATH = "/tmp/dm_data_store"

SESSION_CHECKER_WAIT_TIME = 900  # in seconds

DOMAIN_NO_MATCH = "none"
INTENT_NO_MATCH = "none"
EVENT_NO_MATCH = "none"
DEFAULT_DOMAIN_NAME = "none"
DEFAULT_INTENT_NAME = "none"
SYSTEM_SLOTS_PREFIX = "system."
SYSTEM_SLOTS_POLICY_PREFIX = "system.policy."
RAG_PREFIX = "rag"


DM_ROOT = os.path.join(os.path.dirname(os.path.realpath(__file__)), "../")
LOG_CONFIG = os.path.join(DM_ROOT, "./chat_engine/logger/logging.yaml")
LOG_LEVEL = ["NOTSET", "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
PROMPTS_DIR = os.path.join(DM_ROOT, "chat_engine", "policies", "llm_wrappers", "prompts")

DST_HISTORY_COUNT = 10
NG_EVENT_HISTORY_COUNT = 150

CONTRACTION_DICT = {
    "ain't": "is not",
    "aren't": "are not",
    "can't": "cannot",
    "'cause": "because",
    "could've": "could have",
    "couldn't": "could not",
    "didn't": "did not",
    "doesn't": "does not",
    "don't": "do not",
    "hadn't": "had not",
    "hasn't": "has not",
    "haven't": "have not",
    "he'd": "he would",
    "he'll": "he will",
    "he's": "he is",
    "how'd": "how did",
    "how'd'y": "how do you",
    "how'll": "how will",
    "how's": "how is",
    "I'd": "I would",
    "I'd've": "I would have",
    "I'll": "I will",
    "I'll've": "I will have",
    "I'm": "I am",
    "I've": "I have",
    "i'd": "i would",
    "i'd've": "i would have",
    "i'll": "i will",
    "i'll've": "i will have",
    "i'm": "i am",
    "i've": "i have",
    "isn't": "is not",
    "it'd": "it would",
    "it'd've": "it would have",
    "it'll": "it will",
    "it'll've": "it will have",
    "it's": "it is",
    "let's": "let us",
    "ma'am": "madam",
    "mayn't": "may not",
    "might've": "might have",
    "mightn't": "might not",
    "mightn't've": "might not have",
    "must've": "must have",
    "mustn't": "must not",
    "mustn't've": "must not have",
    "needn't": "need not",
    "needn't've": "need not have",
    "o'clock": "of the clock",
    "oughtn't": "ought not",
    "oughtn't've": "ought not have",
    "shan't": "shall not",
    "sha'n't": "shall not",
    "shan't've": "shall not have",
    "she'd": "she would",
    "she'd've": "she would have",
    "she'll": "she will",
    "she'll've": "she will have",
    "she's": "she is",
    "should've": "should have",
    "shouldn't": "should not",
    "shouldn't've": "should not have",
    "so've": "so have",
    "so's": "so as",
    "this's": "this is",
    "that'd": "that would",
    "that'd've": "that would have",
    "that's": "that is",
    "there'd": "there would",
    "there'd've": "there would have",
    "there's": "there is",
    "here's": "here is",
    "they'd": "they would",
    "they'd've": "they would have",
    "they'll": "they will",
    "they'll've": "they will have",
    "they're": "they are",
    "they've": "they have",
    "to've": "to have",
    "wasn't": "was not",
    "we'd": "we would",
    "we'd've": "we would have",
    "we'll": "we will",
    "we'll've": "we will have",
    "we're": "we are",
    "we've": "we have",
    "weren't": "were not",
    "what'll": "what will",
    "what'll've": "what will have",
    "what're": "what are",
    "what's": "what is",
    "what've": "what have",
    "when's": "when is",
    "when've": "when have",
    "where'd": "where did",
    "where's": "where is",
    "where've": "where have",
    "who'll": "who will",
    "who'll've": "who will have",
    "who's": "who is",
    "who've": "who have",
    "why's": "why is",
    "why've": "why have",
    "will've": "will have",
    "won't": "will not",
    "won't've": "will not have",
    "would've": "would have",
    "wouldn't": "would not",
    "wouldn't've": "would not have",
    "y'all": "you all",
    "y'all'd": "you all would",
    "y'all'd've": "you all would have",
    "y'all're": "you all are",
    "y'all've": "you all have",
    "you'd": "you would",
    "you'd've": "you would have",
    "you'll": "you will",
    "you'll've": "you will have",
    "you're": "you are",
    "you've": "you have",
}

# Defines the distance between two slots for them to be grouped together
COMPOSITE_SLOT_WORD_PROXIMITY = 0

# Predefined domain and intent names to perform specific actions in DM
CUSTOM_DOMAIN = "custom"
CUSTOM_INTENT_RESET = "custom.cancel"

# Base slot allowed datatypes
VALID_SLOT_DATATYPES = [str, bool, int, float]


# HTTP Status code
HTTP_STATUS_DICT = {"200": "Success", "408": "Request Timeout", "500": "Internal Server Error"}


# Reset option for userdata and slots
LONGTERM_MEMORY = "longterm"
SHORTTERM_MEMORY = "shortterm"
SESSION_MEMORY = "session"

# DM level logger traceback print
PRINT_TRACEBACK = False

# Print statement colorsRIVA_COLOR = "green"
WARNING_COLOR = "yellow"
ERROR_COLOR = "red"
INFO_COLOR = "green"

# FM server endpoints suffix
FM_LIST_ENDPOINT = "/list"

# NLP server endpoint suffix
NLP_MODELS_LIST_ENDPOINT = "/model/list_models"

# Custom action names
USER_INTENT_ACTION = "generate_user_intent"
ENTITY_LINKING_ACTION = "entity_linking"
USER_SLOTS_ACTION = "generate_user_slots"

# DM Event interface constants
EVENT_SYSTEM_STREAM = "ace_agent_system_events"
EVENT_LIVENESS_STREAM = "ace_agent_liveness"
EVENT_LIVENESS_STREAM_MAX_LENGTH = 1000
EVENT_LIVENESS_INTERVAL = 10.0

# DM Response Text Length in char
MAX_RESPONSE_TEXT_LENGTH = 2000
ENABLE_RESPONSE_SPLIT = False

RAG_FM_ENDPOINT = "rag/chat"

DEFAULT_RAG_COLANG_CONFIG = """
define flow
  user ...
  $answer = execute chat_plugin(\
    endpoint="rag/chat_stream",\
    )
  bot respond

define bot respond
  "{{$answer}}"

define bot pipeline response
  '''{"text": [""],
  "action": "",
  "json": {},
  "omniverse_json": {},
  "need_user_response": false}'''

define bot event start
  '''{"text": [""],
  "action": "",
  "json": {},
  "omniverse_json": {},
  "need_user_response": true}'''

define flow entry_event
  event system.event_start
  bot event start

define flow exit_event
  event system.event_exit
  bot pipeline response

define flow pipeline_acquired
  event system.event_pipeline_acquired
  bot pipeline response

define flow pipeline_released
  event system.event_pipeline_released
  bot pipeline response
"""
