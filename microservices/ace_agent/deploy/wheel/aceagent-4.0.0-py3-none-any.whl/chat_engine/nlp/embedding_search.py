# Copyright(c) 2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
chat engine class for managing embedding search models
"""

import logging
from typing import Any, List, Dict
import aiohttp
from enum import Enum
from typing import Dict, List

from chat_engine.nlp.constants import NLP_EMBEDDING_SEARCH_TIMEOUT, NLP_EMBEDDING_BUILD_TIMEOUT
from chat_engine.constants import NLU_EMBEDDING_CREATE
from chat_engine.constants import NLU_EMBEDDING_SEARCH, EMBEDDING_MODEL_NAME
from chat_engine import Bot

logger = logging.getLogger("chat_engine")


class StoreType(Enum):
    USER_MESSAGE = "user_message"
    BOT_MESSAGE = "bot_message"
    FLOW_MESSAGE = "flow_message"
    NEMOGUARDRAILS_FLOW = "nemoguardrails"  # For NG Embedding search module
    ENTITY_LINKING = "entity_linking"


class EmbeddingSearch:
    """
    Module to create embeddings and search similar embeddings.
    """

    def __init__(self, configs: List["NlpConfigs"] = [], bot: Bot = None) -> None:
        """Initialization method for NLU base module"""

        self._model_configs = configs
        self._user_store_available = False
        self._bot_store_available = False
        self._flow_store_available = False
        self._bot: Bot = bot

    async def build_index(self, store_type: Enum, store_name: str, anchors: List[Dict[str, Any]]) -> bool:
        """
        Create store and register anchors for embedding search
        """

        url = self._bot.health_monitor.get_nlp_endpoint(NLU_EMBEDDING_CREATE)

        if url is None:
            logger.info(f"Embedding search endpoint is not available. Skipping building index.")
            return False

        request = {"anchors": anchors, "store_name": store_name, "model_name": EMBEDDING_MODEL_NAME}

        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(NLP_EMBEDDING_BUILD_TIMEOUT)) as session:
                async with session.post(url, json=request) as resp:
                    response = resp
                    response_json = await resp.json()

        except Exception as e:
            logger.error(f"Request to {url} failed with exception {e}")
            return False

        if store_type == StoreType.USER_MESSAGE:
            logger.debug(f"User messages store is now available for {self._bot.name}!")
            self._user_store_available = True

        if store_type == StoreType.BOT_MESSAGE:
            logger.debug(f"Bot messages store is now available for {self._bot.name}!")
            self._bot_store_available = True

        if store_type == StoreType.FLOW_MESSAGE:
            logger.debug(f"Flow messages store is now available for {self._bot.name}!")
            self._flow_store_available = True

        if store_type == StoreType.ENTITY_LINKING:
            logger.debug(f"Entity Linking embeddings are now available for {store_name}")

        return True

    async def search(
        self,
        text: str = "",
        top_k: int = 1,
        store_name: List[str] = [],
    ) -> List[Dict[str, Any]]:
        """Search top_k similar queries from store_name"""

        url = self._bot.health_monitor.get_nlp_endpoint(NLU_EMBEDDING_SEARCH)
        if url is None:
            logger.info(f"Embedding search endpoint is not available. Skipping inference.")
            return []

        request = {"query": text, "top_k": top_k, "embedding_stores": store_name, "model_name": EMBEDDING_MODEL_NAME}
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(NLP_EMBEDDING_SEARCH_TIMEOUT)) as session:
                async with session.post(url, json=request) as resp:
                    response = resp
                    response_json = await resp.json()

        except Exception as e:
            logger.error(f"Request to {url} failed with exception {e}")
            return []

        if response.status != 200:
            logger.error(f"Request to {url} failed with error {response.reason}")
            return []

        return response_json.get("results", [])
