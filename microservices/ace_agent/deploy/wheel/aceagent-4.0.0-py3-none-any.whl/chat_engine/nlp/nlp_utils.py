# Copyright(c) 2021-2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
Utility methods used by several NLU and Policy modules
"""

import logging
from re import finditer, escape, findall, IGNORECASE
from typing import List, Dict, Any, Tuple
from difflib import get_close_matches

from chat_engine.nlp.nlp_response import TokenClassValue

logger = logging.getLogger("chat_engine")


def restore_slots_case(slots, query):
    """
    Restores slots from lower case to the case present in the original query
    """
    for slot in slots:
        matches = (
            list(finditer(escape(str(slot["Token"])), query, IGNORECASE))
            if isinstance(slot, dict)
            else list(finditer(escape(str(slot.token)), query, IGNORECASE))
        )
        if len(matches):
            s = matches[0].start()
            e = matches[0].end()
            if isinstance(slot, dict):
                slot["Token"] = query[s:e]
            else:
                slot.token = query[s:e]
            query = query[:s] + query[e + 1 :]


def find_spans(query: str, token: str) -> List[Dict[str, int]]:
    """Method to find all the spans of token inside query.
    Example:
    input:
    query: Add one large french fries and one large pizza, token: large

    output:
    [{"start": 8, "end": 12}, {"start": 35, "end": 39}]
    """

    spans = []

    def update_spans_list(query: str, token: str):
        """util method to get list of spans for token inside given query without modification"""

        # Avoid finding spans of tokens which are substring of a word in the original query
        query = " " + query + " "

        # Use 'escape' to search strings that contain special characters in regex
        # like +, ?, etc
        for match in finditer(escape(str(" " + str(token) + " ")), query):
            curr_span = {"start": match.span()[0], "end": match.span()[1] - 3}
            if curr_span not in spans:
                spans.append(curr_span)

        # WAR to add capability to provide spans for partially tagged tokens with apostropes
        # Example: "who is {john}[user_name]'s manager", here only  "john" is tagged
        for match in finditer(escape(str(" " + str(token) + "'s ")), query):
            curr_span = {"start": match.span()[0], "end": match.span()[1] - 5}
            if curr_span not in spans:
                spans.append(curr_span)

    update_spans_list(query, token)

    # # Replace punctuation like ".", "?", "," to with a space to tag span properly
    update_spans_list(query.replace(". ", "  ").replace("? ", "  ").replace(", ", "  "), token)

    if not len(spans):
        logger.error(f"For token: {token} in query: {query}, no span found. Disregarding the entity.")
    return spans


def find_spans_from_queries(query: str, entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Utility method called from policies to find the spans of different tokens in user query
    Tokens are tagged based on their occurences.
    For example:
    Query: add one large french fries and two large pizzas
    Token: [{'Token': 'large', 'EntityName': 'size'},
            {'Token': 'french fries', 'EntityName': 'item_name'}]

    Output:
    [{'Token': 'large', 'EntityName': 'size', 'Span': {'start': 8, 'end': 12}},
    {'Token': 'french fries', 'EntityName': 'item_name', 'Span': {'start': 14, 'end': 25}}]
    """

    group = {}
    spanned_entities = []

    # Group same tokens in the query different lists
    for ent in entities:
        group[ent["Token"]] = [ent for e in entities if ent["Token"] == e["Token"]]

    # For each of the grouped entities try to find the span
    for token, values in group.items():
        spans = find_spans(query, token)

        if not len(spans):
            continue

        for sp, val in zip(spans, values):
            spanned_entities.append({"Token": val["Token"], "EntityName": val["EntityName"], "Span": sp})

    return spanned_entities


def get_tokenclass_from_entities(slots: List[Dict[str, Any]]) -> List["TokenClassValue"]:
    """Converts entities in Policy format to TokenClassValues used in NLU modules"""

    return (
        [TokenClassValue(token=s["Token"], label=s["EntityName"], span=s.get("Span", {})) for s in slots]
        if len(slots)
        else []
    )


def get_entities_from_tokenclass(slots: List["TokenClassValue"]) -> List[Dict[str, Any]]:
    """Converts tokenclass used in NLU modules format to policy format"""

    return [{"Token": s.token, "EntityName": s.label, "Span": s.span} for s in slots] if len(slots) else []


def get_closest_match(name: str, search_list: List[str], conf: float) -> str:
    """Utility method to find closest match using edit distance"""

    mapped_name = get_close_matches(name.lower(), [x.lower() for x in search_list], 1, conf)
    o_case_mapped_name = []
    for match in mapped_name:  # converting match to original case in search list
        for value in search_list:
            if match.lower() == value.lower():
                o_case_mapped_name.append(value)

    if len(o_case_mapped_name):
        logger.debug(f"Closest match found for {name}: {o_case_mapped_name} with confidence: {conf}")
        return o_case_mapped_name[0]
    return None


def update_entities(
    user: "UserData", entities: List[Dict[str, Any]], consider_user_ent: bool = True
) -> List[Dict[str, Any]]:
    """
    Update entities from user.entities tokenwise and returns the updated list UNLESS:
    1. The new slot occurs later in the list compared to the old slot AND
    2. The old slot is of lower priority than the new slot AND
    3. The slot associated with the old entity (if any) is part of the same domain as the new entity.
                    OR
    1. New entity and old entity are of the same slot AND
    2. New entity is of lower priority (later in the list) for that slot.

    Form the new entities without consider pre-existing values in user.entities if
    consider_user_ent is set to False.
    """

    if consider_user_ent:
        updated_entities = user.entities
    else:
        updated_entities = []

    # dm_cntrl = DomainController.get_instance()
    # domain_rules = dm_cntrl.get_domain_rules(user.domain)

    # if domain_rules and not domain_rules.configs.enable_entity_disambiguation:
    #     logger.info(f"Skipping disambiguation of tagged entities.")
    if consider_user_ent:
        return updated_entities + entities
    else:
        return entities

    # for entity in entities:

    #     tag = entity["EntityName"]
    #     token = entity["Token"]
    #     span = entity.get("Span", {})

    #     slot, domain = dm_cntrl.get_slot_from_entity_all_domains(user.domain, tag)

    #     # If the token does not have an associated entity, tag it
    #     if not any([ent["Token"] == token for ent in updated_entities]):
    #         updated_entities.append(entity)
    #         logger.debug(f"Tagging unmarked token {token} as {tag}.")
    #         continue

    #     # Get the current tag and current postion for the same token in same span
    #     prev_tag, pos = __find_entity_tag(token, span, updated_entities)

    #     # If the token in the given span does not have a valid tag add it
    #     if prev_tag is None:
    #         updated_entities.append(entity)
    #         continue

    #     # If the incoming entity tag has same tag as existing do not overwrite
    #     if tag == prev_tag:
    #         continue

    #     # If the incoming entity tag does not have any slot associated with it do not overwrite
    #     if slot is None:
    #         logger.debug(
    #             f"Skipping update of token: {token} with entity: {tag} due to no valid slot mapping. "
    #             f"Current entity: {prev_tag}."
    #         )
    #         continue

    #     """
    #         Conflict handling - same token in same span already has a tag associated with it at `pos` index
    #         Determine whether to select tag or prev_tag by a set of rules
    #     """
    #     logger.debug(
    #         f"Conflicting token: {token} found. Disambiguating between new tag: {tag} and current tag: {prev_tag}"
    #     )

    #     # Find the slot associated with prev_tag
    #     prev_slot, _ = dm_cntrl.get_slot_from_entity_all_domains(user.domain, prev_tag)

    #     # if the token has previously been tagged by an entity
    #     # that is not defined in any domain config,
    #     # it is overwritten by the new entity.
    #     if prev_slot is None:
    #         updated_entities[pos] = entity
    #         continue

    #     # If priority of new slot is lower than old slot, do not update
    #     domain_slot_list = dm_cntrl.get_slot_list(domain)
    #     if (
    #         prev_slot in domain_slot_list
    #         and slot in domain_slot_list
    #         and domain_slot_list.index(slot) > domain_slot_list.index(prev_slot)
    #         and dm_cntrl.get_slot_priority(domain, prev_slot) >= dm_cntrl.get_slot_priority(domain, slot)
    #     ):
    #         logger.debug(
    #             f"Skipping update of token: {token} with entity: {tag} due to lower slot priority. "
    #             f"Current entity: {prev_tag}, current slot: {prev_slot}."
    #         )
    #         continue

    #     # If priority of new entity is lower than old entity, do not update
    #     priority_list = dm_cntrl.get_slot_rules(slot, domain).entity
    #     if prev_tag in priority_list and priority_list.index(tag) > priority_list.index(prev_tag):
    #         logger.debug(
    #             f"Skipping update of token: {token} with entity: {tag} due to lower entity priority. "
    #             f"Current entity: {prev_tag}."
    #         )
    #         continue

    #     # Overwrite existing entity
    #     logger.debug(f"Overwriting existing entity: {prev_tag} with {tag}: {token}")
    #     updated_entities[pos] = entity

    # # Remove any overlapping entities based on span
    # updated_entities = filter_overlapping_tokens(updated_entities, is_token_class=False)
    # return updated_entities


def get_entities(resp: "TokenClassResponse") -> Dict[str, str]:
    """Get entities corresponding to intent slot NLU result"""

    return [{"Token": s.token, "EntityName": s.label.class_name, "Span": s.span} for s in resp.slots] if resp else []


def __find_entity_tag(token: str, span: Dict[str, Any], entities: List[Dict[str, Any]]) -> Tuple[str, int]:
    """Returns the matching tag associated with the token and span in entities"""

    for pos, ent in enumerate(entities):
        if ent["Token"] == token and ent.get("Span", {}) == span:
            return ent["EntityName"], pos
    return None, None
