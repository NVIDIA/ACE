# copyright(c) 2021 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

from dataclasses import dataclass, field
from typing import List, Dict, Any, Union
from datetime import datetime, timezone

from chat_engine.constants import DOMAIN_NO_MATCH, INTENT_NO_MATCH
from chat_engine.package_info import __version__


@dataclass
class Entity:
    Token: str = ""
    EntityName: str = ""
    ConfidenceScore: float = 0
    Span: Dict = field(default_factory=lambda: {})
    NluType: str = ""
    IsFmEntity: bool = False


@dataclass
class Classification:
    """Classification response containing class name and score"""

    Name: str = ""
    ConfidenceScore: float = 0
    NluType: str = ""


@dataclass
class Slot:
    Name: str
    Values: List[Union[str, "SlotValue"]]


@dataclass
class SlotValue:
    Text: str
    Attributes: List["Slot"]


@dataclass
class SessionSlot:
    Name: str
    Values: List[Union[str, "SlotValue"]]
    RemainingTurn: int
    RemainingTime: int


@dataclass
class GlobalSlot:
    Name: str
    Values: List[Union[str, "SlotValue"]]


@dataclass
class FulfillmentInfo:
    Module: str
    Status: str
    Slots: List["Slot"] = field(default_factory=lambda: [])
    FulfillmentSlots: List["Slot"] = field(default_factory=lambda: [])
    CustomData: Dict[str, Any] = field(default_factory=lambda: {})
    InvalidSlots: List[str] = field(default_factory=lambda: [])


@dataclass
class DialogState:
    SessionSlot: List["SessionSlot"] = field(default_factory=lambda: [])
    GlobalSlot: List["GlobalSlot"] = field(default_factory=lambda: [])


@dataclass
class UserResponse:
    Text: str = ""
    CleanedText: str = ""
    Json: Dict[str, Any] = field(default_factory=lambda: {})
    OmniverseJson: Dict[str, Any] = field(default_factory=lambda: {})
    NeedUserResponse: bool = False
    IsFinal: bool = True


@dataclass
class Latency:
    IntentSlotModel: int = 0
    NaturalQueryModel: int = 0
    InformationRetrievalModel: int = 0
    EntailmentModel: int = 0
    NERModel: int = 0
    MachineTranslation: int = 0
    SemanticSimilarityModel: int = 0
    TextClassifierModel: int = 0
    QueryParaphrasingModel: int = 0
    ResponseParaphrasingModel: int = 0
    PluginPolicy: int = 0
    Fulfillment: int = 0
    DialogManager: int = 0
    NLPModels: int = 0
    LLMModels: int = 0
    EndToEnd: int = 0
    TimeUnit: str = "ms"


@dataclass
class SemanticSimilarityResult:
    Text: str = ""
    LinkedAnchor: str = ""
    SimilarDomain: str = ""
    SimilarIntent: str = ""
    SimilarSlot: str = ""
    ConfidenceScore: int = 0


@dataclass
class EntailmentResult:
    Text: str = ""
    LinkedAnchor: str = ""
    SimilarDomain: str = ""
    SimilarIntent: str = ""
    ConfidenceScore: int = 0


@dataclass
class TextClassifierResult:
    Text: str = ""
    Score: float = 0.0


@dataclass
class QueryParaphrasingResult:
    Query: str = ""
    Score: float = 0.0
    Prompt: str = ""
    Result: str = ""


@dataclass
class ResponseParaphrasingResult:
    ResponseText: str = ""
    Score: float = 0.0
    Prompt: str = ""
    Result: str = ""


@dataclass
class InformationRetrievalResult:
    Results: List[Any] = field(default_factory=lambda: [])
    NumResults: int = 0


@dataclass
class NlpResult:
    Domain: "Classification" = field(default_factory=lambda: Classification())
    Intent: "Classification" = field(default_factory=lambda: Classification())
    Entities: List["Entity"] = field(default_factory=lambda: [])
    NaturalQuery: List[Any] = field(default_factory=lambda: [])
    InformationRetrieval: "InformationRetrievalResult" = field(default_factory=lambda: InformationRetrievalResult())
    SemanticSimilarity: List[SemanticSimilarityResult] = field(default_factory=lambda: [])
    TextClassifier: List["TextClassifierResult"] = field(default_factory=lambda: [])
    Entailment: List[EntailmentResult] = field(default_factory=lambda: [])
    QueryParaphrasing: List[QueryParaphrasingResult] = field(default_factory=lambda: [])
    ResponseParaphrasing: List[ResponseParaphrasingResult] = field(default_factory=lambda: [])


@dataclass
class ResponseData:
    ApiVersion: str = __version__
    BotName: str = ""
    BotVersion: str = ""
    SourceLanguage: str = "en-US"
    TargetLanguage: str = "en-US"
    SchemaVersion: str = "1.2"
    UserId: str = None
    EventId: str = None
    EventType: str = None
    Events: List[Dict[str, Any]] = field(default_factory=lambda: [])
    QueryId: str = ""
    DialogId: str = ""
    SessionId: str = ""
    TimeStamp: str = ""
    Query: str = ""
    ProcessedQuery: str = ""
    Event: str = ""
    StreamId: str = ""
    Response: "UserResponse" = field(default_factory=lambda: UserResponse())
    Domain: str = DOMAIN_NO_MATCH
    Intent: str = INTENT_NO_MATCH
    Entities: List[Dict] = field(default_factory=lambda: {})
    Slots: List["Slot"] = field(default_factory=lambda: [])
    MissingSlots: List[str] = field(default_factory=lambda: [])
    Parameters: Dict[str, str] = field(default_factory=lambda: {})
    PolicyName: str = ""
    Fulfillment: List["FulfillmentInfo"] = field(default_factory=lambda: [])
    NlpResult: "NlpResult" = field(default_factory=lambda: NlpResult())
    DialogState: "DialogState" = field(default_factory=lambda: DialogState())
    Latency: "Latency" = field(default_factory=lambda: Latency())

    def reset(self):
        """Method to reset relevant user data fields"""

        self.Query = ""
        self.ProcessedQuery = ""
        self.QueryId = ""
        self.DialogId = ""
        self.Language = ""
        self.ResponseLanguage = ""
        self.UserResponse = UserResponse()
        self.PolicyName = ""
        self.Event = ""
        self.StreamId = ""
        self.TimeStamp = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        self.Domain = DOMAIN_NO_MATCH
        self.Intent = INTENT_NO_MATCH
        self.Entities = {}
        self.Slots = {}
        self.MissingSlots = []
        self.Parameters = {}
        self.NlpResult = NlpResult()
        self.Fulfillment = []
        self.DialogState = DialogState()
        self.Latency = Latency()
