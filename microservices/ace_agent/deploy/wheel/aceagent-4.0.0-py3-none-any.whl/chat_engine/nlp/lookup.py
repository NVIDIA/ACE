# Copyright(c) 2021-2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.


import logging
from typing import Dict, List

from chat_engine.nlp.nlp_response import TokenClassResponse, TokenClassValue, Classification
from chat_engine.nlp.nlp_utils import find_spans, restore_slots_case

logger = logging.getLogger("chat_engine")


class Lookup:
    """
    lookup based slot tagging.
    """

    @staticmethod
    def process_query(query: str, lookup: Dict[str, List[str]]) -> "TokenClassResponse":
        """
        return dict of entity in lookup_dict
        Input
        e.g query : I am using desktop
        lookup : {"device_type": ["desktop"], "remote_type": ["triangular"]}
        Output
        result : {"device_type": "desktop"}
        """

        result = TokenClassResponse()

        for tag, lookups in lookup.items():
            for value in lookups:
                if " " + value.lower() + " " in " " + query.lower() + " ":
                    # Check whether the value occurs as a word or group of words in the query
                    for span in find_spans(query.lower(), value.lower()):
                        result.slots.append(TokenClassValue(token=value, span=span, label=Classification(tag, 1.0)))

        restore_slots_case(result.slots, query)

        logger.info(f"Lookup NLP module result: {result}")
        return result
