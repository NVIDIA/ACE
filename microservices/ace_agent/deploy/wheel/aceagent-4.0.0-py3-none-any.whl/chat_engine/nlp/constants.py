# copyright(c) 2022-2023 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

""" nlu constants """

NLP_EMBEDDING_SEARCH_TIMEOUT = 120
# Keep lower timeout for embedding search build
# as 120 is time out for bot discovery
NLP_EMBEDDING_BUILD_TIMEOUT = 60

DEFAULT_ENTITY_LINKING_CONF_THRESHOLD = 0.5
