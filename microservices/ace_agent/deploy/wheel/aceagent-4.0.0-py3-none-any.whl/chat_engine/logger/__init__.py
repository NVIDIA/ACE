# Copyright(c) 2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
 Contains logging modules of chat engine.
"""

import logging
import re
from typing import List, Tuple

static_log_information = {"stream_id": ""}


class MessageBasedFilter(logging.Filter):
    def __init__(self, pattern: str, replacements: List[Tuple[str, str]]):
        self.pattern = re.compile(pattern)
        self.replacements = replacements

    def filter(self, record):
        stream_id = static_log_information.get("stream_id", "")
        record.stream_id = f"{stream_id[0:5]}.."
        is_match = self.pattern.match(record.msg)

        if record.levelno > logging.INFO:
            return True

        # Make relevant log output more readable
        if is_match:
            for old, new in self.replacements:
                record.msg = record.msg.replace(old, new)
        return is_match
