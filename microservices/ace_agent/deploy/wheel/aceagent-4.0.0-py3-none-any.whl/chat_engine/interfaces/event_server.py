# Copyright(c) 2022-2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
    This Fast API server provides a minimal API to be run together with the DM in event mode.
    At the moment it only provides the isReady endpoints that will connect with the DM over redis
    and check if the DM has sent out a recent liveness message.

"""

import os
import json
import asyncio
import logging
from typing import Any, Dict, List
from rich import print
from fastapi import FastAPI, Response, status
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timezone, timedelta

from chat_engine.package_info import __version__
from chat_engine.constants import EVENT_LIVENESS_STREAM, EVENT_LIVENESS_INTERVAL
from chat_engine.utils import event_provider_factory, read_isoformat

app = FastAPI(
    title="Chat Engine Event Server API",
    description="NVIDIA ACE Agent Chat Engine Event Server API",
    version=__version__,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logger = logging.getLogger("event_server")

app.event_provider = {}


"""
------------------------
REST API DEFINITIONS
-------------------------
"""


@app.get("/isReady", tags=["Health Check"], status_code=status.HTTP_200_OK)
async def is_ready(response: Response) -> List[Dict[str, Any]]:
    """Check status of the DM in event mode"""

    result = [{"msg": "No live sign of event DM."}]
    dm_is_live = False

    try:
        event_data = await app.event_provider["client"].get_latest_event(app.event_provider["channel"])
        if event_data:
            event = json.loads(event_data)
            time_difference = datetime.now(timezone.utc) - read_isoformat(event["event_created_at"])
            # Check if the the last liveness event is recent enough
            dm_is_live = time_difference < timedelta(seconds=EVENT_LIVENESS_INTERVAL * 2.0)
            result[0]["msg"] = f"Found last life sign of event DM {time_difference.total_seconds()} seconds ago."

        if dm_is_live:
            response.status_code = status.HTTP_200_OK
            return result
        else:
            response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
            return result
    except Exception as e:
        logger.error(f"Error while checking readiness DM event interface: {e}")
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return result


@app.on_event("startup")
def create_app() -> None:
    """
    Entrypoint for HTTP interface for chat engine in event mode.
    Creates a FastAPI based app and initializes the connection with the DM
    """

    try:
        event_provider_name: str = os.environ.get("event_provider_name", "redis")
        event_provider_host: str = os.environ.get("event_provider_host", "localhost")
        event_provider_port: int = os.environ.get("event_provider_port", 6379)

        app.event_provider["channel"] = EVENT_LIVENESS_STREAM
        app.event_provider["client"] = event_provider_factory(
            event_provider_name, event_provider_host, event_provider_port, [app.event_provider["channel"]]
        )

        logger.info(
            "HTTP interface for DM event server connects with event interface at "
            f"{event_provider_name}://{event_provider_host}:{event_provider_port}"
        )

    except Exception as e:
        print(f"Failed to initialize connection to DM core due to error {e}.\nPress Ctrl + C to stop the server.")
        return None

    logger.info(
        f"HTTP interface for DM event server started successfully. "
        f"Endpoint {'https' if os.environ.get('ssl', 'False') == 'True' else 'http'}"
        f"://localhost:{os.environ.get('port', 9000)}/isReady is active. "
    )


@app.on_event("shutdown")
async def stop():
    logger.info("DM HTTP server is shut down.")
