# Copyright(c) 2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

from pydantic import BaseModel, Field, RootModel
from typing import Optional, Dict, List, Union, Any
from chat_engine.bot_factory.constants import MAX_STR_LEN, MAX_NUMBER, MAX_LIST_LENGTH


class HealthResponse(BaseModel):
    message: str = Field(max_length=MAX_STR_LEN)


class ExceptionResponse(BaseModel):
    StatusMessage: str = Field(max_length=MAX_STR_LEN)


class IsReadyResponseStatus(BaseModel):
    BotName: str = Field(max_length=MAX_STR_LEN)
    Ready: bool


class IsReadyResponseList(RootModel):
    root: List[IsReadyResponseStatus] = Field(..., max_items=256)


class Entity(BaseModel):
    """This will be deprecated soon"""

    Token: Union[str, float, bool, int] = Field(description="Optional predefined custom entities for chat engine.")
    EntityName: Optional[str] = Field(description="Entity Name for the Token")


class RequestBody(BaseModel):
    """This will be deprecated soon"""

    BotName: Optional[str] = Field(
        default="",
        description="The Bot Name which needs to be accessed. This field is mandatory if multiple bots are deployed within Chat Engine. It's value should match the 'bot: ' field defined in the bot config file.",
        max_length=MAX_STR_LEN,
    )
    Query: Optional[str] = Field(
        default="", description="The user query which needs to be processed.", max_length=MAX_STR_LEN
    )
    UserId: str = Field(
        description="Mandatory unique identifier to recognize which user is interacting with the chat engine.",
        max_length=MAX_STR_LEN,
    )
    QueryId: Optional[str] = Field(
        default=None,
        description="Unique identifier for the user query. This field is assigned automatically by the chat engine if not defined.",
        max_length=MAX_STR_LEN,
    )
    SessionId: Optional[str] = Field(
        default=None,
        description="Unique identifier for the current session. This field is used to assign a unique session with the UserId. If the value of this field changes, then the conversation state of the associated UserId will be deleted. This field is automatically assigned by Chat Engine if not available as part of request JSON.",
        max_length=MAX_STR_LEN,
    )
    DialogId: Optional[str] = Field(
        default=None,
        description="Unique identifier indicating a ongoing dialog. This identifier remains constant when 'dialog_policy' is responsible for answering the user request and the selected dialog/intent has not changed since last conversation turn.",
        max_length=MAX_STR_LEN,
    )
    SourceLanguage: Optional[str] = Field(
        default=None,
        description="Language of the user query. If language of user query does not match language of the bot, then chat engine tries to call machine translator model (currently not supported) to convert the query to bot language.",
        max_length=MAX_STR_LEN,
    )
    TargetLanguage: Optional[str] = Field(
        default=None,
        description="Expected Langauge of Chat Engine Response text. If language of response text does not match expected output language, then chat engine tries to call machine translator model (currently not supported) to do the conversion.",
        max_length=MAX_STR_LEN,
    )
    Domain: Optional[str] = Field(
        default=None,
        description="Optional predefined Domain name associated with the user query. When this field is populated, chat engine will skip calling any NLU models, to associate any other domain with the user query from any of its defined policies. This can be used to divert a user request to a predefined domain rule file under 'dialog_policy'.",
        max_length=MAX_STR_LEN,
    )
    Intent: Optional[str] = Field(
        default=None,
        description="Optional predefined Intent name associated with the user query. When this field is populated, chat engine will skip calling any NLU models, to associate any other intent with the user query from any of its defined policies. This can be used to divert a user request to a predefined dialog/intent inside a certain domain rule file defined under 'dialog_policy'.",
        max_length=MAX_STR_LEN,
    )
    StreamId: Optional[str] = Field(
        default=None,
        description="Optional predefined StreamId associated with the device sending the query. This field is placeholder and not used in Chat Engine",
        max_length=MAX_STR_LEN,
    )
    Event: Optional[str] = Field(
        default=None,
        description="Placeholder field to provide Event. This is not yet functional in this release.",
        max_length=MAX_STR_LEN,
    )
    DetailedResponse: bool = Field(
        default=True,
        description="Optional predefined DetailedResponse associated. When this field is True, chat engine will give detailed response json. It's default value is 'True'.",
    )
    Entities: Optional[List[Entity]] = Field(
        default=None,
        description="Optional predefined entities to be used by Chat Engine. This can be used to pass slots to chat engine as part of request JSON. The entities defined here must have a corresponding slot defined for it inside the required domain rule file.",
        max_items=MAX_LIST_LENGTH,
    )
    Parameters: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Any runtime custom parameters needed for plugin modules. This is populated as part of the request JSON of fulfillment module's 'processQuery' endpoint.",
    )


class LatencyField(BaseModel):
    """This will be deprecated soon"""

    IntentSlotModel: int = Field(ge=0, le=MAX_NUMBER)
    NaturalQueryModel: int = Field(ge=0, le=MAX_NUMBER)
    InformationRetrievalModel: int = Field(ge=0, le=MAX_NUMBER)
    Fulfillment: int = Field(ge=0, le=MAX_NUMBER)
    DialogManager: int = Field(ge=0, le=MAX_NUMBER)
    MachineTranslation: int = Field(ge=0, le=MAX_NUMBER)
    NERModel: int = Field(ge=0, le=MAX_NUMBER)
    EntailmentModel: int = Field(ge=0, le=MAX_NUMBER)
    SemanticSimilarityModel: int = Field(ge=0, le=MAX_NUMBER)
    TextClassifierModel: int = Field(ge=0, le=MAX_NUMBER)
    QueryParaphrasingModel: int = Field(ge=0, le=MAX_NUMBER)
    ResponseParaphrasingModel: int = Field(ge=0, le=MAX_NUMBER)
    PluginPolicy: int = Field(ge=0, le=MAX_NUMBER)
    LLMModels: int = Field(ge=0, le=MAX_NUMBER)
    NLPModels: int = Field(ge=0, le=MAX_NUMBER)
    EndToEnd: int = Field(ge=0, le=MAX_NUMBER)
    TimeUnit: str = Field(default="ms", max_length=MAX_STR_LEN)


class EntitySpan(BaseModel):
    """This will be deprecated soon"""

    start: Optional[int] = Field(default=None, description="Start Index for Entity", ge=0, le=MAX_NUMBER)
    end: Optional[int] = Field(default=None, description="End Index for Entity", ge=0, le=MAX_NUMBER)


class NlpResp(BaseModel):
    """This will be deprecated soon"""

    class Classification(BaseModel):
        Name: str = Field(description="Name of the label which the query is classified into", max_length=MAX_STR_LEN)
        ConfidenceScore: float = Field(description="Confidence Score of the classification", ge=0)
        NluType: str = Field(
            description="Nlu module type which is used to identify the Domain Name.", max_length=MAX_STR_LEN
        )

    class NluEntity(BaseModel):

        Token: str = Field(max_length=MAX_STR_LEN)
        EntityName: str = Field(max_length=MAX_STR_LEN)
        ConfidenceScore: float = Field(ge=0, le=1.0)
        NluType: str = Field(max_length=MAX_STR_LEN)
        IsFmEntity: bool
        Span: EntitySpan

    class QnaResult(BaseModel):
        """This will be deprecated soon"""

        answer: str = Field(max_length=MAX_STR_LEN)
        ConfidenceScore: Optional[float] = Field(default=None, ge=0, le=1.0)

    class IrResults(BaseModel):
        """This will be deprecated soon"""

        class IrResult(BaseModel):

            # TODO: Check how to do anyOf in pydantic validation
            class IrResponse(BaseModel):
                paragraph: Optional[str] = Field(default=None, max_length=MAX_STR_LEN)
                question: Optional[str] = Field(default=None, max_length=MAX_STR_LEN)
                answer: Optional[str] = Field(default=None, max_length=MAX_STR_LEN)

            ir_type: str = Field(max_length=MAX_STR_LEN)
            source_path: str = Field(max_length=MAX_STR_LEN)
            title: Optional[str] = Field(default=None, max_length=MAX_STR_LEN)
            ir_result: IrResponse
            score: float = Field(ge=0, le=1.0)

        Results: List[IrResult] = Field(max_items=MAX_LIST_LENGTH)
        NumResults: int = Field(ge=0, le=MAX_LIST_LENGTH)

    class SemanticSimilarityResult(BaseModel):
        """This will be deprecated soon"""

        Text: str = Field(max_length=MAX_STR_LEN)
        LinkedAnchor: str = Field(max_length=MAX_STR_LEN)
        SimilarSlot: str = Field(max_length=MAX_STR_LEN)
        SimilarDomain: str = Field(max_length=MAX_STR_LEN)
        SimilarIntent: str = Field(max_length=MAX_STR_LEN)
        ConfidenceScore: float = Field(ge=0, le=1.0)

    class TextClassifierResult(BaseModel):
        """This will be deprecated soon"""

        Text: str = Field(max_length=MAX_STR_LEN)
        Score: float = Field(ge=0, le=1.0)

    class QueryParaphrasingResult(BaseModel):
        """This will be deprecated soon"""

        Query: str = Field(max_length=MAX_STR_LEN)
        Score: float = Field(ge=0, le=1.0)
        Result: str = Field(max_length=MAX_STR_LEN)
        Prompt: str = Field(max_length=MAX_STR_LEN)

    class ResponseParaphrasingResult(BaseModel):
        """This will be deprecated soon"""

        ResponseText: str = Field(max_length=MAX_STR_LEN)
        Score: float = Field(ge=0, le=1.0)
        Result: str = Field(max_length=MAX_STR_LEN)
        Prompt: str = Field(max_length=MAX_STR_LEN)

    class EntailmentResult(BaseModel):
        """This will be deprecated soon"""

        Text: str = Field(max_length=MAX_STR_LEN)
        LinkedAnchor: str = Field(max_length=MAX_STR_LEN)
        SimilarSlot: Optional[str] = Field(max_length=MAX_STR_LEN)
        SimilarDomain: Optional[str] = Field(max_length=MAX_STR_LEN)
        SimilarIntent: Optional[str] = Field(max_length=MAX_STR_LEN)
        ConfidenceScore: Optional[float] = Field(ge=0, le=1.0)

    Domain: Classification
    Intent: Classification
    Entities: List[NluEntity] = Field(max_items=MAX_LIST_LENGTH)
    NaturalQuery: List[QnaResult] = Field(max_items=MAX_LIST_LENGTH)
    InformationRetrieval: IrResults
    SemanticSimilarity: List[SemanticSimilarityResult] = Field(max_items=MAX_LIST_LENGTH)
    TextClassifier: List[TextClassifierResult] = Field(max_items=MAX_LIST_LENGTH)
    QueryParaphrasing: List[QueryParaphrasingResult] = Field(max_items=MAX_LIST_LENGTH)
    ResponseParaphrasing: List[ResponseParaphrasingResult] = Field(max_items=MAX_LIST_LENGTH)
    Entailment: List[EntailmentResult] = Field(max_items=MAX_LIST_LENGTH)


class SlotAttribute(BaseModel):
    """This will be deprecated soon"""

    Text: str = Field(description="Slot Value.", max_length=MAX_STR_LEN)
    Attributes: List["Slot"] = Field(
        description="Composite Slots",
        max_items=MAX_LIST_LENGTH,
    )


class Slot(BaseModel):
    """This will be deprecated soon"""

    Name: str = Field(description="Slot Label", max_length=MAX_STR_LEN)
    Values: List[Union[str, float, int, bool, SlotAttribute]] = Field(
        max_items=MAX_LIST_LENGTH, max_length=MAX_STR_LEN
    )


class FulfillmentInfo(BaseModel):
    """This will be deprecated soon"""

    Module: str = Field(max_length=MAX_STR_LEN)
    Status: str = Field(max_length=MAX_STR_LEN)
    CustomData: Optional[Any]
    FulfillmentSlots: List[Any]
    InvalidSlots: Union[str, List[str]] = Field(max_length=MAX_STR_LEN, max_items=MAX_LIST_LENGTH)
    Slots: List[Any] = Field(max_items=MAX_LIST_LENGTH)


class SessionSlotField(BaseModel):
    """This will be deprecated soon"""

    Name: str = Field(max_length=MAX_STR_LEN)
    Values: List[Union[str, float, int, bool, SlotAttribute]] = Field(
        max_items=MAX_LIST_LENGTH, max_length=MAX_STR_LEN
    )
    RemainingTurn: int = Field(ge=0, le=MAX_NUMBER)
    RemainingTime: float = Field(ge=0, le=MAX_NUMBER)


class ChatRequest(BaseModel):
    class Config:
        extra = "forbid"

    BotName: Optional[str] = Field(
        default=None,
        description="The Bot Name which needs to be accessed. This field is mandatory if multiple bots are deployed within Chat Engine. It's value should match the 'bot: ' field defined in the bot config file.",
        max_length=MAX_STR_LEN,
    )
    Query: Optional[str] = Field(
        default="", description="The user query which needs to be processed.", max_length=MAX_STR_LEN
    )
    UserId: str = Field(
        description="Mandatory unique identifier to recognize which user is interacting with the chat engine.",
        max_length=MAX_STR_LEN,
    )
    SourceLanguage: Optional[str] = Field(
        default=None,
        description="Language of the user query. If language of user query does not match language of the bot, then chat engine tries to call machine translator model (currently not supported) to convert the query to bot language.",
        max_length=MAX_STR_LEN,
    )
    TargetLanguage: Optional[str] = Field(
        default=None,
        description="Expected Langauge of Chat Engine Response text. If language of response text does not match expected output language, then chat engine tries to call machine translator model (currently not supported) to do the conversion.",
        max_length=MAX_STR_LEN,
    )
    UserContext: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Any runtime custom parameters needed for dialog flow. tied to this user id. This is populated as part of the request JSON of all fulfillment endpoints as well under context.",
    )
    Metadata: Optional[Dict[str, Any]] = Field(
        default={}, description="Any chat specific metadata needed for dialog flow."
    )


class EventRequest(BaseModel):
    class Config:
        extra = "forbid"

    BotName: Optional[str] = Field(
        default=None,
        description="The Bot Name which needs to be accessed. This field is mandatory if multiple bots are deployed within Chat Engine. It's value should match the 'bot: ' field defined in the bot config file.",
        max_length=MAX_STR_LEN,
    )
    EventType: str = Field(
        default="", description="The event name which needs to be processed.", max_length=MAX_STR_LEN
    )
    UserId: str = Field(
        description="Mandatory unique identifier to recognize which user is interacting with the chat engine.",
        max_length=MAX_STR_LEN,
    )
    Metadata: Optional[Dict[str, Any]] = Field(
        default={}, description="Any event specific metadata needed for dialog flow."
    )
    UserContext: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Any runtime custom parameters needed for dialog flow, tied to this user id. This is populated as part of the request JSON of all fulfillment endpoints as well under context.",
    )


class ResponseField(BaseModel):
    Text: str = Field(
        description="Text response to be sent out. This field will also be picked by a Text to Speech Synthesis module if enabled for speech based bots.",
        max_length=MAX_STR_LEN,
    )
    CleanedText: str = Field(
        description="Text response from the chat engine with all SSML/HTML tags removed.", max_length=MAX_STR_LEN
    )
    Json: Optional[Dict[str, Any]] = Field(
        default={}, description="JSON response from the chat engine containing any custom data needed."
    )
    OmniverseJson: Optional[Dict[str, Any]] = Field(
        default={},
        description="Optional custom JSON for Omniverse Avatar Control. This is useful only when a Nvidia Omniverse Avatar is plugged in with the bot.",
    )
    NeedUserResponse: Optional[bool] = Field(
        default=None,
        description="This field can be used by end user applications to deduce if user response is needed or not for a dialog initiated query. This is set to true automatically if form filling is active and one or more slots are missing.",
    )
    IsFinal: bool = Field(
        description="This field can be used to indicate the the final response has been sent by Chat Engine. When this field is set to False, Chat Engine sends out this intermediate response and reexecutes the current action in the current intent (example: calling a fulfillment module)."
    )


class ResponseBody(BaseModel):
    """This will be deprecated soon"""

    class Entity(BaseModel):
        Token: Union[str, float, int, bool] = Field(
            description="Entity Value", max_length=MAX_STR_LEN, ge=-MAX_NUMBER, le=MAX_NUMBER
        )
        EntityName: str = Field(description="Entity Name for the token.", max_length=MAX_STR_LEN)
        Span: EntitySpan

    class DialogStateField(BaseModel):
        SessionSlot: List[SessionSlotField] = Field(
            description="Contains all session/shortterm slots with information like slot name, slot value, remaining turn until the query is active, and remaining time for which the slot is active.",
            max_items=MAX_LIST_LENGTH,
        )
        GlobalSlot: List[Slot] = Field(
            description="Contains the global/longterm slots for users with slot name and slot value.",
            max_items=MAX_LIST_LENGTH,
        )

    ApiVersion: str = Field(description="Current API version of NVIDIA ACE Agent.", max_length=MAX_STR_LEN)
    SourceLanguage: str = Field(
        description="Language of the user query. By default this is set as the language as defined in the bot config file unless specified otherwise in request JSON.",
        max_length=MAX_STR_LEN,
    )
    TargetLanguage: str = Field(
        description="Expected Langauge of DM Response. By default this is set as the language as defined in the bot config file unless specified otherwise in request JSON.",
        max_length=MAX_STR_LEN,
    )
    SchemaVersion: str = Field(
        description="Schema Version of Chat Engine Response. This field changes if schema of this response template changes to notify end user applications.",
        max_length=MAX_STR_LEN,
    )
    UserId: str = Field(
        description="Unique identifier to recognize which user is interacting with the chat engine. This is populated from the request JSON.",
        max_length=MAX_STR_LEN,
    )
    SessionId: str = Field(
        description="Unique identifier for the current session associated with the userID in chat engine unless specified in request JSON.",
        max_length=MAX_STR_LEN,
    )
    TimeStamp: str = Field(
        description="Timestamp at which this response JSON is generated in ISO format.", max_length=MAX_STR_LEN
    )
    QueryId: str = Field(
        description="Unique identifier for the user query assigned automatically by the chat engine unless specified in request JSON.",
        max_length=MAX_STR_LEN,
    )
    Query: str = Field(description="The user query which needs to be processed.", max_length=MAX_STR_LEN)
    ProcessedQuery: str = Field(
        description="The query after applying all defined processors in bot config file by Chat Engine like pronoun/query replacement.",
        max_length=MAX_STR_LEN,
    )
    Response: ResponseField = Field(
        description="Final response template from the chat engine. This field can be picked up from domain rule files or can be formulated directly from custom plugin modules."
    )
    Domain: Optional[str] = Field(
        default=None, description="Domain name associated with the user request.", max_length=MAX_STR_LEN
    )
    Intent: Optional[str] = Field(
        default=None, description="Intent name associated with the user request.", max_length=MAX_STR_LEN
    )
    Event: Optional[str] = Field(
        default=None, description="Event name associated with the user request.", max_length=MAX_STR_LEN
    )
    StreamId: Optional[str] = Field(
        default=None, description="Stream Id associated with the user request.", max_length=MAX_STR_LEN
    )
    PolicyName: Optional[str] = Field(
        default=None,
        description="One of policy names from the defined bot config file used to answer the current query. If no policy could answer the user request, 'fallback_policy' is selected.",
        max_length=MAX_STR_LEN,
    )
    Slots: Optional[Any] = Field(
        default=None, description="Slot values formulated by the chat engine. Includes shortterm/longterm slots."
    )
    Entities: Optional[List[Entity]] = Field(
        default=None,
        description="All tagged processed entities of the user query. If same tokens has multiple entity tags associated with it (for example one tag from intent-slot model and another tag from Named Entity Recognizer Model), then the entity defined first in domain rule file is considered here.",
        max_items=MAX_LIST_LENGTH,
    )
    MissingSlots: Optional[List[str]] = Field(
        default=None,
        description="Array of slots missing to fulfill current request. These slots are populated only when a form filling action is active for the selected intent and the required slot needed to close the form is populated here.",
        max_items=MAX_LIST_LENGTH,
    )
    Parameters: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Any runtime custom parameters for plugin modules passed as part of request JSON. This field is populated only if the same is available as part of corresponding request JSON.",
    )
    Latency: Optional[LatencyField] = Field(
        default=None,
        description="Latency information for all components of the chat engine which are enabled in bot configurations.",
    )
    Fulfillment: List[FulfillmentInfo] = Field(
        description="Array of fulfillment objects. Stores information of all fulfillment endpoints used to fulfill the user request.",
        max_items=MAX_LIST_LENGTH,
    )
    NlpResult: NlpResp = Field(
        description="NLU results include domain, intent, and entities tagged by all of the bot's registered policies."
    )
    DialogState: DialogStateField = Field(
        description="Snapshot of the current short term/session slots and long term/global slots value in the DialogState."
    )


class ChatLatencyField(BaseModel):
    LLMModels: int = Field(ge=0, le=MAX_NUMBER)
    NLPModels: int = Field(ge=0, le=MAX_NUMBER)
    Fulfillment: int = Field(ge=0, le=MAX_NUMBER)
    DialogManager: int = Field(ge=0, le=MAX_NUMBER)
    EndToEnd: int = Field(ge=0, le=MAX_NUMBER)
    TimeUnit: str = Field(default="ms", max_length=MAX_STR_LEN)


class ChatResponse(BaseModel):
    UserId: str = Field(
        description="Unique identifier to recognize which user is interacting with the chat engine. This is populated from the request JSON.",
        max_length=MAX_STR_LEN,
    )
    Query: str = Field(description="The user query which needs to be processed.", max_length=MAX_STR_LEN)
    Response: ResponseField = Field(
        description="Final response template from the chat engine. This field can be picked up from domain rule files or can be formulated directly from custom plugin modules."
    )
    Latency: Optional[ChatLatencyField] = Field(
        default=None,
        description="Latency information for all components of the chat engine which are enabled in bot configurations.",
    )
    Metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Any specific details formed during the dialog."
    )


class EventResponse(BaseModel):
    Events: List[Dict[str, Any]] = Field(
        description="The generated event list for the provided EventType from chat engine.",
        max_items=MAX_LIST_LENGTH,
    )
    EventType: str = Field(description="The event name which was processed.", max_length=MAX_STR_LEN)
    Response: ResponseField = Field(
        description="Final response template from the chat engine. This field can be picked up from domain rule files or can be formulated directly from custom plugin modules."
    )
    Latency: Optional[ChatLatencyField] = Field(
        default=None,
        description="Latency information for all components of the chat engine which are enabled in bot configurations.",
    )


class SetUserIdRequest(BaseModel):
    UserId: str = Field(description="New UserId for the session.", max_length=MAX_STR_LEN)
    SessionId: str = Field(
        description="Unique SessionId for which UserId needs to be updated.", max_length=MAX_STR_LEN
    )


class ChatFormat(BaseModel):
    role: str = Field(max_length=MAX_STR_LEN)
    content: str = Field(max_length=MAX_STR_LEN)


class UserContext(BaseModel):
    UserId: str = Field(
        default=None,
        description="Unique identifier to recognize which user is interacting with the chat engine.",
        max_length=MAX_STR_LEN,
    )
    Context: Dict[str, Any] = Field(
        default={},
        description="The key value pairs which needs to be updated in the context of the provided user memory.",
    )
    ChatHistory: Dict[str, List[ChatFormat]] = Field(
        description="The chat history of the provided user id bot wise.", max_items=MAX_LIST_LENGTH
    )
    EventHistory: Dict[str, Any] = Field(description="The event history of the provided user id bot wise.")
