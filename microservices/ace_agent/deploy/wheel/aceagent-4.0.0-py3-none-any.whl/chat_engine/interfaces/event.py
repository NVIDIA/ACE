# Copyright (c) 2020-2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import asyncio
import json
import logging
import os
import select
import signal
from dataclasses import dataclass
from datetime import timedelta, timezone
from multiprocessing import Process
from multiprocessing.connection import Connection, Pipe
from time import sleep
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4
import traceback
from datetime import datetime
from chat_engine import Bot, Core, CreateBots
from chat_engine.constants import (
    EVENT_LIVENESS_INTERVAL,
    EVENT_LIVENESS_STREAM,
    EVENT_LIVENESS_STREAM_MAX_LENGTH,
    EVENT_SYSTEM_STREAM,
)
from chat_engine.logger.logging_manager import LoggingManager
from chat_engine.utils import EventProvider, event_provider_factory, read_isoformat
from nemoguardrails.utils import new_event_dict, new_uid
from chat_engine.logger import static_log_information

logging_manager = LoggingManager(log_dir=os.environ.get("BOT_LOG_PATH", "/workspace/log"), verbose=False)
logger = logging.getLogger("chat_engine")


RIVA_COLOR = "green"
DEFAULT_AGENT_FALLBACK_RESPONSE = ""

CONTROL_MESSAGE_CHECK_HEALTH = "check health"
CONTROL_MESSAGE_HEALTHY = "healthy"
CONTROL_MESSAGE_STOP_WORKER = "stop worker"

WORKER_STOP_GRACE_PERIOD_SECONDS = 5.0
STALE_STREAM_THRESHOLD = timedelta(minutes=10.0)

# We fork after tokenizers have been used we need to disable tokenizer parallelism to avoid deadlocks
os.environ["TOKENIZERS_PARALLELISM"] = "false"


@dataclass
class PipelineInformation:
    stream_uid: str
    session_uid: str
    user_uid: str
    creation_timestamp: str


_available_bots = {}


def _event_to_str(event: Dict[str, Any]) -> str:
    if "type" not in event:
        return "UnknownEvent()"

    e = dict(event)
    event_type = e["type"]

    action_info = ""
    if "action_uid" in e:
        action_info = f", action_id={e['action_uid'][0:4]}.."

    fields_to_ignore = {
        "uid",
        "event_created_at",
        "source_uid",
        "action_info_modality",
        "action_info_modality_policy",
        "action_info_lifetime",
        "tags",
        "action_uid",
        "type",
        "action_started_at",
        "action_finished_at",
        "action_updated_at",
        "bot_id",
        "user_id",
    }

    if "is_success" in e and e["is_success"]:
        fields_to_ignore.add("was_stopped")
        fields_to_ignore.add("failure_reason")
        fields_to_ignore.add("is_success")

    for f in fields_to_ignore:
        if f in e:
            del e[f]

    for key, value in e.items():
        if key.endswith("_uid") and len(value) > 4:
            e[key] = f"{value[0:4]}.."
        if key.startswith("timer_name"):
            e[key] = f"{value[0:15]}.."

    param_str = ",".join([f"{key}={value}" for key, value in e.items()])
    return f"{event_type}({param_str}{action_info})"


def _create_bots(config_paths: List[str]) -> None:
    """
    Helper method to create and initialize a bot.
    Creates a mapping between bot name + bot version to an instance of Bot and returns the mapping
    """

    # Stores mapping between bot name + bot version to the respective bot instance
    if len(_available_bots) > 0:
        logger.debug("Bots already initialized.")
        return

    try:
        # Discover and initializes the available bots from a path
        bots = CreateBots.from_path(config_paths)

        # For each of the returned bots, store it in a map so that we can pick up
        # the required bot at runtime based on name/version
        for bot in bots:
            if bot.name not in _available_bots:
                _available_bots[bot.name] = {}
            _available_bots[bot.name][bot.version] = bot

    except Exception as e:
        logger.critical(f"Failed to initialize bots due to error {e}. Exiting chat engine server.")


def _get_bot(event: Dict[str, Any]) -> Optional[Bot]:
    """
    Returns a Bot based on bot name and bot version provided with event
    """

    # Check for cases where we don't know bot_name and cannot infer it
    if len(_available_bots) == 0:
        logger.critical("No bots available. Please register a bot by providing the path to its config folder.")
        return None
    elif "bot_name" not in event and len(_available_bots) > 1:
        logger.critical(
            "Multiple bots are deployed. "
            "UMIM events must provide bot name in payload 'bot_name: \"your_bot_name\"'."
        )
        return None

    # We have a bot name
    if "bot_name" not in event:
        bot_name = list(_available_bots.keys())[0]
    else:
        bot_name = event["bot_name"]

    # Make sure bot `bot_name` exists
    if bot_name not in _available_bots:
        logger.critical(
            f"The provided bot name: {bot_name} is not available. "
            "Please register a new bot by providing its configs."
        )
        return None

    # Check for cases where we don't know bot_version and cannot infer it
    if "bot_version" not in event and len(_available_bots[bot_name]) > 1:
        logger.critical(
            f"Multiple bot versions of bot {bot_name} are deployed. "
            "UMIM events must provide bot_version in payload 'bot_version: \"your_bot_version\"'."
        )
        return None

    # We have a bot version
    if "bot_version" not in event:
        bot_version = list(_available_bots[bot_name].keys())[0]
    else:
        bot_version = event["bot_version"]

    if bot_version not in _available_bots[bot_name]:
        logger.critical(
            f"The provided bot version: {bot_name}/{bot_version} is not available. "
            "Please register a new bot by providing its configs."
        )
        return None

    return _available_bots[bot_name][bot_version]


class EventWorker:
    """
    The Event Worker is responsible for handling alle UMIM events for a single pipeline (stream_id).
    Every event worker runs in its own multiprocessing. Process and has its own copy of DM Core.
    """

    def __init__(
        self,
        config_paths: List[str],
        provider_name: str,
        event_provider_host: str,
        event_provider_port: int,
        channel_id: str,
        pipeline_information: PipelineInformation,
        control_loops_per_seconds: float = 2.0,
    ) -> None:
        self.channel_id = channel_id
        self._should_terminate = False
        self._control_loop_sleep_duration = 1.0 / control_loops_per_seconds
        self.pipeline_information = pipeline_information

        self._client = event_provider_factory(
            provider_name,
            event_provider_host,
            event_provider_port,
            [channel_id],
            discard_existing_events=False,
        )

        self._config_paths = config_paths
        # Dict: self._bots[bot_name][bot_version] = Bot()
        self._bots: Dict[str, Dict[str, Bot]] = {}

    def _populate_event_tags(self, event: Dict[Any, str]) -> None:
        """Add tags to identify the event with the current user, session and stream."""
        if "tags" not in event:
            event["tags"] = {}

        event["tags"]["user_uid"] = self.pipeline_information.user_uid
        event["tags"]["session_uid"] = self.pipeline_information.session_uid
        event["tags"]["stream_uid"] = self.pipeline_information.stream_uid

    async def _update_session(self, new_session_id: str) -> None:
        """Update session ID and send out PipelineUpdated event"""
        logger.info(f"Session update: {self.pipeline_information.session_uid} -> {new_session_id}")
        self.pipeline_information.session_uid = new_session_id
        await self._client.send_event(
            EVENT_SYSTEM_STREAM,
            json.dumps(
                new_event_dict(
                    "PipelineUpdated",
                    stream_uid=self.pipeline_information.stream_uid,
                    session_uid=self.pipeline_information.session_uid,
                    user_uid=self.pipeline_information.user_uid,
                )
            ),
        )

    async def event_loop(self) -> None:
        """
        This method does two things
        1. It creates all the bots based on the provided config paths and waits until all bots are ready
        2. It translates any incoming and outgoing UMIM events between DM Core and the Event Provider (e.g. Redis)

        The method terminates only if the event worker is stopped (e.g. due to the pipeline being released)
        """
        try:
            await self._client.update_channel_state(self.channel_id)

            user_id = self.pipeline_information.user_uid
            stream_id = self.pipeline_information.stream_uid

            first_iteration = True
            while not self._should_terminate:
                events = await self._client.receive_events(timedelta(seconds=1))

                if first_iteration:
                    initial_event = new_event_dict(
                        "PipelineAcquired",
                        stream_uid=stream_id,
                        session_uid=self.pipeline_information.session_uid,
                        user_uid=user_id,
                        source_uid="botmaker_dm",
                    )
                    events = [json.dumps(initial_event)] + events
                    first_iteration = False

                for e in events:
                    event = json.loads(e)

                    # TODO: Remove filter once NeMoGuardrails is able to handle those events
                    if "source_uid" not in event or event["source_uid"] == "NeMoGuardrails":
                        logger.debug(f"Ignoring event based on source_uid: {e}")
                        continue

                    bot = _get_bot(event)

                    if bot is None:
                        continue

                    if not bot.is_ready:
                        logger.critical(f"Bot with name {bot.name}/{bot.version} not ready, but should be ready.")
                        continue

                    request = {
                        "UserId": user_id,
                        "StreamId": stream_id,
                        "EventId": event["uid"],
                        "Event": "umim_event",
                        "Metadata": event,
                        "BotName": bot.name,
                        "BotVersion": bot.version,
                        "Context": {},
                    }

                    # Only log input events from other components
                    if "NeMoGuardrails-Colang" not in event["source_uid"]:
                        logger.info(f"IN  ==> {_event_to_str(event)}")

                    response = await Core.get_response_async(bot, request)

                    if (
                        "SessionId" in response
                        and response["SessionId"]
                        and response["SessionId"] != self.pipeline_information.session_uid
                    ):
                        await self._update_session(response["SessionId"])

                    if not response or "Response" not in response:
                        continue

                    out_events = response["Events"]
                    if not out_events:
                        continue

                    for out_event in out_events:
                        self._populate_event_tags(out_event)
                        logger.info(f"OUT <== {_event_to_str(out_event)}")
                        await self._client.send_event(self.channel_id, json.dumps(out_event))

        except Exception as e:
            logger.exception(f"Failed to get DM response from core due to error {e}")

    async def control_loop(self) -> None:
        """
        The control loop method runs until the event worker is stopped. It is communicating
        over a process pipe with the EventInterfaceManager to provide health status updates.
        """
        while not self._should_terminate:
            has_pending_messages = self._connection_to_parent.poll()
            if has_pending_messages:
                message = self._connection_to_parent.recv()
                if isinstance(message, str):
                    if message == CONTROL_MESSAGE_CHECK_HEALTH:
                        self._connection_to_parent.send(CONTROL_MESSAGE_HEALTHY)
                    elif message == CONTROL_MESSAGE_STOP_WORKER:
                        self._should_terminate = True
            await asyncio.sleep(self._control_loop_sleep_duration)

    def start(self, connection_to_main: Connection) -> None:
        self._connection_to_parent = connection_to_main

        # Reset signal handlers otherwise terminating the process will terminate the parent
        # see issue https://github.com/python/cpython/issues/94454
        signal.set_wakeup_fd(-1)

        static_log_information["stream_id"] = self.pipeline_information.stream_uid

    async def run_loops(self) -> None:
        """
        Run the control and event loops.
        """
        self._control_task = asyncio.create_task(self.control_loop())
        self._event_task = asyncio.create_task(self.event_loop())

        await self._control_task
        await self._event_task

    def run(self, connection_to_main: Connection) -> None:
        """
        Run the event worker. This method is intended to be called as part of a
        multiprocess.Proces() call.

        Args:
            connection_to_main (Connection): Connection to the EventInterface manager process
        """
        self.start(connection_to_main)

        try:
            asyncio.run(self.run_loops())

        except Exception as e:
            logger.exception(f"Event worker for channel ({self.channel_id}):\n unhandled error: {str(e)}")
        except KeyboardInterrupt as e:
            self._should_terminate
            logger.info(f"Event worker interrupted by KeyBoardInterrupt: {str(e)}")


@dataclass
class WorkerPoolEntry:
    """
    Stores relevant data about each event worker in the worker pool.
    """

    channel_id: str
    process: Process
    worker: EventWorker
    connection_to_worker: Connection
    pipeline_information: PipelineInformation
    is_ready: bool


def start_worker(worker: EventWorker) -> WorkerPoolEntry:
    """
    Starts an event worker in a new multiprocessing.Process.

    Args:
        worker (EventWorker): The worker to start.

    Returns:
        WorkerPoolEntry: Returns the worker pool entry to be added to the worker pool
    """
    to_worker_connection, from_worker_connection = Pipe()

    p = Process(target=worker.run, args=(from_worker_connection,))
    p.start()

    return WorkerPoolEntry(
        worker.channel_id,
        p,
        worker,
        to_worker_connection,
        worker.pipeline_information,
        False,
    )


class EventInterfaceManager:
    """
    The EventInterfaceManager manages the pool of event workers. It has the following main responsibilities:
    1) It adds and removes event workers based on PipelineAcquired and PipelineReleased events in
    the `EVENT_SYSTEM_STREAM` event stream.
    """

    def __init__(
        self,
        config_paths: List[str],
        event_provider_name: str,
        event_provider_host: str,
        event_provider_port: int,
        initial_stream_uids: List[str],
        debug_mode: bool = False,
    ) -> None:
        self.config_paths = config_paths
        self.event_provider_name = event_provider_name
        self.event_provider_host = event_provider_host
        self.event_provider_port = event_provider_port
        self.initial_stream_uids = initial_stream_uids
        self.worker_pool: Dict[str, WorkerPoolEntry] = {}

        self.PIPELINE_ACQUIRED: str = "acquired"
        self.PIPELINE_RELEASED: str = "released"
        self.PIPELINE_UPDATED: str = "updated"

        self._should_terminate = False
        self.worker_pool_size: int = -1
        self.debug_mode = debug_mode

        self.client: EventProvider

        # Configs
        self.WORKER_GRACE_PERIOD = timedelta(seconds=5)
        self.CONTROL_LOOPS_PER_SECOND = 2
        self.HEALTH_RESPONSE_GRACE_PERIOD = timedelta(seconds=1 / self.CONTROL_LOOPS_PER_SECOND * 4)
        self.READINESS_RESPONSE_GRACE_PERIOD = timedelta(seconds=180)

        _create_bots(config_paths)

        # Wait for bots to be ready
        all_bots_ready = False
        while not all_bots_ready:
            all_bots_ready = True
            for bot_name in _available_bots.keys():
                for bot_version in _available_bots[bot_name]:
                    if not _available_bots[bot_name][bot_version].is_ready:
                        logger.info(f"Bot '{bot_name}/{bot_version}' is not yet initialized. Please wait...")
                        all_bots_ready = False
            sleep(1.0)

        new_pipelines = [
            PipelineInformation(
                stream_id,
                str(uuid4()),
                str(uuid4()),
                datetime.now(timezone.utc).isoformat(),
            )
            for stream_id in initial_stream_uids
        ]
        for pipeline in new_pipelines:
            self._create_event_worker(pipeline)

        self._system_channel = EVENT_SYSTEM_STREAM
        self._liveness_channel = EVENT_LIVENESS_STREAM
        self.last_liveness_message: Optional[datetime] = None
        self._update_worker_pool_size()

    def _update_worker_pool_size(self) -> None:
        if self.worker_pool_size != len(self.worker_pool):
            self.worker_pool_size = len(self.worker_pool)
            logger.info(f"Number of workers changed: {self.worker_pool_size} workers are running.")

    def _get_pipeline_changes(self, events: List[str]) -> Dict[str, Tuple[str, PipelineInformation]]:
        """
        Returns a dict that provides the pipeline status for every stream based on the received system events
        together with Pipeline information.

        Args:
            events (List[str]): List of system events

        Returns:
            Dict[str, Tuple[str, PipelineInformation]]: Dict with pipeline status (string) and pipeline information
            for every stream
        """
        pipeline_changes: Dict[str, Tuple[str, PipelineInformation]] = {}

        for event_json in events:
            event = json.loads(event_json)
            if "type" not in event:
                logger.warning(f"Invalid event received on {self._system_channel}")
                continue

            stream_uid = event["stream_uid"]
            if event["type"] == "PipelineAcquired":
                status = self.PIPELINE_ACQUIRED
            elif event["type"] == "PipelineReleased":
                status = self.PIPELINE_RELEASED
            else:
                status = self.PIPELINE_UPDATED
            new_pipeline = PipelineInformation(
                stream_uid,
                event["session_uid"] if event.get("session_uid", None) else "",
                event["user_uid"] if event.get("user_uid", None) else "",
                event["event_created_at"],
            )
            pipeline_changes[stream_uid] = (status, new_pipeline)

        return pipeline_changes

    async def _is_pipeline_stale(self, pipeline: PipelineInformation) -> bool:
        event_data = await self.client.get_latest_event(f"umim_events_{pipeline.stream_uid}")
        if event_data:
            event = json.loads(event_data)
            time_difference = datetime.now(timezone.utc) - read_isoformat(event["event_created_at"])
        else:
            time_difference = datetime.now(timezone.utc) - read_isoformat(pipeline.creation_timestamp)

        if time_difference >= STALE_STREAM_THRESHOLD:
            logger.debug(
                f"Stream {pipeline.stream_uid} appears to be stale (most recent event {time_difference} ago)."
            )
            return True

        return False

    async def _update_event_workers(self, pipeline_changes: Dict[str, Tuple[str, PipelineInformation]]) -> None:
        """
        Stops and starts workers based on the pipeline states for each stream.

        Args:
            pipeline_changes (Dict[str, Tuple[str, PipelineInformation]]): Dictionary containing pipeline information
            and status for each stream.
        """

        # Remove workers from stale sessions
        for stream_uid in list(self.worker_pool.keys()):
            pipeline = self.worker_pool[stream_uid].pipeline_information
            if await self._is_pipeline_stale(pipeline):
                logger.info("Terminating event worker for stale stream.")
                await self._stop_pipeline(pipeline, self.WORKER_GRACE_PERIOD)

        for status, pipeline in pipeline_changes.values():
            if status == self.PIPELINE_ACQUIRED:
                if not await self._is_pipeline_stale(pipeline):
                    self._create_event_worker(pipeline)
                else:
                    logger.debug("Will not create an event worker for stale stream.")
            elif status == self.PIPELINE_RELEASED:
                await self._stop_pipeline(pipeline, self.WORKER_GRACE_PERIOD)

    def _is_connection_full(self, conn: Connection) -> bool:
        """
        Check if the pipe is full. A full connection can occur if the event worker is not consuming from the
        connection. If a connection sending data to a connection will block indefinitely. We use this method to check
        if the connection is ready to receive new data before sending to the connection.

        Args:
            conn (Connection): _description_

        Returns:
            bool: _description_
        """
        r, w, x = select.select([], [conn], [], 0.0)
        return 0 == len(w)

    async def _send_liveness(self) -> None:
        if not self.last_liveness_message or (
            datetime.now(timezone.utc) - self.last_liveness_message > timedelta(seconds=EVENT_LIVENESS_INTERVAL)
        ):
            event = new_event_dict("LivenessMessage", source_uid="botmaker_dm")
            self.last_liveness_message = datetime.now(timezone.utc)
            await self.client.send_event(self._liveness_channel, json.dumps(event))
            await self.client.trim_channel(self._liveness_channel, EVENT_LIVENESS_STREAM_MAX_LENGTH)

    async def _ensure_all_workers_healthy(self) -> None:
        """
        Ensure that all workers in the pool respond to the health check message.
        If a worker is not able to respond within the grace period the worker is restarted.
        """
        # Skip health checks if in debug mode, because event workers might be blocked on a breakpoint
        # and cannot react to the health messages.
        if self.debug_mode:
            return

        tasks = []
        for w in self.worker_pool.values():
            tasks.append(asyncio.create_task(self._ensure_worker_healthy(w)))

        await asyncio.gather(*tasks)

    async def _ensure_worker_healthy(self, worker_entry: WorkerPoolEntry) -> None:
        """
        Ensure that the worker is able to respond to the health check message. If a worker is not able to respond
        within the grace period the worker is restarted.

        Args:
            worker_entry (WorkerPoolEntry): The worker to check
        """

        if self._should_terminate:
            return

        healthy = False
        if not self._is_connection_full(worker_entry.connection_to_worker):
            try:
                worker_entry.connection_to_worker.send(CONTROL_MESSAGE_CHECK_HEALTH)
                send_time = datetime.now(timezone.utc)

                if worker_entry.is_ready:
                    grace_period = self.HEALTH_RESPONSE_GRACE_PERIOD
                else:
                    grace_period = self.READINESS_RESPONSE_GRACE_PERIOD

                # Since poll() does not support asyncio we have to create this while loop to wait for the response
                while datetime.now(timezone.utc) - send_time < grace_period:
                    if worker_entry.connection_to_worker.poll():
                        response = worker_entry.connection_to_worker.recv()
                        if response == CONTROL_MESSAGE_HEALTHY:
                            if not worker_entry.is_ready:
                                logger.debug(
                                    f"Event worker for channel {worker_entry.channel_id} has started and is healthy"
                                )
                            healthy = True
                            worker_entry.is_ready = True
                        break
                    else:
                        await asyncio.sleep(0.1)
            except BrokenPipeError:
                # Silently return if we are shutting down. Broken pipe to be expected.
                if self._should_terminate:
                    return

                logger.warning(f"Broken Pipe for event worker for channel {worker_entry.channel_id}")
            except ConnectionResetError:
                # Silently return if we are shutting down. Connection reset to be expected.
                if self._should_terminate:
                    return

                logger.warning(f"Connection to worker was reset for channel {worker_entry.channel_id}")

        if not healthy:
            logger.warning(f"Event worker for channel {worker_entry.channel_id} is unhealthy. Restarting it.")
            await self._stop_event_worker(
                worker_entry,
                timeout=timedelta(seconds=WORKER_STOP_GRACE_PERIOD_SECONDS),
            )
            self._create_event_worker(worker_entry.pipeline_information, override=True)

    async def manage_pipelines(self) -> None:
        """
        Manage all pipelines based on PipelineAcquired and PipelineReleased events until the process
        is terminated (SIGINT or SIGTERM is received).

        This will start event workers when new pipelines become available. Those event workers will handle all events
        for that particular pipeline and will be destroyed once a pipeline is released.
        Event workers run in separate processes.
        """
        self.client = event_provider_factory(
            self.event_provider_name,
            self.event_provider_host,
            self.event_provider_port,
            [self._system_channel],
            discard_existing_events=False,
        )

        try:
            while not self._should_terminate:
                events = await self.client.receive_events(timedelta(seconds=1))
                pipeline_changes = self._get_pipeline_changes(events)
                await self._update_event_workers(pipeline_changes)
                await self._ensure_all_workers_healthy()
                await self._send_liveness()
                self._update_worker_pool_size()

        except Exception as e:
            print(f"[ERROR] {str(e)}")
            logger.debug(
                f"Exception in EventInterfaceManager {''.join(traceback.TracebackException.from_exception(e).format())}"
            )

        logger.info("Pipeline management terminated.")

    def _create_event_worker(self, pipeline: PipelineInformation, override: bool = False) -> None:
        """
        Create a new event worker for the provided pipeline.

        Args:
            pipeline (PipelineInformation): Information about the pipeline for which a event worker should be started
            override (bool, optional): Force the creation of an event worker if if there is a (potentially corrupt)
            event worker currently registered for the pipeline. Defaults to False.
        """
        if not override and pipeline.stream_uid in self.worker_pool:
            logger.debug(f"Event worker for stream {pipeline.stream_uid} already exists")
            if pipeline.user_uid:
                self.worker_pool[pipeline.stream_uid].pipeline_information.user_uid = pipeline.user_uid
            if pipeline.session_uid:
                self.worker_pool[pipeline.stream_uid].pipeline_information.session_uid = pipeline.session_uid
            return

        channel_id = f"umim_events_{pipeline.stream_uid}"
        w = EventWorker(
            self.config_paths,
            self.event_provider_name,
            self.event_provider_host,
            self.event_provider_port,
            channel_id,
            pipeline,
        )
        self.worker_pool[pipeline.stream_uid] = start_worker(w)

    async def _stop_pipeline(self, pipeline: PipelineInformation, timeout: timedelta) -> None:
        """
        Stop a pipeline and update the worker pool.

        Args:
            pipeline (PipelineInformation): Pipeline to stop
            timeout (timedelta): Grace period for the pipeline to stop until the worker is killed.
        """
        if pipeline.stream_uid not in self.worker_pool:
            return

        worker_entry = self.worker_pool[pipeline.stream_uid]
        del self.worker_pool[pipeline.stream_uid]
        await self._stop_event_worker(worker_entry, timeout)

    async def _stop_event_worker(self, worker_entry: WorkerPoolEntry, timeout: timedelta) -> None:
        """
        Stop the event worker.

        Args:
            worker_entry (WorkerPoolEntry): Worker to stop
            timeout (timedelta): Grace period for the worker to shut down. Otherwise the worker is killed
        """
        graceful_timeout_fraction = 0.5
        timeout_in_seconds = timeout.total_seconds()

        graceful_timeout = graceful_timeout_fraction * timeout_in_seconds
        termination_timeout = (1.0 - graceful_timeout_fraction) * timeout_in_seconds

        # First ask nicely to stop
        worker_entry.connection_to_worker.send(CONTROL_MESSAGE_STOP_WORKER)
        await asyncio.sleep(graceful_timeout)

        process = worker_entry.process
        if not process.is_alive():
            logger.info(f"Worker for stream {worker_entry.channel_id} gracefully stopped")
            return

        # Worker did not terminate when asked politely, sending termination command with a grace period.
        process.terminate()
        terminated = False
        number_of_checks = 5
        for i in range(number_of_checks):
            if not process.is_alive():
                terminated = True
                break
            await asyncio.sleep(termination_timeout / number_of_checks)

        if not terminated:
            logger.warning(
                f"Killing event worker {process.name} because it did not terminate within timeout = {timeout}s."
            )
            process.kill()

        process.join()
        logger.info(f"Worker for stream {worker_entry.channel_id} terminated.")

    async def shutdown(self, signal_name: str, loop: asyncio.AbstractEventLoop) -> None:
        """
        Setup graceful shutdown handling on SIGINT

        Args:
            signal_name (str): Name of signal received
            loop (asyncio.AbstractEventLoop): Reference to the event loop
        """
        if self._should_terminate:
            return

        print("\nTerminating...")
        logger.info(f"Signal {signal_name} received. Cleaning up.")
        logger.info(f"Worker pool size {len(self.worker_pool)}")
        self._should_terminate = True

    def install_shutdown_handler(self, loop: asyncio.AbstractEventLoop) -> None:
        """
        Installs a signal handler to handle graceful shutdown of all workers.

        Args:
            loop (asyncio.AbstractEventLoop): Reference to the event loop
        """
        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(self.shutdown("SIGINT", loop)))
        loop.add_signal_handler(signal.SIGTERM, lambda: asyncio.ensure_future(self.shutdown("SIGTERM", loop)))

    async def run(self) -> None:
        """
        Run the event interface manager. This will run until the process is terminated externally (SIGTERM) and will
        create and delete workers based on the pipeline events received.
        """
        loop = asyncio.get_event_loop()
        self.pipeline_management_task = loop.create_task(self.manage_pipelines())
        await self.pipeline_management_task

        # Shut down
        logger.info("Stopping all workers...")
        tasks = []
        for w in self.worker_pool.values():
            tasks.append(
                loop.create_task(self._stop_event_worker(w, timedelta(seconds=WORKER_STOP_GRACE_PERIOD_SECONDS)))
            )

        await asyncio.gather(*tasks)
        logger.info("All workers stopped.")
        loop.stop()


def main(
    config_paths: List[str],
    event_provider_name: str,
    event_provider_host: str,
    event_provider_port: int,
    stream_uids: List[str],
    debug_mode: bool,
) -> None:
    """
    Entrypoint for event-based DM interface
    1. Sets up event interface manager that spawns event stream workers based on pipelines available in the system
    2. Each event worker forwards events to DM Core
    """

    logger.info("Starting ACE Agent with event-driven interface")
    manager = EventInterfaceManager(
        config_paths, event_provider_name, event_provider_host, event_provider_port, stream_uids, debug_mode=debug_mode
    )

    # Some versions of nemoguardrails apply patching of the asyncio core library.
    # The patches break redis.asyncio (calls will just hang forever)
    # We try to detect this here and stop immediately.
    from nemoguardrails import patch_asyncio

    if patch_asyncio.nest_asyncio_patch_applied:
        text = (
            "[ERROR] Asyncio patching is enabled. DM in event mode is incompatible with asyncio patching. "
            "Make sure you use nemoguardrails>0.5.0 (excluding 0.5.0)"
        )
        logger.error(text)
        return

    loop = asyncio.get_event_loop()
    manager.install_shutdown_handler(loop)

    loop.create_task(manager.run())
    loop.run_forever()
    logger.info("ACE Agent event interface terminated.")
