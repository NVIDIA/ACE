"""
 copyright(c) 2021 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

from chat_engine.system_slot.datetime_parser import DateFormatter
from typing import List, Union, Any


class Parser:
    """Manages calls to all system slot parser functions"""

    __instance = None
    cache = {}

    @staticmethod
    def get_instance():
        if Parser.__instance is None:
            raise Exception("You must call create_instance before calling get_instance")
        return Parser.__instance

    @staticmethod
    def create_instance():
        if Parser.__instance is None:
            Parser()
        else:
            raise Exception(
                "An instance has already been created. Creation of "
                "second instance of singleton class "
                "Parser is not allowed"
            )
        return Parser.get_instance()

    def __init__(self) -> None:
        """
        Initialize Parser class
        """

        if Parser.__instance is not None:
            raise Exception("Parser is a singleton class. Use get_instance to get access to Parser object")
        else:
            Parser.__instance = self

    @staticmethod
    def destroy():
        Parser.__instance = None

    def parse(self, query_id: str, query: str, slot_name: str, slot_val: List) -> Any:

        if query_id not in Parser.cache:
            Parser.cache[query_id] = {}
        if tuple([query, slot_name, tuple(slot_val)]) in Parser.cache[query_id]:
            return Parser.cache[query_id][tuple([query, slot_name, tuple(slot_val)])]
        if slot_name == "system.date_time":
            answer = DateFormatter().parse_ner(query, slot_val)
            Parser.cache[query_id][tuple([query, slot_name, tuple(slot_val)])] = answer
            return answer
        return slot_val

    @staticmethod
    def clear_cache(query_id: str):

        if query_id in Parser.cache:
            del Parser.cache[query_id]
