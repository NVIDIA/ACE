# Copyright(c) 2021-2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import logging
from time import time
from typing import Any, List, Dict, Tuple
from string import punctuation

# from chat_engine.config_parser.domain_controller import DomainController
from chat_engine import Bot
from chat_engine.core.userdata import SlotData, UserData, DialogState, SlotStateInfo, SlotStateValues
from chat_engine.constants import DST_HISTORY_COUNT, PROCESSOR_POSTPROCESSED, SHORTTERM_MEMORY, LONGTERM_MEMORY

logger = logging.getLogger("chat_engine")


class DialogStateTracker:
    """
    Dialog State Tracker is responsible for maintaining different
    information about ongoing dialogs that will be needed during
    a multi turn dialog. Dialog state tracker is capable of taking
    UserData as input and store all necessary information
    in a separate DialogState as per the requirement.
    """

    def __init__(self, bot: Bot) -> None:
        """Initialization method of Dialog State Tracker"""

        self._dialog_state = {}  # Dict of DialogStates for the current bot
        self._bot = bot

    def set_dialog_state(self, user_id: str, dialog_state: Dict[str, "DialogState"]) -> None:
        """Extract dialog state information from user data"""

        if user_id not in dialog_state:
            dialog_state[user_id] = DialogState()
        self._dialog_state[user_id] = dialog_state[user_id]

    def delete_dialog_state(self, user_id: str):
        """Delete the user_id from the dialog_state object."""

        if user_id in self._dialog_state:
            del self._dialog_state[user_id]

    def get_intents_from_memory(self, user_id: str) -> List[str]:
        """
        Get list of intents in memory for current user
        """
        return self._dialog_state[user_id].intents[:DST_HISTORY_COUNT]

    def get_domains_from_memory(self, user_id: str) -> List[str]:
        """
        Get list of domains in memory for current user
        """
        return self._dialog_state[user_id].domains[:DST_HISTORY_COUNT]

    def get_entities_from_memory(self, user_id: str) -> List[Dict[str, str]]:
        """
        Get list of entities in memory for current user
        """
        return self._dialog_state[user_id].nlu_result[:DST_HISTORY_COUNT]

    def get_queries_from_memory(self, user_id: str) -> List[str]:
        """
        Get list of queries in memory for current user
        """

        return self._dialog_state[user_id].queries[:DST_HISTORY_COUNT]

    def get_labeled_queries_from_memory(self, user_id: str) -> List[str]:
        """
        Get list of labeled queries in memory for current user
        """

        return self._dialog_state[user_id].labeled_queries[:DST_HISTORY_COUNT]

    def get_responses_from_memory(self, user_id: str) -> List[str]:
        """
        Get list of responses in memory for current user
        """

        return self._dialog_state[user_id].responses[:DST_HISTORY_COUNT]

    def get_slots_from_memory(self, user_id: str, slot_name: str) -> List["SlotStateValues"]:
        """
        Public method that returns a list of SlotStateValues if the
        SlotInfo is present in memory for current user.
        Also validates and updates the turn number and timestamp
        associated with slots. Creates an empty DialogState instance
        if user_id does not have any associated memory.

        Args:
            user_id: user id of the present query
            slot_name: slot_name for which value is needed

        Returns:
            A list of SlotStateValue instaces if the slot tag is present
            in memory or an empty list otherwise
        """

        _slot_value = []

        if user_id not in self._dialog_state:
            self._dialog_state[user_id] = DialogState()

        self.__check_time_out(user_id)

        if slot_name in self._dialog_state[user_id].session_slots:
            _slot_value = self._dialog_state[user_id].session_slots[slot_name].values
            self._dialog_state[user_id].session_slots[slot_name].last_conv_time = time()

            logger.info(f"Found valid session slot: {slot_name} with value: {_slot_value}")

        elif slot_name in self._dialog_state[user_id].global_slots:
            _slot_value = self._dialog_state[user_id].global_slots[slot_name].values
            self._dialog_state[user_id].global_slots[slot_name].last_conv_time = time()

            logger.info(f"Found valid global slot: {slot_name} with value: {_slot_value}")

        return _slot_value

    def get_fm_slots_memory(self, user_id: str) -> Dict[str, str]:
        """Returns the fm slots for the last turn"""

        return self._dialog_state[user_id].fulfillment_slots

    def set_fm_slots_memory(self, user_data: UserData) -> Dict[str, str]:
        """Set the fm slots"""

        self._dialog_state[user_data.user_id].fulfillment_slots = user_data.fulfillment_slots

    def update_pronoun_replacement_slots(self, user_data: UserData) -> None:
        """Updates pronoun replacement slots"""

        for slot in user_data.pronoun_replacement_slots:
            if slot in user_data.slots:
                if (str(user_data.slots[slot][0]).strip(punctuation).strip() in user_data.response.text.lower()) or (
                    not len(user_data.pronoun_replacement_slots[slot])
                    and str(user_data.slots[slot][0]).strip(punctuation).strip()
                    in user_data.processed_query[PROCESSOR_POSTPROCESSED]
                ):  # overwrites slots if present in response else stores if slot is empty and present in query or processed query
                    user_data.pronoun_replacement_slots[slot] = user_data.slots[slot][0]

    async def update_dialog_state(self, user_data: UserData, slot_mngr=None) -> None:
        """
        Public method that is called at the end of a conversation
        turn to update the current dialog state. Updates all session and
        global slots of DST by comparing them with current UserData

        Args:
        user_data: A UserData instance that contains prepopulated
                   fields from policy manager
        """
        if user_data.user_id not in self._dialog_state:
            self._dialog_state[user_data.user_id] = DialogState()

        if user_data.partial_response.active:
            if len(self._dialog_state[user_data.user_id].responses) >= 1 and user_data.user_query == "":
                self._dialog_state[user_data.user_id].responses[0] = (
                    self._dialog_state[user_data.user_id].responses[0] + user_data.response.text
                )
            else:
                self._dialog_state[user_data.user_id].responses.insert(0, user_data.response.text)

            if user_data.user_query != "":
                self._dialog_state[user_data.user_id].queries.insert(0, user_data.user_query)
        else:
            self._dialog_state[user_data.user_id].domains.insert(0, user_data.domain)
            self._dialog_state[user_data.user_id].intents.insert(0, user_data.intent)
            self._dialog_state[user_data.user_id].queries.insert(0, user_data.user_query)
            self._dialog_state[user_data.user_id].postprocessed_queries.insert(
                0, user_data.processed_query[PROCESSOR_POSTPROCESSED]
            )
            self._dialog_state[user_data.user_id].labeled_queries.insert(0, user_data.labeled_query)
            self._dialog_state[user_data.user_id].responses.insert(0, user_data.response.text)
            self._dialog_state[user_data.user_id].nlu_result.insert(0, user_data.nlu_result)

        self._dialog_state[user_data.user_id].last_conv_time = time()
        self._dialog_state[user_data.user_id].fulfillment_slots = user_data.fulfillment_slots
        self.update_pronoun_replacement_slots(user_data)
        self._dialog_state[user_data.user_id].pronoun_replacement_slots = user_data.pronoun_replacement_slots

        # TODO: Implement this once slot manager is available
        if self._bot.slot_config and self._bot.slot_manager:
            domain_slots = self._bot.slot_config.get_slot_list()
            slot_mngr = self._bot.slot_manager
            await self.__store_slots_in_memory(user_data, user_data.slots, user_data.linked_slots, slot_mngr)
            self.__update_slot_timestamps(user_data.user_id, domain_slots)
        self.__check_time_out(user_data.user_id)

    def reset_dialog_state(self, user_data: UserData, memory: str = "", bot_name: str = "") -> None:
        """
        Utility function to reset the dialog state for
        a specific user

        Args:
        user_data: The user data of the current query
        memory: The type of memory to be cleared. Can be either
                "shortterm" or "longterm" or blank string which indicates to
                clear all dialog state.
        """

        logger.info(f"Clearing memory type: {memory}")
        logger.info(f"Clearing all fulfillment slots, fulfillment memory and dialog graph state.")
        user_data.fulfillment_memory = {}
        user_data.dialog = None
        user_data.fallback_dialog = None
        user_data.fulfillment_slots = {}
        user_data.slots = {}
        user_data.pronoun_replacement_slots = {}
        user_data.form.active = False
        self._dialog_state[user_data.user_id].domains = []
        self._dialog_state[user_data.user_id].intents = []
        self._dialog_state[user_data.user_id].queries = []
        self._dialog_state[user_data.user_id].responses = []
        self._dialog_state[user_data.user_id].nlu_result = []
        self._dialog_state[user_data.user_id].deleted_slot_tags = []
        user_data.dialog_state[user_data.user_id].event_history[bot_name] = []
        user_data.dialog_state[user_data.user_id].chat_history[bot_name] = []

        if memory == "":
            logger.info(f"Resetting both longterm and shortterm slots in memory.")
            self._dialog_state[user_data.user_id] = DialogState()
            user_data.dialog_state[user_data.user_id] = self._dialog_state[user_data.user_id]

        elif memory == SHORTTERM_MEMORY:
            self.__delete_shortterm_slots(user_data.user_id)
            self._dialog_state[user_data.user_id].session_slots = {}
            logger.info(f"Resetting only dialog state's short term memory.")

        elif memory == LONGTERM_MEMORY:
            self.__delete_longterm_slots(user_data.user_id)
            self._dialog_state[user_data.user_id].global_slots = {}
            logger.info(f"Resetting only dialog state's long term memory.")

        else:
            logger.info(f"Invalid memory type passed to dialog state. Not clearing any info.")

    def reset_slots_turn(self, user_id: str, slots: dict) -> None:
        """
        Public method that resets the slot turn which indicates the
        turns for which slot had been in memory to 0

        Args:
        user_id: The user id of the current query
        slots: slots for which turn has to be reset
        """
        if not len(slots):
            return
        for slot in slots:
            slot_name = slot
            slot_value = slots[slot]
            if (
                slot_name in self._dialog_state[user_id].session_slots
                and slot_value in self._dialog_state[user_id].session_slots[slot_name].values[-1].value
            ):
                self._dialog_state[user_id].session_slots[slot_name].values[-1].turn_num = 0
            elif (
                slot_name in self._dialog_state[user_id].global_slots
                and slot_value in self._dialog_state[user_id].global_slots[slot_name].values[-1].value
            ):
                self._dialog_state[user_id].global_slots[slot_name].values[-1].turn_num = 0

    def get_dialog_state(self, user_id: str) -> DialogState:
        """
        Public method that returns the complete dialog state for
        current user id if present

        Args:
        user_id: The user id of the current query

        Returns:
        A DialogState instance containing stored info of user
        if any. Returns an empty DialogState instance otherwise.
        """

        if user_id not in self._dialog_state:
            dialog_state = DialogState()
            self._dialog_state[user_id] = dialog_state

        self.__check_time_out(user_id)
        return self._dialog_state[user_id]

    def remove_slot(self, user_id: str, slot: str) -> None:
        """
        Public method that removes a session or global slot value for
        current user id if present

        Args:
        user_id: The user id of the current query
        slot: slot tag which needs to be removed from dst
        """

        if slot in self._dialog_state[user_id].session_slots:
            logger.info(f"Removing session slot {slot} from memory")
            del self._dialog_state[user_id].session_slots[slot]

        if slot in self._dialog_state[user_id].global_slots:
            logger.info(f"Removing global slot {slot} from memory")
            del self._dialog_state[user_id].global_slots[slot]

    def get_last_conv_time(self, user_id: str) -> time:
        """Get last conversation time of user with dm"""
        return self._dialog_state[user_id].last_conv_time

    def get_active_user(self) -> List[str]:
        """
        Get list of all active user in chat engine
        """

        return [*self._dialog_state]

    def __check_time_out(self, user_id: str) -> None:
        """
        Utility function to check timeout and validity
        of session slots. Also removes the session slots
        if max time or max duration allowed is exceeded

        Args:
        user_id: The user id of the current query
        """

        delete_tags = []

        for tag, info in self._dialog_state[user_id].session_slots.items():
            if time() - info.last_conv_time > info.max_duration:
                delete_tags.append(tag)
                logger.info(
                    f"Removing session info for slot: {tag} "
                    f"as max duration: {info.max_duration} exceeded "
                    f": {time() - info.last_conv_time}"
                )

            elif info.last_conv_turn_idx > info.max_turn:
                delete_tags.append(tag)
                logger.info(
                    f"Removing session info for slot: {tag} "
                    f"as to max turn {info.max_turn} exceeded. "
                    f"Current turn: {info.last_conv_turn_idx}"
                )

        for key in delete_tags:
            del self._dialog_state[user_id].session_slots[key]
        self._dialog_state[user_id].deleted_slot_tags.extend(delete_tags)

    def __update_slot_timestamps(self, user_id: str, domain_slots: List[str]) -> None:
        """
        1. Update DST session slot timestamp only if the
           slot is not present in the current domain which indicates
           that it has not been used in slot filling
        2. Update DST session slot turn number only if the
           slot is present in the current domain which indicates
           that it has been used in slot filling
        """

        for slot in self._dialog_state[user_id].session_slots:
            if slot not in domain_slots:
                self._dialog_state[user_id].session_slots[slot].last_conv_time = time()
                logger.debug(f"Updated timestamp for {slot}")
            else:
                self._dialog_state[user_id].session_slots[slot].last_conv_turn_idx += 1
                logger.debug(f"Updated turn number for {slot}")

    async def __store_slots_in_memory(
        self, user_data, slots: Dict[str, str], similar_slots: Dict[str, List[SlotData]] = {}, slot_mngr=None
    ) -> None:
        """Utility function to store either slots or
        fulfillment slots in memory.
        """

        curr_slots = {}
        if slot_mngr != None:
            curr_slots = await slot_mngr.get_slots(
                user_data,
                self._bot.slot_config.slot_rules,
                use_defaults=False,
                use_dst_slots=False,
                form_compo_slots=False,
            )
        # Iterate over all slots in userdata and store them in DST
        for tag, values in slots.items():
            rules = self._bot.slot_config.get_slot_rules(tag)

            # Skip storing if slots do have any rules defined
            if rules is None:
                continue

            # Avoid storing slots in memory which have invalid values
            if values is None or values == []:
                continue

            # Attempt to convert the values into SlotData type
            # TODO: Handle case where an ambiguous slot lookup value is the match.
            values = self.__convert_to_slotvalue(values, similar_slots.get(tag, []))

            if rules.memory == SHORTTERM_MEMORY:

                # If current userdata.slot is already present in Session slot
                # then Update the queue to store the latest value at end
                # If not present then add a new entry

                if tag in self._dialog_state[user_data.user_id].session_slots:
                    _current_timestamp = self._dialog_state[user_data.user_id].session_slots[tag].last_conv_time
                    _current_turn_number = self._dialog_state[user_data.user_id].session_slots[tag].last_conv_turn_idx
                    _current_slot_values = self._dialog_state[user_data.user_id].session_slots[tag].values

                    _prev_value = SlotStateValues(value=[], domain=user_data.domain, intent=user_data.intent)

                    for idx, value in enumerate(_current_slot_values):
                        curr_value_dict = SlotStateValues(
                            value=values, domain=user_data.domain, intent=user_data.intent
                        ).__dict__
                        del curr_value_dict["turn_num"]
                        if value.__dict__.items() >= curr_value_dict.items():
                            _prev_value = _current_slot_values[idx]
                            del _current_slot_values[idx]

                    turn_num = 1
                    if values == _prev_value.value:
                        if tag not in curr_slots or values != curr_slots[tag]:
                            turn_num = _prev_value.turn_num + 1

                    _current_slot_values.append(
                        SlotStateValues(
                            value=values, domain=user_data.domain, intent=user_data.intent, turn_num=turn_num
                        )
                    )

                    self._dialog_state[user_data.user_id].session_slots[tag] = SlotStateInfo(
                        name=tag,
                        max_turn=rules.max_turn,
                        max_duration=rules.max_duration,
                        values=_current_slot_values,
                        last_conv_time=_current_timestamp,
                        last_conv_turn_idx=_current_turn_number,
                    )

                else:
                    self._dialog_state[user_data.user_id].session_slots.update(
                        {
                            tag: SlotStateInfo(
                                name=tag,
                                max_turn=rules.max_turn,
                                max_duration=rules.max_duration,
                                values=[
                                    SlotStateValues(
                                        value=values, domain=user_data.domain, intent=user_data.intent, turn_num=1
                                    )
                                ],
                                last_conv_time=time(),
                                last_conv_turn_idx=1,
                            )
                        }
                    )

            elif rules.memory == LONGTERM_MEMORY:

                # If current tag is already present in SlotStateInfo, update all SlotStateValues
                if tag in self._dialog_state[user_data.user_id].global_slots:
                    _current_timestamp = self._dialog_state[user_data.user_id].global_slots[tag].last_conv_time
                    _current_turn_number = self._dialog_state[user_data.user_id].global_slots[tag].last_conv_turn_idx
                    _current_slot_values = self._dialog_state[user_data.user_id].global_slots[tag].values

                    _prev_value = SlotStateValues(value=[], domain=user_data.domain, intent=user_data.intent)

                    for idx, value in enumerate(_current_slot_values):
                        curr_value_dict = SlotStateValues(
                            value=values, domain=user_data.domain, intent=user_data.intent
                        ).__dict__
                        del curr_value_dict["turn_num"]
                        if value.__dict__.items() >= curr_value_dict.items():
                            _prev_value = _current_slot_values[idx]
                            del _current_slot_values[idx]

                    turn_num = 1
                    if values == _prev_value.value:
                        if tag not in curr_slots or values != curr_slots[tag]:
                            turn_num = _prev_value.turn_num + 1

                    _current_slot_values.append(
                        SlotStateValues(
                            value=values, domain=user_data.domain, intent=user_data.intent, turn_num=turn_num
                        )
                    )

                    self._dialog_state[user_data.user_id].global_slots[tag] = SlotStateInfo(
                        name=tag,
                        max_turn=rules.max_turn,
                        max_duration=rules.max_duration,
                        values=_current_slot_values,
                        last_conv_time=_current_timestamp,
                        last_conv_turn_idx=_current_turn_number,
                    )

                else:
                    self._dialog_state[user_data.user_id].global_slots.update(
                        {
                            tag: SlotStateInfo(
                                name=tag,
                                max_turn=rules.max_turn,
                                max_duration=rules.max_duration,
                                values=[
                                    SlotStateValues(
                                        value=values, domain=user_data.domain, intent=user_data.intent, turn_num=1
                                    )
                                ],
                                last_conv_time=time(),
                                last_conv_turn_idx=1,
                            )
                        }
                    )

    def __convert_to_slotvalue(self, slot_values: List[str], similar_slots: List[SlotData]) -> List[Any]:
        """Utility to attempt to convert list of string slot values to a list of SlotValue type.
        Return List[SlotValue] if the slot is a regular slot, return the original if composite slot.
        Inputs:
            slot_values: ["cheeseburger", "tea"]
            similar_slots: [SlotValue(token="tea", similar="coffee")]
        Output:
            values: [SlotValue(token="cheeseburger", similar=""), SlotValue(token="tea", similar="coffee")]"""

        if any(isinstance(slot_value, dict) or isinstance(slot_value, SlotData) for slot_value in slot_values):
            return slot_values

        tagged_slot_values = {entry.value: entry.linked_value for entry in similar_slots}
        values = []
        for value in slot_values:
            values.append(SlotData(value=value, linked_value=tagged_slot_values.get(value, "")))

        return values

    def __delete_shortterm_slots(self, user_id: str):
        """
        Utility method to add all session slots to deleted_slot_tags.
        """

        for tag in self._dialog_state[user_id].session_slots:
            self._dialog_state[user_id].deleted_slot_tags.append(tag)

    def __delete_longterm_slots(self, user_id: str):
        """
        Utility method to add all global slots to deleted_slot_tags.
        """

        for tag in self._dialog_state[user_id].global_slots:
            self._dialog_state[user_id].deleted_slot_tags.append(tag)
