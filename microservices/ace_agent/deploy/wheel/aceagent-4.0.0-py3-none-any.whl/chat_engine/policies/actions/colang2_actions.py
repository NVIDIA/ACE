# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import asyncio
from collections import deque
import json
import logging
import re
import aiohttp
from typing import Deque, Dict, Optional, Any
from urllib.parse import urljoin
from dataclasses import asdict, dataclass

from chat_engine.constants import RAG_FM_ENDPOINT
from nemoguardrails.actions.actions import action
from chat_engine.core.core import Core
from chat_engine.policies.actions.generate_user_intent import generate_user_intent

logger = logging.getLogger("chat_engine")


@action(name="GenerateIntentThenSlotsAction")
async def generate_intent_then_slots_action(
    utterance: str,
    context: Dict[str, Any],
    model_name: Optional[str] = None,
    endpoint: Optional[str] = None,
    confidence_threshold: float = 0.5,
    request_timeout: int = 5,
) -> Any:
    """
    Custom Action to call Intent Slot model used together with Colang 2.0.
    """
    logger.info(f"Calling GenerateIntentThenSlotsAction with utterance={utterance}")
    bot = generate_intent_then_slots_action.bot

    bot.configs.enable_intent_slot = True

    result = await generate_user_intent(
        events=[],
        query=utterance,
        model_name=model_name,
        endpoint=endpoint,
        confidence_threshold=confidence_threshold,
        request_timeout=request_timeout,
        context=context,
        skip_llm=True,
    )

    user_intent = result.events[0]["intent"]
    conf_score = result.events[0]["conf_score"]
    context_slots = result.context_updates

    logger.info(f"GenerateIntentThenSlotsAction intent={user_intent}, entities={context_slots}")
    return {"intent": user_intent, "slots": context_slots, "intent_confidence": conf_score}


@dataclass
class FulfillmentConnectionState:
    is_starting: bool
    in_progress: bool
    is_chunked: bool
    chunks: Deque[str]
    response: Any


fulfillment_connection_state: Dict[str, FulfillmentConnectionState] = {}


async def perform_fulfillment_call(
    method: str,
    url: str,
    headers: Optional[dict] = None,
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    timeout: Optional[int] = 10,
):
    fulfillment_connection_state[url] = FulfillmentConnectionState(
        is_starting=True, in_progress=False, is_chunked=True, chunks=deque(), response=None
    )

    args = {}
    if headers:
        args["headers"] = headers
    if params:
        args["params"] = params
    if data:
        args["json"] = data
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
            async with session.request(method=method, url=url, **args) as response:
                response.raise_for_status()
                if response.headers.get("Transfer-Encoding") == "chunked":
                    fulfillment_connection_state[url].in_progress = True
                    fulfillment_connection_state[url].is_starting = False

                    async for chunk, _ in response.content.iter_chunks():
                        if not chunk:
                            break

                        decoded_chunk = chunk.decode("utf-8")

                        # If the chunk is in a JSON format in the Chat Response format, extract only the text
                        # component from the JSON
                        try:
                            decoded_chunk = json.loads(chunk)["Response"]["Text"]
                        except Exception:
                            pass

                        decoded_chunk = decoded_chunk.replace('"', "").replace("''", "").replace("\n", "'")
                        fulfillment_connection_state[url].chunks.append(decoded_chunk)

                else:
                    fulfillment_connection_state[url].response = await response.json()
                    fulfillment_connection_state[url].is_chunked = False
                    fulfillment_connection_state[url].is_starting = False

    except Exception as e:
        logger.warning(f"Could not connect to fulfillment endpoint={url}. Error {e}")
    finally:
        fulfillment_connection_state[url].is_starting = False
        fulfillment_connection_state[url].in_progress = False


@action(name="InvokeFulfillmentAction")
async def invoke_fulfillment_action(
    endpoint: str,
    request_type: str = "get",
    request_timeout: Optional[int] = 10,
    context: Optional[dict] = {},
    data: Optional[dict] = {},
    additional_context: Optional[dict] = {},
    **kwargs,
) -> Any:

    started = await invoke_fulfillment_streaming_action(
        endpoint=endpoint,
        request_type=request_type,
        request_timeout=request_timeout,
        context=context,
        data=data,
        additional_context=additional_context,
        **kwargs,
    )

    if started:
        await asyncio.sleep(0.2)
        result = await fulfillment_streaming_response_action(endpoint=endpoint)
        return result
    else:
        return None


@action(name="InvokeFulfillmentStreamingAction")
async def invoke_fulfillment_streaming_action(
    endpoint: str,
    request_type: str = "get",
    request_timeout: Optional[int] = 10,
    context: Optional[dict] = {},
    data: Optional[dict] = {},
    additional_context: Optional[dict] = {},
    **kwargs,
) -> bool:
    """
    This function is registered as a custom action in Nemoguardrails and is used to call
    ACE Agent plugin REST endpoints from Nemoguardrails Colang flows.
    """

    logger.info(f"Starting InvokeFulfillmentAction to endpoint : {endpoint}")
    logger.debug(f"kwargs: {kwargs}")
    logger.debug(f"Context: {context}")

    request_parameters_from_context = ["stream_id", "user_id", "session_id"]

    if context is None:
        return False

    if data is None:
        data = {}

    for c in request_parameters_from_context:
        if c not in context:
            logger.info(f"{c} missing from context, skipping fulfillment request.")
            return False

    if not endpoint:
        logger.info("No endpoint for fulfillment action, skipping fulfillment request")
        return False

    if not request_type:
        logger.info("No request type provided in fulfillment action, skipping fulfillment request")
        return False

    request_type = request_type.lower()
    if request_type not in ["post", "get"]:
        logger.info(f"Invalid http request type provided {request_type}, supported request types are GET/POST")
        return False

    if additional_context:
        context.update(additional_context)

    url = urljoin(invoke_fulfillment_streaming_action.bot.configs.plugin_server_url, endpoint)
    params = kwargs
    headers = {"accept": "application/json"}

    # Fill default parameters from context
    for r in request_parameters_from_context:
        params[r] = context[r]

    try:
        if request_type == "post":
            data.update({"context": context})

        asyncio.ensure_future(
            perform_fulfillment_call(
                method=request_type,
                url=url,
                headers=headers,
                params=params,
                data=data,
                timeout=request_timeout,
            )
        )
    except asyncio.TimeoutError:
        logger.info("Http request to plugin server endpoint timed out.")
    except aiohttp.ClientConnectionError:
        logger.info("Failed to establish a connection with plugin server")
    except Exception as e:
        logger.info(f"An error occurred in http request to plugin server endpoint {str(e)}")

    return True


@action(name="FulfillmentStreamingResponseAction")
async def fulfillment_streaming_response_action(endpoint: str, pattern: Optional[str] = None):
    url = urljoin(fulfillment_streaming_response_action.bot.configs.plugin_server_url, endpoint)

    if url not in fulfillment_connection_state:
        logger.warning(f"No connection information for {url}. Did you forget to call InvokeFulfillmentAction()?")
        return ""

    max_tries = 3
    while fulfillment_connection_state[url].is_starting:
        await asyncio.sleep(0.1)
        max_tries -= 1
        if max_tries < 0:
            logger.warning(f"Fulfillment connection never started for {url}.")
            return None

    if fulfillment_connection_state[url].is_chunked:
        data = []
        while fulfillment_connection_state[url].in_progress or len(fulfillment_connection_state[url].chunks) > 0:
            while len(fulfillment_connection_state[url].chunks) > 0:
                data.append(fulfillment_connection_state[url].chunks.popleft())
                if (pattern is not None) and re.findall(pattern, data[-1]):
                    splits = re.split(pattern, data[-1])
                    if len(splits) > 0:
                        logger.debug(f"Pattern did split the last chunk: {splits}")
                        data[-1] = splits[0]
                        fulfillment_connection_state[url].chunks.extendleft(splits[1:])

                    logger.debug(f"Partial Fulfillment response: {''.join(data)}")
                    return "".join(data)
            await asyncio.sleep(0.1)

        if len(data) > 0:
            logger.debug(f"Partial Fulfillment response (no data): {''.join(data)}")
            return "".join(data)
        else:
            return None
    else:
        return fulfillment_connection_state[url].response


@action(name="InvokeRagChainStreamingAction")
async def invoke_rag_chain_streaming_action(
    question: str,
    streaming: Optional[bool] = True,
    endpoint: Optional[str] = RAG_FM_ENDPOINT,
    request_timeout: Optional[int] = 20,
    context: Optional[dict] = {},
) -> bool:
    """
    This function is registered as a custom action in Nemoguardrails and is used to call
    a RAG chain server's generation endpoint from Nemoguardrails Colang flows.
    """

    if not question:
        logger.warning("Empty question in InvokeRagChainStreamingAction.")
        return False

    request_json = {"Query": question, "UserId": context.get("user_id")}

    return await invoke_fulfillment_streaming_action(
        endpoint=endpoint,
        request_type="post",
        request_timeout=request_timeout,
        context=context,
        data=request_json,
    )


@action(name="RagChainStreamingResponseAction")
async def rag_chain_streaming_response_action(endpoint: str = RAG_FM_ENDPOINT, pattern: Optional[str] = None):
    return await fulfillment_streaming_response_action(endpoint, pattern=r"[\.\?\!]")


@action(name="ResetAction")
async def reset_action_colang_2(memory: str = "shortterm", context: Optional[dict] = {}) -> None:
    """
    Reset the slots, chat history, event history and/or create a new session ID based on the memory type
    """
    user_id = context.get("user_id")
    request_id = context.get("event_id") if context.get("event_id") else context.get("query_id")
    user = Core.fetch_user_data(user_id, request_id)
    user.reset_user_memory = memory
