# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

from typing import List, Optional


async def generate_value(
    instructions: str,
    events: List[dict],
    var_name: Optional[str] = None,
    confidence_threshold: Optional[float] = 0.5,
):
    """Generate slot values"""
    # TODO: Until llm is enabled at DM use NG implementation
    # Slots can be used from generate_user_intent

    last_event = events[-1]
    assert last_event["type"] == "StartInternalSystemAction"
    self = generate_value.policy_instance

    if not var_name:
        var_name = last_event["action_result_key"]

    # We search for the most relevant flows.
    examples = ""
    if self.use_embedding_search:
        results = await self.embedding_search.search(
            text=f"${var_name} = ", top_k=5, store_name=[f"{generate_value.bot.name}_user_message"]
        )
        if confidence_threshold is not None:
            results = [r for r in results if r.get("confidence_score") >= confidence_threshold]

    else:
        results = self.flows_index.search(text=f"${var_name} = ", max_results=5)

    # We add these in reverse order so the most relevant is towards the end.
    for result in reversed(results):
        examples += f"{result.text}\n\n"

    # TODO: Generate prompt and sent it to llm to extract var
    # return literal_eval(value)
