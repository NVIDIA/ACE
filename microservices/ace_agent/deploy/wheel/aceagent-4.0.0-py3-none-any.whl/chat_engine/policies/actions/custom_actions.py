# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import requests
import logging
import json
import os
from urllib.parse import urljoin
from typing import Optional, Any, List, Union, Dict
from time import time
import aiohttp
import asyncio

from chat_engine import Bot
from chat_engine.core.userdata import UserData
from chat_engine.core.core import Core
from chat_engine.nlp.nlp_response import TokenClassValue, Classification
from chat_engine.constants import (
    NLU_NER,
    NLU_QNA,
    NLU_TEXT_CLASSIFIER,
    USER_SLOTS_ACTION,
    RAG_FM_ENDPOINT,
)
from chat_engine.policies.utils import get_response_data

logger = logging.getLogger("chat_engine")


def disambiguate_file_path(file_name: str, bot_dir_path: str = "") -> str:
    for root, dirs, files in os.walk(bot_dir_path):
        if file_name in files:
            return os.path.abspath(os.path.join(root, file_name))
    return file_name


# TODO: Connect with fulfullment manager and make sure the FM response json is parsed and FM result populated in userdata
async def fulfillment_action(
    endpoint: str,
    request_type: str = "get",
    request_timeout: Optional[int] = 10,
    streaming: Optional[bool] = True,
    context: Optional[dict] = {},
    data: Optional[dict] = {},
    **kwargs,
) -> Any:
    """
    This function is registered as a custom action in Nemoguardrails and is used to call
    ACE Agent plugin REST endpoints from Nemoguardrails Colang flows.
    """

    if endpoint and request_type:
        url = urljoin(fulfillment_action.bot.configs.plugin_server_url, endpoint)
        params = kwargs
        headers = {"accept": "application/json"}
        response = None
        request_type = request_type.lower()

        bot: Bot = fulfillment_action.bot
        user_id = context.get("user_id")
        request_id = context.get("event_id") if context.get("event_id") else context.get("query_id")
        user: UserData = Core.fetch_user_data(user_id, request_id)

        # WAR: Remove parameters that have None value to prevent aiohttp from throwing an error
        params = {key: value for key, value in params.items() if value is not None}

        if request_type == "post":
            try:

                # Pass the available colang context as part of request body if available
                if context:
                    data.update({"context": context})

                data.update({"metadata": user.metadata})

                # Pass the available conversation context as part of request body in a special variable
                data.update({"conv_history": user.dialog_state[user.user_id].chat_history.get(bot.name)})

                start = time()
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(request_timeout)) as session:
                    async with session.post(url, headers=headers, params=params, json=data) as response:
                        response.raise_for_status()
                        streaming_handler = user.colang_streaming_handler if streaming else None
                        response_data = await get_response_data(response, streaming_handler)

                user.latency.fulfillment += time() - start
                logger.info(
                    f"Response received from plugin server: {response_data}. Latency: {(time() - start) * 1000} milliseconds."
                )
                return response_data

            except asyncio.TimeoutError:
                logger.info("Http request to plugin server endpoint timed out.")
            except aiohttp.ClientConnectionError:
                logger.info(f"Failed to establish a connection with plugin server")
            except Exception as e:
                logger.info(f"An error occurred in http request to plugin server endpoint {str(e)}")
                if hasattr(response, "text"):
                    logger.info(f"{response.text}")

            return None

        elif request_type == "get":
            try:
                data.update({"context": context})
                start = time()
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(request_timeout)) as session:
                    async with session.get(url, headers=headers, params=params, json=data) as response:
                        response.raise_for_status()
                        streaming_handler = user.colang_streaming_handler if streaming else None
                        response_data = await get_response_data(response, streaming_handler)

                user.latency.fulfillment += time() - start
                logger.info(
                    f"Response received from plugin server: {response_data}. Latency: {(time() - start) * 1000} milliseconds."
                )
                return response_data

            except asyncio.TimeoutError:
                logger.info("Http request to plugin server endpoint timed out.")
            except aiohttp.ClientConnectionError:
                logger.info(f"Failed to establish a connection with plugin server")
            except Exception as e:
                logger.info(f"An error occurred in http request to plugin server endpoint {str(e)}")
                if hasattr(response, "text"):
                    logger.info(f"{response.text}")

            return None

        else:
            logger.info(f"Invalid http request type provided {request_type}, supported request types are GET/POST")
            return None
    else:
        logger.info(f"No endpoint name or request type provided in fulfillment action, skipping fulfillment request")
        return None


# ------------------------------------
# NLP server Action Implementations
# ------------------------------------
# TODO: Connect with NLP manager and make sure the NLP responses are populated in userdata
async def ner_action(
    query: Optional[str] = "",
    model_name: Optional[str] = "riva_ner",  # riva_ner, zero_shot_ner
    endpoint: Optional[str] = "",
    confidence_threshold: Optional[float] = 0.5,
    request_timeout: Optional[int] = 5,
    context: Optional[dict] = None,
    **kwargs,
) -> Dict[str, List[str]]:
    """
    This function is registered as a custom action in Nemoguardrails and is used to call
    ACE Agent NLP Server NER model REST endpoints from Nemoguardrails Colang flows.
    """

    bot: Bot = ner_action.bot
    user_id = context.get("user_id")
    request_id = context.get("event_id") if context.get("event_id") else context.get("query_id")
    user = Core.fetch_user_data(user_id, request_id)

    # Setting parameters from NLP model configs
    if bot.nlp_model_configs:
        for config in bot.nlp_model_configs:
            if config.task_name == USER_SLOTS_ACTION:
                logger.info(f"Using NLP models configs for {USER_SLOTS_ACTION}: {config}")
                model_name = config.model_name if config.model_name != "" else model_name
                confidence_threshold = config.confidence_threshold
                request_timeout = config.request_timeout
                endpoint = config.endpoint

    headers = {"accept": "application/json", "Content-Type": "application/json"}
    data = {}
    if query:
        data["query"] = query.replace("?", "")
    else:
        if context:
            data["query"] = context.get("last_user_message", "").replace("?", "")

    if not data["query"]:
        logger.warning("Empty query found, skipping ner request")
        return {}

    if model_name:
        data["model_name"] = model_name

    response = None
    confidence_threshold = float(confidence_threshold)
    request_timeout = int(request_timeout)

    url = ""
    if endpoint:  # For custom provided endpoint from colang
        url = urljoin(ner_action.bot.configs.nlp_server_url, endpoint)

    else:  # We automatically find the url from health monitor
        url = ner_action.bot.health_monitor.get_nlp_endpoint(NLU_NER)
        data["anchors"] = {}
        for key, value in kwargs.items():
            data["anchors"][value] = key

    if url is None:
        logger.info(
            "Named Entity Recognizer model which is needed for ner_action is not deployed behind NLP server yet. Skipping this action."
        )
        return {}

    try:
        start = time()
        response = requests.post(url, headers=headers, data=json.dumps(data), timeout=request_timeout)
        user.latency.nlu_ner += time() - start
        response.raise_for_status()
        logger.info(
            f"Response received from NLP server for NER request: {response.json()}. Latency: {(time() - start) * 1000} milliseconds."
        )
    except requests.exceptions.Timeout:
        logger.info("Http request to NLP server ner model endpoint timed out.")
    except requests.exceptions.RequestException as e:
        logger.info(f"An error occurred in http request to NLP server ner model endpoint {str(e)}")

    if response and response.json():
        entities = response.json().get("entities", [])
        parsed_entities = {}
        if entities:
            for entity in entities:
                # Convert the returned entities in a colang parsable format
                conf_score = entity["label"]["score"]
                name = entity["label"]["class_name"]
                value = entity["token"]
                span = entity["span"]

                if conf_score <= confidence_threshold:
                    logger.info(f"Ignoring ner model response: {entity} due to low confidence score: {conf_score}")
                    continue

                if name in parsed_entities:
                    parsed_entities[name].append(value)
                else:
                    parsed_entities[name] = [value]

                # Populate the entity in userdata
                ent = TokenClassValue(
                    token=value,
                    span=span,
                    label=Classification(class_name=name, score=conf_score),
                )
                user.nlu_result.ner_result.slots.append(ent)
            return parsed_entities
        else:
            logger.info("No entities found in the response returned by NLP server ner model endpoint")
            return {}
    else:
        logger.info(f"Invalid or empty response returned by the NLP server ner model endpoint {response}")
        return {}


async def eqa_action(
    kb_document_path: str = "",
    kb_data: Union[List[str], str] = "",
    top_n: int = 2,
    query: str = "",
    model_name: Optional[str] = "",
    endpoint: Optional[str] = "",
    confidence_threshold: Optional[float] = 0.5,
    request_timeout: Optional[int] = 5,
    context: Optional[dict] = None,
    **kwargs,
) -> str:
    """
    This function is registered as a custom action in Nemoguardrails and is used to call
    ACE Agent NLP Server EQA model REST endpoints from Nemoguardrails Colang flows.
    """

    bot: Bot = eqa_action.bot
    user_id = context.get("user_id")
    request_id = context.get("event_id") if context.get("event_id") else context.get("query_id")
    user = Core.fetch_user_data(user_id, request_id)

    # Setting parameters from NLP model configs
    if bot.nlp_model_configs:
        for config in bot.nlp_model_configs:
            if config.task_name == NLU_QNA:
                logger.info(f" Using NLP models configs for {NLU_QNA}: {config}")
                model_name = config.model_name if config.model_name != "" else model_name
                confidence_threshold = config.confidence_threshold
                request_timeout = config.request_timeout
                endpoint = config.endpoint

    kb_document_str = ""
    if kb_document_path:
        kb_document_path = disambiguate_file_path(
            bot_dir_path=os.path.dirname(eqa_action.bot.config_path), file_name=kb_document_path
        )
        if os.path.exists(kb_document_path):
            try:
                kb_document_str = open(kb_document_path, "r").read()
            except Exception as e:
                logger.info(f"Exception occurred while opening QnA KB document at path: {kb_document_path}")
        else:
            logger.debug(f"Invalid path provided for QnA KB document: {kb_document_path}")

    query_str = ""
    if query:
        query_str = query.replace("?", "")
    else:
        if context:
            query_str = context.get("last_user_message", "").replace("?", "")

    kb_str = []
    if kb_document_str:
        kb_str = [kb_document_str]
    if kb_data:
        if isinstance(kb_str, list):
            kb_str.extend(kb_data)
        else:
            kb_str += kb_data
    if not query_str or not kb_str:
        logger.warning("Either query str or knowledge base str is empty, skipping eqa request")
        return ""

    headers = {"accept": "application/json", "Content-Type": "application/json"}
    data = {"query": query_str, "documents": kb_str, "top_n": top_n}
    if model_name:
        data["model_name"] = model_name

    url = ""
    if endpoint:  # For custom provided endpoint from colang
        url = urljoin(eqa_action.bot.configs.nlp_server_url, endpoint)
    else:  # We automatically find the url from health monitor
        url = eqa_action.bot.health_monitor.get_nlp_endpoint(NLU_QNA)

    if url is None:
        logger.warning(
            "Extractive QA model which is needed for eqa_action is not deployed behind NLP server yet. Skipping this action."
        )
        return ""

    response = None
    top_n = int(top_n)
    confidence_threshold = float(confidence_threshold)
    request_timeout = int(request_timeout)

    try:
        start = time()
        response = requests.post(url, headers=headers, data=json.dumps(data), timeout=request_timeout)
        user.latency.nlu_qna += time() - start
        response.raise_for_status()
        logger.info(
            f"Response received from NLP server for QNA request: {response.json()}. Latency: {(time() - start) * 1000} milliseconds."
        )
    except requests.exceptions.Timeout:
        logger.info("Http request to NLP server eqa model endpoint timed out.")
    except requests.exceptions.RequestException as e:
        logger.info(f"An error occurred in http request to NLP server eqa model endpoint {str(e)}")

    if response and response.json():
        results = response.json().get("results", [])
        if results:
            result = results[0]
            conf_score = result["score"]
            if conf_score >= confidence_threshold:
                return result["answer"]
            else:
                logger.info(f"Ignoring eqa model response due to low confidence score: {conf_score}")
                return ""
        else:
            logger.info("No results found in the response returned by NLP server eqa model endpoint")
            return ""
    else:
        logger.info(f"Invalid or empty response returned by the NLP server eqa model endpoint {response}")
        return ""


async def text_classifier_action(
    query: Optional[str] = "",
    model_name: Optional[str] = "",
    endpoint: Optional[str] = "",
    confidence_threshold: Optional[float] = 0.5,
    request_timeout: Optional[int] = 5,
    context: Optional[dict] = None,
    **kwargs,
) -> str:
    """
    This function is registered as a custom action in Nemoguardrails and is used to call
    ACE Agent NLP Server text classification model REST endpoints from Nemoguardrails Colang flows.
    """

    bot: Bot = text_classifier_action.bot
    user_id = context.get("user_id")
    request_id = context.get("event_id") if context.get("event_id") else context.get("query_id")
    user = Core.fetch_user_data(user_id, request_id)

    # Setting parameters from NLP model configs
    if bot.nlp_model_configs:
        for config in bot.nlp_model_configs:
            if config.task_name == NLU_TEXT_CLASSIFIER:
                logger.info(f" Using NLP models configs for {NLU_TEXT_CLASSIFIER}: {config}")
                model_name = config.model_name if config.model_name != "" else model_name
                confidence_threshold = config.confidence_threshold
                request_timeout = config.request_timeout
                endpoint = config.endpoint

    headers = {"accept": "application/json", "Content-Type": "application/json"}
    data = {}
    if query:
        data["query"] = query.replace("?", "")
    else:
        if context:
            data["query"] = context.get("last_user_message", "").replace("?", "")

    if not data["query"]:
        logger.warning("Empty query found, skipping text classification request")
        return {}

    if model_name:
        data["model_name"] = model_name

    response = None
    confidence_threshold = float(confidence_threshold)
    request_timeout = int(request_timeout)

    url = ""
    if endpoint:  # For custom provided endpoint from colang
        url = urljoin(bot.configs.nlp_server_url, endpoint)

    else:  # We automatically find the url from health monitor
        url = bot.health_monitor.get_nlp_endpoint(NLU_TEXT_CLASSIFIER)

    if url is None:
        logger.warning("Text classifier model is not deployed behind NLP server yet. Skipping this action.")
        return ""

    try:
        start = time()
        response = requests.post(url, headers=headers, data=json.dumps(data), timeout=request_timeout)
        user.latency.nlu_text_classifier += time() - start
        response.raise_for_status()
        logger.info(
            f"Response received from NLP server for text classification request: {response.json()}. Latency: {(time() - start) * 1000} milliseconds."
        )
    except requests.exceptions.Timeout:
        logger.info("Http request to NLP server text classification model endpoint timed out.")
    except requests.exceptions.RequestException as e:
        logger.info(f"An error occurred in http request to NLP server text classifier model endpoint {str(e)}")

    if response and response.json():
        class_name = response.json().get("class_name", "")
        conf_score = response.json().get("score", None)
        if not class_name or not conf_score:
            logger.info(
                "Class name or confidence score not found in the text classification response returned by NLP server"
            )
            return ""
        if conf_score >= confidence_threshold:
            return class_name
        else:
            logger.info(f"Ignoring text classifier model response due to low confidence score: {conf_score}")
            return ""
    else:
        logger.info(f"Invalid or empty response returned by the NLP server text classifier model endpoint {response}")
        return ""


async def reset_action(memory: str = "shortterm", context: Optional[dict] = {}) -> None:
    """
    Reset the slots, chat history, event history and/or create a new session ID based on the memory type
    """

    user_id = context.get("user_id")
    request_id = context.get("event_id") if context.get("event_id") else context.get("query_id")
    user = Core.fetch_user_data(user_id, request_id)
    user.reset_user_memory = memory


async def chat_plugin(
    endpoint: str,
    question: Optional[str] = "",
    user_id: Optional[str] = "",
    streaming: Optional[bool] = True,
    request_timeout: Optional[int] = 20,
    context: Optional[dict] = {},
) -> str:
    """
    This function is registered as a custom action in Nemoguardrails and is used to call
    a RAG chain server's generation endpoint from Nemoguardrails Colang flows.
    """

    if not question:
        question = context.get("last_user_message", "")

    request_json = {"Query": question, "UserId": user_id if user_id else context.get("user_id")}

    response = await fulfillment_action(
        endpoint=endpoint,
        request_type="post",
        streaming=streaming,
        context=context,
        request_timeout=request_timeout,
        data=request_json,
    )
    if response:
        return response

    return ""
