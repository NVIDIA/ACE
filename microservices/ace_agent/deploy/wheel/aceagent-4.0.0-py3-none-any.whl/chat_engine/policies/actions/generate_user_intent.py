# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import logging
import json
import requests
from typing import Optional, List, Any
from urllib.parse import urljoin
from dataclasses import asdict
from copy import deepcopy
from time import time

from chat_engine.constants import NLU_INTENT_SLOT
from chat_engine.core.userdata import SlotData
from chat_engine.core.core import Core
from nemoguardrails.actions.actions import ActionResult, action
from nemoguardrails.utils import new_event_dict
from chat_engine.policies.actions.custom_actions import ner_action
from chat_engine.constants import INTENT_NO_MATCH, EVENT_NO_MATCH, USER_INTENT_ACTION, DOMAIN_NO_MATCH
from chat_engine.nlp.nlp_response import Classification, TokenClassValue, TokenClassResponse
from chat_engine.nlp.nlp_utils import update_entities, get_entities
from chat_engine.policies.utils import get_lookup_result, get_regex_result, update_llm_context

logger = logging.getLogger("chat_engine")


@action(is_system_action=True)
async def generate_user_intent(
    events: List[dict],
    query: Optional[str] = "",
    model_name: Optional[str] = "",
    endpoint: Optional[str] = "",
    confidence_threshold: Optional[float] = 0.5,
    request_timeout: Optional[int] = 5,
    context: Optional[dict] = None,
    skip_llm: bool = False,
) -> Any:
    """
    This function is registered as a custom action in Nemoguardrails and is used to call
    ACE Agent Legacy model endpoints endpoints behind NLP server and fallback to Nemoguardrails Colang
    flows if NLP server is not deployed.
    """

    logger.info(f"Overridden system action generate_user_intent with query={query}")
    headers = {"accept": "application/json", "Content-Type": "application/json"}
    self = generate_user_intent.policy_instance
    bot = generate_user_intent.bot
    configs = generate_user_intent.configs
    user_id = context.get("user_id", "")
    request_id = context.get("event_id") if context.get("event_id") else context.get("query_id", "")
    user = Core.fetch_user_data(user_id, request_id)
    user_intent = user.intent
    user_event = user.event
    url = ""
    data = {}
    slots = {}
    entities_tcv = []
    enable_intent_slot_call = bot.configs.enable_intent_slot

    # We update all the available context variables as a valid llm prompt context
    update_llm_context(generate_user_intent.rails, context=context)

    # Setting parameters from NLP model configs
    if bot.nlp_model_configs:
        for config in bot.nlp_model_configs:
            if config.task_name == USER_INTENT_ACTION:
                logger.info(f" Using NLP models configs for {USER_INTENT_ACTION}: {config}")
                model_name = config.model_name if config.model_name != "" else model_name
                confidence_threshold = config.confidence_threshold
                request_timeout = config.request_timeout
                endpoint = config.endpoint

    # If query is passed in params, use it, else extract the query from system context
    if query:
        data["query"] = query.replace("?", "")
    else:
        if context:
            data["query"] = context.get("last_user_message", "").replace("?", "")

    if not data["query"]:
        logger.warning("Empty query found, skipping Joint Intent Slot model request")
        return {}

    # If model name is passed in params, use it.
    if model_name:
        data["model_name"] = model_name

    # If endpoint is passed in params, use it, else get it from NLU manager
    if endpoint:
        url = urljoin(bot.configs.nlp_server_url, endpoint)
    else:
        url = bot.health_monitor.get_nlp_endpoint(task_name=NLU_INTENT_SLOT)

    if url is None:
        logger.info(
            "Joint Intent Slot model is not yet deployed behind NLP server yet. Skipping this action for generate_user_intent."
        )
        enable_intent_slot_call = False

    response = None
    confidence_threshold = float(confidence_threshold)
    request_timeout = int(request_timeout)
    conf_score = 0.0

    # We first try to call NLP server endpoint for intent slot model
    if enable_intent_slot_call:
        try:
            start = time()
            response = requests.post(url, headers=headers, data=json.dumps(data), timeout=request_timeout)
            user.latency.nlu_intent_slot += time() - start
            response.raise_for_status()
            logger.info(
                f"Response received from NLP server for Joint Intent Slot request: {response.json()}. Latency: {(time() - start) * 1000} milliseconds."
            )
        except requests.exceptions.Timeout:
            logger.info("Http request to NLP server Joint Intent Slot model endpoint timed out.")
        except requests.exceptions.RequestException as e:
            logger.info(f"An error occurred in http request to NLP server Joint Intent Slot model endpoint {str(e)}")

    # We try to parse the response received from intent slot model
    if response and response.json():
        domain = response.json().get("domain", {})
        intent = response.json().get("intent", {})
        entities = response.json().get("entities", None).get("entities", None)

        # Populate the result in userdata
        user.nlu_result.intent_slot_result.domain.class_name = domain.get("class_name", DOMAIN_NO_MATCH)
        user.nlu_result.intent_slot_result.domain.score = domain.get("score", 0.0)
        user.nlu_result.intent_slot_result.intent.class_name = intent.get("class_name", INTENT_NO_MATCH)
        user.nlu_result.intent_slot_result.intent.score = intent.get("score", 0.0)

        # If intent is available and userdata.intent is nomatch, we extract the recognized intent
        if intent and user_intent == INTENT_NO_MATCH:
            conf_score = intent.get("score", 0.0)
            class_name = intent.get("class_name", "")
            if conf_score >= confidence_threshold:
                user_intent = class_name
            else:
                logger.info(f"Ignoring joint intent slot model response due to low confidence score: {conf_score}")
        else:
            logger.info("No intent found in the response returned by NLP server joint intent slot model endpoint")

        # If slots are recognized from intent slot model, we update them in userdata and system context
        if entities:
            for entity in entities:
                entity_class_name = entity.get("label", {}).get("class_name", "")
                score = entity["label"]["score"]
                token = entity.get("token", {})
                span = entity["span"]
                if entity_class_name not in slots:
                    slots[entity_class_name] = []
                slots[entity_class_name].append(token)
                ent = TokenClassValue(
                    token=token,
                    span=span,
                    label=Classification(class_name=entity_class_name, score=score),
                )
                user.nlu_result.intent_slot_result.slots.slots.append(ent)
                entities_tcv.append(ent)
        else:
            logger.info("No slots found in the response returned by NLP server joint intent slot model endpoint")

    # We also run NER on the user query to extract any entities
    ner_result = await ner_action(query=data["query"], context=context)
    if ner_result:
        for key, value in ner_result.items():
            if type(value) == list:
                slots[key] = value
            else:
                slots[key] = [value]
        entities_tcv.extend(user.nlu_result.ner_result.slots)
    context_slots = {"slot_results": deepcopy(slots)}

    # Delete any slots, which are removed by Dialog State Tracker from colang context
    dst = bot.state_manager.get_dialog_state(user.user_id)
    if dst.deleted_slot_tags and len(dst.deleted_slot_tags) > 0:
        for slot, slot_val in context.items():
            if slot in ["last_user_message", "last_bot_message"]:
                continue
            if slot in dst.deleted_slot_tags:
                logger.debug(f"Deleted {slot} from colang context due to DST max turn")
                context_slots[slot] = None
            elif slot not in context_slots:
                context_slots[slot] = slot_val
        dst.deleted_slot_tags = []

    # We update the userdata with all the extracted slots and entities data
    if user:
        user.intent = user_intent
        user.entities = update_entities(user, get_entities(TokenClassResponse(entities_tcv)))
        slots = await execute_slot_manager(data["query"], slots)
        user.slots.update(slots)

    # We update colang context with the slots returned from slot manager and linked slots
    context_slots.update(user.slots)

    # Deserialize the linked slots dictionary
    linked_slots = {}
    for slot, links in user.linked_slots.items():
        linked_slots[slot] = []
        for value in links:
            if isinstance(value, SlotData):
                linked_slots[slot].append(asdict(value))
            else:
                linked_slots[slot].append(value)

    context_slots.update({"linked_slots": linked_slots})

    # If we don't find any valid intent for the query or the intent returned in nomatch, we move to LLM
    if not skip_llm and (not user_intent or user_intent == INTENT_NO_MATCH):
        # We will now try to call vanilla NG generate_user_intent
        # TODO, add NLP server LLM calls here

        action_result = None

        # We check if LLM model has been defined in the config and continue based on it.
        if self.llm_model_available:
            if not self._actions.config.user_messages:
                logger.info("Setting intent as none, since no user messages were defined.")
                user_intent = "none"
            else:
                logger.info("Attempting Nemoguardrails generate_user_intent action")
                try:
                    start = time()
                    action_result = await self._actions.generate_user_intent(events, context, configs)
                    user.latency.llm_models += time() - start
                    logger.debug(f"Latency for Nemoguardrails call for generate_user_inent: {time() - start} seconds.")
                except Exception as e:
                    logger.debug(f"Exception occurred while calling Nemoguardrails generate_user_intent: {e}")

                if action_result and len(action_result.events) > 0:
                    user_intent = action_result.events[0].get("intent", "")

        # If LLM also doesn't give valid intent we then perform embedding search on the user query
        # to find most relevant user_intent
        if user_intent == "unknown message" or user_intent == INTENT_NO_MATCH:
            embedding_search_results = await self.search_user_embedding_index(
                query=data["query"], confidence_threshold=confidence_threshold
            )
            embedding_search_intent = await self.get_embedding_index_user_intent(embedding_search_results)
            if embedding_search_intent:
                logger.info(f"Found nearest match for user intent from embedding search: {embedding_search_intent}")
                user_intent = embedding_search_intent

    logger.info(
        f"Intent recognized by overridden generate user intent action: {user_intent}, entities: {user.entities}"
    )
    return ActionResult(
        events=[new_event_dict("UserIntent", intent=user_intent, conf_score=conf_score)],
        context_updates=context_slots,
    )


async def execute_slot_manager(query: str, slots: List[str]):
    """
    Function to invoke ACE Agent slot manager module along with slot
    lookup and regex.
    """

    self = generate_user_intent.policy_instance
    bot = generate_user_intent.bot
    user = generate_user_intent.user_data

    if not bot.slot_config:
        return slots

    if not bot.slot_manager:
        return slots

    slot_rules = bot.slot_config.slot_rules
    slot_lookup_rules = bot.slot_config.slot_lookup_rules
    slot_regex_rules = bot.slot_config.slot_regex_rules
    # Running lookup on the slots
    slot_lookup_result = get_lookup_result(user, query, slot_lookup_rules)
    user.entities += update_entities(user, get_entities(slot_lookup_result), False)
    # Running regex on the slots
    slot_regex_result = get_regex_result(user, query, slot_regex_rules)
    user.entities += update_entities(user, get_entities(slot_regex_result), False)

    slots = await bot.slot_manager.get_slots(
        user,
        slot_rule=slot_rules,
        ent=user.entities,
        use_dst_slots=True,
        use_defaults=False,
    )
    logger.info(f"Slots resolved by Slot Manager: {slots}")
    return slots
