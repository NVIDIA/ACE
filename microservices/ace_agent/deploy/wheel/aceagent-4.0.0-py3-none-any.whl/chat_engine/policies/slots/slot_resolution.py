# Copyright(c) 2021-2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
chat engine processor module called from slot_handler
which corrects mispelled or partially tagged
slot values and slot tags based on lookup lists.
Correction can happen based on edit distance or substring based search.
"""

import logging
import json
from typing import List, Dict, Any
from chat_engine.bot_factory.configs import SlotConfig, SlotRules
from chat_engine.core.userdata import UserData
from chat_engine.nlp.nlp_utils import get_closest_match
from chat_engine.constants import VALID_SLOT_DATATYPES
import re

logger = logging.getLogger("chat_engine")


class SlotResolution:
    def __init__(self, slot_config: "SlotConfig") -> None:
        self.slot_config = slot_config
        logger.debug(f"Initialized slot resolution module")

    def process_slot_resolution(
        self,
        user: UserData,
        slot_rule: "SlotRules" = None,
        value: str = "",
        current_slots: Dict[str, List[str]] = {},
        replace_index: int = None,
        orig_val: str = "",
    ) -> bool:
        """Method that corrects slot values and slot tags based on slot lookup
        and slot validity list. Uses difflib lib of python to find closest match.
        Input:
        user: Current userdata for the dm request
        slot_rule: Slot rules of the interest slot
        value: value of the interest slot which needs to be resolved
        current_slots: slots already disambiguated by slot manager. This is
                       updated if necessary depending on resolution state.
        replace_index: Index where a specific slot value needs to be replaced/modified if resolved
        orig_val: If the passed slot value was pre-disambiguated by DM based on synonyms then this value
                 is populated. This is mainly used to store the correct mapping of resolved slot values
                 which is reused in slot linking to deduce spans.
        Output:
        returns a boolean value indicating whether slot value resolution was success/failure
        """

        domain = user.domain

        if slot_rule.resolution_confidence == 1.0:
            return False

        if not slot_rule.enable_resolution:
            return False

        self._conf = slot_rule.resolution_confidence

        logger.info(
            f"Carrying out slot resolution for slot {slot_rule.name}:{value}. "
            f"Current slots before resolution: {current_slots}"
        )

        # Search for match in slots lookup and validity lookup list.
        # matched_val can be a single value or multiple values. Example:
        # multi matched val -> food_name: ["cheese with fried onions"] -> food_name: ["cheese", "fried_onions"]
        # single matched val -> food_name: ["salad options"] -> food_name: ["salad"]
        matched_val = self.__search_for_match(domain, slot_rule, value)

        if len(matched_val):

            # If the resolved slot value needs to be replaced at a particular index
            if replace_index is not None:
                current_slots[slot_rule.name].pop(replace_index)
                current_slots[slot_rule.name][replace_index:replace_index] = matched_val

                logger.debug(
                    f"Replacing slot tag and value - {slot_rule.name}:{value} with resolved tag and value - {slot_rule.name}:{matched_val}"
                )

                if orig_val:
                    user.resolved_slots[orig_val] = matched_val.copy()
                else:
                    user.resolved_slots[value] = matched_val.copy()
                return True

            # If the resolved slot value needs to be added to the slot list
            if slot_rule.name not in current_slots:
                current_slots[slot_rule.name] = matched_val
            else:
                current_slots[slot_rule.name].extend(matched_val)

            logger.debug(
                f"Replacing slot tag and value - {slot_rule.name}:{value} with resolved tag and value - {slot_rule.name}:{matched_val}"
            )

            if orig_val:
                user.resolved_slots[orig_val] = matched_val.copy()
            else:
                user.resolved_slots[value] = matched_val.copy()

            return True

        logger.debug(
            f"No match found for slot with tag: {slot_rule.name} and value: {value}. "
            f"Checking if match can be found in ambiguous slots."
        )

        # Check if ambiguous slots are defined. If the key is not defined return.
        if slot_rule.ambiguous_slots is None:
            logger.debug(f"No ambiguous slots defined. Skipping slot resolution.")
            return False

        ambiguous_slots = slot_rule.ambiguous_slots
        if not len(slot_rule.ambiguous_slots):
            logger.debug(f"No ambiguous slots defined.")

        # Remove current slot name from ambiguous slot list
        if slot_rule.name in ambiguous_slots:
            ambiguous_slots.remove(slot_rule.name)

        for slot in ambiguous_slots:
            logger.debug(f"Searching for match in lookup and validity list for ambiguous slot: {slot}")
            rule = self.slot_config.get_slot_rules(slot)

            if rule is None:
                logger.info(f"No defination found for slot:{slot} in any of the defined domains.")
                continue

            matched_val = self.__search_for_match(domain, rule, value)

            if len(matched_val):
                logger.debug(
                    f"Value: {value} of slot with tag: {slot_rule.name} "
                    f"found match in a different slot with tag: {rule.name}. Changing slot tag."
                )

                if replace_index is not None:
                    current_slots[slot_rule.name].pop(replace_index)

                if rule.name not in current_slots:
                    current_slots[rule.name] = matched_val
                else:
                    current_slots[rule.name].extend(matched_val)

                logger.debug(
                    f"Replacing slot tag and value - {slot_rule.name}:{value} with resolved tag and value - {rule.name}:{matched_val}"
                )

                if orig_val:
                    user.resolved_slots[orig_val] = matched_val.copy()
                else:
                    user.resolved_slots[value] = matched_val.copy()
                return True

        return False

    def __search_for_match(self, domain, slot, value) -> List[str]:
        """Forms the reference values for closest match api,
        the lookup and validity lookup list of the slot, and
        calls closest match api
        Matching happens in below order:
          1. String match
          2. Edit distance
          3. Substring match
        """

        matched_val = []

        # Get the validity and lookup list for the slot
        lookup_list = self.slot_config.slot_lookup_rules.get(slot.name)
        validity_lookup_list = []
        if slot.validity:
            for field, values in slot.validity.items():
                if field == "lookup":
                    validity_lookup_list = values

        # Try to find the match in the slots lookup and validity list by using string match case insensitively
        if value.lower() in [x.lower() for x in lookup_list] or value.lower() in [
            x.lower() for x in validity_lookup_list
        ]:
            return [value]

        # Try to find the closest match using edit distance
        matched_val = get_closest_match(value, lookup_list, self._conf)
        if not matched_val:
            matched_val = get_closest_match(value, validity_lookup_list, self._conf)

        if matched_val is None:
            # Try to find the match in the slots lookup and validity list by using substring match
            validated_values = self.__search_for_substring_match(value, lookup_list)

            if validated_values:
                logger.debug(f"Validity of {slot.name}:{value} successful with substring match in lookup list.")
                return validated_values

            validated_values = self.__search_for_substring_match(value, validity_lookup_list)

            if validated_values:
                logger.debug(f"Validity of {slot.name}:{value} successful with substring match in validity list.")
                return validated_values

        return [matched_val] if matched_val is not None else []

    def __search_for_substring_match(self, value: str, search_list: List[str]) -> List[str]:
        """Returns a list of values from search_list which contains one or more word from value as a substring.
        Example:
        food_name: ["cheese with fried onions"] -> food_name: ["cheese", "fried_onions"]
        food_name: ["salad options"] -> food_name: ["salad"]
        If multiple matches are present, return the longest match.
        """

        validated_values = []
        while True:
            longest_value = ""
            for lookup in search_list:
                if (
                    " " + lookup.lower() + " " in " " + value.lower() + " "
                    and len(value) > len(longest_value)
                    and len(lookup) > len(longest_value)
                ):
                    longest_value = lookup

            if longest_value:
                validated_values.append(longest_value)
                pattern = re.compile(re.escape(longest_value), re.IGNORECASE)
                value = pattern.sub("", value)
            else:
                break

        return validated_values
