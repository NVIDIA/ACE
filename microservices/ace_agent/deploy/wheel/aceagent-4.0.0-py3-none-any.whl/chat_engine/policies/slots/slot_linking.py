# Copyright(c) 2021-2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
chat engine slot handler module which is responsible for
parsing and creating composite slots.
Composite slots can be grouped based on several approches.
Currently only proximity rule based composite slot formation is available.
Called by dialog policy for composite slot value disambiguation.
"""

import logging
from typing import Dict, Any, List
from uuid import uuid4

from chat_engine.core.userdata import UserData
from chat_engine.bot_factory.configs import SlotConfig

from chat_engine.constants import (
    COMPOSITE_SLOT_WORD_PROXIMITY,
    VALID_SLOT_DATATYPES,
    PROCESSOR_PREPROCESSED,
    PROCESSOR_POSTPROCESSED,
)
from chat_engine.nlp.nlp_utils import update_entities, find_spans_from_queries
from chat_engine.policies.utils import correct_query

logger = logging.getLogger("chat_engine")


class SlotLinking:
    def __init__(self, slot_config: "SlotConfig") -> None:
        self.slot_config = slot_config
        logger.debug("Successfully initialized slot linking module..")

    def process_composite_slots(self, user: "UserData", slots: Dict[str, Any]) -> Dict[str, Any]:
        """
        Public method called from slot manager to create
        composite slots from current user slots.
        This module auto deduces spans of the slots and
        utilizes that info to group together slots which are adjacent to each other.
        """

        current_slot_tags = []  # Store token specific slot tags and their parent slot tags
        composite_slots = {}  # Store the formed composite slots
        updated_entities = []

        # If no composite slots defined for the current domain return
        if not len(self.slot_config.get_composite_slots()):
            return {}

        # Form updated entities with resolved slot values so that corrected slot values are considered
        # while forming composite slots
        query = correct_query(user.processed_query[PROCESSOR_PREPROCESSED], user.resolved_slots)
        logger.debug(f"Forming composite slots with {slots}..")

        # Form local entities with the slots to get their spans.
        # Span info will be utilized to form composite slots.
        for slot_name, slot_vals in slots.items():
            if self.slot_config.get_slot_rules(slot_name):
                entities = self.slot_config.get_slot_rules(slot_name).entity
                if len(entities) != 1:
                    continue
                entity_list = [
                    {"Token": val, "EntityName": entities[0]} for val in slot_vals if type(val) in VALID_SLOT_DATATYPES
                ]
                updated_entities.extend(
                    update_entities(user, find_spans_from_queries(query, entity_list), consider_user_ent=False)
                )

        logger.debug(
            f"Updated entities from resolved slot values are: {updated_entities}. Building composite slots with these."
        )

        # Map entities to slots for each detected entities and also deduce their parent slot tag
        for ent in updated_entities:
            slot_tag = self.slot_config.get_slot_from_entity(ent["EntityName"])
            current_slot_tags.append(
                {
                    "token": ent["Token"],
                    "tag": slot_tag,
                    "span": ent.get("Span", {}),
                    "parent_tag": None,
                    "bucket_id": None,
                }
            )

        # Get list of all composite slots in current domain and construct it based on available entities
        for compo_slot in self.slot_config.get_composite_slots():
            slot_tags = []
            self._groupings = {}

            # Fetch all entries from current_slot_tags which are listed
            # as a child slot for current composite slot
            for slot in current_slot_tags:
                slot["bucket_id"] = None
                if slot["tag"] in compo_slot.child_slots:
                    slot["parent_tag"] = compo_slot.name
                    slot_tags.append(slot)

            # Group slot_tags together based on proximity
            for i in range(len(slot_tags)):
                for j in range(i + 1, len(slot_tags)):
                    if self.__is_valid_distance(
                        user.processed_query[PROCESSOR_PREPROCESSED], slot_tags[i], slot_tags[j]
                    ):
                        self.__combine_childslots(slot_tags[i], slot_tags[j])

            # Place single unvisited slot_tags in buckets if they are have a valid parent tag
            for i in range(len(slot_tags)):
                if slot_tags[i]["parent_tag"] is not None and slot_tags[i]["bucket_id"] is None:
                    self._groupings[str(uuid4())] = [slot_tags[i]]

            # Combine child slots into composite slots
            for key, values in self._groupings.items():
                slots = {}
                for value in values:
                    parent_tag = value["parent_tag"]
                    slot_tag = value["tag"]
                    if slot_tag in slots:
                        slots[slot_tag].append(value["token"])
                    else:
                        slots[slot_tag] = [value["token"]]

                if parent_tag in composite_slots:
                    composite_slots[parent_tag].append(slots)
                else:
                    composite_slots[parent_tag] = [slots]

            # Multi level composite slot combination
            is_combined = False

            if composite_slots:
                while True:
                    for slot, values in composite_slots.items():
                        parent_slot = self.slot_config.get_parent_slot(slot)
                        if parent_slot is not None and parent_slot in composite_slots.keys():
                            composite_slots[parent_slot].append({slot: values})
                            del composite_slots[slot]
                            is_combined = True
                            break
                        else:
                            is_combined = False

                    if is_combined:
                        continue
                    else:
                        break

        # TODO: Form original text for all composite slots
        return composite_slots

    def __is_valid_distance(self, user_query: str, val1: Dict[str, str], val2: Dict[str, str]) -> bool:
        """Utility method to check if two tokens fulfill proximity criteria"""

        if val1["parent_tag"] != val2["parent_tag"] or val1["parent_tag"] is None or val2["parent_tag"] is None:
            return False

        word_distance = self.__get_word_distance(user_query, val1, val2)
        if word_distance <= COMPOSITE_SLOT_WORD_PROXIMITY and word_distance != -1:
            return True
        return False

    def __get_word_distance(self, s: str, s1: Dict[str, str], s2: Dict[str, str]) -> int:
        """Utility method to find minimum distance between two substrings in a sentence"""

        if s1["span"]["start"] == s2["span"]["start"]:
            return -1

        boundary_words = []
        start = s1["span"]["start"]
        end = s2["span"]["start"]

        if start < end:
            start = start + len(s1["token"])
            boundary_words = s[start:end]
        else:
            end = end + len(s2["token"])
            boundary_words = s[end:start]

        return len(boundary_words.split())

    def __combine_childslots(self, s1, s2) -> None:
        """Utility method to combine different child slots into buckets"""

        # Create a bucket to for s1 and store s2 into same bucket
        if s1["bucket_id"] is None and s2["bucket_id"] is None:
            id = str(uuid4())
            self._groupings[id] = [s1, s2]
            s1["bucket_id"] = s2["bucket_id"] = id

        elif s1["bucket_id"] is not None and s2["bucket_id"] is None:
            self._groupings[s1["bucket_id"]].append(s2)
            s2["bucket_id"] = s1["bucket_id"]

        elif s2["bucket_id"] is not None and s1["bucket_id"] is None:
            self._groupings[s2["bucket_id"]].append(s1)
            s1["bucket_id"] = s2["bucket_id"]
