# Copyright(c) 2021-2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
chat engine slot manager module that forms slot values from entity values.
This module forms the slots and post processes them to correct values/tags
and also helps form different types of slots like composite slots, system slots.
Called from Dialog Rule Policy as well as Action execution module of selected dialog,
when slots are needed to be updated or new slots are needed to be added.
"""

from copy import deepcopy
import logging
from typing import List, Dict, Any
import re
import json

from chat_engine.core.userdata import UserData
from chat_engine.constants import SYSTEM_SLOTS_PREFIX, PROCESSOR_PREPROCESSED
from chat_engine.dialog_state_tracker.dialog_state_tracker import DialogStateTracker
from chat_engine.system_slot.parser import Parser
from chat_engine.bot_factory.configs import SlotConfig, SlotRules
from chat_engine.policies.slots.slot_linking import SlotLinking
from chat_engine.policies.slots.slot_resolution import SlotResolution
from chat_engine.policies.slots.entity_linking import EntityLinking
from chat_engine import Bot

logger = logging.getLogger("chat_engine")


class SlotManager:
    __instance = None

    @staticmethod
    def get_instance():
        if SlotManager.__instance is None:
            raise Exception("You must call create_instance before calling " "get_instance")
        return SlotManager.__instance

    @staticmethod
    def create_instance(slot_config: "SlotConfig", dst: "DialogStateTracker") -> "SlotManager":
        if SlotManager.__instance is None:
            SlotManager(slot_config, dst)
        else:
            raise Exception(
                "An instance has already been created. Creation of "
                "second instance of singleton class Slothanlder is "
                "not allowed"
            )
        return SlotManager.get_instance()

    @staticmethod
    def destroy():
        Parser.destroy()
        SlotManager.__instance = None
        logger.debug(f"Destroying Slot Manager Object..")

    def __init__(self, slot_config: "SlotConfig", dst: "DialogStateTracker") -> None:
        if SlotManager.__instance is not None:
            raise Exception(
                "SlotHandler is a singleton class. Use get_instance " "to get access to the SlotHandler object"
            )
        else:
            SlotManager.__instance = self

        logger.debug("Successfully initialized slot manager module.")
        self._parser = Parser.create_instance()
        self._slot_linker = SlotLinking(slot_config)
        self._slot_res = SlotResolution(slot_config)
        self._entity_linker = EntityLinking(slot_config)
        self._slot_resolution_cache = {}
        self._slot_validation_cache = {}
        self.slot_config = slot_config
        self.dst = dst

    async def initialize(self, bot: Bot):
        """Initialize all the downstream async classes for slot management"""

        await self._entity_linker.initialize(bot)

    async def get_slots(
        self,
        user: "UserData",
        slot_rule: List["SlotRules"],
        ent: List[Dict[str, Any]] = None,
        use_defaults: bool = True,
        use_dst_slots: bool = True,
        form_compo_slots: bool = True,
    ) -> Dict[str, List[str]]:
        """
        Get a list of slot info dataclasses corresponding to a given
        domain and token class response. Token class response can come
        from any NLU module i.e. intent slot, ner, lookup or regex. Even
        if NLU response does not have a specific slot but domain rule
        has a default value available for the corresponding slot, it is
        added to the list.
        """

        slots = {}
        entities = user.entities if ent is None else ent
        query_id = user.query_id
        if query_id not in self._slot_resolution_cache:
            self._slot_resolution_cache[query_id] = {}
        if query_id not in self._slot_validation_cache:
            self._slot_validation_cache[query_id] = {}

        if use_dst_slots:
            logger.debug("Populating slot values from Dialog State Tracker..")
            slots = self.__get_dialog_state_slots(user.user_id)

        slots = self._entity_linker.reset_results(query_id, slots)
        dst_slots = list(slots)

        new_slots = {}
        logger.debug(
            f"Using entities: {entities} to form all types of slots after correcting their values if needed.."
        )

        for s in slot_rule:
            for ent in entities:
                tag = ent["EntityName"]
                token = ent["Token"]
                if tag in s.entity or tag == s.name:
                    val = self.__replace_synonyms(token, s.synonyms)

                    # If slot resolution is successful skip validity checking and slot updation
                    cached_answer = self._slot_resolution_cache[query_id].get(
                        tuple([user.domain, s.name, val, tag]), None
                    )
                    if cached_answer is not None:
                        is_resolved = cached_answer
                    else:
                        is_resolved = self._slot_res.process_slot_resolution(user, s, val, new_slots, orig_val=token)
                        self._slot_resolution_cache[query_id][tuple([user.domain, s.name, val, tag])] = is_resolved

                    if is_resolved:
                        continue

                    is_resolved = await self._entity_linker.perform_entity_linking(
                        user, s.name, s.ambiguous_slots, token
                    )

                    cached = self._slot_validation_cache[query_id].get(tuple([user.domain, s.name, val]), None)
                    if cached is not None:
                        is_slot_valid = cached
                    else:
                        is_slot_valid = self.__validate_slot_value(s, val)
                        self._slot_validation_cache[query_id][tuple([user.domain, s.name, val])] = is_slot_valid
                    if is_slot_valid:

                        if s.name not in new_slots:
                            new_slots[s.name] = [val]

                        # Overwrite slots from DST if found in user query
                        elif s.name in dst_slots:
                            new_slots[s.name] = [val]
                            dst_slots.remove(s.name)

                        else:
                            new_slots[s.name].append(val)
                    continue

            if use_defaults and s.default and s.name not in slots:
                if s.name not in new_slots:
                    new_slots[s.name] = [s.default]  # TODO: Consider multiple default values
                logger.debug(f"Using default value for: {s.name}: {s.default}")

            if s.name.startswith(SYSTEM_SLOTS_PREFIX) and s.name in new_slots:
                new_slots[s.name] = self._parser.parse(
                    query_id, user.processed_query[PROCESSOR_PREPROCESSED], s.name, new_slots[s.name]
                )

        slots.update(self.__remove_duplicate_slot_values(new_slots))

        if form_compo_slots:
            slots.update(self._slot_linker.process_composite_slots(user, slots))

        self._entity_linker.store_entity_link_results(user)

        logger.debug(f"Slots formed for {user.domain}: {slots}")
        return slots

    def check_slots(
        self, user: UserData, slots: Dict[str, List[str]], form_compo_slots: bool = True
    ) -> Dict[str, List[str]]:
        """Utlity method to check slots validity and map
        slot values to synonyms.
        Returns the updated list of slots values:
        1. By mapping slot values to their synomyms
        2. By removing entries which has invalid slot values
        3. Remove slots which are not defined in current domain's rule file

        If substring_allowed is True, look for the longest lookup value that is a
        word in the slot value.
        If substring_allowed is True and slot validity fails,
        check whether the value is valid for slots in zero_shot_slot_names.
        """

        domain = user.domain
        if self.slot_config.slots is None:
            return slots

        new_slots = {}
        slots = self.__remove_duplicate_slot_values(slots)

        for slot_name, slot_value in slots.items():
            if slot_name not in self.slot_config.get_slot_list():
                logger.warning(f"Slot with name: {slot_name} is not defined in current {domain} domain's rule file.")
                continue

            rule = self.slot_config.get_slot_rules(slot_name)
            new_slots[slot_name] = slot_value

            invalid_values = []

            for idx, token in enumerate(slot_value):
                val = self.__replace_synonyms(token, rule.synonyms)
                is_resolved = self._slot_res.process_slot_resolution(
                    user, rule, val, new_slots, replace_index=idx, orig_val=token
                )
                if is_resolved:
                    continue

                # Validate the slot value. If it is invalid, add it to invalid_values. Else, update the slot value
                validated_values = self.__validate_slot_value(rule, new_slots[slot_name][idx])
                if not validated_values:
                    invalid_values.append(val)
                else:
                    new_slots[slot_name][idx] = validated_values
            new_slots[slot_name] = [val for val in new_slots[slot_name] if val not in invalid_values]

        if form_compo_slots:
            new_slots.update(self._slot_linker.process_composite_slots(user, new_slots))

        logger.debug(f"Slots after re-processing and validity checks are: {new_slots}")
        return new_slots

    def form_composite_slots(self, user: UserData, slots: Dict[str, Any]) -> Dict[str, Any]:
        """Forms composite slots from current user slots with the help of slot linker module
        and retuns them. Called from dialog policy."""

        return self._slot_linker.process_composite_slots(user, slots)

    def get_all_slots_from_current_turn(
        self, user: UserData, slots_from_entities: Dict[str, List[str]]
    ) -> Dict[str, List[str]]:
        """Given the list of slots formed from entities of current turn and the list of slots for all domains,
        return all the slots which are formed in the current turn. This includes slots which are not formed based on entities
        like system.toxicity."""

        all_current_slots = deepcopy(slots_from_entities)
        all_slot_names = set()
        # for domain in self._dm_ctrl.get_domain_list():
        #     all_slot_names.update(self._dm_ctrl.get_slot_list(domain))
        for name, values in user.slots.items():
            if name not in all_slot_names:
                all_current_slots.update({name: values})

        return all_current_slots

    def clear_cache(self, query_id):
        if query_id in self._slot_resolution_cache:
            del self._slot_resolution_cache[query_id]
        if query_id in self._slot_validation_cache:
            del self._slot_validation_cache[query_id]
        self._entity_linker.clear_cache(query_id)
        Parser.clear_cache(query_id)

    async def update_entity_links(self, dm_rules):
        """
        create entity links for domain rules
        """
        await self._entity_linker.update_entity_links(dm_rules)

    # -------------------------------------------------------------
    # Helper methods for SlotManager public methods
    # -------------------------------------------------------------
    def __get_dialog_state_slots(self, user_id: str) -> Dict[str, str]:

        d_state = self.dst.get_dialog_state(user_id)
        logger.info(f"Available short term slots are: {d_state.session_slots.keys()}")
        logger.info(f"Available long term slots are: {d_state.global_slots.keys()}")

        slots = {}
        for s in d_state.session_slots:
            if len(d_state.session_slots[s].values):
                slots[s] = d_state.session_slots[s].values[-1].value

        for s in d_state.global_slots:
            if len(d_state.global_slots[s].values):
                slots[s] = d_state.global_slots[s].values[-1].value
        return slots

    def __replace_synonyms(self, slot_val: str, synonyms: Dict[str, List[str]]):
        """Checks if the slot value is present in the synonyms of a slot rule with a case insentive search and updates slot value to the synonym"""

        l_case_slot_val = slot_val.lower() if isinstance(slot_val, str) else slot_val
        if len(synonyms):
            for syn in synonyms:
                if l_case_slot_val in [x.lower() if isinstance(x, str) else x for x in synonyms[syn]]:
                    slot_val = syn
        return slot_val

    def __validate_slot_value(self, slot: "SlotRules", value: str) -> str:
        """Check if the slot value is valid or not.
        If it is, return the validated value. Else, return None.
        Comparision takes place with a string or regex expression,
        if 'validity' is defined in the slot rules"""

        if not slot.validity:
            return value

        for field, values in slot.validity.items():

            if field == "regex":
                for regex in values:
                    if len(re.findall(re.compile(regex), value)) == 1:
                        logger.debug(f"Validity of {slot.name} successful with regex: {regex}")
                        return value

            elif field == "lookup":
                values = [
                    value.lower() if isinstance(value, str) else value for value in values
                ]  # converting validity lookup values to lowercase
                if value.lower() in values:
                    logger.debug(f"Validity of {slot.name} successful with lookup: {value}")
                    return value

        logger.debug(f"Validity failed for slot: {slot.name}  with value: {value}")
        return None

    def __remove_duplicate_slot_values(self, slots: Dict[str, List[str]]) -> Dict[str, List[str]]:
        """Removes duplicate values from same slot tag inplace.
        Skip composite slots validation.
        """

        modified_slots = {}
        for slot, values in slots.items():
            seen = {}
            if any([isinstance(v, dict) for v in values]):
                modified_slots[slot] = values
                continue
            modified_slots[slot] = [seen.setdefault(x, x) for x in values if x not in seen]
        return modified_slots
