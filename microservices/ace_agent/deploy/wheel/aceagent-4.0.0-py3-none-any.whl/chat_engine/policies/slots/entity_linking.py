# Copyright(c) 2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
chat engine processor module called from slot_handler
which searches for semantically similar lookup values as the
filled slot value.
"""

import logging
from typing import Any, List, Dict
from time import time

from chat_engine.bot_factory.configs import SlotConfig
from chat_engine import Bot
from chat_engine.core.userdata import UserData, SlotData
from chat_engine.nlp.nlp_response import SemanticSimilarityResult
from chat_engine.nlp.embedding_search import StoreType, EmbeddingSearch
from chat_engine.constants import NLU_EMBEDDING_CREATE, ENTITY_LINKING_ACTION
from chat_engine.nlp.constants import DEFAULT_ENTITY_LINKING_CONF_THRESHOLD

logger = logging.getLogger("chat_engine")


class EntityLinking:
    """
    Peform Entity Linking for the query tags.
    Calculate and store embeddings for slots during init and
    perform similarity search during inference.
    """

    def __init__(self, slot_config: "SlotConfig") -> None:
        """Initialize Entity Linking class"""

        self.allowed_slots = {}
        self.slots_with_embeddings = set()
        self.slot_config = slot_config
        self._results = {}
        self._latency = {}
        self._previous_slots = {}  # If any linked slots are present in DST, they are stored here
        self._performed_searches = {}  # Map a tuple of domain, slot value, slot name to its result
        self._skip_model_call = False
        self.confidence_threshold = DEFAULT_ENTITY_LINKING_CONF_THRESHOLD

    async def initialize(self, bot: Bot):
        """Initialize embeddings and lookup tags for Entity Linking."""

        self._embedding_search = EmbeddingSearch(bot=bot)
        self.bot_name = bot.name

        if bot.nlp_model_configs:
            for config in bot.nlp_model_configs:
                if config.task_name == ENTITY_LINKING_ACTION:
                    self.confidence_threshold = config.confidence_threshold

        await self.__create_entity_links(self.slot_config)

    async def perform_entity_linking(
        self, user: UserData, slot_name: str, ambiguous_slots: List[str], query_token: str
    ) -> bool:
        """
        Perform Entity Linking for the given slot. Return True if a match was found, else False.
        """

        query_id = user.query_id
        if query_id not in self._performed_searches:
            self._performed_searches[query_id] = {}
        if query_id not in self._results:
            self._results[query_id] = []
        if query_id not in self._previous_slots:
            self._previous_slots[query_id] = {}
        if query_id not in self._latency:
            self._latency[query_id] = 0.0

        # If model was not deployed, return False
        if self._skip_model_call:
            return False

        # If slot resolution is not enabled for the given slot in that domain, return False.
        if not self.allowed_slots or slot_name not in self.allowed_slots:
            return False

        # Check if search has already been performed for the token and slot pair.
        for value in self._results[query_id]:
            if value.token == query_token and value.slot == slot_name:
                return True

        # Clear previous slot values when new entities are of the slot are tagged.
        if slot_name in self._previous_slots[query_id]:
            del self._previous_slots[query_id][slot_name]

        search_details = tuple([query_token, slot_name])
        if search_details in self._performed_searches[query_id]:
            slot, tag, score = self._performed_searches[query_id][search_details]
            logger.debug(
                f"Setting entity linking result for token: {query_token}, name: {slot_name}"
                f" from memory. Tag: {tag}, linked slot: {slot}, score: {score}"
            )
            self._results[query_id].append(SemanticSimilarityResult(query_token, tag, score, slot))
            return True

        start_time = time()
        match_found = False
        ambiguous_slots = ambiguous_slots if ambiguous_slots is not None else []

        # List of slots which need to be searched, which also have embeddings created for them.
        store_names = [
            f"{self.bot_name}_{slot}" for slot in [slot_name] + ambiguous_slots if slot in self.slots_with_embeddings
        ]

        if not store_names:
            return False

        try:
            results = await self._embedding_search.search(text=query_token, store_name=store_names)
        except Exception as e:
            logger.error(f"Encountered error while performing embedding search: {e}")
            results = []

        if len(results):
            for result in results:
                score = result["confidence_score"]
                if score < self.confidence_threshold:
                    continue
                match_found = True
                slot = result.get("metadata", {}).get("slot")
                tag = result.get("text")
                self._results[query_id].append(SemanticSimilarityResult(query_token, tag, score, slot))
                self._performed_searches[query_id][search_details] = tuple([slot, tag, score])
                logger.debug(
                    f"Found valid result using entity linking for: {query_token}. Linked slot: {slot} with score: {score}"
                )
                break

        self._latency[query_id] += time() - start_time

        return match_found

    def reset_results(self, query_id: str, dst_slots: Dict[str, Any]) -> None:
        """Reset the results of Semantic similarity to an empty list.
        Store the contents of DialogState Slots to prevent unnecessary re-calculation.
        Return the contents of DialogState as in a list of strings/dicts."""

        self._latency[query_id] = 0.0
        self._previous_slots[query_id] = {}
        slots = {}  # Stores the cleaned DST slots

        for slot_name, values in dst_slots.items():
            slots[slot_name] = []

            for value in values:

                # If the slot value is a regular slot, return it as it is.
                if not isinstance(value, SlotData):
                    slots[slot_name].append(value)
                    continue

                if slot_name not in self._previous_slots[query_id]:
                    self._previous_slots[query_id][slot_name] = []

                self._previous_slots[query_id][slot_name].append(value)
                slots[slot_name].append(value.value)

        return slots

    def store_entity_link_results(self, user: UserData):
        """Store the results of Semantic similarity in UserData."""

        if user.query_id not in self._results:
            return

        for result in self._results[user.query_id]:
            if result in user.nlu_result.semantic_similarity_result:
                continue
            user.nlu_result.semantic_similarity_result.append(result)

        user.latency.nlu_semantic_similarity += self._latency[user.query_id]

        user.linked_slots = self._previous_slots[user.query_id]

        for entry in self._results[user.query_id]:
            if entry.slot not in user.linked_slots:
                user.linked_slots[entry.slot] = []
            user.linked_slots[entry.slot].append(SlotData(value=entry.token, linked_value=entry.closest_match))

    def clear_cache(self, query_id: str):
        """
        Delete results for the current query_id. Called at the end of every query from core.
        """

        if query_id in self._performed_searches:
            del self._performed_searches[query_id]
        if query_id in self._latency:
            del self._latency[query_id]
        if query_id in self._results:
            del self._results[query_id]
        if query_id in self._previous_slots:
            del self._previous_slots[query_id]

    async def __create_entity_links(self, slot_config) -> None:
        """Calculate the set of slots that need embeddings created for all domain in domain_rules."""
        await self.update_entity_links(slot_config)

    async def update_entity_links(self, slot_config) -> None:
        """Calculate the set of slots that need embeddings created."""

        logger.debug(f"Updating Entity links")
        self.allowed_slots = {}

        # Get the list of slots of that domain for which embeddings need to be calculated.
        entity_linking_slots = set()
        for slot in slot_config.slot_rules:
            if slot.enable_resolution:
                entity_linking_slots.add(slot.name)
                if slot.ambiguous_slots:
                    entity_linking_slots.update(slot.ambiguous_slots)

        # Calculate embeddings for the necessary slots and store it under the current domain.
        for slot in slot_config.slot_rules:
            if slot.name in entity_linking_slots:
                tag_list = slot_config.slot_lookup_rules.get(slot.name, []) + slot.validity.get("lookup", [])
                if tag_list is None:
                    tag_list = []

                self.allowed_slots[slot.name] = tag_list

                await self.create_entity_linking_embeddings(slot.name, tag_list)

    async def create_entity_linking_embeddings(self, slot_name: str, anchors: List[str]) -> bool:
        """Call NLU server's embedding creation endpoint for the given slot and lookup list."""

        embedding_create_endpoint = self._embedding_search._bot.health_monitor.get_nlp_endpoint(NLU_EMBEDDING_CREATE)
        if embedding_create_endpoint is None:
            return

        items = []
        for anchor in anchors:
            items.append({"text": anchor, "metadata": {"slot": slot_name}})

        if len(items) == 0:
            return

        self.slots_with_embeddings.add(slot_name)

        # We register a callback with health monitor to call this method asynchronously
        self._embedding_search._bot.health_monitor.register_callback(
            fn=self._embedding_search.build_index,
            task_name=NLU_EMBEDDING_CREATE,
            kwargs={
                "store_type": StoreType.ENTITY_LINKING,
                "store_name": f"{self.bot_name}_{slot_name}",
                "anchors": items,
            },
        )
