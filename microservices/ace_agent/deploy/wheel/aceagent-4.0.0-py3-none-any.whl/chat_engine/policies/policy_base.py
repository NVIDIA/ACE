# Copyright(c) 2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

from chat_engine import Bot
from chat_engine.constants import POLICY_DIALOG
from abc import ABC, abstractmethod


class PolicyBase(ABC):

    name: str

    def __init__(self) -> None:
        self.bot = None

    @abstractmethod
    def initialize():
        ...

    @abstractmethod
    def run():
        ...

    def set_bot(self, bot: Bot):
        self.bot = bot
