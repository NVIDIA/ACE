# Copyright(c) 2022-2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import aiohttp
import logging
from typing import Any, Dict, List
from dataclasses import asdict
import json
from chat_engine.core.userdata import UserData
from chat_engine.interfaces.server_schemas import ChatResponse, ChatLatencyField, ResponseField, EventResponse
from chat_engine.nlp.nlp_response import (
    TokenClassResponse,
)
from chat_engine.nlp.regex import Regex
from chat_engine.nlp.lookup import Lookup
from nemoguardrails.streaming import StreamingHandler

logger = logging.getLogger("chat_engine")


def __postprocess_json_response(response: Dict[str, Any]):
    """
    Post-process the chat/event response to the server response format.
    """

    response["Metadata"] = {}
    for key in ["ApiVersion", "UserId", "SessionId", "QueryId", "StreamId", "EventId"]:
        if response.get(key):
            response["Metadata"][key] = response[key]


def correct_query(query: str, resolved_values: Dict[str, List[str]]) -> str:
    """
    Corrects spelling errors in query and returns it
    """

    for old_val, new_val in resolved_values.items():
        if len(new_val) == 1 and " " + old_val.lower() + " " in " " + query.lower() + " ":
            query = query.replace(old_val, new_val[0])

    return query


def get_lookup_result(user: UserData, query: str, lookup_rules) -> TokenClassResponse:
    entities = Lookup.process_query(query, lookup_rules)
    user.nlu_result.slot_lookup_result.slots += entities.slots
    return entities


def get_regex_result(user: UserData, query: str, regex_rules) -> TokenClassResponse:
    entities = Regex.process_query(query, regex_rules)
    user.nlu_result.slot_regex_result.slots += entities.slots
    return entities


def update_llm_context(rails: "LLMRails", context: Dict[str, Any]) -> None:
    """Update the available contexts in llm prompt.
    This makes sure that the prompt has access to all context variables as part of its placeholders"""

    for key, val in context.items():
        rails.register_prompt_context(key, val)


def get_system_slots(bot_name: str, user: UserData):
    """Provide a dict of predefined system slots which is updated in colang context"""

    return {
        "user_id": user.user_id,
        "stream_id": user.stream_id,
        "session_id": user.session_id,
        "query_id": user.query_id,
        "event_id": user.event_id,
    }


async def form_response_for_event(user_data: UserData):
    """Update hardcoded response for certain events."""

    if not user_data.user_query and user_data.event:
        if user_data.event in ["system.event_start"]:
            user_data.response.need_user_response = True
        else:
            user_data.response.need_user_response = False
        if user_data.colang_streaming_handler:
            await user_data.colang_streaming_handler.push_chunk(None)
            user_data.colang_streaming_handler.streaming_finished_event.set()
        user_data.response.text = ""
        user_data.response.ready = True


async def process_streaming_response(response: aiohttp.ClientResponse, streaming_handler: StreamingHandler):
    """Consolidate chunks from a stream and add them to a streaming handler if present."""

    received_chunks = []
    async for chunk, _ in response.content.iter_chunks():
        if not chunk:
            break
        chunk = chunk.decode("utf-8")

        # If the chunk is in a JSON format in the Chat Response format, extract only the text component from the JSON
        try:
            chunk = json.loads(chunk)["Response"]["Text"]
        except Exception:
            pass

        received_chunks.append(chunk)
        if streaming_handler:
            await streaming_handler.push_chunk(chunk)

    if streaming_handler:
        await streaming_handler.push_chunk(None)
        streaming_handler.streaming_finished_event.set()

    return "".join(received_chunks)


async def get_response_data(response: aiohttp.ClientResponse, streaming_handler: StreamingHandler):
    """Process the response based on whether it is a streaming or non-streaming endpoint"""

    if response.headers.get("Transfer-Encoding") == "chunked":
        response_data = await process_streaming_response(response, streaming_handler)

    else:
        response_data = await response.json()

    return response_data


def get_response_json_from_text(user_data: UserData, text: str) -> Dict[str, Any]:
    """
    Form the full JSON response from the given response text.
    """

    response_field = ResponseField(Text=text, CleanedText=text, IsFinal=False)
    latency = ChatLatencyField(LLMModels=0, NLPModels=0, Fulfillment=0, DialogManager=0, EndToEnd=0)
    metadata = {"SessionId": user_data.session_id, "StreamId": user_data.stream_id}
    if user_data.user_query or not user_data.event:
        metadata["QueryId"] = user_data.query_id
        response = ChatResponse(
            UserId=user_data.user_id,
            Query=user_data.user_query,
            Response=response_field,
            Latency=latency,
            Metadata=metadata,
        )
    else:
        response = EventResponse(
            Events=[],
            EventType=user_data.event,
            Response=response_field,
            Latency=latency,
        )
    return response.dict()


async def stream_json(user_data: UserData):
    """
    Convert the individual text chunks in the colang streaming handler to a streaming chunk
    """

    async for chunk in user_data.colang_streaming_handler:
        if chunk is None:
            break
        response = get_response_json_from_text(user_data, chunk)
        await user_data.streaming_handler.push_chunk(json.dumps(response))


async def close_stream(user_data: UserData):
    """
    Called by Core when the complete query is processed. Pushes any lingering chunks to the stream and sends the final chunk.
    """

    # Close the colang streaming handler if it has not already been closed,
    # and wait for all chunks to be read
    await user_data.colang_streaming_handler.push_chunk(None)
    await user_data.stream_handler_task

    bot_response = asdict(user_data.core_response)
    __postprocess_json_response(bot_response)

    if user_data.user_query or not user_data.event:
        final_response = ChatResponse.parse_obj(bot_response)

        final_response.Metadata = {
            "QueryId": user_data.query_id,
            "SessionId": user_data.session_id,
            "StreamId": user_data.stream_id,
        }

    else:
        final_response = EventResponse.parse_obj(bot_response)

    final_response.Response.Text = ""
    final_response.Response.CleanedText = ""
    final_response.Response.IsFinal = True

    json_response = final_response.dict()
    await user_data.streaming_handler.push_chunk(json.dumps(json_response))
    await user_data.streaming_handler.push_chunk(None)

    user_data.stream_handler_task = None
    user_data.colang_streaming_handler = None
    user_data.streaming_handler = None
