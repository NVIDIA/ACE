# Copyright(c) 2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

import os
from multiprocessing import shared_memory


def on_starting(server):
    """gunicorn hook: Executes when master starts"""

    # Shared List to store [DataClean, DataStorePath]
    # True: Clean store data
    try:
        store_info = shared_memory.ShareableList([True, "/tmp/dm_data_store"], name="dm")
    except FileExistsError as e:
        # Re-use shared memory if it already exist
        store_info = shared_memory.ShareableList(name="dm")
        store_info[0] = True
    store_info.shm.close()


def on_exit(server):
    """gunicorn hook: Executes when gunicorn exits"""

    try:
        store_info = shared_memory.ShareableList(name="dm")
        dirpath = store_info[1]
        store_info.shm.close()
        store_info.shm.unlink()  # Remove shared storage
        __clean_store(dirpath)
    except Exception as e:
        print(f"Exception from on_exit handler of gunicorn: {e}")


def post_worker_init(worker):
    """gunicorn hook: Executes after worker starts successfully"""

    try:
        store_info = shared_memory.ShareableList(name="dm")
        if store_info[0] == True:
            store_info[0] = False
            __clean_store(store_info[1])
        store_info.shm.close()
    except Exception as e:
        print(f"Exception from post_worker_init handler of gunicorn: {e}")


def __clean_store(dirpath):
    """Clear userdata from store path"""

    # If directory does not exist skip
    # when store type redis/mongo is used
    # directory is not created
    if not os.path.isdir(dirpath):
        return

    for filename in os.listdir(dirpath):
        if filename.endswith(".pkl"):
            path = os.path.join(dirpath, filename)
            if os.path.exists(path):
                try:
                    os.remove(path)
                except:
                    print(f"Error while deleting {path}")
