# Copyright(c) 2021-2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.


# default values for different bot configurations

DEFAULT_LANGUAGE = "en-US"
DEFAULT_HEALTH_CHECK_INTERVAL = 3
DEFAULT_BOT_VERSION = "1"

# default values for domain rules and bot configurations
DEFAULT_MEMORY_MAX_DEPTH = 5
DEFAULT_MEMORY_MAX_DURATION = 600
DEFAULT_CONFIDENCE_THRESHOLD = 0.0
DEFAULT_RESOLUTION_THRESHOLD = 0.8
DEFAULT_REQUEST_TIMEOUT = 5

# Default server URL's
DEFAULT_NLP_SERVER_URL = "http://localhost:9003"
DEFAULT_PLUGIN_SERVER_URL = "http://localhost:9002"

# Validation constants for API Governance
MAX_STR_LEN = 4096
MAX_NUMBER = 1e9
MAX_LIST_LENGTH = 256
