# Copyright(c) 2023 NVIDIA Corporation. All rights reserved

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
Contains all the configuration models used by bot
"""

import os
import logging
import yaml
from pydantic.v1 import BaseModel
from typing import Optional, Dict, Any, Union, List

from chat_engine.constants import LOCAL_STORE_PATH, STORE_LOCAL_FILE
from chat_engine.bot_factory.constants import (
    DEFAULT_NLP_SERVER_URL,
    DEFAULT_PLUGIN_SERVER_URL,
    DEFAULT_LANGUAGE,
    DEFAULT_HEALTH_CHECK_INTERVAL,
    DEFAULT_MEMORY_MAX_DEPTH,
    DEFAULT_MEMORY_MAX_DURATION,
    DEFAULT_RESOLUTION_THRESHOLD,
    DEFAULT_CONFIDENCE_THRESHOLD,
    DEFAULT_REQUEST_TIMEOUT,
)
from nemoguardrails import RailsConfig

logger = logging.getLogger("chat_engine")


class ConfigRule(BaseModel):
    """Stores and formulates the bot level configurations defined under configs key for a bot"""

    nlp_server_url: Optional[str] = DEFAULT_NLP_SERVER_URL
    plugin_server_url: Optional[str] = DEFAULT_PLUGIN_SERVER_URL
    need_user_response: Optional[bool] = False
    language: Optional[str] = DEFAULT_LANGUAGE
    request_language: Optional[str] = DEFAULT_LANGUAGE
    response_language: Optional[str] = DEFAULT_LANGUAGE
    health_check_interval: Optional[int] = DEFAULT_HEALTH_CHECK_INTERVAL
    enable_intent_slot: Optional[bool] = False
    use_stateful_guardrails: Optional[bool] = False
    colang_disable_async_execution: Optional[bool] = False
    voice_name: Optional[str] = ""
    remove_incomplete_sentences: bool = False
    register_ace_agent_intent_generation: bool = True
    register_ace_agent_bot_message_generation: bool = True
    register_ace_agent_next_step_generation: bool = True

    @classmethod
    def get_configs(cls, raw_bot_configs: Dict[str, Any]) -> "ConfigRule":
        """Extract and returns the bot top level configurations from the provided bot config yaml as a dict"""
        return cls(**raw_bot_configs.get("configs", {}))


class NlpModelConfigs(BaseModel):
    """Stores and formulates the bot level configurations defined under nlp_models key for a bot"""

    task_name: str
    model_name: Optional[str] = ""
    confidence_threshold: Optional[float] = DEFAULT_CONFIDENCE_THRESHOLD
    request_timeout: Optional[int] = DEFAULT_REQUEST_TIMEOUT
    endpoint: Optional[str] = ""

    @classmethod
    def get_configs(cls, raw_bot_configs: Dict[str, Any]) -> List["NlpModelConfigs"]:
        """Extract and returns the bot top nlp model configurations. These are mainly configurations for the non-llm models behind NLP server"""

        nlp_models = []
        for model in raw_bot_configs.get("nlp_models", {}):
            nlp_models.append(cls(**model))
        return nlp_models

    @classmethod
    def discover_speech_configs(cls, file_path: str) -> dict:
        """Parses the speech yaml file and returns the relevant configs in dict"""

        if not os.path.isfile(file_path):
            return {}

        yml = None
        with open(file_path, "r") as sc:
            yml = yaml.safe_load(sc)

        return yml.get("riva_tts", {}).get("RivaTTS", {})


class StorageConfig(BaseModel):
    """Stores and formulates the dm userdata storage information in a bot"""

    name: str = STORE_LOCAL_FILE
    path: Optional[str] = LOCAL_STORE_PATH
    url: Optional[str]
    parameters: Optional[Dict[str, Any]] = {}

    @classmethod
    def get_storage_configs(cls, raw_bot_configs: Dict[str, Any]) -> "StorageConfig":
        """Extract and returns the bot top level configurations from the provided bot config yaml as a dict"""
        if "storage" in raw_bot_configs:
            return cls(**raw_bot_configs.get("storage", {}))
        return {}


class ColangConfig:
    @classmethod
    def get_colang_files(cls, bot_dir_path: str) -> Union[RailsConfig, None]:
        """Checks and discovers available colang files in bot config directory. If atleast one colang file is
        found then the LLMRails instance is created and returned.
        """
        for root, dir, files in os.walk(bot_dir_path):
            for file in files:
                if file.endswith(".co"):
                    return RailsConfig.from_path(bot_dir_path)


class SlotRules(BaseModel):
    """Stores the Slot Rules used by SlotConfig"""

    name: str = ""
    description: Optional[str] = ""
    entity: Optional[List[str]] = []
    memory: Optional[str] = ""  # shortterm longterm
    default: Optional[str] = ""
    validity: Optional[Dict[str, List[str]]] = {}
    synonyms: Optional[Dict[str, List[str]]] = {}
    max_turn: Optional[int] = DEFAULT_MEMORY_MAX_DEPTH
    max_duration: Optional[int] = DEFAULT_MEMORY_MAX_DURATION
    child_slots: Optional[List[str]] = []
    resolution_confidence: Optional[float] = DEFAULT_RESOLUTION_THRESHOLD
    ambiguous_slots: Optional[List[str]] = []
    enable_resolution: Optional[bool] = True


class SlotConfig(BaseModel):
    """Stores and formulates the Slots related information in a bot"""

    slot_rules: Optional[List["SlotRules"]] = []
    slot_lookup_rules: Optional[Dict[str, List[str]]] = {}
    slot_regex_rules: Optional[Dict[str, str]] = {}
    shortterm_max_turns: Optional[int] = DEFAULT_MEMORY_MAX_DEPTH
    shortterm_max_dur: Optional[int] = DEFAULT_MEMORY_MAX_DURATION
    resolution_confidence: Optional[float] = DEFAULT_RESOLUTION_THRESHOLD

    @classmethod
    def get_slot_configs(cls, bot_dir_path: str) -> "SlotConfig":
        for root, dir, files in os.walk(bot_dir_path):
            for file in files:
                if file.endswith(".yaml") or file.endswith(".yml"):
                    file_path = os.path.join(root, file)
                    slot_config = cls.discover_slot_configs(file_path)
                    if slot_config:
                        return cls(
                            slot_rules=slot_config.get("slot_rules", []),
                            slot_lookup_rules=slot_config.get("slot_lookup", {}),
                            slot_regex_rules=slot_config.get("slot_regex", {}),
                        )

    @classmethod
    def discover_slot_configs(cls, file_path: str) -> dict:
        slot_rules = []
        slot_lookup_rules = {}
        slot_regex_rules = {}

        if not os.path.isfile(file_path):
            return []

        yml = None
        with open(file_path, "r") as sc:
            yml = yaml.safe_load(sc)

        if not yml.get("slots", {}):
            return {}

        shortterm_max_turns = yml.get("shortterm_memory_max_turns", DEFAULT_MEMORY_MAX_DEPTH)
        shortterm_max_dur = yml.get("shortterm_memory_timeout", DEFAULT_MEMORY_MAX_DURATION)
        resolution_conf = yml.get("confidence_resolution", DEFAULT_RESOLUTION_THRESHOLD)

        for slot in yml.get("slots", {}):
            slot_lookup_rules[slot.get("name")] = slot.get("lookup", [])
            slot_regex_rules[slot.get("name")] = slot.get("regex", "")
            shortterm = True if slot.get("memory", "shortterm") == "shortterm" else False
            max_turn = shortterm_max_turns
            # Treat no-memory slots as shortterm slots with max_turn=0
            if "memory" not in slot:
                max_turn = 0
            slot_rules.append(
                SlotRules(
                    name=slot.get("name", None),
                    description=slot.get("description", None),
                    entity=slot.get("entity", [slot.get("name", None)]),
                    memory=slot.get("memory", "shortterm"),
                    default=slot.get("default", None),
                    validity=slot.get("validity", {}),
                    synonyms=slot.get("synonyms", {}),
                    max_turn=max_turn if shortterm else None,
                    max_duration=shortterm_max_dur if shortterm else None,
                    child_slots=slot.get("child_slots", []),
                    resolution_confidence=slot.get("resolution_confidence", resolution_conf),
                    ambiguous_slots=slot.get("ambiguous_slots", None),
                    enable_resolution=slot.get("enable_resolution", False),
                )
            )
        return {"slot_rules": slot_rules, "slot_lookup": slot_lookup_rules, "slot_regex": slot_regex_rules}

    def get_slot_rules(self, slot: str) -> "SlotRules":
        """Get slot rules corresponding to a given slot"""
        for s in self.slot_rules:
            if slot == s.name:
                return s

    def get_slot_list(self) -> List[str]:
        """Get a list of Slot names"""
        return [s.name for s in self.slot_rules]

    def get_slot_from_entity(self, entity: str) -> str:
        """Find the slot name corresponding to an entity in a domain"""
        for s in self.slot_rules:
            if entity in s.entity:
                return s.name

    def get_composite_slots(self) -> List["SlotRules"]:
        """Public function to get list of composite slots in a domain"""
        composite_slots = []
        for s in self.slot_rules:
            if len(s.child_slots):
                composite_slots.append(s)
        return composite_slots

    def get_parent_slot(self, slot: str) -> str:
        """Public function to get the parent slot tag for a child slot in a domain"""
        for s in self.slot_rules:
            if slot in s.child_slots:
                return s.name
        return None
