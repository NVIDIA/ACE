# Copyright(c) 2023 NVIDIA Corporation. All rights reserved

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

""" Defines a bot structure and exposes API to initialize a bot """

import yaml
import logging
import gc
from typing import Optional, List
from pydantic.v1 import BaseModel, validator
from chat_engine.bot_factory.constants import DEFAULT_BOT_VERSION
from chat_engine.constants import RAG_PREFIX, DEFAULT_RAG_COLANG_CONFIG

from chat_engine.bot_factory.configs import (
    ConfigRule,
    ColangConfig,
    StorageConfig,
    NlpModelConfigs,
    SlotConfig,
)
from nemoguardrails import RailsConfig

logger = logging.getLogger("chat_engine")


class Bot(BaseModel):
    """Store and formulates bot specific configurations"""

    class Config:
        arbitrary_types_allowed = True

    # These attributes are populated when the bot is created ie. when configurations are parsed
    name: str
    version: str
    config_path: str
    streaming: bool
    configs: Optional[ConfigRule]
    colang_configs: Optional[RailsConfig]
    storage_configs: Optional[StorageConfig]
    nlp_model_configs: Optional[List[NlpModelConfigs]]
    slot_config: Optional[SlotConfig]

    # These attributes are populated when the bot is initialized by the core
    state_manager: Optional["DialogStateTracker"]
    policy_manager: Optional["PolicyManager"]
    slot_manager: Optional["SlotManager"]
    data: Optional["UserData"]
    health_monitor: Optional["HealthMonitor"]
    store_manager: Optional["Store"]

    # Indicates readiness of the bot to accept requests
    # This is set to true once all its core components has successfully initialized
    is_ready: bool = False

    @validator("name", pre=True)
    def check_bot_name(cls, value):
        if value == "" or value is None:
            raise ValueError(
                "A bot name must be provided in the config yaml file. Please provide a bot name using a top level key 'bot: your_bot_name'"
            )
        return value

    @classmethod
    def get_bot(cls, bot_dir_path, bot_config_file_path) -> "Bot":
        """Returns a Bot with all configurations parsed"""

        try:
            with open(bot_config_file_path, "r") as f:
                raw_configs = yaml.safe_load(f)
                bot_name = raw_configs.get("bot", None)

                colang_configs = ColangConfig.get_colang_files(bot_dir_path)
                if not colang_configs and bot_name.startswith(RAG_PREFIX):
                    colang_configs = RailsConfig.from_content(DEFAULT_RAG_COLANG_CONFIG)

                # Unless streaming is set to False, enable it
                if raw_configs.get("streaming") != False and colang_configs:
                    colang_configs.streaming = True

                return cls(
                    name=bot_name,
                    version=raw_configs.get("version", DEFAULT_BOT_VERSION),
                    config_path=bot_config_file_path,
                    streaming=raw_configs.get("streaming", True),
                    configs=ConfigRule.get_configs(raw_configs),
                    colang_configs=colang_configs,
                    storage_configs=StorageConfig.get_storage_configs(raw_configs),
                    nlp_model_configs=NlpModelConfigs.get_configs(raw_configs),
                    slot_config=SlotConfig.get_slot_configs(bot_dir_path),
                )
        except (Exception, ValueError) as e:
            raise e

    def __del__(self) -> None:
        try:
            """Remove existing object when Core module object is removed"""
            # Forceful deleting Singleton
            print(f"Deleting Bot: {self.name}..")
            self.store_manager.reset_active_user()
            gc.collect()
        except Exception as e:
            pass
