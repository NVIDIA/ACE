# Copyright(c) 2021-2023 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
chat engine core module which interacts with various modules inside
chat engine.
"""

import logging
from dataclasses import dataclass, field
from time import time
import re
from asyncio import Task

from typing import List, Dict, Any

from chat_engine.nlp.nlp_response import AnalyzeIntentResponse, Classification, NluResponse, TokenClassResponse
from chat_engine.nlp.response_data import ResponseData
from chat_engine.constants import (
    DOMAIN_NO_MATCH,
    INTENT_NO_MATCH,
    DEFAULT_DOMAIN_NAME,
    DEFAULT_INTENT_NAME,
    EVENT_NO_MATCH,
)
from nemoguardrails.streaming import StreamingHandler


logger = logging.getLogger("chat_engine")


@dataclass
class UserResponse:
    """
    Response text, action and possibly other information which is generated
    by the chat engine after processing the user query
    """

    text: str = None
    cleaned_text: str = None
    action: str = None
    json: str = None
    ready: bool = False
    omniverse_json: str = None
    need_user_response: bool = None
    is_partial_response: bool = None
    events: List[Dict[str, Any]] = None


@dataclass
class FormInfo:
    active: bool = False
    action_idx: int = 0
    missing_fields: List[str] = field(default_factory=lambda: [])
    active_idx: int = 0
    max_turn_exceeded: bool = False
    # nlu_qna_action: NluRules = (
    #     None  # Stores information of entities that needs to be filled by nlu: qna when form is active
    # )


class PartialResponseInfo:
    active: bool = False
    action_idx: int = 0
    chunks: List[str] = field(default_factory=lambda: [])
    chunk_idx: int = 0


@dataclass
class Latency:
    fulfillment: int = 0
    nlu_intent_slot: int = 0
    nlu_entailment: int = 0
    dialog_manager: int = 0
    nlu_qna: int = 0
    nlu_ner: int = 0
    nlu_machine_translation: int = 0
    nlu_semantic_similarity: int = 0
    nlu_ir: int = 0
    nlu_text_classifier: int = 0
    nlu_query_paraphrasing: int = 0
    nlu_response_paraphrasing: int = 0
    llm_models: int = 0
    plugin_policy: int = 0
    end_to_end: int = 0
    time_unit: str = "ms"


@dataclass
class DialogState:
    domains: List[str] = field(default_factory=lambda: [])
    intents: List[str] = field(default_factory=lambda: [])
    queries: List[str] = field(default_factory=lambda: [])
    postprocessed_queries: List[str] = field(default_factory=lambda: [])
    labeled_queries: List[str] = field(default_factory=lambda: [])
    responses: List[str] = field(default_factory=lambda: [])
    nlu_result: List["NluResponse"] = field(default_factory=lambda: [])
    session_slots: Dict[str, "SlotStateInfo"] = field(default_factory=lambda: {})
    global_slots: Dict[str, "SlotStateInfo"] = field(default_factory=lambda: {})
    fulfillment_slots: Dict[str, List[str]] = field(default_factory=lambda: {})
    pronoun_replacement_slots: Dict[str, str] = field(default_factory=lambda: {})
    last_conv_time: float = time()
    chat_history: Dict[str, List[Dict]] = field(default_factory=lambda: {})  # Stores bot specific chat history
    event_history: Dict[str, List[Dict]] = field(default_factory=lambda: {})  # Stores bot specific event history
    guardrails_state: Dict[str, Dict[str, Any]] = field(
        default_factory=lambda: {}
    )  # Stores bot specific guardrails state

    deleted_slot_tags: List[str] = field(default_factory=lambda: [])


@dataclass
class SlotStateInfo:
    name: str
    max_turn: int
    max_duration: int
    values: List["SlotStateValues"] = field(default_factory=lambda: [])
    last_conv_time: float = time()
    last_conv_turn_idx: int = 1


@dataclass
class SlotData:
    value: str = ""
    linked_value: str = ""


@dataclass
class SlotStateValues:
    value: List[SlotData] = field(default_factory=lambda: [])
    intent: str = DEFAULT_DOMAIN_NAME
    domain: str = DEFAULT_INTENT_NAME
    turn_num: int = 1  # indicates for how many turns the slot has been in memory since it appeard in user query


@dataclass
class UserData:
    """Data corresponding to each user session"""

    # Simple Attributes used in multi-turn queries
    user_id: str = None
    session_id: str = None
    query_id: str = None
    event_id: str = None
    dialog_id: str = None
    stream_id: str = None
    detailed_response = True
    active_bot_name: str = None
    active_bot_version: str = None

    language: str = "en-US"  # Default language of the bot
    dialog_state: Dict[str, "DialogState"] = field(default_factory=lambda: {})
    # Used to store fulfillment specific memory with key name as fulfillment module name
    fulfillment_memory: Dict[str, Any] = field(default_factory=lambda: {})
    dialog: "DialogRules" = None
    fallback_dialog: "DialogRules" = None

    # Simple Attributes reset after every query
    request_language: str = ""  # Language that is sent as part of request to DMs
    response_language: str = "en-US"  # Language that is send as part of response out of DM
    user_query: str = ""  # original query sent by user
    processed_query: Dict[str, str] = field(
        default_factory=lambda: {}
    )  # modified query after various processing (e.g. preprocessed (punctuation removed, lowercase), pronoun_replacement, etc.)
    labeled_query: str = ""  # query labeled with slot names
    is_question: bool = False  # Flag indicating whether query is a question or command
    request_time: float = 0.0
    last_response_time: float = 0.0
    dialog_match_found: bool = False
    entities: List[Dict[str, Any]] = field(default_factory=lambda: [])

    nlu_result: "NluResponse" = field(default_factory=lambda: NluResponse())
    response: "UserResponse" = field(default_factory=lambda: UserResponse())
    response_templates: List[Dict[str, str]] = field(default_factory=lambda: [])
    action: Any = None
    latency: "Latency" = field(default_factory=lambda: Latency())
    fulfillment_response: List[Any] = field(default_factory=lambda: [])
    core_response: "Response" = field(default_factory=lambda: ResponseData())
    policy: str = None
    # Used to indicate if dialog memory needs to be cleared at the
    # end of a conversation turn and what type of memory to be cleared
    reset_user_memory: str = ""

    # Reset if form is not active
    domain: str = DOMAIN_NO_MATCH
    model_name: str = DOMAIN_NO_MATCH
    intent: str = INTENT_NO_MATCH
    event: str = EVENT_NO_MATCH
    metadata: Dict[str, Any] = field(default_factory=lambda: {})
    slots: Dict[str, List[str]] = field(default_factory=lambda: {})
    current_events: List[Dict[str, Any]] = field(default_factory=lambda: [])

    # Used to store slot value to corrected slot value mapping as found by slot resolution module for the current turn
    resolved_slots: Dict[str, str] = field(default_factory=lambda: {})

    fulfillment_slots: Dict[str, List[str]] = field(default_factory=lambda: {})
    pronoun_replacement_slots: Dict[str, str] = field(default_factory=lambda: {})

    # Used to store the slot values which are linked by Semantic similarity NLU module for current conversation turn
    linked_slots: Dict[str, List[SlotData]] = field(default_factory=lambda: {})

    params: Dict[str, str] = field(default_factory=lambda: {})
    form: "FormInfo" = field(default_factory=lambda: FormInfo())
    partial_response: PartialResponseInfo = field(default_factory=lambda: PartialResponseInfo())

    streaming_handler: StreamingHandler = None  # The final streaming handler which will contain JSON chunks
    colang_streaming_handler: StreamingHandler = None  # Only used internally for interaction with NG and plugins
    stream_handler_task: Task = None  # The background task that converts regular chunks to JSON chunks

    def reset(self):
        """Method to reset relevant user data fields"""

        if not self.form.active:
            self.slots = {}
            self.fulfillment_slots = {}
            self.pronoun_replacement_slots = {}
            self.form = FormInfo()

        if not self.partial_response.active:
            self.partial_response = PartialResponseInfo()
            self.model_name = DOMAIN_NO_MATCH
            self.domain = DOMAIN_NO_MATCH
            self.intent = INTENT_NO_MATCH
            self.entities = []
            self.user_query = None
            self.processed_query = {}
            self.labeled_query = None
            self.request_language = ""
            self.response_language = "en-US"
            self.nlu_result = NluResponse()
            self.nlu_result.qna_result.results = []
            self.nlu_result.intent_slot_result = AnalyzeIntentResponse(
                domain=Classification(DOMAIN_NO_MATCH, 1.0),
                intent=Classification(INTENT_NO_MATCH, 1.0),
                slots=TokenClassResponse(),
            )
            self.resolved_slots = {}
            self.linked_slots = {}
            self.is_question = False
            self.fulfillment_response = []

        self.request_time = 0.0
        self.response = UserResponse()
        self.response_templates = []
        self.latency = Latency()
        self.core_response = ResponseData()
        self.policy = None
        self.reset_user_memory = ""
        self.detailed_response = True
        self.stream_id = None  # TODO:update based on usecase
        self.event = EVENT_NO_MATCH

    def reset_form_data(self):
        """Method to clear session info"""

        self.form.active = False
        self.domain = DOMAIN_NO_MATCH
        self.model_name = DOMAIN_NO_MATCH
        self.intent = INTENT_NO_MATCH
        self.event = EVENT_NO_MATCH
        self.slots = {}
        self.fulfillment_slots = {}
        self.pronoun_replacement_slots = {}
        self.form = FormInfo()

    def reset_active_form(self):
        self.form.active = False
        self.form = FormInfo()

    def get_slot_value(self, slot: str, fulfillment: bool = False) -> str:
        """
        This method is used to get the value corresponding to a slot key.
        This method first searches for the given slot-key in current active
        entity list and then in slot list and if not found then it searches
        for the slot in dialog state tracker.
        """

        if fulfillment:
            for s in self.fulfillment_slots:
                key = re.fullmatch(slot, s, re.I)
                if key:
                    return self.fulfillment_slots[key.group(0)]

            return None

        for s in self.slots:
            key = re.fullmatch(slot, s, re.I)
            if key:
                return self.slots[key.group(0)]

        return None
