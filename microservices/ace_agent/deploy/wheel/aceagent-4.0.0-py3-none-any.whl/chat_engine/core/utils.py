# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

"""
    Contains utility methods that can be used by any core component
"""

import logging
import aiohttp
from typing import Dict, Any
from requests.exceptions import HTTPError

logger = logging.getLogger("chat_engine")


async def async_http(url: str, timeout: int) -> Dict[str, Any]:
    """Utility method to call endpoints asynchronously using aiohttp for a provided url with a specified timeout"""

    response = {}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
            async with session.get(url) as resp:
                response = resp
                response = await resp.json()

        # Raise HTTPError when 4xx or 5xx received from server
        resp.raise_for_status()
    except HTTPError as e:  # The logger prints are commented here to avoid spamming of DM logs since this endpoint is called as part of polling threads
        # logger.debug(f"Exception {e} while trying get endpoints list for {url} endpoint using aiohttp")
        return {}
    except aiohttp.ClientResponseError as e:
        # logger.debug(f"Unable to connect to {url} to get endpoint list as error code was returned")
        return {}
    except Exception as e:
        # logger.debug(f"Unable to connect to {url} to get endpoint due to exception {e}")
        return {}

    return response
