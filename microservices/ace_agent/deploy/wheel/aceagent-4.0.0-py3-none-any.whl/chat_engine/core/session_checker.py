"""
 copyright(c) 2021 NVIDIA Corporation.All rights reserved.

 NVIDIA Corporation and its licensors retain all intellectual property
 and proprietary rights in and to this software, related documentation
 and any modifications thereto.Any use, reproduction, disclosure or
 distribution of this software and related documentation without an express
 license agreement from NVIDIA Corporation is strictly prohibited.
"""

import threading
import time
import logging

from chat_engine.constants import SESSION_CHECKER_WAIT_TIME

logger = logging.getLogger("chat_engine")


class SessionChecker(threading.Thread):
    """
    Thread to check session timeout for users and clear their data when timedout
    """

    def __init__(self, config, store, *args, **kwargs):
        super(SessionChecker, self).__init__(*args, **kwargs)
        self._session_timeout = config.configs.session_timeout
        self._store = store
        self._wait_time = SESSION_CHECKER_WAIT_TIME  # in seconds

    def __check_sessions(self):
        active_user_data = self._store.get_active_user_data()
        for user_id in active_user_data.copy():
            request_time = active_user_data[user_id]
            if (time.time() - request_time) >= self._session_timeout:
                try:
                    user_data = self._store.get_user_data(user_id)
                    if (time.time() - user_data.request_time) >= self._session_timeout:
                        self._store.delete_user_data(user_id)
                        del active_user_data[user_id]
                        logger.info(f"Session timed out, deleting user data for user id:{user_id}")
                    else:
                        active_user_data[user_id] = user_data.request_time
                except:
                    del active_user_data[user_id]

    def run(self):
        while True:
            self.__check_sessions()
            time.sleep(self._wait_time)
