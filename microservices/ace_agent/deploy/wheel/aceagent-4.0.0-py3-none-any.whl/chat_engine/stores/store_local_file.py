# Copyright(c) 2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

"""
chat engine core module which interacts with various modules inside
chat engine.
"""

import logging
import os, errno
import _pickle as pickle
from multiprocessing import shared_memory

from chat_engine.stores.store_base import StoreBase

from typing import Any, Dict

from chat_engine.core.userdata import UserData
from chat_engine.constants import LOCAL_STORE_PATH

logger = logging.getLogger("chat_engine")


class StoreFileSystem(StoreBase):
    def __init__(self, storage_config: Dict[str, Any]) -> None:

        self._local_store_path = storage_config.path
        if not os.path.exists(self._local_store_path):
            os.makedirs(self._local_store_path, mode=0o774, exist_ok=True)

        try:
            # Extract [clear_data, data_store_path]
            store_info = shared_memory.ShareableList(name="dm")
            # Update data store path. This is used by gunicorn to clean data store directory
            store_info[1] = self._local_store_path
            store_info.shm.close()
        except FileNotFoundError:
            logger.debug("Cli mode data path is not updated")

        self._user_data = {}
        self._active_user_data = {}

    def reset_active_user(self):
        """Remove active user data from memory"""
        for user in self._active_user_data:
            self.delete_user_data(user)

    def get_active_user_data(self) -> Dict[str, float]:
        """
        Get list of active user ids
        """
        return self._active_user_data

    def get_user_data(self, user_id: str) -> UserData:
        """
        Check if user data corresponding to user_id is available with store
        Raise exception if no user data corresponding to the user_id has
        been available in the store
        """

        path = os.path.join(self._local_store_path, f"{user_id}.pkl")
        if os.path.exists(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        raise ValueError(f"Invalid user id {user_id}")

    def save_user_data(self, data: UserData) -> None:
        """
        Check if user id corresponding to the user data is already available
        in the store. If yes then update the corresponding user_data with
        new userdata. Otherwise create a new user data entry and store it.
        """
        user_id = data.user_id
        session_id = data.session_id

        if user_id not in self._user_data:
            logger.info(
                f"Adding a new data corresponding to user-id {user_id} "
                f"to the store."
                f"Data of Total {len(self._user_data)+1} users are available "
                f"in store"
            )

        path = os.path.join(self._local_store_path, f"{user_id}.pkl")
        with open(path, "wb") as f:
            pickle.dump(data, f)
        self._active_user_data[user_id] = data.request_time

        # Update user_id in session pkl
        path = os.path.join(self._local_store_path, f"session_{session_id}.pkl")
        with open(path, "wb") as f:
            pickle.dump(user_id, f)

    def delete_user_data(self, user_id: str) -> None:
        """
        Delete user data corresponding to user_id in the store
        """
        path = os.path.join(self._local_store_path, f"{user_id}.pkl")
        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception as e:
                logger.error(f"Error while deleting {path}")

    def get_user_for_session(self, session_id: str) -> str:
        """
        Return list of users in given session_id
        Args:
            session_id: session_id whose user_id needs to be extracted
        """
        path = os.path.join(self._local_store_path, f"session_{session_id}.pkl")
        if os.path.exists(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        logger.info(f"No session exist with id {session_id}")
        return ""
