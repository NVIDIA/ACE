# Copyright(c) 2022 NVIDIA Corporation. All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.


import logging

from typing import Dict

from chat_engine.core.userdata import UserData
from chat_engine.stores.store_base import StoreBase


logger = logging.getLogger("chat_engine")


class StoreCache(StoreBase):
    def __init__(self, storage_config: "StorageConfig") -> None:

        self._user_data = {}
        self._active_user_data = {}
        self._user_in_session = {}

    def reset_active_user(self):
        """Remove active user data from memory"""
        for user in self._active_user_data:
            self.delete_user_data(user)

    def get_active_user_data(self) -> Dict[str, float]:
        """
        Get list of active user ids
        """
        return self._active_user_data

    def get_user_data(self, user_id: str) -> UserData:
        """
        Check if user data corresponding to user_id is available with store
        Raise exception if no user data corresponding to the user_id has
        been available in the store
        """

        if user_id in self._user_data:
            return self._user_data[user_id]

        raise ValueError(f"Invalid user id {user_id}")

    def save_user_data(self, data: UserData) -> None:
        """
        Check if user id corresponding to the user data is already available
        in the store. If yes then update the corresponding user_data with
        new userdata. Otherwise create a new user data entry and store it.
        """
        user_id = data.user_id
        session_id = data.session_id
        if user_id not in self._user_data:
            logger.info(
                f"Adding a new data corresponding to user-id {user_id} "
                f"to the store."
                f"Data of Total {len(self._user_data)+1} users are available "
                f"in store"
            )

        self._user_data[user_id] = data
        self._active_user_data[user_id] = data.request_time

        self._user_in_session[session_id] = user_id

    def delete_user_data(self, user_id: str) -> None:
        """
        Delete user data corresponding to user_id in the store
        """
        if user_id in self._user_data:
            del self._user_data[user_id]

    def get_user_for_session(self, session_id: str) -> str:
        """
        Return list of users in given session_id
        Args:
            session_id: session_id whose user_id needs to be extracted
        """
        return self._user_in_session.get(session_id, "")
