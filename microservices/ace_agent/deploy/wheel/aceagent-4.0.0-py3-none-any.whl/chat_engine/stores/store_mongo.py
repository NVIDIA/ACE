# copyright(c) 2022 NVIDIA Corporation.All rights reserved.

# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.

from pymongo import MongoClient

import logging
from typing import Dict

from chat_engine.stores.data_converter import DataConverter
from chat_engine.stores.constants import MONGO_DEFAULT_HOST
from chat_engine.stores.store_base import StoreBase

logger = logging.getLogger("chat_engine")


class MongoStore(StoreBase):
    """Storage class for mongo storage"""

    def __init__(self, storage_config: "StorageConfig") -> None:

        host = storage_config.url
        if storage_config.url.strip() == "":
            host = MONGO_DEFAULT_HOST
            logger.info(f"No url found using default url : {host}")

        self._mongo_client = MongoClient(
            host=host,
            username=storage_config.parameters.get("username", None),
            password=storage_config.parameters.get("password", None),
            authSource=storage_config.parameters.get("auth_source", "admin"),
            serverSelectionTimeoutMS=10,
        )
        try:
            self._mongo_client.server_info()
            self._db = self._mongo_client["dm"]
            self._user_data = self._db["user_data"]
            self._active_user_data = self._db["active_user_data"]
            self._user_in_session = self._db["session_data"]
        except:
            logger.error("Unable to connect mongo server. ")
            raise

    def reset_active_user(self):

        self._active_user_data.drop()

    def get_active_user_data(self) -> Dict[str, float]:
        """
        Get list of active user ids
        """
        res = list(self._active_user_data.find({}))
        return {data.get("user_id"): data.get("request_time") for data in res if data.get("user_id", None) is not None}

    def get_user_data(self, user_id: str) -> "UserData":
        """
        Check if user data corresponding to user_id is available with store
        Raise exception if no user data corresponding to the user_id has
        been available in the store
        """
        try:
            userdata = self._user_data.find_one({"user_id": user_id})
            if userdata is None:
                raise ValueError(f"Invalid user id {user_id}")

            return DataConverter.deserialise_data(userdata.get("userdata"))

        except Exception as e:
            raise ValueError(f"Invalid user id {user_id}")

    def save_user_data(self, data: "UserData") -> None:
        """
        Check if user id corresponding to the user data is already available
        in the store. If yes then update the corresponding user_data with
        new userdata. Otherwise create a new user data entry and store it.
        """

        self._user_data.update_one(
            {"user_id": data.user_id},
            {"$set": {"userdata": DataConverter.serialise_data(data)}},
            upsert=True,
        )

        self._active_user_data.update_one(
            {"user_id": data.user_id},
            {"$set": {"request_time": data.request_time}},
            upsert=True,
        )

        self._user_in_session.update_one(
            {"session_id": data.session_id},
            {"$set": {"user_id": data.user_id}},
            upsert=True,
        )

    def delete_user_data(self, user_id: str) -> None:
        """
        Delete user data corresponding to user_id in the store
        """

        self._user_data.delete_one({"user_id": user_id})

    def get_user_for_session(self, session_id: str) -> str:
        """
        Return list of users in given session_id
        Args:
            session_id: session_id whose user_id needs to be extracted
        """
        try:
            session_info = self._user_in_session.find_one({"session_id": session_id})
            if session_info is None:
                logger.info(f"No session exist with id {session_id}")

            return session_info.get("user_id")
        except Exception as e:
            logger.info(f"No session exist with id {session_id}")
        return ""
